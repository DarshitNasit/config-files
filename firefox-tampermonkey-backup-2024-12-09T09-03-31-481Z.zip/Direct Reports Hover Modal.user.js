// ==UserScript==
// @name         Direct Reports Hover Modal
// @namespace    https://phonetool.amazon.com/users/hishamzd
// @version      0.3
// @description  Hovering Manager's Name Will Display Their Direct Reports
// @author       hishamzd
// @match        https://phonetool.amazon.com/users/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=amazon.com
// @require    http://code.jquery.com/jquery-2.2.0.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('document').ready(function(e){
        // prepare the modal Dev
        $('body').append('<div id="detailed-dialog" style="background-color:white;padding:10px" title="Basic dialog"><span id="direct-moadl-content"></span> <div id="direct-modal-close" style="background-color: black; color: white; position: absolute; right: 10px; top:10px; height: 20px; width: 20px; text-align: center;cursor:pointer; font-weight: bold; border-radius: 50%; ">x</div> </div>');
        $('#detailed-dialog').css('border','1px solid cornflowerblue');
        $('#detailed-dialog').css("display","none");
        $('#detailed-dialog').css('position',"absolute");

        // Assigning event to hide the modal when the mouse is leaves the managers anchor
        $('#direct-modal-close').on("click", function(e) {
            $('#detailed-dialog').css("display","none");
        });
    });

    // initiate events on Managers names anchor
    $(document).on("mouseenter", ".user-information a", function(e) {
        // Adjust the Modal Location and resset content
        $('#detailed-dialog').css("display","none");
        $('direct-moadl-content').html('');
        $('#detailed-dialog').css('left',$(this).offset().left+150);
        $('#detailed-dialog').css('top',$(this).offset().top);

        // get Username
        var user = e.target.href.substring(e.target.href.lastIndexOf('/')+1);

        // get hovered User Details
        $.get( 'https://phonetool.amazon.com/users/'+user+'/setup_org_chart.json', function( data ) {

            //get selected user to check if manager
            const selectedUser = data.results.filter(selectedUser => selectedUser.id == user)[0];
            // if not manager do nothing
            if(!selectedUser.user.is_manager){
                return;
            }
            $('#detailed-dialog').css("display","block");

            // filter list to remove the manager managers and the manager themselves
            while(!data.results[0].highlight ) {
                data.results.splice(0, 1);
            }
            var details='<h3 style="color:#0088cc ;border-bottom:1px solid grey">Direct reports</h3><br>';
            for(var i=1 ; i<data.results.length;i++){
                details+="<div style='padding-bottom:5px'> <img height='44' width='34' src ='"+ data.results[i].user.badge_photo_url + "' style='margin-right:10px ;border:2px solid #a4a2a2; border-radius: 1%; height: 40px; width: 30px;'/> " + "<a style='color:#0088cc' href='/users/"+data.results[i].username+"'>"+data.results[i].user.full_name + "</a> " + data.results[i].user.job_title+"</div>";
            }

            $('#direct-moadl-content').html(details);
        });
    });

    $(document).mouseup(function(e)
{
    var container = $('#detailed-dialog');

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0)
    {
        container.hide();
    }
});
})();
// ==UserScript==
// @name         SDC Diff Tools
// @namespace    http://tampermonkey.net/
// @updateURL    https://code.amazon.com/packages/S3ReplicationToolbox/blobs/mainline/--/scripts/monkeyScripts/sdcDiffTools/sdcDiffTools.user.js?raw=1
// @downloadURL  https://code.amazon.com/packages/S3ReplicationToolbox/blobs/mainline/--/scripts/monkeyScripts/sdcDiffTools/sdcDiffTools.user.js?raw=1
// @version      0.2.4
// @description  Scrolls down to the next change in SDC, right click then chose scroll to next diff.
// @author       @ozgut, @sebcorb
// @match        https://*.amazon.com/dynamic_config_data_reviews/*
// @match        https://*.amazon.com/templates/review/*
// @grant        GM_registerMenuCommand
// ==/UserScript==

(function() {
    'use strict';

    // Function to scroll to the next/previous/first/last <li class="ins"> element
    function scrollToInsElement(direction) {
        // Find all <li class="ins"> elements on the page
        const insElements = document.querySelectorAll('li.ins, li.del');

        // Determine the target element based on the direction
        let targetElement = null;
        if (direction === 'next') {
            for (const insElement of insElements) {
                if (insElement.getBoundingClientRect().top > window.innerHeight) {
                    targetElement = insElement;
                    break;
                }
            }
        } else if (direction === 'prev') {
            for (const insElement of insElements) {
                if (insElement.getBoundingClientRect().top < window.innerHeight) {
                    targetElement = insElement;
                }
            }
        } else if (direction === 'first') {
            for (const insElement of insElements) {
                targetElement = insElement;
                break;
            }
        } else if (direction === 'last') {
            for (const insElement of insElements) {
                targetElement = insElement;
            }
        }

        // Scroll to the target element
        if (targetElement) {
            targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
            console.log(`No ${direction} diff found below the current position.`);
        }
    }

    GM_registerMenuCommand('Scroll to First', () => scrollToInsElement('first'));
    GM_registerMenuCommand('Scroll to Prev', () => scrollToInsElement('prev'));
    GM_registerMenuCommand('Scroll to Next', () => scrollToInsElement('next'));
    GM_registerMenuCommand('Scroll to Last', () => scrollToInsElement('last'));

    function createButton(text, actionLabel) {
        const btn = document.createElement("button");
        btn.textContent = text;
        btn.onclick = () => scrollToInsElement(actionLabel);
        btn.style.marginLeft = "10px";
        return btn
    }

    function appendButtons() {
        $("body > iframe").contents().find('#region-services-header').append(createButton('First change', 'first'));
        $("body > iframe").contents().find('#region-services-header').append(createButton('Previous', 'prev'));
        $("body > iframe").contents().find('#region-services-header').append(createButton('Next', 'next'));
        $("body > iframe").contents().find('#region-services-header').append(createButton('Last change', 'last'));
    }

    if ($("body > iframe").contents().find('#region-services-header').length > 0) {
        appendButtons();
    } else {
    console.log("waiting for iframe to load", $("body > iframe").contents().find('#region-services-header'));
        $("body > iframe").load(() => {
            console.log("iframe loaded");
            appendButtons();
        });
    }
})();
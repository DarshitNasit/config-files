// ==UserScript==
// @name         Pipeline Update Audio Notification
// @namespace    http://tampermonkey.net/
// @version      0.1.6
// @description  Play an audio notification when a pipeline is updated. You may need to give Permissions to Play audio on the pipelines.amazon.com page. Please send donco@ your voice saying the "Pipeline has updated" or your variant, to be included as part of the tool! Requests to add more audio for other state changes have been noted.
// @author       donco@amazon.com
// @updateURL    https://drive.corp.amazon.com/documents/donco@/pipeline_updated_notification/Pipeline_Update_Audio_Notification.user.js?download=true
// @downloadURL  https://drive.corp.amazon.com/documents/donco@/pipeline_updated_notification/Pipeline_Update_Audio_Notification.user.js?download=true
// @match        https://pipelines.amazon.com/pipelines/*
// @icon         https://www.google.com/s2/favicons?domain=amazon.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var audioNotes = new Map()

    audioNotes.set('donco', {src:'https://drive.corp.amazon.com/view/donco@/pipeline_updated_notification/pipeline_updated_notification.m4a?download=true', type:'audio/mp4'});
    audioNotes.set('milesnfo', {src:'https://drive.corp.amazon.com/view/donco@/pipeline_updated_notification/pipeline_status_milesnfo.m4a?download=true', type:'audio/mp4'});
    audioNotes.set('microwave', {src:'https://drive.corp.amazon.com/view/donco@/pipeline_updated_notification/microwave_bell.mp4?download=true', type:'audio/mp4'});

    var player = document.createElement('audio');
    // player.src = 'https://drive.corp.amazon.com/view/donco@/pipeline_updated_notification/pipeline_updated_notification.m4a?download=true';
    // player.type = 'audio/mp4';
    const randomNote = Math.floor(Math.random() * audioNotes.size);
    var audioKeys = Array.from(audioNotes.keys());
    player.src = audioNotes.get(audioKeys[randomNote]).src;
    player.type = audioNotes.get(audioKeys[randomNote]).type;
    player.preload = 'auto';

    var targetNode = document.body;
    var config = { attributes: true, childList: true};

    var callback = function(mutationsList) {
        for (var mutation of mutationsList) {
            if (mutation.type == 'childList') {
                var updateNode = document.getElementById('update-bubble');
                if ( updateNode != null && updateNode.innerHTML.indexOf('date!') != -1) {
                    player.play()
                }
            }
        }
    }
    var pipeline_observer = new MutationObserver(callback);
    pipeline_observer.observe(targetNode, config);
})();
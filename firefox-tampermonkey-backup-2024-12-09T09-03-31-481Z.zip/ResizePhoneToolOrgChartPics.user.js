// ==UserScript==
// @name        ResizePhoneToolOrgChartPics
// @namespace   Phone Tool
// @description Increase and decrease the size of the phonetool org chart
// @include     http*://phonetool.amazon.com/*
// @version     1
// @grant       none
// @author      jackhigg@
// ==/UserScript==

// https://en.wiktionary.org/wiki/embiggen

/**
 * Conserve aspect ratio of the orignal region. Useful when shrinking/enlarging
 * images to fit into a certain area.
 *
 * @param {Number} srcWidth Source area width
 * @param {Number} srcHeight Source area height
 * @param {Number} maxWidth Fittable area maximum available width
 * @param {Number} maxHeight Fittable area maximum available height
 * @return {Object} { width, heigth }
 *
 * Lovingly stolen from http://opensourcehacker.com/2011/12/01/calculate-aspect-ratio-conserving-resize-for-images-in-javascript/
 */
function calculateAspectRatioFit(srcWidth, srcHeight, maxWidth, maxHeight) {
  var ratio = Math.min(maxWidth / srcWidth, maxHeight / srcHeight);

  return { width: srcWidth*ratio, height: srcHeight*ratio };
}

$('widget-move-handle').ready(function() {
  html = `
  <div id="emsmallener" class="title pull-right">
    <a class="muted"><i class="fa fa-angle-double-down"></i></a>
  </div>
  <div id="embiggener" class="title pull-right">
    <a class="muted"><i class="fa fa-angle-double-up"></i></a>
  </div>
  <div class="title pull-right">
    <div>Badge Size</div>
  </div>
  `;

  $('#widget-1').children().first().append(html);

  $('#embiggener').click(function() {
    $('.blue-badge-small').each(function(pic) {
      image = calculateAspectRatioFit($(this).width(), $(this).height(), $(this).width() + 20, $(this).height() + 20);
      $(this).width(image.width);
      $(this).height(image.height);
    });
  });

  $('#emsmallener').click(function() {
    $('.blue-badge-small').each(function(pic) {
      image = calculateAspectRatioFit($(this).width(), $(this).height(), $(this).width() - 20, $(this).height() - 20);
      $(this).width(image.width);
      $(this).height(image.height);
    });
  });
});

// ==UserScript==
// @name         CRUX Reviewers
// @downloadURL  https://code.amazon.com/packages/DevScripts-alinra/blobs/mainline/--/tampermonkey/CruxReviewers.user.js?raw=1
// @updateURL    https://code.amazon.com/packages/DevScripts-alinra/blobs/mainline/--/tampermonkey/CruxReviewers.user.js?raw=1
// @namespace    https://code.amazon.com/
// @version      1.2
// @description  Extends CRUX dashboard with list of reviewers of last revision of each CR. Inspired from @derby's https://improvement-ninjas.amazon.com/GreaseMonkey/crux-re-dash.user.js
// @author       alinra
// @match        https://code.amazon.com/
// @grant        none
// @run-at       document-start
// ==/UserScript==

'use strict';
// ==/UserScript==

function addGlobalStyle(cssString) {
  const style = document.getElementById("CRUXReviewers_CSS") || (function() {
    const style = document.createElement('style');
    style.type = 'text/css';
    style.id = "CRUXReviewers_CSS";
    document.head.appendChild(style);
    return style;
  })();
  const sheet = style.sheet;
  sheet.insertRule(cssString, (sheet.rules || sheet.cssRules || []).length);
}

addGlobalStyle(''
    + '.cr-reviewer {'
    + '    margin-right: 5px;'
    + '}'
);

addGlobalStyle(''
    + '.cr-reviewer.bold {'
    + '    font-weight: bold;'
    + '}'
);

addGlobalStyle(''
    + '.cr-reviewer::before {'
    + '    margin-right: 1px;'
    + '}'
);

addGlobalStyle(''
    + '@media (max-width: 2100px) {'
    + '    .reviews td:nth-of-type(2) {'
    + '        max-width: 60vw;'
    + '        width: 60vw;'
    + '    }'
    + '}'
);

function htmlToElement(html) {
    var template = document.createElement('template');
    html = html.trim(); // Never return a text node of whitespace as the result
    template.innerHTML = html;
    return template.content.firstChild;
}

function updateStatusField(td, user, reviewType, data) {
    const addStatus = function (icon, reviewerId, altText) {
        const status = htmlToElement(`<span class="cr-reviewer">${reviewerId}</span>`);
        status.title = altText;

        icon.forEach(function(i) {
            status.classList.add(i);
        });

        if (reviewerId === user) {
             status.classList.add('green');
        }

        td.appendChild(status);
    }

    td.innerHTML = '';
    if (!data) {
        addStatus(['fa', 'fa-ellipsis-h'], 'Loading review...', true);
        return;
    }

    let approvers = data.revision.cr_revision.approved_by.map(x => x.split(':')[1]);
    let commenters = data.revision.cr_revision.comments
                          .map(x => x.cr_comment.author.entity_id)
                          .filter(x => x.type === 'USER')
                          .map(x => x.id);

    let reviewers = data.revision.cr_revision.reviewers
                        .map(x => x.interested_entity)
                        .filter(x => x.type === 'USER')
                        .map(x => Object.assign({}, {
                            id: x.id,
                            approved: approvers.indexOf(x.id) > -1,
                            commented: commenters.indexOf(x.id) > -1
                        }));

    reviewers.sort(reviewersOrder).forEach(reviewer => {
        if (reviewer.approved) {
            addStatus(['fa', 'fa-thumbs-up', 'bold'], reviewer.id, 'Approved');
        } else if (reviewer.commented) {
            addStatus(['fa', 'fa-comments'], reviewer.id, 'Commented');
        } else {
            addStatus(['fa', 'fa-eye'], reviewer.id, 'Watching');
        }
    });
}

function reviewersOrder(first, second) {
    if (first.approved && !second.approved) {
        return -1;
    }

    if (first.commented && !second.commented) {
        return -1;
    }

    return 1;
}

function updateReviewRow(row, user, reviewType) {
    const col = row.querySelectorAll('td');
    if (col.length < 3) {
        return;
    }

    const crLink = col[1].querySelector('a');
    const reviewId = crLink.getAttribute('href').substring('/r/'.length);

    const state = {
        id: reviewId,
    };

    // Immediate updates
    if (row.querySelectorAll('td').length < 4) {
        const statusColumn = document.createElement('td');
        statusColumn.classList.add('subtext');
        row.appendChild(statusColumn);
    }

    const statusCol = row.querySelectorAll('td')[3];
    updateStatusField(statusCol, user, reviewType, undefined);

    // Request the simple page to redirect to the latest revision
    const reviewRequest = new XMLHttpRequest();
    reviewRequest.open("GET", 'https://code.amazon.com/reviews/' + encodeURI(reviewId));
    reviewRequest.send();
    reviewRequest.onreadystatechange = function(e) {
        if (e.target.readyState === 4) {
            // Now use the latest revision to grab the actual JSON data about it
            const reviewRequestData = new XMLHttpRequest();
            reviewRequestData.open("GET", e.target.responseURL + '.json');
            reviewRequestData.send();
            reviewRequestData.onreadystatechange = function(e) {
                if (e.target.readyState === 4) {
                    // Update any columns that want it
                    const data = JSON.parse(e.target.response);
                    const col = row.querySelectorAll('td')[3];

                    updateStatusField(col, user, reviewType, data);
                }
            };
        }
    };

    return reviewId;
}

function waitForElement(selector) {
  return new Promise(resolve => {
      if (document.querySelector(selector)) {
          return resolve(document.querySelector(selector));
      }

      const observer = new MutationObserver(mutations => {
          if (document.querySelector(selector)) {
              resolve(document.querySelector(selector));
              observer.disconnect();
          }
      });

      observer.observe(document.body, {
          childList: true,
          subtree: true
      });
  });
}

function handleOpenAndAssignedToUserAPI(data, user) {
    if (data.html === undefined) {
        console.error('[CRUX Reviewers] Got a response with no html key!');
        return;
    }

    // Convert to a DOM to easily manipulate it
    const root = new DOMParser().parseFromString(data.html, 'text/html');
    root.body.querySelectorAll('table > tbody').forEach((tableBody) => {
        const rows = tableBody.querySelectorAll('tr');
        const reviews = new Set();
        let currentReviewType = undefined;

        rows.forEach(function(row) {
            if (/\n\[CR-\d+\] /.test(row.textContent)) {
                 updateReviewRow(row, user, currentReviewType);
            }
        });
    });

    waitForElement('.reviews').then((reviewTable) => {
      reviewTable.innerHTML = '';
      root.body.childNodes.forEach(function(e) {
        reviewTable.appendChild(e);
      });
    });
}

const currentUser = document.getElementById('user').placeholder;

// Hook into the API calls so we don't need to do more
(function overrideXMLHttpRequestOpen(open) {
    const handleXMLHttpResponseForOpenAndAssignedToUserAPI = function() {
        // Check if request is DONE and Status Code is OK
        if (this.readyState === 4 && this.status === 200) {
            // The response is JSON
            const responseJSON = JSON.parse(this.response);
            handleOpenAndAssignedToUserAPI(responseJSON, currentUser);
        }
    };

    XMLHttpRequest.prototype.open = function() {
        if (arguments[1].includes('/api/reviews/open_and_assigned_to_user_html')) {
            // Remove any previous listeners to ensure we only call this once.
            this.removeEventListener('readystatechange', handleXMLHttpResponseForOpenAndAssignedToUserAPI);
            this.addEventListener('readystatechange', handleXMLHttpResponseForOpenAndAssignedToUserAPI, false);
        }
        open.apply(this, arguments);
    };
})(XMLHttpRequest.prototype.open);

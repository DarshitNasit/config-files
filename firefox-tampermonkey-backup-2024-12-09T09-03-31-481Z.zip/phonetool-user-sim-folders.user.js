// ==UserScript==
// @name        phonetool-user-sim-folders
// @namespace   marker
// @author      marker
// @description Adds the SIM folders for this person
// @include         https://connect.amazon.com/users/*
// @include         https://phonetool.amazon.com/users/*
// @grant           GM_xmlhttpRequest
// @require	https://internal-cdn.amazon.com/btk.amazon.com/ajax/libs/jquery/1.5.2/jquery.min.js
// @version     1.0
// ==/UserScript==

function getUserId() {
    return $(location).attr('pathname').match(/users\/(\w+)/)[1];
}

function getSIMFolderHTML(groups) {
    var links = $.map(groups, function(group, i) { return "<a href='https://sim.amazon.com/issues/create?assignedFolder=" + group.id + "'>" + group.name + "</a>"; });
    return new Promise(function (resolve, reject) {
        resolve("<div class='card'>"
                + "<div class='card-header'><a class='btn btn-primary' id='open-sim-toggle' href='#open-sim-folders' data-toggle='collapse'>Folders</a></div>"
                + "<div id='open-sim-folders' class='card-body collapse'>" + links.join("<br/>") + "</div>"
                + "</div>");
    });
}

function getSIMFolderInfo(folders) {
   return new Promise(function (resolve, reject) {
       var nonBacklogFolders = $.grep(folders.documents, function(doc, i) {
           return doc.type != "Backlog";
       });
       resolve($.map(nonBacklogFolders, function(doc, i) {
           return {id: doc.id, name: doc.label[0].text};
       }));
   });
}

function getSIMFoldersForUser(userId) {
    return new Promise(function (resolve, reject) {
        GM_xmlhttpRequest({
            method: "GET",
            url: "https://maxis-service-prod-pdx.amazon.com/folders?q=status%3AActive&authQuery=operation%3ACAN_RESOLVE_ISSUE_IN%20AND%20actor%3A%22kerberos%3A" + userId + "%40ANT.AMAZON.COM%22",
            headers: {
                "Accept": "application/json"
            },
            onload: function (response) {
                resolve(JSON.parse(response.responseText));
            },
            onerror: function (response) {
                reject(response.statusText);
            }
        });
    });
}

(function () {
    $('.dl-horizontal').append("<dt>open sim</dt><dd id=\"open-sim\">Loading...</dd>");
    getSIMFoldersForUser(getUserId())
        .then(getSIMFolderInfo)
        .then(getSIMFolderHTML)
        .then(function(html) { $("#open-sim").html(html); });
})();

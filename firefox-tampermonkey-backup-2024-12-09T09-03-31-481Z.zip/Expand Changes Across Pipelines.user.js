// ==UserScript==
// @name         Expand Changes Across Pipelines
// @namespace    https://www.amazon.com
// @version      1.0
// @description  When viewing the Track Changes in Pipelines page for a package with multiple pipeline, gives an option to expand each pipeline on one page.
// @author       staricm
// @match        https://pipelines.amazon.com/changes/PKG/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // add a button to expand the pipelines
    let expandButton = $('<button class="primary">Expand Pipelines</button>');
    expandButton.click(expandPipelines);
    $("h3.pipeline-choices-title").append(expandButton);

    // handler for the button
    function expandPipelines() {
        // get links to pipelines
        let pipelineLinks = $("label").find("a");

        // add stylesheet to page so changes tables show correctly
        $("head").append('<link rel="stylesheet" media="screen" href="https://internal-cdn.amazon.com/pipelines.amazon.com/public/assets/changes-9c8d3827f0947934ebc5734cd328b37a.css">');

        // fetch a single pipeline's status, add it to the page and set a delay to fetch the next one
        function fetchPipeline(i) {
            if(i < pipelineLinks.length) {
                $.get($(pipelineLinks[i]).attr("href"), {}, (data) => $(pipelineLinks[i]).parent().append($(data).find("div.change_progress")));
                setTimeout(() => fetchPipeline(i+1), 1000);
            }
        }
        fetchPipeline(0);
    }
})();
// This script currently only works for Bar Raisers and Recruiters.
// ==UserScript==
// @name            Add interview counts to phone tool
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/showInterviewCount.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/showInterviewCount.user.js
// @namespace       http://amazon.com
// @description     Adds interview counts to phone tool
// @include         https://connect.amazon.com/people/*
// @include         https://connect.amazon.com/users/*
// @include         https://phonetool.amazon.com/people/*
// @include         https://phonetool.amazon.com/users/*
// @exclude         https://phonetool.amazon.com/users/*.json
// @exclude         https://phonetool.amazon.com/users/*/org
// @exclude         https://phonetool.amazon.com/users/*/communities
// @exclude         https://phonetool.amazon.com/bookmark*
// @require         https://m.media-amazon.com/images/G/01/envImprovement/js/gm4-polyfill/gm4-polyfill.js
// @connect         hire.amazon.com
// @grant           unsafeWindow
// @grant           GM.xmlhttpRequest
// @grant           GM.xmlHttpRequest
// @grant           GM_xmlhttpRequest
// @grant           GM.info
// @version         1.2
// ==/UserScript==


let xhrMakerFn = GM.xmlHttpRequest || GM.xmlhttpRequest || GM_xmlhttpRequest;
let url = new URL("https://hire.amazon.com/search");

let login;

try {
    let userReactData = JSON.parse(document.querySelector("div[data-react-class=UserDetails]").dataset.reactProps);
    login = userReactData.targetUser.targetUserLogin;

    if (!login) {
        throw new Error("Failed to find user login");
    }
} catch (e) {
    console.log(`Failed to find user login:  '${GM.info.script.name}' Greasemonkey script probably needs to be updated`, e);
    return;
}

// Methods
let handleResponse = function (resp, attempt) {

    let hasJsonContent = resp.responseHeaders.split("\n").find((h) => h.includes("content-type: application/json"));

    if (hasJsonContent === undefined) {
        console.log("Response content type does not match application/json.")
        if (attempt < 1) {
            console.log("Retrying the request to handle midway cookie refresh scenario.")
            callHireSearch(++attempt);
        }
        return;
    }
    let hireResponse = JSON.parse(resp.responseText);
    let currentUserdata = hireResponse.records.find((u) => u.login === login);
    let interviewCount = Object.values(currentUserdata.interviewCounts).reduce((sum, v) => sum + parseFloat(v || 0), 0);
    let container = document.querySelector(".UserDetailsTable");
    container.innerHTML += `
<div class="TableRow InterviewCountRow">
    <div class="TableProperty">Interview Count:</div>
    <div id="interviewCount" class="TableValue">${interviewCount}</div>
</div>
`;
}

let callHireSearch = function (attempt) {

    let requestBody = {
        "q": `${login}@`,
        "page": 1,
        "sort": "relevance_desc",
        "type": "user"
    };

    xhrMakerFn({
        url: url,
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        data: JSON.stringify(requestBody),
        onload: resp => handleResponse(resp, attempt)
    });

}

callHireSearch(0);



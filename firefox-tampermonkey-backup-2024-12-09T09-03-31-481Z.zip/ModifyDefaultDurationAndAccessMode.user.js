// ==UserScript==
// @name         ModifyDefaultDurationAndAccessMode
// @namespace    http://amazon.com
// @version      0.11
// @description  Change console default duration to 12 hours and also run in AdministratorAccess mode
// @author       ganbn
// @updateURL    https://axzile.corp.amazon.com/-/carthamus/download_script/modify-default-duration-and-access-mode.user.js
// @downloadURL  https://axzile.corp.amazon.com/-/carthamus/download_script/modify-default-duration-and-access-mode.user.js
// @match        https://conduit.security.a2z.com/accounts
// @match        https://conduit.security.a2z.com/accounts/*
// @require      http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js
// @grant        GM_addStyle
// ==/UserScript==

function changeDurationAndAccessMode (jsNode) {

    'use strict';

    if (jsNode[0].href.includes("consoleUrl"))
    {
        if (jsNode[0].href.includes("sessionDuration"))
        {
           jsNode[0].href = jsNode[0].href.replace("3600","43200");
        }
        else
        {
           jsNode[0].href = jsNode[0].href+"&sessionDuration=43200";
        }
      
        if (jsNode[0].href.includes("policy"))
        {
           jsNode[0].href = jsNode[0].href.replace("ReadOnlyAccess","AdministratorAccess");
        }
        else
        {
           jsNode[0].href = jsNode[0].href+"&policy=arn:aws:iam::aws:policy/AdministratorAccess";
        }
 
      
        if (jsNode[0].text.includes("Read Only Console"))
        {
          jsNode[0].text = "Admin Console 12Hr";
        }
    }
}

function compareFunciton (jsNode) {
  'use strict';
  if (jsNode[0].href.includes("43200") && jsNode[0].href.includes("AdministratorAccess")) {
    return true;
  }
  jsNode.data ('alreadyFound', false);
  return false;
}

waitForKeyElements ("a.awsui-button", changeDurationAndAccessMode, compareFunciton);

// Edited from https://gist.github.com/raw/2625891/waitForKeyElements.js
/*--- waitForKeyElements():  A utility function, for Greasemonkey scripts,
    that detects and handles AJAXed content.

    Usage example:

        waitForKeyElements (
            "div.comments"
            , commentCallbackFunction
        );

        //--- Page-specific function to do what we want when the node is found.
        function commentCallbackFunction (jNode) {
            jNode.text ("This comment changed by waitForKeyElements().");
        }

    IMPORTANT: This function requires your script to have loaded jQuery.
*/
function waitForKeyElements (
    selectorTxt,    /* Required: The jQuery selector string that
                        specifies the desired element(s).
                    */
    actionFunction, /* Required: The code to run when elements are
                        found. It is passed a jNode to the matched
                        element.
                    */
    comparatorFunction, /* Required: The code to run when elements are
                        found. It is passed a jNode to the matched
                        element.
                    */
    bWaitOnce,      /* Optional: If false, will continue to scan for
                        new elements even after the first match is
                        found.
                    */
    iframeSelector  /* Optional: If set, identifies the iframe to
                        search.
                    */
) {
    var targetNodes, btargetsFound;

    if (typeof iframeSelector == "undefined")
        targetNodes     = $(selectorTxt);
    else
        targetNodes     = $(iframeSelector).contents ()
                                           .find (selectorTxt);

    if (targetNodes  &&  targetNodes.length > 0) {
        btargetsFound   = true;
        /*--- Found target node(s).  Go through each and act if they
            are new.
        */
        targetNodes.each ( function () {
            var jThis        = $(this);
            compareFunciton(jThis);
            var alreadyFound = jThis.data ('alreadyFound')  ||  false;

            if (!alreadyFound) {
                //--- Call the payload function.
                var cancelFound     = actionFunction (jThis);
                if (cancelFound)
                    btargetsFound   = false;
                else
                    jThis.data ('alreadyFound', true);
            }
        } );
    }
    else {
        btargetsFound   = false;
    }

    //--- Get the timer-control variable for this selector.
    var controlObj      = waitForKeyElements.controlObj  ||  {};
    var controlKey      = selectorTxt.replace (/[^\w]/g, "_");
    var timeControl     = controlObj [controlKey];

    //--- Now set or clear the timer as appropriate.
    if (btargetsFound  &&  bWaitOnce  &&  timeControl) {
        //--- The only condition where we need to clear the timer.
        clearInterval (timeControl);
        delete controlObj [controlKey]
    }
    else {
        //--- Set a timer, if needed.
        if ( ! timeControl) {
            timeControl = setInterval ( function () {
                    waitForKeyElements (    selectorTxt,
                                            actionFunction,
                                            comparatorFunction,
                                            bWaitOnce,
                                            iframeSelector
                                        );
                },
                300
            );
            controlObj [controlKey] = timeControl;
        }
    }
    waitForKeyElements.controlObj   = controlObj;
}

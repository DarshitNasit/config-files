// ==UserScript==
// @name         Phonetool Recent Projects
// @namespace    https://phonetool.amazon.com/users/
// @version      1.1.1
// @description  Shows the most recent projects where person did commits.
// @author       aleksash@amazon.com
// @match        https://phonetool.amazon.com/users/*
// @match        https://connect.amazon.com/users/*
// @updateURL    https://code.amazon.com/packages/PhonetoolRecentProjects/blobs/mainline/--/PhonetoolRecentProjects.user.js?raw=1
// @grant        GM.xmlHttpRequest
// ==/UserScript==

var css = `
#recent-commits { min-width: 350px; }
#recent-commits-table { margin-bottom: 0px; }
#recent-commits-graph-checkbox { transform: translateX(-5px); vertical-align: baseline; }
.recent-commits-graph-label { text-transform: inherit; font-weight: 500; font-size: 1em; padding-right: 7px; float: right; }
#recent-commits-graph-table { background-color: white; padding: 5px; display: table; border: 1px solid #CCC; margin-top: 5px; }
#recent-commits-graph-table .month { margin-top: -4px !important; padding-bottom: 3px; }
#recent-commits-graph-table .heat-level-0, .heatmap .heat-level-0 { background-color: #EEEEEE }
#recent-commits-graph-table .heat-level-1, .heatmap .heat-level-1 { background-color: #A4D3EE }
#recent-commits-graph-table .heat-level-2, .heatmap .heat-level-2 { background-color: #67C8FF }
#recent-commits-graph-table .heat-level-3, .heatmap .heat-level-3 { background-color: #5995B7 }
#recent-commits-graph-table .heat-level-4, .heatmap .heat-level-4 { background-color: #003F87 }
#recent-commits-graph-table .heat-level-5, .heatmap .heat-level-5 { background-color: #003F87 }
#recent-commits-graph-table .heat-level-6, .heatmap .heat-level-6 { background-color: #003F87 }
#recent-commits-graph-table .week, .heatmap .week { float: left }
#recent-commits-graph-table .week .day, .heatmap .week .day { color: grey; font-size: 10px; margin: 0px; width: 12px; height: 12px; border: 1px solid white }
#recent-commits-graph-table .week .day:hover, .heatmap .week .day:hover { border: 1px solid black }
#recent-commits-graph-table .week .day.mon, #user_activity .week .day.wed, #user_activity .week .day.fri, .heatmap .week .day.mon, .heatmap .week .day.wed, .heatmap .week .day.fri { margin-right: 10px; margin-top: 12px }
#recent-commits-graph-table .week .day.mon, .heatmap .week .day.mon { margin-top: 31px }
#recent-commits-graph-table .week .day:first-child, .heatmap .week .day:first-child { border: none }
#recent-commits-graph-table .week .day:first-child:hover, .heatmap .week .day:first-child:hover { border: none }
`;

function loadRecentProjectsScript() {
    jQuery(function ($) {
        'use strict';

        function getVersion() {
            var version = GM.info.script.version;
            while (version.lastIndexOf('.') !== version.indexOf('.')) {
                var end = version.lastIndexOf('.');
                version = version.substring(0, end) + version.substring(end + 1);
            }
            return version;
        }

        function extractPackageName(index, item) {
            // package name is he first word in the "title" element
            var title = $(item).find("title").text();
            return title.split(" ")[0];
        }

        function extractPackagesCount($xml) {
            var packagesCount = {};
            $xml.find("item").map(extractPackageName).each(function () {
                if (this in packagesCount) {
                    packagesCount[this] = packagesCount[this] + 1;
                } else {
                    packagesCount[this] = 1;
                }
            });
            return packagesCount;
        }

        function createCommitsTable(packagesCount, commitsNumber, login) {
            var tableBody = Object.entries(packagesCount).sort((a, b) => b[1] - a[1]).map(([name, count]) => {
                var percentage = (Math.round((count / commitsNumber) * 1000) / 10).toFixed(1);
                return `<tr>
                        <td><a href="https://code.amazon.com/packages/${name}/logs?filters%5Bauthor%5D=${login}" target="_blank" data-trackable="contacts_tool">${name}</a></td>
                        <td class="percent text-right">${percentage}%</td>
                        <td class="commit_count"><div style="width: 80px">${count} commits</div></td>
                        </tr>`
            }).join('\n');

            return `<table id="recent-commits-table" class="toc table table-condensed table-striped">
                    <tr>
                    <th>Package</th>
                    <th>Percentage</th>
                    <th>Count</th>
                    </tr>` + tableBody + '</table>';
        }

        function readShowCommitGraphState() {
            const showCommitGraph = localStorage.phonetoolRecentProjectsCommitGraph;
            return showCommitGraph && JSON.parse(showCommitGraph);
        }

        function writeShowCommitGraphState(showCommitGraph) {
            localStorage.phonetoolRecentProjectsCommitGraph = showCommitGraph;
        }

        function findManager(login, callback) {
            var url = new URL("https://phonetool.amazon.com/users/" + encodeURIComponent(login) + "/setup_org_chart.json");
            $.ajax({
                url: url,
                method: "GET",
                dataType: 'json',
                success: function(response) {
                    var foundUser = false;
                    var lastManager = null;
                    for (var user of response.results) {
                        if (user.username === login) {
                            foundUser = true;
                        } else if (!foundUser && user.user.is_manager) {
                            lastManager = user.username;
                        }
                    }
                    if (lastManager) {
                        callback(lastManager);
                    }
                }});
        }

        // Support Object.entries for IE, Opera and older browsers
        if (!Object.entries) {
            Object.entries = function (obj) {
                var ownProps = Object.keys(obj), i = ownProps.length, resArray = new Array(i);
                while (i--) {
                    resArray[i] = [ownProps[i], obj[ownProps[i]]];
                }
                return resArray;
            };
        }

        var loadingIndicator = 'Loading...';
        var startTime = Date.now();
        var fixLogin = function (login) {
            login = $.trim(login);
            return login && login.endsWith('@') ? login.substring(0, login.length - 1) : login;
        };
        var showCommitGraph = readShowCommitGraphState();
        var user = fixLogin($('#edit_user_profile').attr('action').split('/').slice(-1).pop());
        var login = fixLogin($('.login').text());
        var firstName = $.trim($('.name strong').text());
        var fullName = $.trim($('.PersonalInfoName .name').text());
        var $links = $(".UserLinks .links-list").first();
        $links.append('<a href="https://code.amazon.com/reviews/from-user/' + login + '" target="_blank" data-trackable="contacts_tool">' + firstName + '\'s CRs</a><br/>');
        $links.append('<a href="https://code.amazon.com/users/' + login + '/activity" target="_blank" data-trackable="contacts_tool">' + firstName + '\'s code activity</a><br/>');
        findManager(login, function callback(managerLogin) {
            $links.append('<a href="https://us-east-1.quicksight.aws.amazon.com/sn/dashboards/797c3f91-5ca2-485d-b956-7067f38fd861?directory_alias=amazonbi#p.login=' + managerLogin + '?time=month" target="_blank" data-trackable="contacts_tool">' + firstName + '\'s team stats</a><br/>');
        });
        var style = $("<style>");
        style.html(css);
        $("head").append(style);

        var passion = $('.SharePassion');
        if (!!passion.text()) {
            passion.append('<hr/>');
        }
        passion.append('<span class="title">Recent commits: </span><label class="recent-commits-graph-label"><input id="recent-commits-graph-checkbox" type="checkbox">Display commit graph</label>');
        passion.append('<div id="recent-commits">' + loadingIndicator + '</div>');
        GM.xmlHttpRequest({
            method: "GET",
            url: 'https://code.amazon.com/users/' + encodeURIComponent(login) + '/activity.rss',
            onload: function (response) {
                var rowCount = 0;
                var error = '';
                if (response.status !== 200) {
                    $('#recent-commits').html("Error loading data from code.amazon.com");
                    error = JSON.stringify(response);
                    console.log('Error loading code.amazon.com data: ' + error);
                } else {
                    var xml = $.parseXML(response.responseText);
                    var $xml = $(xml);
                    var commitsNumber = $xml.find("item").length; // in the activity rss each commit is represented by a "item" element
                    if (commitsNumber === 0) {
                        $('#recent-commits').html("No commits in the last month");
                    } else {
                        var packagesCount = extractPackagesCount($xml);
                        var commitsTable = createCommitsTable(packagesCount, commitsNumber, login);
                        $('#recent-commits').html(commitsTable);
                    }
                }
                var latency = Date.now() - startTime;
                var metrics = {id: 'PhoneToolRecentProjects', version: getVersion(), user: user, url: window.location.href, login: login, name: fullName, latency: latency, count: rowCount, error: error, showCommitGraph: showCommitGraph};
                passion.append('<img src="https://site-metrics.aka.corp.amazon.com/prod?' + $.param(metrics) + '" style="display:none" alt=""/>');
            }
        });

        passion.append('<div id="recent-commits-graph"></div>');
        var recentCommitsGraph = $('#recent-commits-graph');
        var checkbox = $('#recent-commits-graph-checkbox');
        var lastCommitGraph;

        function commitGraphErrorCallback() {
            recentCommitsGraph.html('Error loading the commit graph.');
        }

        function loadCommitGraph() {
            if (lastCommitGraph) {
                recentCommitsGraph.html(lastCommitGraph);
                return;
            }
            var url = new URL('https://code.amazon.com/users/' + encodeURIComponent(login) + '/activity');
            var lastMonths = new Date();
            lastMonths.setMonth(lastMonths.getMonth() - 6);
            url.searchParams.set("start_time", lastMonths);
            url.searchParams.set("end_time", startTime);
            recentCommitsGraph.html(loadingIndicator);
            GM.xmlHttpRequest({
                method: "GET",
                url: url,
                onerror: commitGraphErrorCallback,
                onabort: commitGraphErrorCallback,
                onload: function(response) {
                    var activity = $(response.responseText).find(".activity_by_time");
                    if (activity && activity.length) {
                        var graph = '';
                        var skipEmptyWeeks = true; // skip first empty weeks
                        activity.find('.week').each(function() {
                            var week = $(this);
                            if (week.find('.day').length >= 7) {
                                var emptyWeek = week.find('.empty').length >= 5;
                                graph += emptyWeek && skipEmptyWeeks ? "" : this.outerHTML;
                                skipEmptyWeeks |= !emptyWeek;
                            }
                        });
                        lastCommitGraph = '<div id="recent-commits-graph-table">' + graph + "</div>";
                        recentCommitsGraph.html(lastCommitGraph);
                    } else {
                        recentCommitsGraph.html("");
                    }
                }
            });
        }
        checkbox.on('change', _ => {
            var checked = _.target.checked;
            writeShowCommitGraphState(checked);
            recentCommitsGraph.html('');
            if (checked) {
                loadCommitGraph();
            }
        });
        if (showCommitGraph) {
            checkbox.prop("checked", true);
            loadCommitGraph();
        }
    });
}

loadRecentProjectsScript();

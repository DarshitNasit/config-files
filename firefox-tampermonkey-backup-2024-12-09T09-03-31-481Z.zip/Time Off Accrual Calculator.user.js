// ==UserScript==
// @name         Time Off Accrual Calculator
// @namespace    http://tampermonkey.net/
// @version      12
// @description  Figure out when you can take that vacation.
// @author       gscott
// @match        https://atoz.amazon.work/time
// @match        https://atoz.amazon.work/time/*
// @match        https://timeoff.amazon.com
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        GM.xmlHttpRequest
// @downloadURL https://code.amazon.com/packages/UnofficialTimeOffForecastScript/blobs/mainline/--/src/TimeOffAccrualCalculator.user.js?download=1&foo=file.user.js
// @updateURL https://code.amazon.com/packages/UnofficialTimeOffForecastScript/blobs/mainline/--/src/TimeOffAccrualCalculator.user.js?download=1&foo=file.user.js
// ==/UserScript==

// auto-redirect from the old deprecated time-off site
if (document.URL.includes("timeoff.amazon.com")) {
  window.location.href = "https://atoz.amazon.work/time";
}

const startDateId = "start-date-input";
const stateInputId = "state-input";
const timeFormatInputId = "time-format-input";
const forecastId = "forecast";
const forecastTableId = "forecast-table";
const newForecastTableId = "forecast-table-new";
const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const forecastMonths = 24;
let cachedPhoneToolData;

const timeTypeConfigs = {
  vacation: {
    validForThisUser: false,
    availableHeaderLabel: "TimeOff_USA_VacationTime",
    tableLabel: "Vacation Time",
    updateFunction: getNewVacationTime,
  },
  californiaPto: {
    validForThisUser: false,
    availableHeaderLabel: "TimeOff_USA_CaliforniaPaidTimeOff",
    tableLabel: "California PTO",
    updateFunction: getNewCaliforniaPtoTime,
  },
  personal: {
    validForThisUser: false,
    availableHeaderLabel: "TimeOff_USA_PaidPersonalTime",
    tableLabel: "Personal Time",
    updateFunction: getNewPersonalTime,
  },
  sick: {
    validForThisUser: false,
    availableHeaderLabel: "TimeOff_USA_SickAndSafeTime",
    tableLabel: "Sick Time",
    updateFunction: getNewSickTime,
  },
  floatingHoliday: {
    validForThisUser: false,
    availableHeaderLabel: "TimeOff_USA_FloatingHoliday",
    tableLabel: "Floating Holiday Time",
    updateFunction: getNewFloatingHolidayTime,
  },
};

const timeTypes = Object.keys(timeTypeConfigs);

const supportedCountries = ["USA"];

const states = [
  "Alabama",
  "Alaska",
  "Arizona",
  "Arkansas",
  "California",
  "Colorado",
  "Connecticut",
  "Delaware",
  "District of Columbia",
  "Florida",
  "Georgia",
  "Hawaii",
  "Idaho",
  "Illinois",
  "Indiana",
  "Iowa",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Maine",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "Mississippi",
  "Missouri",
  "Montana",
  "Nebraska",
  "Nevada",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "New York",
  "North Carolina",
  "North Dakota",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Vermont",
  "Virginia",
  "Washington",
  "West Virginia",
  "Wisconsin",
  "Wyoming",
];

const timeFormat = ["hours", "days"];

// phone tool includes country and city, not state
// TODO don't rely on hardcoded values here
const cityToState = {
  Seattle: "Washington",
  "New York": "New York",
  Herndon: "Virginia",
  Dallas: "Texas",
  Denver: "Colorado",
  Charlotte: "North Carolina",
  Chicago: "Illinois",
  "Santa Monica": "California",
  "San Francisco": "California",
  "Culver City": "California",
  Nashville: "Tennessee",
  Detroit: "Michigan",
  Arlington: "Virginia",
  Austin: "Texas",
  Portland: "Oregon",
};

// *****************************************************************************

const statesWithSomePersonalTimeCarryover = [
  "Arizona",
  "California",
  "Colorado",
  "Connecticut",
  "District of Columbia",
  "Illinois",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "New Jersey",
  "New York",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "Texas",
  "Vermont",
  "Washington",
];

const fixedMaxSickTimeCarryOverByState = {
  California: 24,
  Connecticut: 40,
  Massachusetts: 40,
  "New Jersey": 40,
  "District of Columbia": 7,
};

const BALANCES_CARD_SELECTOR = "div[data-test-id=BalancesCard]";

const oldVersionClassname = "unofficial-forecast-old";
const newVersionClassname = "unofficial-forecast-new";

const DEFAULT_VERSION = "old";
const NEW_VERSION_FORECAST_LENGTH = 6;

function getNewVacationTime(request) {
  // QUESTION how do partial hours work?
  const hours =
    request.currentHours.vacation.value +
    (request.tenureMonths <= 12
      ? 80 / 12
      : request.tenureMonths <= 72
      ? 120 / 12
      : 160 / 12);
  const value = Math.min(160, hours);
  const explanation = `Employees with ${
    request.tenureMonths <= 12
      ? "0-1"
      : request.tenureMonths <= 72
      ? "2-5"
      : "6+"
  } years at Amazon get ${
    request.tenureMonths <= 12 ? 80 : request.tenureMonths <= 72 ? 120 : 160
  } hours of vacation time a year, spread evenly over twelve months and capped at 160 hours.${
    value === 160 ? " You've hit the cap, go on a vacation!" : ""
  }`;

  return { value, explanation, emphasize: value >= 160 };
}

// Calculated using information from
// https://inside.hr.amazon.dev/content/inside/us/en/employment/policies/taking-time-off/california-corp.html#h2_794035
function getNewCaliforniaPtoTime(request) {
  const hours =
    request.currentHours.californiaPto.value +
    (request.tenureMonths <= 12
      ? 120 / 12
      : request.tenureMonths <= 72
      ? 160 / 12
      : 200 / 12);
  const value = Math.min(240, hours);
  const explanation = `Employees with ${
    request.tenureMonths <= 12
      ? "0-1"
      : request.tenureMonths <= 72
      ? "2-5"
      : "6+"
  } years at Amazon get ${
    request.tenureMonths <= 12 ? 120 : request.tenureMonths <= 72 ? 160 : 200
  } hours of vacation time a year, spread evenly over twelve months and capped at 240 hours.${
    value === 240 ? " You've hit the cap, go on a vacation!" : ""
  }`;

  return { value, explanation, emphasize: value >= 240 };
}

function getNewSickTime(request) {
  if (request.calendarMonth === 0) {
    if (request.state === "Washington") {
      const value =
        Math.min(
          24,
          request.currentHours.sick.value +
            Math.max(0, request.currentHours.personal.value - 48)
        ) + 2;
      return {
        value,
        explanation:
          "In Washington, personal time in excess of 48 hours is carried over as sick time, up to 24 hours of carried over sick time.",
        emphasize: value > 24,
      };
    }
    if (request.state === "New York") {
      return {
        value: request.currentHours.sick.value + 2,
        explanation:
          "In New York, all sick time can be carried over into the new year.",
        emphasize: false,
      };
    }
    if (request.state === "Illinois") {
      return {
        value:
          Math.min(20, Math.floor(request.currentHours.sick.value / 2)) + 2,
        explanation:
          "In Illinois, half of your accrued sick time, up to 20 hours, can be carried over into the new year.",
        emphasize: false,
      };
    }
    if (fixedMaxSickTimeCarryOverByState[request.state]) {
      return {
        value: fixedMaxSickTimeCarryOverByState[request.state] + 2,
        explanation: `In ${request.state}, up to ${
          fixedMaxSickTimeCarryOverByState[request.state]
        } hours of sick time can be carried over into the new year.`,
        emphasize: false,
      };
    }
    return {
      value: 2,
      explanation:
        "The author of this script isn't sure how sick time carries over into the new year for your state, so I'll conservatively assume nothing is. If this is wrong for your state, please reach out!",
      emphasize: false,
    };
  }
  const value = request.currentHours.sick.value + 2;
  const emphasize =
    request.state === "Washington"
      ? Math.max(0, request.currentHours.personal.value - 48) + value > 72
      : fixedMaxSickTimeCarryOverByState[request.state]
      ? value > fixedMaxSickTimeCarryOverByState[request.state]
      : request.currentHours.sick && request.calendarMonth === 11;
  return {
    value,
    emphasize,
    explanation:
      "All Amazon employees accrue 2 sick hours per month. Please reach out to the author of this script if that is incorrect for your state.",
  };
}

function getNewPersonalTime(request) {
  const cap = !statesWithSomePersonalTimeCarryover.includes(request.state)
    ? 0
    : request.state === "Washington"
    ? 48
    : request.state === "California"
    ? 240
    : 48;
  if (request.calendarMonth === 0) {
    if (!statesWithSomePersonalTimeCarryover.includes(request.state)) {
      return {
        value: 10,
        explanation:
          "Full-time employees receive 10 hours personal time on Jan 1. Then 8 hours is accrued each paycheck until 48 hours cap is reached",
        emphasize: false,
      };
    } else {
      const sickTimeCarriedOverAsPersonal =
        request.state === "Washington"
          ? Math.max(0, request.currentHours.sick.value - 24)
          : 0;
      const value =
        Math.min(
          cap,
          request.currentHours.personal.value + sickTimeCarriedOverAsPersonal
        ) + 10;
      return {
        value,
        explanation: `In ${
          request.state
        }, up to 48 hours of personal time are carried over, and 10 new hours or personal time are added. ${
          request.state === "Washington"
            ? "If you had more than 48 hours, the rest is converted into sick time, up to a combined max of 72 hours between the two categories."
            : ""
        }`.trim(),
        emphasize: value > cap,
      };
    }
  }
  const delta =
    request.calendarMonth <= 4 ? 8 : request.calendarMonth === 5 ? 6 : 0;
  const explanation =
    request.calendarMonth <= 4
      ? "8 hours accrued each paycheck from January to April"
      : request.calendarMonth === 5
      ? "6 hours accrued on May paycheck, bringing total personal time this year to 48 hours"
      : request.calendarMonth === 11 && !statesWithSomePersonalTimeCarryover.includes(request.state)
      ? "You work in a state with a 'use-it-or-lose-it' policy for personal time, so make sure to use it!"
      : "No additional personal time accrued after May paycheck.";

  const value = request.currentHours.personal.value + delta;
  return {
    value,
    explanation,
    emphasize: cap === 0 ? value && request.calendarMonth === 11 : value > cap,
  };
}

// Calculated using information from
// https://inside.hr.amazon.dev/content/inside/us/en/employment/policies/taking-time-off/california-corp.html#h2_651865
function getNewFloatingHolidayTime(request) {
  if (request.calendarMonth === 0) {
    const value = Math.min(48, request.currentHours.floatingHoliday.value + 24);
    return {
      value,
      explanation:
        "On any January 1 on which you have more than 24 hours of floating holiday, you will only earn enough floating holiday to reach the maximum cap of 48 hours",
      emphasize: value >= 48,
    };
  } else {
    return {
      value: request.currentHours.floatingHoliday.value,
      explanation:
        "After your first year of employment, employees earn 24 hours of floating holiday on each January 1 up to a maximum cap of 48 hours",
      emphasize: request.currentHours.floatingHoliday.value >= 48,
    };
  }
}

// *****************************************************************************

function getValidTimeTypes() {
  return timeTypes.filter((_) => timeTypeConfigs[_].validForThisUser);
}

function createElement(type, className, content, attrs) {
  const node = document.createElement(type);
  if (className) {
    node.setAttribute("class", className);
  }
  if (content) {
    const children = Array.isArray(content) ? content : [content];
    children.forEach((_) => {
      var child =
        typeof _ === "string" || _ instanceof String
          ? document.createTextNode(_)
          : _;
      node.appendChild(child);
    });
  }
  if (attrs) {
    Object.entries(attrs).forEach((pair) => {
      node.setAttribute(pair[0], pair[1]);
    });
  }
  return node;
}

function createTable(id, rows) {
  const table = createElement("table", null, null, {
    border: "black 1px",
    style: "border-collapse: collapse; width: 100%; height: 100%;",
    id,
  });
  const padding = "8px";
  var hasHeader = false;
  rows.forEach((cells) => {
    var row = createElement("tr", null, null, {
      style: `padding: ${padding};`,
    });
    cells.forEach((_) => {
      const attributes = {
        style: `padding: ${padding};`,
        class: "forecast-tooltip",
      };
      const value = _.hasOwnProperty("value") ? _.value : _;
      const cellContents = [
        createElement(
          "span",
          _.emphasize ? "forecast-emphasize" : "",
          typeof value === "number" ? `${Math.round(value)}` : value
        ),
      ];
      if (_.explanation) {
        cellContents.push(
          createElement("span", null, _.explanation, {
            class: "forecast-tooltiptext",
          })
        );
      }
      if (!hasHeader) {
        attributes.class = "balance-header forecast-tooltip";
      }
      row.appendChild(
        createElement(hasHeader ? "td" : "th", null, cellContents, attributes)
      );
    });
    hasHeader = true;
    table.appendChild(row);
  });
  return table;
}

// interface Request {
//   calendarMonth: Number,
//   tenureMonths: Number,
//   currentHours: {
//     vacation: {},
//     ...
//   }
// }

function getAdjustedHours(request) {
  return timeTypes
    .filter((_) => timeTypeConfigs[_].validForThisUser)
    .reduce(
      (prev, _) => ({
        ...prev,
        [_]: timeTypeConfigs[_].updateFunction(request),
      }),
      {}
    );
}

function addMonths(date, months) {
  var now = date.getDate();
  date.setMonth(date.getMonth() + +months);
  if (date.getDate() != now) {
    date.setDate(0);
  }
  return date;
}

function monthDiff(d1, d2) {
  var months;
  months = (d2.getFullYear() - d1.getFullYear()) * 12;
  months -= d1.getMonth();
  months += d2.getMonth();
  return Math.max(months, 0);
}

function getMonth(monthDelta) {
  const date = new Date();
  date.setMonth(date.getMonth() + monthDelta, 1);
  return date;
}

function formatDate(date) {
  return `${monthNames[date.getMonth()]} ${date.getFullYear()}`;
}

function populateValidTimeTypeConfigs() {
  timeTypes.forEach((type) => {
    timeTypeConfigs[type].validForThisUser = getCurrentAvailableHours(
      timeTypeConfigs[type].availableHeaderLabel
    ).valid;
  });
  console.log(timeTypeConfigs);
}

function getCurrentAvailableHours(label) {
  const card = document.querySelector(BALANCES_CARD_SELECTOR);
  if (!card) {
    throw Error("Could not find balances card");
  }
  waitForElement(`[data-testid=BalancesCardEntry-${label}]`, card);
  const row = card.querySelector(`[data-testid=BalancesCardEntry-${label}]`);
  if (!row) {
    return { valid: false };
  }
  return {
    valid: true,
    value: parseInt(
      Array.from(row.querySelectorAll("div"))
        .filter(
          (_) =>
            _.innerText.toLowerCase().includes("available") &&
            _.innerText.toLowerCase().includes("hr") &&
            !_.innerText.toLowerCase().includes("planned")
        )[0]
        .innerText.split("\n")[1]
        .match("(-?[0-9]+) .*")[1]
    ),
  };
}

function getHeaders() {
  const columns = getValidTimeTypes().map((_) => timeTypeConfigs[_].tableLabel);
  return ["Date", ...columns, "Total"];
}

function pluralize(message, number) {
  return number === 1 ? message : `${message}s`;
}

function convertHoursToLongFormat(totalHours) {
  const hours = Math.floor(totalHours) % 8;
  const days = Math.floor(totalHours / 8) % 5;
  const weeks = Math.floor(Math.floor(totalHours / 8) / 5);
  const messageComponents = [];
  if (weeks) {
    messageComponents.push(pluralize(`${weeks} week`, weeks));
  }
  if (days) {
    messageComponents.push(pluralize(`${days} day`, days));
  }
  if (hours) {
    messageComponents.push(pluralize(`${hours} hour`, hours));
  }
  return messageComponents.join(", ");
}

function convertHoursToDays(totalHours) {
  const days = (totalHours.value / 8).toFixed(1);
  return {
    value: days,
    explanation: totalHours.explanation,
    emphasize: totalHours.emphasize,
  };
}

function populateTable(phoneToolData) {
  if (!cachedPhoneToolData) {
    console.log("No cached phone tool data, exiting.");
    return;
  }
  console.log("Populating table");
  const wrapper = document.querySelector(`#${forecastId}`);

  if (!supportedCountries.includes(cachedPhoneToolData.country)) {
    console.log(`Unsupported country: ${cachedPhoneToolData.country}`);
    wrapper.replaceChild(
      createElement(
        "div",
        null,
        [
          `Sorry, only these countries are currently supported: ${supportedCountries.join(
            ", "
          )}`,
        ],
        { id: forecastTableId }
      ),
      document.querySelector(`#${forecastTableId}`)
    );
    return;
  }

  populateValidTimeTypeConfigs();
  const startDate = document.querySelector(`#${startDateId}`).value;
  if (!startDate) {
    console.error("Unable to populate table with no hire date defined");
    return;
  }
  const state = document.querySelector(`#${stateInputId}`).value;
  if (!state || !states.includes(state)) {
    console.error("Unable to populate table with no state defined");
    return;
  }
  var tenureMonths = monthDiff(new Date(startDate), new Date());
  console.log(
    `Populating table based on start date: ${startDate} (tenure of ${tenureMonths} months) and state ${state}`
  );
  const rows = [];
  var hours = getValidTimeTypes().reduce((prev, timeType) => {
    return {
      ...prev,
      [timeType]: {
        value: getCurrentAvailableHours(
          timeTypeConfigs[timeType].availableHeaderLabel
        ).value,
      },
    };
  }, {});
  console.log("Starting Hours", JSON.stringify(hours, null, 2));

  const timeFormat = document.querySelector(`#${timeFormatInputId}`).value;
  console.log(`Populating table with time format: ${timeFormat}`);

  for (let monthDelta = 0; monthDelta < forecastMonths; monthDelta++) {
    const date = getMonth(monthDelta);

    const request = {
      calendarMonth: date.getMonth(),
      tenureMonths,
      currentHours: hours,
      state,
    };
    hours = getAdjustedHours(request);

    const values_hours = getValidTimeTypes().map((_) => hours[_]);
    const total = values_hours.map((_) => _.value).reduce((a, b) => a + b, 0);
    values_hours.push({
      value: total,
      explanation: convertHoursToLongFormat(total),
    });
    const values_days = values_hours.map((value) => convertHoursToDays(value));

    let values_to_use = values_hours;
    if (timeFormat === "days") {
      values_to_use = values_days;
    }

    rows.push([formatDate(date), ...values_to_use]);
    tenureMonths++;
  }
  wrapper.replaceChild(
    createTable(forecastTableId, [getHeaders(), ...rows]),
    document.querySelector(`#${forecastTableId}`)
  );
}

function getAlias() {
  return Array.from(document.querySelectorAll(".app-root"))
    .find((_) => !!_.getAttribute("data-employee-login"))
    .getAttribute("data-employee-login");
}

function getState(city) {
  const match = city.match("Virtual Location - ([a-zA-Z]+)");
  const defState = "Washington";
  if (match) {
    return {
      usedDefault: !match[1],
      value: match[1] || defState,
    };
  } else {
    return {
      usedDefault: !cityToState[city],
      value: cityToState[city] || defState,
    };
  }
}

// must return date as "yyyy-MM-dd" string
async function getPhoneToolData() {
  const alias = getAlias();
  const headers = {
    ContactAlias:
      "https://code.amazon.com/packages/UnofficialTimeOffForecastScript",
  };
  const response = await GM.xmlHttpRequest({
    method: "GET",
    url: `https://phonetool.amazon.com/users/${alias}.json`,
    headers,
    synchronous: true,
  });
  const data = JSON.parse(response.response);
  const state = getState(data.city);
  if (state.usedDefault) {
    console.log(`Missing state mapping for city: ${data.city}`);
  }
  console.log(`Determined user's state: ${state.value}`);
  return {
    country: data.country,
    city: data.city,
    state: state.value,
    startDate: data.hire_date_iso,
    timeFormat: "hours",
  };
}

// <div data-test-component="StencilReactCard" data-test-id="PublicHolidays" class="css-19kogn7">
//.     <div data-test-component="StencilReactCol" class="css-uq47w"><div data-test-component="StencilReactRow" class="css-1wfbxj"><div data-test-component="StencilReactRow" class="css-7yvmjo"><div data-test-component="StencilText" role="heading" aria-level="2" class="css-mrwx4v">Amazon holidays</div><button data-test-component="StencilReactButton" type="button" class="e4s17lp0 css-id3a61" style="margin-top: -11px; margin-bottom: -11px;"><svg color="neutral60" display="block" xmlns="http://www.w3.org/2000/svg" class="stencilSvgIcon css-ogmfju" width="16" height="16" aria-hidden="true" focusable="false" viewBox="0 0 16 16" data-test-component="StencilIconInformationFill" style="width: 16px; height: 16px;"><path fill-rule="evenodd" fill="currentColor" d="M8,0a8,8,0,1,0,8,8A8,8,0,0,0,8,0ZM9,13a1,1,0,0,1-2,0V7A1,1,0,0,1,9,7ZM8,4H8A1,1,0,0,1,7,3H7A1,1,0,0,1,8,2H8A1,1,0,0,1,9,3H9A1,1,0,0,1,8,4Z"></path></svg><div class="css-1aayaoq e1aayydo0">More info about Amazon holidays</div></button></div><button data-test-component="StencilTriggerButton" aria-expanded="false" type="button" class="exidgq40 e4s17lp0 css-y860" style="margin-top: -11px; margin-bottom: -11px;"><div data-test-component="StencilReactRow" class="css-fpj0yv">2023<div class="css-mtbjwo e1fhen290"><svg display="block" xmlns="http://www.w3.org/2000/svg" class="stencilSvgIcon css-14wvfj0" width="20" height="20" aria-hidden="true" focusable="false" viewBox="0 0 20 20" data-test-component="StencilIconChevronDown" style="width: 20px; height: 20px;"><path fill-rule="evenodd" fill="currentColor" d="M3.29324 7.70725L9.29324 13.7072C9.68424 14.0982 10.3162 14.0982 10.7072 13.7072L16.7072 7.70725C17.0982 7.31625 17.0982 6.68425 16.7072 6.29325C16.3162 5.90225 15.6842 5.90225 15.2932 6.29325L10.0002 11.5862L4.70724 6.29325C4.51224 6.09825 4.25624 6.00025 4.00024 6.00025C3.74424 6.00025 3.48824 6.09825 3.29324 6.29325C2.90224 6.68425 2.90224 7.31625 3.29324 7.70725"></path></svg></div></div></button></div><div style="margin: 0px -16px;"><hr data-test-component="StencilReactHr" aria-hidden="true" class="css-knso7"></div><div data-test-component="StencilReactRow" data-test-id="Mon, Jan 2, 2023" class="css-93w5zn"><div data-test-component="StencilText" data-test-id="holiday-name" class="css-1473lup">New Years Day</div><div data-test-component="StencilText" data-test-id="holiday-date" class="css-fb261c">Mon, Jan 2, 2023</div></div><div data-test-component="StencilReactRow" data-test-id="Mon, Jan 16, 2023" class="css-93w5zn"><div data-test-component="StencilText" data-test-id="holiday-name" class="css-1473lup">Martin Luther King Jr Day</div><div data-test-component="StencilText" data-test-id="holiday-date" class="css-fb261c">Mon, Jan 16, 2023</div></div><div data-test-component="StencilReactRow" data-test-id="Mon, May 29, 2023" class="css-93w5zn"><div data-test-component="StencilText" data-test-id="holiday-name" class="css-1473lup">Memorial Day</div><div data-test-component="StencilText" data-test-id="holiday-date" class="css-fb261c">Mon, May 29, 2023</div></div><div data-test-component="StencilReactRow" data-test-id="Tue, Jul 4, 2023" class="css-93w5zn"><div data-test-component="StencilText" data-test-id="holiday-name" class="css-1473lup">Independence Day</div><div data-test-component="StencilText" data-test-id="holiday-date" class="css-fb261c">Tue, Jul 4, 2023</div></div><div data-test-component="StencilReactRow" data-test-id="Mon, Sep 4, 2023" class="css-93w5zn"><div data-test-component="StencilText" data-test-id="holiday-name" class="css-1473lup">Labor Day</div><div data-test-component="StencilText" data-test-id="holiday-date" class="css-fb261c">Mon, Sep 4, 2023</div></div><div data-test-component="StencilReactRow" data-test-id="Thu, Nov 23, 2023" class="css-93w5zn"><div data-test-component="StencilText" data-test-id="holiday-name" class="css-1473lup">Thanksgiving</div><div data-test-component="StencilText" data-test-id="holiday-date" class="css-fb261c">Thu, Nov 23, 2023</div></div><div style="margin: 0px -16px;"><hr data-test-component="StencilReactHr" aria-hidden="true" class="css-knso7"></div><a data-test-component="StencilLink" data-test-id="see-all-holidays" class="e14r8j251 css-vsz6wx">See all</a></div></div>

// function createElement(type, className, content, attrs) {

function createButton(title, style, onClick) {
  const button = document.createElement("button");
  Object.entries(style).forEach((entry) => {
    button.style[entry[0]] = entry[1];
  });
  button.innerText = title;
  button.onclick = async () => {
    try {
      await onClick();
    } catch (error) {
      window.alert(error.message);
      throw error;
    }
  };
  return button;
}

async function createCard(title, className, content, subtitle, actionButton) {
  await waitForElement(BALANCES_CARD_SELECTOR);
  const titleNode = createElement(
    "span",
    document
      .querySelector(BALANCES_CARD_SELECTOR)
      .querySelector(`[data-test-component="StencilText"][role="heading"]`)
      .className,
    [document.createTextNode(title)]
  );

  const headerNodes = [titleNode];
  if (actionButton) {
    headerNodes.push(actionButton);
  }
  return createElement(
    "div",
    `${document.querySelector(BALANCES_CARD_SELECTOR).className} ${className}`,
    [
      createElement(
        "div",
        document.querySelector(`${BALANCES_CARD_SELECTOR} div`).className,
        [
          // header text
          createElement(
            "div",
            document.querySelector(`${BALANCES_CARD_SELECTOR} div`).className,
            [
              createElement("div", "", headerNodes, {
                "data-test-component": "StencilText",
                "aria-level": "2",
              }),
              document.createTextNode(subtitle || ""),
            ],
            { "data-test-component": "StencilReactRow" }
          ),
          createElement(
            "div",
            "",
            createElement("hr", "css-knso7", [], {
              "data-test-component": "StencilReactHr",
            }),
            { style: "margin: 0px -16px;" }
          ),
          content,
        ],
        { "data-test-component": "StencilReactCol" }
      ),
    ],
    { "data-test-component": "StencilReactCard" }
  );
}

function hide(selector) {
  if (document.querySelector(selector)) {
    document.querySelector(selector).style.display = "none";
  }
}

function show(selector) {
  if (document.querySelector(selector)) {
    document.querySelector(selector).style.display = "block";
  }
}

function switchVersion(version) {
  if (version === "new") {
    hide(`.${oldVersionClassname}`);
    show(`.${newVersionClassname}`);
  } else {
    show(`.${oldVersionClassname}`);
    hide(`.${newVersionClassname}`);
  }
}

async function getOldVersion() {
  await waitForAny(
    Object.values(timeTypeConfigs).map(
      (_) => `[data-testid=BalancesCardEntry-${_.availableHeaderLabel}]`
    )
  );
  populateValidTimeTypeConfigs();
  const startDateInput = createElement("input", null, null, {
    id: startDateId,
    type: "date",
    autocomplete: "off",
    placeholder: "mm/dd/YYYY",
  });
  startDateInput.style.width = "125px";
  startDateInput.onchange = populateTable;

  const stateInput = createElement(
    "select",
    null,
    [
      createElement("option", null, "-", { value: "-" }),
      ...states.map((_) => createElement("option", null, _, { value: _ })),
    ],
    {
      id: stateInputId,
    }
  );
  stateInput.style.width = "150px";
  stateInput.onchange = populateTable;

  const timeFormatInput = createElement(
    "select",
    null,
    [
      createElement("option", null, "-", { value: "-" }),
      ...timeFormat.map((_) => createElement("option", null, _, { value: _ })),
    ],
    {
      id: timeFormatInputId,
    }
  );
  timeFormatInput.style.width = "100px";
  timeFormatInput.onchange = populateTable;

  const tableHeaders = getHeaders();

  const body = createElement(
    "div",
    null,
    createElement(
      "div",
      `ui-tabs ui-corner-all ui-widget main-section ${oldVersionClassname}`,
      [
        createElement(
          "div",
          "outer",
          createElement("div", "inner", [
            createElement("div", "top-section", [
              createElement("div", "Flt", [
                createElement("div", "form-row", [
                  createElement("label", null, ["Your most recent hire date"]),
                  document.createTextNode(" "),
                  startDateInput,
                ]),
              ]),
              createElement("div", "Flt", [
                createElement("div", "form-row", [
                  createElement("label", null, ["Your state"]),
                  document.createTextNode(" "),
                  stateInput,
                ]),
              ]),
              createElement("div", "Flt", [
                createElement("div", "form-row", [
                  createElement("label", null, ["Time format"]),
                  document.createTextNode(" "),
                  timeFormatInput,
                ]),
              ]),
            ]),
            createElement(
              "div",
              null,
              [
                createTable(forecastTableId, [
                  tableHeaders,
                  tableHeaders.map((_) => "-"),
                ]),
              ],
              { id: forecastId, style: "padding: 10px; overflow:scroll;" }
            ),
          ])
        ),
        createElement(
          "a",
          null,
          "Click here to report an issue with this script",
          {
            href: "https://issues.amazon.com/issues/create?template=2a8cc7ba-a245-4e74-9843-be80a89d6aa5",
          }
        ),
      ],
      {}
    ),
    {}
  );
  return createCard(
    "Accrual Forecast",
    oldVersionClassname,
    body,
    "Unofficial estimates for full-time, salaried employees. Each row represents the hours you will have after you receive your paycheck for that month, factoring in time off you have already planned.",
    createButton("Try new, more accurate version", { float: "right" }, () =>
      switchVersion("new")
    )
  );
}

function waitForAny(selectors) {
  return new Promise((resolve) => {
    selectors.forEach((selector) => {
      waitForElement(selector).then(resolve);
    });
  });
}

function waitForElement(selector) {
  return new Promise((resolve) => {
    if (document.querySelector(selector)) {
      return resolve(document.querySelector(selector));
    }

    const observer = new MutationObserver((mutations) => {
      if (document.querySelector(selector)) {
        resolve(document.querySelector(selector));
        observer.disconnect();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  });
}

function getEmployeeId() {
  return document.querySelector(".app-root").getAttribute("data-employee-id");
}

async function getBalancesFromAPI(date) {
  const url = `https://atoz-api.amazon.work/v1/time-away/balances?employeeId=${getEmployeeId()}&asOfDateTime=${date}T00%3A00%3A00Z&asOfDateTimeTimezone=UTC`;
  const headers = {
    accept: "*/*",
    "accept-language": "en-US,en;q=0.9",
    "content-type": "application/json",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "x-atoz-client-id": "ATOZ_TAAPI_SERVICE",
    ContactAlias:
      "https://code.amazon.com/packages/UnofficialTimeOffForecastScript",
  };
  const response = await GM.xmlHttpRequest({
    method: "GET",
    url,
    headers,
  });

  return JSON.parse(response.response);
}

function arrayEquals(a, b) {
  return (
    Array.isArray(a) &&
    Array.isArray(b) &&
    a.length === b.length &&
    a.every((val, index) => val === b[index])
  );
}

/*
{
    "month": "2024-02-16",
    "balances": {
      "employeeId": string,
      "asOfDateTime": string,
      "asOfDateTimeTimezone": "UTC",
      "balances": [
        {
          "balanceName": "TimeOff_USA_VacationTime",
          "balanceUnit": "hours",
          "currentBalance": number,
          "availableBalance": number,
          "hoursPerDay": number
        },
        {
          "balanceName": "TimeOff_USA_SickAndSafeTime",
          "balanceUnit": "hours",
          "currentBalance": number,
          "availableBalance": number,
          "hoursPerDay": number
        },
        {
          "balanceName": "TimeOff_USA_PaidPersonalTime",
          "balanceUnit": "hours",
          "currentBalance": number,
          "availableBalance": number,
          "hoursPerDay": number
        }
      ],
      "nextToken": null
    }
  }
*/
async function getFutureBalances() {
  const start = new Date();
  const months = Array.from(Array(NEW_VERSION_FORECAST_LENGTH).keys()).map(
    (delta) => {
      const date = new Date(start);
      date.setMonth(date.getMonth() + delta + 1);
      date.setDate(15);
      return date.toISOString().slice(0, 10);
    }
  );
  const balances = await Promise.all(
    months.map((date) => getBalancesFromAPI(date))
  );
  const monthBalances = [{ month: months[0], balances: balances[0].balances }];
  for (let i = 1; i < months.length; i++) {
    if (
      arrayEquals(
        balances[i - 1].balances.map((_) => _.availableBalance),
        balances[i].balances.map((_) => _.availableBalance)
      )
    ) {
      return monthBalances;
    }
    monthBalances.push({ month: months[i], balances: balances[i].balances });
  }
  return monthBalances;
}

function prettifyBalanceName(name) {
  return name
    .split("_")
    .pop()
    .replace(/([A-Z])/g, " $1")
    .trim();
}

function sumBalances(balances) {
  return balances
    .map((_) => _.availableBalance)
    .reduce((num, total) => {
      return num + total;
    }, 0);
}

function getMonthName(dateString) {
  return new Date(dateString).toLocaleString("default", { month: "long" });
}

async function getNewVersion() {
  const balances = await getFutureBalances();
  console.log(`Balances from API: ${JSON.stringify(balances, null, 2)}`);
  const headers = [
    "Month",
    ...balances[0].balances.map((_) => prettifyBalanceName(_.balanceName)),
    "Total (hours)",
  ];
  const body = createElement(
    "div",
    null,
    createElement(
      "div",
      `ui-tabs ui-corner-all ui-widget main-section`,
      [
        createElement(
          "div",
          "outer",
          createElement("div", "inner", [
            createElement(
              "div",
              null,
              createTable("new-forecast-table", [
                headers,
                ...balances.map((row) => [
                  getMonthName(row.month),
                  ...row.balances.map((_) => _.availableBalance),
                  sumBalances(row.balances),
                ]),
              ])
            ),
          ])
        ),
        createElement(
          "a",
          null,
          "Click here to report an issue with this script",
          {
            href: "https://issues.amazon.com/issues/create?template=2a8cc7ba-a245-4e74-9843-be80a89d6aa5",
          }
        ),
      ],
      {}
    ),
    {}
  );
  return createCard(
    "Accrual Forecast (New)",
    newVersionClassname,
    body,
    "Unofficial estimates for full-time, salaried employees. Each row represents the hours you will AVAILABLE TO SPEND DURING THAT MONTH, including time off that has already been planned. The data in this new version comes directly from the API that this website uses under the hood (but doesn't expose), so it should be more accurate than the older, estimated numbers. Unfortunately, it only seems to provide calculations a few months in advance.",
    createButton("Return to older version", { float: "right" }, () =>
      switchVersion("old")
    )
  );
}

(function () {
  "use strict";
  document.head.insertAdjacentHTML(
    "beforeend",
    `
        <style>
            .forecast-tooltip .forecast-tooltiptext {
                visibility: hidden;
                width: 300px;
                background-color: white;
                color: black;
                text-align: center;
                padding: 5px 0;
                border: black solid 1px;
                border-radius: 6px;
                position: absolute;
                z-index: 1;
            }

            .forecast-tooltip:hover .forecast-tooltiptext {
                visibility: visible;
            }

            .forecast-emphasize {
              color: red;
              font-weight: bold;
            }
    </style>`
  );

  const bodySelector = "#timeoff-balance";
  waitForElement(bodySelector).then((_) => {
    waitForElement(BALANCES_CARD_SELECTOR).then((_) => {
      getOldVersion().then((oldCard) => {
        const content = document.querySelector(bodySelector);
        content.appendChild(oldCard);
        switchVersion(DEFAULT_VERSION);
        getNewVersion()
          .then((newCard) => {
            content.appendChild(newCard);
            switchVersion(DEFAULT_VERSION);
          })
          .catch(console.log);
        getPhoneToolData()
          .then((phoneToolData) => {
            console.log(
              `Received start date from phone tool: ${phoneToolData.startDate} (should be yyyy-MM-dd)`
            );
            document.querySelector(`#${startDateId}`).value =
              phoneToolData.startDate;
            document.querySelector(`#${stateInputId}`).value =
              phoneToolData.state;
            document.querySelector(`#${timeFormatInputId}`).value =
              phoneToolData.timeFormat;
            cachedPhoneToolData = phoneToolData;
            populateTable();
          })
          .catch(console.error);
      });
    });
  });
})();

// Include this file before openid.xhr.js to accomplish the following:
// -OpenID implementation of XMLHttpRequest will be available for selective use.
// -XMLHttpRequest.prototype will not be modified by openid.xhr.js
// -Form POST logic will not be modified by openid.xhr.js.
(function(window) {
    window.Amazon = window.Amazon || {};
    window.Amazon.IDP = window.Amazon.IDP || {};
    window.Amazon.IDP.config = window.Amazon.IDP.config || {};

    window.Amazon.IDP.config.defaultOff = true;
})(window);

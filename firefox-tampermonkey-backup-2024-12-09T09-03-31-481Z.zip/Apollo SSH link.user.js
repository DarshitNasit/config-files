// ==UserScript==
// @name         Apollo SSH link
// @namespace    http://amazon.com/
// @downloadURL  https://code.amazon.com/packages/AARG-SCRIPTS/blobs/heads/devel/--/apollo_ssh_linker.user.js?raw=1
// @updateURL    https://code.amazon.com/packages/AARG-SCRIPTS/blobs/heads/devel/--/apollo_ssh_linker.user.js?raw=1
// @version      2.1
// @description  Expand apollo hosts and include MP/SSH links, works with the new Apollo UI
// @author       caolive@amazon.com
// @match        https://apollo.amazon.com/environments/*
// @match        https://apollo.amazon.com/r/environments/*
// @match        https://odin.amazon.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=amazon.com
// @grant        none
// ==/UserScript==


var mutator_root = null;

function dom_mutator(s, n = 1, t = 3000, cback) {
    n = Math.max(n, 1);
    return new Promise((x) => {
        setTimeout(function() {
            var ir = false, r = (e) => { if(ir) return false; ir = true; x(e) };
            var d = mutator_root || document, q = (e) => d.querySelectorAll(e), m;
            if(!cback && q(s).length >= n) return r(q(s));
            if(cback) { if(cback() === true) return r(q(s)); }
            var vx = () => cback ? cback() : q(s).length >= n;
            m = new MutationObserver(_ => vx() ? r(q(s)) && m && m.disconnect() : null);
            m.observe(mutator_root || document.body, { childList: true, subtree: true });
            t && setTimeout(r, t);
        }, 500);
    });
}

$(function creq() {
    $.fn.granpa = function(n) { return n > 1 ? $(this).parent().granpa(n - 1) : $(this).parent() };
    var $e, s, $elem;
    var has = (str) => (window.location.href + '').indexOf(str) >= 0;
    var link = {
        monitor: (host) => `<a class="ixlink" title="Open in Monitor Portal" target="_blank" href="https://monitorportal.amazon.com/hosts/graphs?&name=${host}">[MP]</a>`,
        ssh: (host) => `<a class="ixlink" title="Open in Web SSH" style="text-decoration: none; color: #321299" href="https://ssh.corp.amazon.com/?tabs=${host}&ide=false" target="_blank">[SSH]</a>`
    }
    var environmentsHandler = function() {
        dom_mutator('#capacitySection').then(function() {
            var r = document.getElementById('capacitySection');
            if(r) mutator_root = r;
            var tw = 0;
            $(r).find('td:contains(" / ")').each(function() {
                var elems = $(this).html().split(' / ');
                if(elems && elems.length) tw+=parseInt(elems[0]);
            });
            $(r).find('awsui-button').each(function (c,b) {
                $(b).find('button:first').trigger('click');
            });
            dom_mutator('tr.awsui-table-row', tw, 3000, function() {
                return tw == $(r).find('[class^="status"]').length;
            }).then(function() {
                $(r).find('[class^="status"]').granpa(3).each(function(c,b) {
                    $e = $(b).children().first().find('span:contains("amazon")').last();
                    var sshlink = link.ssh($e.text());
                    var monitorlink = link.monitor($e.text());
                    $e.after(`<span> - ${sshlink} - ${monitorlink}</span>`);
                });
            });
            dom_mutator('.capacityNameLink').then(function() {
                $(r).find('.capacityNameLink:contains("amazon.com")').each(function(_, e) {
                    var sshlink = link.ssh($(e).html());
                    var monitorlink = link.monitor($(e).html());
                    $(e).after(`<span> - ${sshlink} - ${monitorlink}</span>`);
                });
            });
        });
    }
    if(has('/r/environments') && has('capacity')) {
        dom_mutator('.ExpanderRows').then(function() {
            s = Math.max($('.ExpanderRows').length - 1,1);
            $('.ExpanderRows').find('button:first').trigger('click');
            dom_mutator('.HostRows', s).then(function() {
                $('.HostRows').find('div').find('a:first').each(function() {
                    let host = $(this).html();
                    $(this).parent().next().prepend(`<span>${link.ssh(host)}</span><span>${link.monitor(host)}</span><span>|</span>`);
                });
            });
        });
        return;
    }
    if(has('/environments')) {
        environmentsHandler();
        var rh = document.querySelectorAll('.awsui-tabs-header')[0], xobs = new MutationObserver(environmentsHandler);
        xobs.observe(rh,{ childList: true, subtree: true, attributes: true });
        return;
    }
    if(has('odin.amazon')) {
        dom_mutator('.host-entities tr').then(function() {
            var $od = $('.association_norm').find('a');
            $od.length && $od.each(function() {
                $(this).after(`<span> - <a class="ixlink" title="Open in Apollo" style="text-decoration: none; color: #328811" href="https://apollo.amazon.com/hosts/${$(this).html()}" target="_blank">[APL]</a></span>`);
            });
        });
        return;
    }
});



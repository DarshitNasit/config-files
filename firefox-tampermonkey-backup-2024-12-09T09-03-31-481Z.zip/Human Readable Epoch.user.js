// ==UserScript==
// @name         Human Readable Epoch
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Converts epoch timestamps into human readable time on a tooltip
// @author       Arian Hatefi (ahhatefi@amazon.com)
// @match        https://*.amazon.com/*
// @match        https://*.a2z.com/*
// @grant        none
// @require.     http://code.jquery.com/jquery-latest.js
// ==/UserScript==

(function() {
    'use strict';

    $(document).ready(function() {
        $('body').click(() => {
            let selection = window.getSelection().toString();
            if (selection === undefined || selection === '' || !isNumeric(selection)) {
                return;
            }

            let timestamp = +selection;
            if (!Number.isInteger(timestamp)) {
                timestamp = Math.trunc(timestamp * 1000);
            }
            if (timestamp.toString().length < 13) {
                timestamp *= 1000;
            }

            let date = new Date(timestamp);

            let range = window.getSelection().getRangeAt(0);
            let rect = range.getBoundingClientRect();

            var div = document.createElement('div');
            div.style.border = '2px solid black';
            div.style.position = 'fixed';
            div.style.top = rect.top + 'px';
            div.style.left = rect.left + 'px';
            div.style.background = 'white';
            div.textContent += date.toLocaleString();

            var x = document.createElement('p');
            x.style.color = 'red';
            x.style.fontWeight = 'bold';
            x.style.cursor = 'pointer';
            x.style.display = 'inline';
            x.style.marginLeft = '5px';
            x.textContent += "X";
            $(x).click(function() {
              $(this).parent().remove();
            });
            div.appendChild(x);

            document.body.appendChild(div);
        });
    });


    function isNumeric(str) {
        if (typeof str != 'string') return false // we only process strings!
        return !isNaN(str) && // use type coercion to parse the _entirety_ of the string (`parseFloat` alone does not do this)...
            !isNaN(parseFloat(str)) // ...and ensure strings of whitespace fail
    }
})();
// ==UserScript==
// @name         CRUX - Power search
// @version      2.0
// @description  Adds dedicated search input fields for filepath and repository in crux navbar with autocomplete suggestions (for files inside repo too). Also adds checkbox to exclude test files in the results. Usage: https://tiny.amazon.com/1iieknlgd/drivcorpamazviewshswGreePowe
// @author       Shashank Swaminathan <shswan@amazon.com>
// @match        https://code.amazon.com/*
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js
// @run-at       document-start
// @grant        GM_addStyle
// @updateURL    https://axzile.corp.amazon.com/-/carthamus/download_script/crux-power-search.user.js
// @downloadURL  https://axzile.corp.amazon.com/-/carthamus/download_script/crux-power-search.user.js
// ==/UserScript==

(function() {
////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Styles used by script
    GM_addStyle(`
            #Hides nav-bar till the script renders the three search inputs
            .navbar-default {
                display: none !important;
            }
            .margins {
                margin-top: 13px;
                margin-bottom: 10px;
            }
            .search-input {
                margin-right: 13px;
            }
            .navbar-nav:first-of-type > :first-child {
                display: none !important;
            }
            .dropdown {
                position: relative;
                display: inline-block;
            }
            .dropdown-content {
                display: none;
                position: absolute;
                background-color: white;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
            }
            .dropdown-content a {
                padding: 12px 16px;
                display: block;
            }
            .dropdown-content a:hover {
                 background-color: #ddd;
            }
            .dropdown:hover .dropdown-content {
                 display: block;
            }
            .powersearch-autocomplete-suggestions {
                  text-align: left;
                  cursor: default;
                  border: 1px solid #ccc;
                  border-top: 0;
                  background: #fff;
                  box-shadow: -1px 1px 3px rgba(0,0,0,0.1);
                  position: absolute;
                  display: none;
                  z-index: 9999;
                  max-height: 254px;
                  overflow: hidden;
                  overflow-y: auto;
                  box-sizing: border-box;
            }
            .powersearch-autocomplete-suggestion {
                  position: relative;
                  padding: 0 .6em;
                  line-height: 23px;
                  white-space: nowrap;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  font-size: 1.02em;
                  color: #333;
            }
            .powersearch-autocomplete-suggestion.selected, .powersearch-autocomplete-suggestion:hover {
                  background-color:#f0f0f0;
            }
            .search-guide .popover {
                  min-width: 500px;
                  font-size: 12px;
            }
            .powersearch-exclude-tests-checkbox-label-margins {
                  margin-left: 10px;
            }`);
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const RUN_DELAY = 400;
     const MIN_INPUT_LENGTH = 40;
     const TYPING_COMPLETE_WAIT_DELAY = 400;
     const PACKAGE_AUTOCOMPLETE_URL = "/packages/autocomplete_package_id?";
     const PACKAGE_VS_AUTOCOMPLETE_URL = "/packages/autocomplete_package_id?vs=true&";
     const FILE_AUTOCOMPLETE_URL = "/packages/<PackageNamePlaceholder>/commits/mainline/autocomplete_file_name?";
     const PACKAGE_URL = "https://code.amazon.com/packages/<PackageNamePlaceholder>";
     const FILE_URL = "https://code.amazon.com/packages/<PackageNamePlaceholder>/blobs/mainline/--/<FilePathPlaceholder>";
     const VERSION_SET_URL = "https://code.amazon.com/version-sets/<VersionSetNamePlaceholder>";
     const TEST_FILE_PATTERN = "!*Test*,!tst/*";
////////////////////////////////////////////////////////////////////////////////////////////////////////////
    var $term;
    var $filepath;
    var $repository;
    var typingTimer;
    var $autoSuggestionsContainer;
    var $codeSearchTerm;
    var $settingsDropdown;
    var $searchGuideContainer;
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const initializePowerSearch = function () {
         var $searchInput = $(".navbar-nav:first li:nth-child(1)");
         if(!$searchInput || $searchInput.length === 0) {
             setTimeout(initializePowerSearch, RUN_DELAY);
             return;
         }
         var autocompleteContainer = "<div class='powersearch-autocomplete-suggestions'></div>";
         var termHtml = "<li><input type='text' placeholder='Code Search' data-autocomplete-package=true data-autocomplete-vs=true id='term' class='search-input margins input-medium search-query form-control search' autocomplete='off'/></li>";
         var repositoryHtml = "<li><input type='text' placeholder='Repository' data-autocomplete-package=true id='repository' class='search-input margins input-medium  search-query form-control search' autocomplete='off'/></li>";
         var filepathHtml = "<li><input type='text' placeholder='Filepath' data-autocomplete-file=true id='filepath' class='search-input margins input-medium search-query form-control search' autocomplete='off'/></li>";
         var excludeTestsCheckboxHtml = "<li><div class='margins'><input type='checkbox' id='powersearch-exclude-tests' name='powersearch-exclude-tests' value='true'><label class='powersearch-exclude-tests-checkbox-label-margins' for='powersearch-exclude-tests'> Exclude tests</label></div></li>";
         var searchGuide = "<li class='search-guide' id='search-guide'><a href='#' class='do-not-move-into-settings'><img src='https://internal-cdn.amazon.com/btk.amazon.com/img/icons-1.0/tooltip-bubble.png' target_popup='search-bar-hint'></a></li>";
         var advancedSearch = "<li><a href='/search'>Advanced Search</a></li>";
         var settings = "<li><a class='do-not-move-into-settings settings-dropdown-link'><div class='dropdown'><span>Settings</span><div id='settings-dropdown-content' class='dropdown-content'></div></div></a></li>";

         $(advancedSearch).insertAfter($searchInput);
         $(settings).insertAfter($searchInput);
         $(searchGuide).insertAfter($searchInput);
         $(excludeTestsCheckboxHtml).insertAfter($searchInput);
         $(filepathHtml).insertAfter($searchInput);
         $(repositoryHtml).insertAfter($searchInput);
         $(termHtml).insertAfter($searchInput);
         $("body").append(autocompleteContainer);

         initVariables();
         moveSearchGuide();
         populateInputsFromQuery();
         moveOptionsUnderSettings();
         $(".navbar-default").show();
         $("#filepath, #repository, #term").on('keydown', handleKeyPress);
         $("#filepath, #repository, #term").on('blur', hideAutoCompleteSuggestions);
         $(document).on("click",".powersearch-autocomplete-suggestion", handleAutocompleteSelection);
         $(document).on("mouseover",".powersearch-autocomplete-suggestion", handleAutocompleteMouseOver);
         $(document).on("click","#powersearch-exclude-tests", toggleTestExcludeSearchParttern);
     };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
    const initVariables = function() {
        $codeSearchTerm = $("#search_top");
        $term = $("#term");
        $filepath = $("#filepath");
        $excludeTests = $("#powersearch-exclude-tests");
        $repository = $("#repository");
        $autoSuggestionsContainer = $(".powersearch-autocomplete-suggestions");
        $settingsDropdown = $("#settings-dropdown-content");
        $searchGuideContainer = $("#search-guide");
    };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
    const setInputLength = function($input) {
        var inputLength = $input.val().length;
        if (inputLength < MIN_INPUT_LENGTH) {
            inputLength = MIN_INPUT_LENGTH;
        }
        $input.css("width", inputLength + "ch");
    };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
    const moveSearchGuide = function() {
       $searchGuideContainer.append($("#search-bar-hint").remove());
    };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const populateInputsFromQuery = function () {
         var queryString = $codeSearchTerm.val();
         var repositoryMatch = queryString.match(/rp:(.*$)\s*/i);
         if (repositoryMatch && repositoryMatch[1]) {
             $repository.val(repositoryMatch[1].trim());
             queryString = queryString.replace("rp:" + repositoryMatch[1], "");
         }
         var filepathMatch = queryString.match(/fp:(.*$)\s*/i);
         if (filepathMatch && filepathMatch[1]) {
             var filePathStr = filepathMatch[1].trim();
             $filepath.val(filePathStr);
             $excludeTests.prop("checked", filePathStr.indexOf(TEST_FILE_PATTERN) != -1);
             queryString = queryString.replace("fp:" + filepathMatch[1], "");
         }
         $term.val(queryString.trim());
         setInputLength($term);
         setInputLength($filepath);
         setInputLength($repository);
     };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const handleKeyPress = function(event) {
         var keyCode = event.keyCode;
         var $input = $(this);
         if (keyCode === 13) { //Enter key
             // Take user to package/vs/file if auto suggestion is seleced
             if ($autoSuggestionsContainer.is(":visible")) {
                 var $selectedItem = $autoSuggestionsContainer.find(".selected");
                 if($selectedItem && $selectedItem.length > 0) {
                     handleAutocompleteSelection();
                     return;
                 }
             }
             //else do conventional search
             prepareQueryUrlAndRedirect();
         } else if(keyCode === 40 || keyCode === 38) { //Down arrow and up arrow
             if ($autoSuggestionsContainer.is(":visible")) {
                 var $selectedItem = $autoSuggestionsContainer.find(".selected");
                 if(!$selectedItem || $selectedItem.length === 0) {
                     var $firstChild =  $(":first-child", $autoSuggestionsContainer);
                     $firstChild.addClass("selected");
                     $input.val($firstChild.data("val"));
                 } else if (keyCode === 40) {
                     $selectedItem.removeClass("selected");
                     var $nextSibling = $selectedItem.next();
                     $nextSibling.addClass("selected");
                     scrollToTarget($nextSibling[0], $autoSuggestionsContainer[0]);
                     $input.val($nextSibling.data("val"));
                 } else if (keyCode === 38) {
                     $selectedItem.removeClass("selected");
                     var $prevSibling = $selectedItem.prev();
                     $prevSibling.addClass("selected");
                     scrollToTarget($prevSibling[0], $autoSuggestionsContainer[0]);
                     $input.val($prevSibling.data("val"));
                 }
             }
         } else {
             var inputQuery = $input.val();
             if (inputQuery.length < 4) {
                 return;
             }
             //clear timeout and reschedule a timer to run on typing complete
             if (typingTimer) {
                 clearTimeout(typingTimer);
             }
             if (!isPrintableCharacter(keyCode)) {
                 return;
             }
             typingTimer = setTimeout(function() {
                 getAndDisplayAutoSuggestions($input);
             }, TYPING_COMPLETE_WAIT_DELAY);
         }
     };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const prepareQueryUrlAndRedirect = function(event) {
         var args = encodeURIComponent($term.val());
         if($filepath.val().length > 0) {
             args = args + "+" + encodeURIComponent("fp:" + $filepath.val());
         }
         if($repository.val().length > 0) {
             args = args + "+" + encodeURIComponent("rp:" + $repository.val());
         }
         window.location = "https://code.amazon.com/search?term=" + args;
     };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const getAndDisplayAutoSuggestions = function ($input) {
         var inputQuery = $input.val();
         var autocompletePackage = $input.data("autocomplete-package");
         var autocompleteVs = $input.data("autocomplete-vs");
         var autocompleteFile = $input.data("autocomplete-file");
         var repositoryName = $repository.val() || "";
         var url;
         var isFileAutoCompletion = false;

         if (autocompletePackage && autocompleteVs) {
             url = PACKAGE_VS_AUTOCOMPLETE_URL;
         } else if (autocompletePackage) {
             url = PACKAGE_AUTOCOMPLETE_URL;
         } else if (autocompleteFile && repositoryName.length > 0) {
             url = FILE_AUTOCOMPLETE_URL.replace("<PackageNamePlaceholder>", repositoryName);
             isFileAutoCompletion = true;
         } else {
             return;
         }

         url += "term=" + inputQuery;

         $.ajax({
             type: 'GET',
             url: url,
             async: true,
             cache: false,
             contentType: 'application/x-www-form-urlencoded; charset=UTF-8;',
             dataType: 'text',
             success: function (data, status, response) {
                 populateAutoCompleteSuggestions(JSON.parse(data), $input, isFileAutoCompletion, repositoryName);
             },
             error: function (xhr, status, error) {
                 console.log("Failed CRUX auto-complete ajax call: \nStatus: " + status + " \nError: " + error);
             }
         });
     };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const populateAutoCompleteSuggestions = function (suggestions, $input, isFileAutocompletion, repositoryName) {
         if (!suggestions || suggestions.length == 0) {
             return;
         }
         var longestResultSize = 0;
         $autoSuggestionsContainer.empty();
         $.each(suggestions, function (value, item) {
             if (typeof item === "string") {
                 $autoSuggestionsContainer.append("<div class='powersearch-autocomplete-suggestion' data-val='" + item + "' data-file="+ isFileAutocompletion + " data-repository='"+ repositoryName +"'>" + item + "</div>");
                 longestResultSize = returnGreatest(longestResultSize, item.length);
             } else if (typeof item === "object") {
                 $autoSuggestionsContainer.append("<div class='powersearch-autocomplete-suggestion' data-val='" + item.value + "' data-versionset=true>" + item.label + "</div>");
                 longestResultSize = returnGreatest(longestResultSize, item.label.length);
             }
         });

         // Display autocomplete suggestions
         var inputPosition = $input.offset();
         var topOffset = inputPosition.top + 27; //add height of inputs
         longestResultSize += 5;
         $autoSuggestionsContainer.css("left",inputPosition.left + "px");
         $autoSuggestionsContainer.css("top",topOffset + "px");
         $autoSuggestionsContainer.css("width", longestResultSize + "ch");
         $autoSuggestionsContainer.css("display", "block");
     };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const moveOptionsUnderSettings = function () {
         $(".navbar-nav:first li > a").each(function(index, value) {
             if (!$(this).hasClass("do-not-move-into-settings")) {
                 var $anchor = $(this).detach();
                 $settingsDropdown.append($anchor);
             }
         });
     };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
     const handleAutocompleteSelection = function (event) {
         var $selectedItem = event? $(this): $autoSuggestionsContainer.find(".selected");
         if ($selectedItem.data("file")) {
             redirectToFile($selectedItem.data("val"), $selectedItem.data("repository"));
         } else if ($selectedItem.data("versionset")) {
             redirectToVersionSet($selectedItem.data("val"));
         } else {
             redirectToPackage($selectedItem.data("val"));
         }
     };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const handleAutocompleteMouseOver = function() {
             var $lastHover = $(".autocomplete-hovering");
             if ($lastHover && $lastHover.length > 0) {
                 $lastHover.removeClass("autocomplete-hovering");
             }
             $(this).addClass("autocomplete-hovering");
      }
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const toggleTestExcludeSearchParttern = function() {
            var filePath = $filepath.val() || "";
            if ($excludeTests.is(":checked")) {
                filePath = filePath !== "" ? filePath + "," : filePath;
                filePath += TEST_FILE_PATTERN;
            } else {
                filePath = filePath.replace("," + TEST_FILE_PATTERN, "");
                filePath = filePath.replace(TEST_FILE_PATTERN, "");
            }
            $filepath.val(filePath);
            prepareQueryUrlAndRedirect();
      }
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const hideAutoCompleteSuggestions = function () {
          var $hoveringOnAutoSuggestion = $(".autocomplete-hovering");
          if ($hoveringOnAutoSuggestion && $hoveringOnAutoSuggestion.length > 0) {
              return;
          }
         $autoSuggestionsContainer.css("display", "none");
      }
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const returnGreatest = function (val1, val2) {
          return val1 > val2? val1: val2;
      }
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const redirectToPackage = function (package) {
          window.location = PACKAGE_URL.replace("<PackageNamePlaceholder>", package);
      }
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const redirectToFile = function (filePath, repositoryName) {
          var url = FILE_URL.replace("<PackageNamePlaceholder>", repositoryName);
          url = url.replace("<FilePathPlaceholder>", filePath);
          window.location = url;
      }
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const redirectToVersionSet = function (versionSetName) {
          window.location = VERSION_SET_URL.replace("<VersionSetNamePlaceholder>", versionSetName);
      }
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const isPrintableCharacter = function (charCode) {
          if (!charCode ||
              !(charCode === 8) && // backspace
              !(charCode > 47 && charCode < 58) && // numeric (0-9)
              !(charCode > 64 && charCode < 91) && // upper alpha (A-Z)
              !(charCode > 96 && charCode < 123)) { // lower alpha (a-z)
              return false;
          }
          return true;
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////
      const scrollToTarget = function(target, container) {
          // Moved up here for readability:
          var isElement = target && target.nodeType === 1,
              isNumber = Object.prototype.toString.call(target) === '[object Number]';

          if (isElement) {
              container.scrollTop = target.offsetTop;
          } else if (isNumber) {
              container.scrollTop = target;
          } else if (target === 'bottom') {
              container.scrollTop = container.scrollHeight - container.offsetHeight;
          } else if (target === 'top') {
              container.scrollTop = 0;
          }
      };
////////////////////////////////////////////////////////////////////////////////////////////////////////////
    initializePowerSearch();
})();
    
// ==UserScript==
// @name         Phonetool Oncall Badges
// @namespace    https://w?User:Kmmcclai
// @version      1.28
// @description  Show oncall badges in phonetool https://w.amazon.com/index.php/OncallPhoneTool
// @author       kmmcclai@ | kheraf@ | blakhurd@ | jayjons@
// @match        https://phonetool.amazon.com/users/*
// @match        https://connect.amazon.com/users/*
// @run-at       document-end
// @grant        GM.xmlHttpRequest
// @grant        unsafeWindow
// @connect      oncall-api.corp.amazon.com
// @connect      oncall.corp.amazon.com
// @connect      midway-auth.amazon.com
// @connect      midway.amazon.com
// @downloadURL  https://improvement-ninjas.amazon.com/GreaseMonkey/PhoneToolOncallBadges.user.js
// @updateURL    https://improvement-ninjas.amazon.com/GreaseMonkey/PhoneToolOncallBadges.user.js
// ==/UserScript==

(function() {
  'use strict';

  var DEBUG_ENABLED = true;

  if (unsafeWindow.PhoneTool && unsafeWindow.PhoneTool.targetUserLogin) {
    var currentUser = unsafeWindow.PhoneTool.targetUserLogin;

    debug("Finding team aliases for " + currentUser + "...");

    getOncallTeamsByUser(currentUser).then(function(teams) {
      debug("ONCALL-API: Found " + teams.length + " teams for " + currentUser);
      teams.forEach(function(team) {
        getTeamAliases(team).then(function(aliases) {
          debug("ONCALL-API: Found " + (aliases ? aliases.length : "0") + " team aliases for " + team + ": ", aliases);
          var promises = []
          aliases.forEach(function (alias) {
            if(alias.aliasType === 'PAGE') {
              debug("Processing pager alias for team " + alias.aliasName, alias);
              var promise = getOncallFromTeam(team, alias.aliasName);
              promises.push(promise);
            }
          });

          debug("Fetching oncalls for " + promises.length + " teams...");

          Promise.all(promises).then(function(teamOncalls) {
            teamOncalls.forEach(function(oncallData) {
              if (oncallData !== null) {
                debug('ONCALL-API: got oncallData for', oncallData[0].pagerdutyName, oncallData);
                domAddResolverToPhonetool(oncallData[0].pagerdutyName, oncallData);
              } else {
                debug('ONCALL-API: got NULL oncallData');
              }
            });
          });

        }); // End of getTeamAliases.then

      }); // End of teams.forEach

    }); // End of getOncallTeamsByUser
  }

  function debug() {
    if (DEBUG_ENABLED) {
      var args = Array.from(arguments);
      args.splice(0, 0, '[Phonetool Oncall Badges]');
      console.log.apply(console.log, args);
    }
  }

  function throwError(msg) {
    console.log('[Phonetool Oncall Badges] [ERROR]', msg);
    $.toast('<small><u>Error from Phonetool Oncall Badges:</u></small><br/>' + msg, {type:'error'});
    throw Error(msg);
  }

  function throwMidwayError(msg) {
    console.log("[MIDWAY ERROR]", msg);
    $.toast('<small><u>Error from Phonetool Oncall Badges:</u></small><br/>'
        + msg
        + '<br/><br/> You may need to <a href="https://midway-auth.amazon.com/" target="_blank">Authenticate via Midway</a>',
        {type:'error'});
    throw Error(msg);
  }

  function getJson(url) {
    return new Promise(function(resolve, reject) {
      GM.xmlHttpRequest({
        method: 'GET',
        url: url,
        headers: { 'Accept': 'application/json' },
        onload: function (response) {
          var result = JSON.parse(response.responseText);
          resolve(result);
        },
        onerror: function (response) {
          console.log("Error ", response);
          reject(response.statusText);
        }
      });
    });
  }

  function getTeamAliases(team) {
    var url = 'https://oncall-api.corp.amazon.com/teams/' + team + '/aliases';
    debug('Fetching ' + url);
    return getJson(url);
  }

  function unescapeHtml(text) {
    return new DOMParser().parseFromString(text, 'text/html').documentElement.textContent;
  }

  /* Returns list of oncall teams the user is apart of. */
  function getOncallTeamsByUser(user) {
    return new Promise(function(resolve) {
      // Get search results for the user
      var url = 'https://oncall-api.corp.amazon.com/teams?q=owners:%27' + user + '%27%20OR%20members:%27' + user + '%27';
      getJson(url).then(function(results) {
        debug('ONCALL-API: Got ' + results.length + ' search results for ' + user + ' via ' + url, results);
        if (results.error !== undefined) {
          throwMidwayError(results.error);
          return;
        }

        // Fetch team info to check if user is in the team.
        var teamIncludesUserPromises = results.map(function(result) {
          var realTeamName = unescapeHtml(result.teamName); // Convert "team&#45;name" to "team-name"
          debug("Team name fetched: " + realTeamName);
          return getOncallTeamForUserOrNull(user, realTeamName);
        });

        // Iterate team info results
        Promise.all(teamIncludesUserPromises).then(function(teamsOrNulls) {
          var userTeams = [];
          teamsOrNulls.forEach(function(teamOrNull) {
            if (teamOrNull !== null) {
              userTeams.push(teamOrNull);
            }
          });
          debug('ONCALL-API: Got ' + userTeams.length + ' teams in which ' + user + ' is a member/owner of', userTeams);
          resolve(userTeams);
        });

      }).catch(throwMidwayError); // End of getJson

    }); // End of Promise()

  }

  /** Returns null if teamName does not include user, otherwise returns the (string) teamName. */
  function getOncallTeamForUserOrNull(user, teamName) {
    return new Promise(function(resolve) {
      var url = 'https://oncall-api.corp.amazon.com/teams/' + teamName;
      getJson(url).then(function(teamInfo) {
        var isMemberOrOwner = (teamInfo.members.includes(user) || teamInfo.owners.includes(user));
        debug("ONCALL-API: User " + user + (isMemberOrOwner ? " is " : "is NOT ") + "a member of Team " + teamName + ", according to " + url, teamInfo);
        resolve(isMemberOrOwner ? teamName : null);
      }).catch(throwMidwayError);
    });
  }

  /** Convert Date object to string in LOCAL YYYY-MM-DD format. */
  function dateToYYYYMMDD(d) {
    var year = d.getFullYear().toString();
    var month = (d.getMonth() + 1).toString();
    if (month.length === 1) month = "0" + month;
    var day = (d.getDate()).toString();
    if (day.length === 1) day = "0" + day;
    return [year, month, day].join("-");
  }

  /** Returns oncallData for a team. ({currentOncall, pagerdutyUrl, pagerdutyName}) */
  function getOncallFromTeam(teamName, teamAlias) {
    return new Promise(function(resolve, reject) {
      var today = dateToYYYYMMDD(new Date());
      var tomorrowDate = new Date();
      tomorrowDate.setDate(new Date().getDate() + 1);
      var tomorrow = dateToYYYYMMDD(tomorrowDate);

      var teamUrl = 'https://oncall-api.corp.amazon.com/teams/' + teamName + '/aliases_schedules/' + teamAlias + '?from=' + today + '&to=' + tomorrow;
      debug("ONCALL-API: Fetching oncall schedule for team " + teamName + " via " + teamUrl);
      getJson(teamUrl).then(function(results) {
        debug('ONCALL-API: Got schedule for team ' + teamName + ' via ' + teamUrl, results);
        if (results.error !== undefined) {
          console.log("There was error in midway", results);
          console.log('Error for team URL: ' + teamUrl);
          console.log(results.error);
          throwMidwayError(results.error);
          reject(results.error);
          return;
        }
        // Ignore previous/future oncalls, only consider current oncalls.
        var dateNow = new Date();
        results = results.filter(function(result) {
          var isCurrent = (new Date(result.startDateTime) <= dateNow)
                       && (new Date(result.endDateTime)   >= dateNow);
          if (!isCurrent) {
            debug('ONCALL-API: ignoring entry for team ', teamName,
                  'because start', result.startDateTime, 'is greater than now', dateNow.toISOString(),
                  ', or end', result.endDateTime, 'is less than now', dateNow.toISOString(), result);
          }
          return isCurrent;
        });

        if (results.length === 0) {
          resolve(null);
          return;
        }

        if (results.length > 1) {
          debug('ONCALL-API: Found multiple current oncall schedules, assuming first is relevant', results);
        }

        var result = results[0]; // Presume first entry is relevant entry.
        debug("Got first entry of results of schedule", result);
        if (result.oncallMember && result.oncallMember.length > 0) {
          var oncallData = result.oncallMember.map(function(oncallMember) {
            debug('ONCALL-API: Found oncallMember', oncallMember);
            return {
              'currentOncall': new Promise(function(resolve) {
                resolve(oncallMember);
              }),
              'pagerdutyUrl': 'https://oncall.corp.amazon.com/#/view/' + teamName + '/schedule',
              'pagerdutyName': teamAlias,
              'teamAlias' : teamAlias
            };
          });
          debug('ONCALL-API: getOncallFromTeam() resolved oncallData', oncallData);
          resolve(oncallData);
        } else {
          resolve(null);
        }
      }).catch(throwMidwayError);
    });
  }

  //////////////
  // DOM methods
  function domCreate(tag, classes, attrs) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.assign(node, attrs);
    }
    if (typeof(classes) === 'string') {
      classes = classes.replace(/^\s*|\s*$/g, '').split(/\s+/g);
    }
    if (classes instanceof Array) {
      classes.forEach(function(clazz) {
        if (clazz !== '') {
          node.classList.add(clazz);
        }
      });
    }
    return node;
  }

  var baseOncallStyle = 'opacity: 0.9; text-shadow: 0px 1px rgba(1, 1, 1, 0.3); padding: 2px 5px; color: #fff;';

  function domAddResolverToPhonetool(group, oncalls) {
    if (oncalls.length === 0) {
      return;
    }

    var tableProperty = domCreate('div', 'TableProperty', {textContent: 'Team Oncall:'});
    tableProperty.style.maxWidth = '110px'; // Fix alignment on table cells.
    var tableValue = domCreate('div', 'TableValue');

    var header = domCreate('h5', '', {textContent:group});
    tableValue.appendChild(header);

    var oncallList = domCreate('ul');
    tableValue.append(oncallList);


    oncalls.forEach(function(oncallData) {
      var oncallAlias = domCreate('a', '', {
        href: oncallData.pagerdutyUrl,
        target: '_blank',
        title: 'Oncall Schedule for team "' + oncallData.pagerdutyName + '"',
        textContent: oncallData.pagerdutyName,
        onmouseenter: function() { oncallAlias.style.opacity = 1.0; },
        onmouseleave: function() { oncallAlias.style.opacity = 0.9; }
      });
      oncallAlias.style.cssText = baseOncallStyle + 'border-top-left-radius: 4px; border-bottom-left-radius: 4px; background-image: linear-gradient(0deg, #4C4C4C, #5F5F5F);';

      var oncallUser = domCreate('a', '', {
        target: '_blank',
        textContent: 'Loading...',
        onmouseenter: function() { oncallUser.style.opacity = 1.0; },
        onmouseleave: function() { oncallUser.style.opacity = 0.9; }
      });
      oncallUser.style.cssText = baseOncallStyle + 'border-top-right-radius: 4px; border-bottom-right-radius: 4px; background-image: linear-gradient(0deg, #E47031, #F78344);';

      // Resolve current oncall
      oncallData.currentOncall.then(function(currentOncall) {
        oncallUser.textContent = currentOncall + '@';
        oncallUser.href = window.location.origin + '/users/' + currentOncall;
        oncallUser.title = 'Phonetool page for "' + currentOncall + '"';
      }).catch(function(reason) {
        oncallUser.textContent = 'Failed to find oncall';
        oncallUser.href = oncallData.pagerdutyUrl;
        oncallUser.title = 'Open the oncall page for team "' + oncallData.pagerdutyName + '"';
        throwError(reason);
      });

      var oncallEntry = domCreate('li');
      oncallEntry.style.cssText = 'padding-bottom: 8px; word-break: keep-all;';
      oncallEntry.appendChild(oncallAlias);
      oncallEntry.appendChild(oncallUser);
      oncallList.appendChild(oncallEntry);
    });

    var resolverRow = domCreate('div', 'TableRow ResolverRow');
    resolverRow.appendChild(tableProperty);
    resolverRow.appendChild(tableValue);

    var resolverWrapper = domCreate('span', 'optional-wrapper');
    resolverWrapper.appendChild(resolverRow);

    var userDetailsTable = document.querySelector('.UserDetailsTable');
    userDetailsTable.appendChild(resolverWrapper);
  }

})();

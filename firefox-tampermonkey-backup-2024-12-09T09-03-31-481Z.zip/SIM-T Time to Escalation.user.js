// ==UserScript==
// @name           SIM-T Time to Escalation
// @version        1.1
// @namespace      http://tampermonkey.net/
// @description    Provides a "Escalation Time" counter for sev2 SIM-Ts
// @author         zzhidong
// @match          https://t.corp.amazon.com/*
// @require        https://momentjs.com/downloads/moment.min.js
// @include        https://maxis-service-prod-iad.amazon.com/*
// @grant          GM_xmlhttpRequest
// @grant          GM.xmlHttpRequest
// @downloadURL    https://axzile.corp.amazon.com/-/carthamus/download_script/sim-t-time-to-escalation.user.js
// @updateURL      https://axzile.corp.amazon.com/-/carthamus/download_script/sim-t-time-to-escalation.user.js
// ==/UserScript==

// Changelogs
// V1.1: Timer will be added or remove automtically after users change the SIM-T status or severity, no page refresh needed anymore.

isDebug = false;
var debug = isDebug ? console.log.bind(console) : function () { };

const simApiUrl = "https://maxis-service-prod-iad.amazon.com";

httpGet = (url) => {
    return new Promise(resolve => {
        GM.xmlHttpRequest({
            method: "GET",
            url,
            onload: resolve
        });
    })
}

getAllEdits = async (ticketId) => {
    const result = await httpGet(`${simApiUrl}/issues/${ticketId}/edits`);
    return JSON.parse(result.responseText).edits;
}

waitForElm = (selector) => {
    return new Promise(resolve => {
        if (document.querySelector(selector)) {
            return resolve(document.querySelector(selector));
        }

        const observer = new MutationObserver(mutations => {
            if (document.querySelector(selector)) {
                resolve(document.querySelector(selector));
                observer.disconnect();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
}

var TIME_REMAINING_DIV = '<div style="margin: 0 auto 0 auto; margin-bottom: 5px; font-size: 24px; text-align: center; background-color: #ffffff; color: #ff0000;"><p> Time to escalation: {0}:{1}:{2}</p></div>';

// add support string formatting so we can do index based substitution in strings
String.prototype.format = function () {
    var content = this;
    for (var i = 0; i < arguments.length; i++) {
        var replacement = '{' + i + '}';
        content = content.replace(replacement, arguments[i]);
    }
    return content;
};

// display the hour, minute and second	as 2 digit string with a 0 prepended for single digit values.
function getNumberAsTwoDigits(number) {
    if (number < 10) {
        return "0" + number.toString();
    }

    return number.toString();
}
// convert time to UTC
function toUTC(inTime) {
    var inTimeUTC = Date.UTC(inTime.getUTCFullYear(), inTime.getUTCMonth(), inTime.getUTCDate(), inTime.getUTCHours(), inTime.getUTCMinutes(), inTime.getUTCSeconds());
    return inTimeUTC;
}

// get the current time in UTC
function getCurrentTimeInUTC() {
    var currentTime = new Date();
    return toUTC(currentTime);
}

// check if the pathEdit is WIP
function isPathEditWIP(pathEdit) {
    if (
        pathEdit.path == "/next_step"
        && (pathEdit.data && pathEdit.data.action == "Implementation")
        && (!pathEdit.data.exceptions || pathEdit.data.exceptions.length == 0)
    ) {
        return true;
    }

    if (pathEdit.path == "/next_step/action" && pathEdit.data == "Implementation") {
        return true
    }

    return false;
}

// get the Work in Progress time in UTC
async function getWIPTimeInUTC() {
    const ticketIdElement = await waitForElm('.ticket-id');
    const ticketId = ticketIdElement.dataset.id;
    const edits = await getAllEdits(ticketId);

    edits.reverse();

    debug(edits);

    for (let edit of edits) {
        const pathEdits = edit.pathEdits;

        for (let pathEdit of pathEdits) {
            if (isPathEditWIP(pathEdit)) {
                const createDate = edit.effectiveCreateDate;
                debug(createDate);
                return moment(createDate).unix() * 1000;
            }
        }
    }
}

function createCountDownElement() {
    var countDown = document.createElement("p");
    countDown.id = "count_down_timer";
    document.querySelector(".issue-detail-content").before(countDown);
    return countDown;
}

function UpdateCountDownElement(countDownElement, hoursToEscalation, minutesToEscalation, secondsToEscalation) {
    if (hoursToEscalation == 0 && minutesToEscalation == 0 && secondsToEscalation == 0) {
        countDownElement.innerHTML = "About to escalate";
        return false;
    }

    countDownElement.innerHTML = TIME_REMAINING_DIV.format(getNumberAsTwoDigits(hoursToEscalation), getNumberAsTwoDigits(minutesToEscalation), getNumberAsTwoDigits(secondsToEscalation));
    return true;
}

function removeEscalationTimer() {
    // clear the escalation time if exist
    debug("clear the escalation time if exist");
    if (timerInterval) {
        clearInterval(timerInterval);
    }

    const count_down_timer = document.querySelector("#count_down_timer");
    if (count_down_timer) {
        count_down_timer.parentNode.removeChild(count_down_timer)
    }
}

async function main() {
    var showEscalationTime = false;
    var statusElement = await waitForElm(".issue-summary-status .info-value");
    var severityElement = await waitForElm(".issue-summary-severity .info-value");
    var currentTime = getCurrentTimeInUTC();
    var eventTime;
    var escalationHours;
    var escalationMinutes;
    var escalationSeconds;

    // todo add escalation for status = "Researching"

    // show escalation time if status is "Work In Progress"
    if (severityElement.innerText == "2" && statusElement.innerText == "Work in Progress") {
        showEscalationTime = true;
        eventTime = await getWIPTimeInUTC();
        escalationHours = 8;
        escalationMinutes = 60;
        escalationSeconds = 60;
    } 

    removeEscalationTimer();

    if (showEscalationTime) {
        var countDownElement = createCountDownElement();
        var timeDiff = (currentTime - eventTime) / 1000; // get the time difference between the original WIP time and now in seconds

        // compute the time remaining to escalate in hours, minutes and seconds
        var secondsToEscalation = escalationSeconds - (timeDiff % 60);
        if (secondsToEscalation < 60) {
            escalationMinutes--;
        }

        timeDiff = Math.floor(timeDiff / 60);
        var minutesToEscalation = escalationMinutes - (timeDiff % 60);
        if (minutesToEscalation < 60) {
            escalationHours--;
        }

        var hoursToEscalation = escalationHours - Math.floor(timeDiff / 60);

        function wait() {
            if (UpdateCountDownElement(countDownElement, hoursToEscalation, minutesToEscalation, secondsToEscalation)) {
                secondsToEscalation--;
                if (secondsToEscalation == -1) {
                    secondsToEscalation = 59;
                    minutesToEscalation--;
                }
                if (minutesToEscalation == -1) {
                    minutesToEscalation = 59;
                    hoursToEscalation--;
                }
            }
        }

        wait();

        //wait for a second
        timerInterval = setInterval(wait, 1000);
    }
}

let timerInterval;

await main();

const statusObserver = new MutationObserver(async (mutations) => {
    debug("status observer is triggered");
    await main();
});
const severityObserver = new MutationObserver(async (mutations) => {
    debug("severity observer is triggered");
    await main();
});
const statusElement = await waitForElm(".issue-summary-status .display-mode");
const severityElement = await waitForElm(".issue-summary-severity .display-mode");
const observerConfig =  { attributes: true };

debug("set up observer for status and severity");
statusObserver.observe(statusElement, observerConfig);
severityObserver.observe(severityElement, observerConfig);

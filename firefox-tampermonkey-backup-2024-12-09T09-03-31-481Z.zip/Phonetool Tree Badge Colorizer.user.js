// ==UserScript==
// @name         Phonetool Tree Badge Colorizer
// @version      1.0
// @description  Displays the color badge of the current chart tree in the phonetool page
// @author       zajaalex@
// @match        *://phonetool.amazon.com/users/*
// @grant        GM.xmlHttpRequest
// @run-at       document-idle
// ==/UserScript==

/////////////////////////////////////////////////////////////////////

(function() {
    'use strict';
    const BLUE_BADGE_COLOR = "#33d0eb";
    const ORANGE_BADGE_COLOR = "#f0ae3e";
    const RED_BADGE_COLOR = "#f44336";
    const PURPLE_BADGE_COLOR = "#8b32df";
    const SILVER_BADGE_COLOR = "#bcbcbc";
    const GOLD_BADGE_COLOR = "#bf9000";

    const _makeHeaders = (cookies) => ({
        "accept": "*/*",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "cookie": cookies
    });

    const _getBadgeColorFromTenure = (yearsOfTenure) => {
        try {
            if (yearsOfTenure < 5) return BLUE_BADGE_COLOR;
            if (yearsOfTenure < 10) return ORANGE_BADGE_COLOR;
            if (yearsOfTenure < 15) return RED_BADGE_COLOR;
            if (yearsOfTenure < 20) return PURPLE_BADGE_COLOR;
            if (yearsOfTenure < 25) return SILVER_BADGE_COLOR;
            return GOLD_BADGE_COLOR;
         }
        catch(e) {
            console.error(`[Phonetool Color Badge Highlighter]: ${e}`);
        }
    }

    const _waitForElement = (element, callback, attempt_counter=0, attempt_counter_max=100) => {
        if($(element).length >= 1) callback();
        else {
            if(attempt_counter >= attempt_counter_max) return false;
            setTimeout(function(){
                _waitForElement(element, callback, attempt_counter + 1);
            }, 100);
        }
    }

    const _extractUsername = (htmlObject) => {
        return htmlObject.match(/https:\/\/internal-cdn.amazon.com\/badgephotos.amazon.com\/.uid=([\w]*)/)[1];
    }

    const _sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    const _extractTenureFromString = (tenureStringFormatted) => {
        // if it includes the years then we can safely extract the number this way
        if (tenureStringFormatted.includes("year")){
            return Number(tenureStringFormatted.split(" ")[0]);
        }
        // 0 here will fallback to blue badge which is correct if someone has lees than 1 year tenure
        return 0;
    }

    const _getYearsofTenure = async(username, dateToCompare) => {
        const requestParams = {
            "headers": _makeHeaders(document.cookie),
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": null,
            "method": "GET",
            "mode": "cors",
            "credentials": "include"
        };
        let delayMs = 250;
        let phonetoolInfoResponse = await fetch(`https://phonetool.amazon.com/users/${username}.json`, requestParams);
        while (!phonetoolInfoResponse.ok) {
            // waiting for a couple of ms to avoid being throttled
            await _sleep(delayMs);
            phonetoolInfoResponse = await fetch(`https://phonetool.amazon.com/users/${username}.json`, requestParams);
            // delay backoff increase
            delayMs *= 2;
        }
        // Calculating years of tenure and matching with color
        const { total_tenure_formatted } = await phonetoolInfoResponse.json();
        // tenure is in the format: 20 years, 5 days
        return _extractTenureFromString(total_tenure_formatted);
    }

    const _updateUserBadgeColor = (userHTMLObject, badgeColor) => {
        const badgeDOMElement = userHTMLObject.getElementsByClassName("badge-photo")[0];
        badgeDOMElement.style.width = "36px";
        badgeDOMElement.style.height = badgeDOMElement.style.width;
        badgeDOMElement.style.objectFit = "cover";
        badgeDOMElement.style.border = "3px solid "+badgeColor;
        badgeDOMElement.style.borderRadius = "50%";
    }

    // Main update function
    const _updateBadgeFaceouts = async() => {
        const orgChartSelector = ".org-chart-row";
        const expandableSelector = ".level,.expandable";
        _waitForElement(orgChartSelector, async() => {
            try {
                const currentDate = Date.now();
                // represents all the HTML dom objects for each user in the tree chart of the current page
                const usersHTMLObjects = $(orgChartSelector).toArray();
                // yes, I know what you are thinking. This processing could all be done in one loop. But I chose to separate it to be able to separate concerns between API call for
                // phone tool data and UI update. In this case, O(3*n) is really similar to O(n) and I think more easy to extend the logic is with this form (especially when one page doesn't have millions of
                // org chart users)
                const orgChartUsernames = usersHTMLObjects.map((usersHTMLObject) => _extractUsername(usersHTMLObject.innerHTML));
                const orgChartUserTenures = [];
                for (const username of orgChartUsernames) {
                    orgChartUserTenures.push(await _getYearsofTenure(username, currentDate));
                }
                orgChartUserTenures.forEach((yearsOfTenure, i) => {
                    const badgeColor = _getBadgeColorFromTenure(yearsOfTenure);
                    _updateUserBadgeColor(usersHTMLObjects[i], badgeColor);
                });
                // this part waits for updates to the org chart (expansion/removal of nodes) and re-triggers updates (timeout is needed ti guarantee UI correctness)
                _waitForElement(expandableSelector, async () => {
                    $(expandableSelector).each((_, expendableButton) => {
                        expendableButton.addEventListener('click', async (e) => setTimeout(async() => await _updateBadgeFaceouts(), 500));
                    });
                });
            }
            catch(e) {
                console.error(`[Phonetool Color Badge Highlighter]: ${e}`);
            }
        });
    }
    (async () => {
        await _updateBadgeFaceouts();
    })();
})();



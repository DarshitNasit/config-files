// ==UserScript==
// @name        PowerChat
// @description Enable natural language conversations on any web pages. See https://w.amazon.com/bin/view/PowerChat/ for more information.
// @namespace   yinliy.people.amazon.dev
// @author      yinliy
// @match       https://*.amazon.com/*
// @match       https://*.amazon.dev/*
// @match       https://*.amazon.jobs/*
// @match       https://*.amazon.work/*
// @match       https://quip-amazon.com/*
// @match       https://*.a2z.com/*
// @match       https://*.ring.com/*
// @match       https://*.awsapps.com/*
// @match       https://*.scinetamazon.com/*
// @exclude     https://code.amazon.com/*
// @exclude     https://phonetool.amazon.com/*
// @exclude     https://isengard.amazon.com/*
// @exclude     https://conduit.security.a2z.com/*
// @exclude     https://bindles.amazon.com/*
// @exclude     https://sage.amazon.dev/*
// @exclude     /^https://.*\.console\.aws\.amazon\.com/.*$/
// @version     1.00
// @grant       GM.xmlHttpRequest
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_addStyle
// @require     https://code.amazon.com/packages/PowerChat/blobs/mainline/--/dependencies/jquery.min.js?raw=1
// @require     https://code.amazon.com/packages/PowerChat/blobs/mainline/--/dependencies/Readability.min.js?raw=1
// @require     https://code.amazon.com/packages/PowerChat/blobs/mainline/--/dependencies/purify.min.js?raw=1
// @require     https://internal-cdn.amazon.com/sentry.amazon.com/public/javascripts/openid.default-off.js
// @require     https://internal-cdn.amazon.com/sentry.amazon.com/public/javascripts/openid.xhr.js
// @updateURL   https://code.amazon.com/packages/PowerChat/blobs/mainline/--/src/PowerChat.user.js?raw=1
// @downloadURL https://code.amazon.com/packages/PowerChat/blobs/mainline/--/src/PowerChat.user.js?raw=1
// ==/UserScript==

/*
* ===============================================
* PowerChat Configurations
* ===============================================
*/
const PowerChatConfig = class {
    /**
     * App configurations
     */
    static APP_CONFIG = {
        "endpoint": "https://prod.yinliy.people.amazon.dev/chatOnPage",
        "debugMode": false,
        "followUpMode": false,
    };
    /**
     * Default context parser map from context keys to parser functions
     */
    static DEFAULT_CONTEXT_PARSER_MAP = {
        "Title": (readability, jDoc) => readability.title,
        "Modified By": (readability, jDoc) => readability.byline,
        "Content": (readability, jDoc) => simplifyHtml(readability.content) || simplifyHtml(jDoc.find("body")),
    }
    /**
     * Override context parser map by website host name
     */
    static WEBSITE_CONTEXT_PARSER_OVERRIDES = {
        "w.amazon.com": {
            "Title": (readability, jDoc) => jDoc.find(".xcontent #document-title").text().trim(),
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find(".search-results"))
                || simplifyHtml(jDoc.find("#xwikicontent").clone()
                    .each((i, node) => $(node).find("table#toc").remove())),
        },
        "wiki.amazon.com": {
            "Title": (readability, jDoc) => jDoc.find(".xcontent #document-title").text().trim(),
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find(".search-results"))
                || simplifyHtml(jDoc.find("#xwikicontent").clone()
                    .each((i, node) => $(node).find("table#toc").remove())),
        },
        "quip-amazon.com": {
            "Title": (readability, jDoc) => jDoc.find(".nav-path-title-container").text().trim(),
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find(".folder-list-body"))
                || simplifyHtml(transformQuip(jDoc.find(".document-editor").clone())),
            "Comment": (readability, jDoc) =>
                jDoc.find(".thread-message.message, .thread-message.comment").toArray().map((element) => {
                    return {
                        "Quote": $(element).find(".thread-message-quote annotation").text()
                            || $(element).find(".thread-message-quote").text().trim(),
                        "Message": $(element).find(".thread-message-content").text(),
                    };
                }),
        },
        "docs.aws.amazon.com": {
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find("div[role='list']"))
                || simplifyHtml(jDoc.find("main")),
        },
        "t.corp.amazon.com": {
            "Title": (readability, jDoc) => jDoc.find("#sim-title").text().trim(),
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find("#sim-issueListContent"))
                || simplifyHtml(jDoc.find("div[role='tabpanel']").clone()
                    .each((i, node) => $(node).find(".sim-communicationActions").remove())),
            "Announcement": (readability, jDoc) => simplifyHtml(jDoc.find(".sim-announcement")),
            "Metadata": (readability, jDoc) => simplifyHtml(jDoc.find(".issue-summary").clone()
                .each((i, node) => $(node).find("a.edit-label").remove()))
        },
        "tt.amazon.com": {
            "Title": (readability, jDoc) => jDoc.find("#sim-title").text().trim(),
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find("#sim-issueListContent"))
                || simplifyHtml(jDoc.find("div[role='tabpanel']").clone()
                    .each((i, node) => $(node).find(".sim-communicationActions").remove())),
            "Announcement": (readability, jDoc) => simplifyHtml(jDoc.find(".sim-announcement")),
            "Metadata": (readability, jDoc) => simplifyHtml(jDoc.find(".issue-summary").clone()
                .each((i, node) => $(node).find("a.edit-label").remove()))
        },
        "www.coe.a2z.com": {
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find(".tab-content.active").clone()
                .each((i, node) => $(node).find("span.line-number").remove()))
                || simplifyHtml(jDoc.find("main")),
        },
        "amazon.awsapps.com": {
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find("#pdf_viewer_container")
                .contents().find("#viewerContainer .textLayer").clone()
                .each((i, node) => $(node).find("#page-desc").remove())),
        },
        "news.a2z.com": {
            "Content": (readability, jDoc) => simplifyHtml(jDoc.find("iframe").contents())
        }
    }
    /**
     * Get context url history as below
     * {<url>: [<scope>, ...]}
     */
    getContextUrlHistory() {
        return GM_getValue("contextUrlHistory", {});
    }
    /**
     * Set context url history as below
     * {<url>: [<scope>, ...]}
     */
    setContextUrlHistory(config) {
        return GM_setValue("contextUrlHistory", config);
    }
    /**
     * Get context urls from the given scope of history
     */
    getContextUrlsFromHistory(scope) {
        const urlsWithScopes = this.getContextUrlHistory();
        return Object.keys(urlsWithScopes).filter((url) => urlsWithScopes[url].includes(scope));
    }
    /**
     * Get all context urls from history (regardless of scope)
     */
    getAllContextUrlsFromHistory() {
        return Object.keys(this.getContextUrlHistory());
    }
    /**
     * Add new context urls to the given scope of history
     */
    addContextUrlsToHistory(scope, newUrls) {
        const urlsWithScopes = this.getContextUrlHistory();
        newUrls.forEach((url) => {
            const currentScopes = urlsWithScopes[url] ?? [];
            if (!currentScopes.includes(scope)) currentScopes.push(scope);
            urlsWithScopes[url] = currentScopes;
        });
        this.setContextUrlHistory(urlsWithScopes);
    }
    /**
     * Remove a context url from the given scope of history
     */
    removeContextUrlFromHistory(scope, url) {
        const urlsWithScopes = this.getContextUrlHistory();
        if (!Object.keys(urlsWithScopes).includes(url)) return;
        const currentScopes = urlsWithScopes[url] ?? [];
        const index = currentScopes.indexOf(scope);
        if (index > -1) currentScopes.splice(index, 1);
        urlsWithScopes[url] = currentScopes;
        // Keep the URL even if there is no scope left
        this.setContextUrlHistory(urlsWithScopes);
    }
    /**
     * Remove a context url from history regardless of scope
     */
    removeContextUrlFromAllHistory(url) {
        const urlsWithScopes = this.getContextUrlHistory();
        if (Object.keys(urlsWithScopes).includes(url)) {
            delete urlsWithScopes[url];
        }
        this.setContextUrlHistory(urlsWithScopes);
    }
    /**
     * Get a context parser map from context keys to parser functions for the given host name
     */
    getContextParserMap(hostName) {
        return {
            ...PowerChatConfig.DEFAULT_CONTEXT_PARSER_MAP,
            ...PowerChatConfig.WEBSITE_CONTEXT_PARSER_OVERRIDES[hostName]
        }
    }
    /**
     * Get endpoint
     */
    getEndpoint() {
        return PowerChatConfig.APP_CONFIG["endpoint"];
    }
    /**
     * Check if the debug mode is enabled
     */
    isDebugModeEnabled() {
        return PowerChatConfig.APP_CONFIG["debugMode"];
    }
    /**
     * Check if the follow-up mode is enabled
     */
    isFollowUpModeEnabled() {
        return PowerChatConfig.APP_CONFIG["followUpMode"];
    }
}

/*
* ===============================================
* PowerChat Core
* ===============================================
*/
const PowerChatCore = class {
    /**
     *  @param {PowerChatConfig} config
     */
    constructor(config) {
        this.config = config;
        // Cache for external context
        this.externalContextCache = {};
        // page context urls
        this.pageContextUrls = [];
        this.updatePageContextUrlOnLocationChange();
        // Total cost 
        this.totalCost = 0.0;
        // Logs for debugging
        this.logs = [];
        // Event handlers
        this.eventHandlers = {};
    }
    /**
     * Listen on location change event to update pageContextUrls
     */
    updatePageContextUrlOnLocationChange() {
        let ordUri = this.getCurrentPageUri();
        new MutationObserver(mutations => {
            const newUri = document.location.href.split("#")[0];
            if (ordUri === newUri) return;
            this.removeUrlFromPageContext(ordUri);
            this.addUrlsToPageContext([newUri]);
            ordUri = newUri;
        }).observe(document.querySelector("body"), { childList: true, subtree: true });
    }
    /**
     * Parse context from the given document
     */
    parseContextFromDoc(doc, url) {
        const hostName = new URL(url).hostname;
        const context = {"Url": url, "Current Page": this.isCurrentPage(url)};
        // Get readability result
        const readability = new Readability(doc.cloneNode(true)).parse() ?? {};
        // Get additional page specific context
        const contextParserMap = this.config.getContextParserMap(hostName);
        const defaultContextParserMap = this.config.getContextParserMap();
        const jDoc = $(doc);
        for (const contextKey in contextParserMap) {
            if (!this.parseContext(contextParserMap, contextKey, context, readability, jDoc)) {
                // fallback to use the default parser if available
                this.parseContext(defaultContextParserMap, contextKey, context, readability, jDoc);
            }
        }
        // Save to cache
        this.externalContextCache[url] = context;
        this.triggerEvent("pageContext");
        return context;
    }
    /**
     * Parse context using the corresponding parser from the context parser map
     */
    parseContext(contextParserMap, contextKey, context, readability, jDoc) {
        const contextParser = contextParserMap[contextKey];
        if (!contextParser) return false;
        const value = contextParser(readability, jDoc);
        if (value !== null && value !== undefined && value !== "") {
            context[contextKey] = value;
            return true;
        }
        return false;
    }
    /**
     * Reset page context
     */
    resetPageContext() {
        this.pageContextUrls.length = 0;
        this.addUrlsToPageContext([this.getCurrentPageUri()]);
        // load pages from config
        const historyContextUrls = this.config.getContextUrlsFromHistory(this.getCurrentPagePath());
        this.addUrlsToPageContext(historyContextUrls);
        // Preload the context
        this.loadContextSequentially(historyContextUrls);
    }
    /**
     * Remove a url from the page context
     */
    removeUrlFromPageContext(url) {
        const index = this.pageContextUrls.indexOf(url);
        if (index > -1) {
            this.pageContextUrls.splice(index, 1);
            this.triggerEvent("pageContext");
        }
    }
    /**
     * Add a list of pages to the page context
     */
    addUrlsToPageContext(urls) {
        let changed = false;
        urls.forEach((url) => {
            if (!this.pageContextUrls.includes(url)) {
                this.pageContextUrls.push(url);
                changed = true;
            }
        })
        if (changed) this.triggerEvent("pageContext");
    }
    /**
     * Get page context urls
     */
    getPageContextUrls() {
        return this.pageContextUrls;
    }
    /**
     * Check if a URL is included in page context
     */
    isInPageContext(url) {
        return this.pageContextUrls.includes(url);
    }
    /** 
     * Check if a URL is the current page 
     */
    isCurrentPage(url) {
        return this.getCurrentPageUri() === url.split("#")[0];
    }
    /** 
     * Get the current page URI without hash
     */
    getCurrentPageUri() {
        return window.location.href.split("#")[0];
    }
    /**
     * Remember a list of context urls for the current page
     */
    rememberContextUrlsForCurrentPage(urls) {
        const currentScope = this.getCurrentPagePath();
        this.config.addContextUrlsToHistory(currentScope, urls.filter((url) => !this.isCurrentPage(url)));
    }
    /**
     * Forget a context url for the current page
     */
    forgetContextUrlForCurrentPage(url) {
        const currentScope = this.getCurrentPagePath();
        this.config.removeContextUrlFromHistory(currentScope, url);
    }
    /**
     * Get the URL path of the current page
     */
    getCurrentPagePath() {
        const currentUrl = new URL(this.getCurrentPageUri());
        const pathname = currentUrl.pathname;
        return `${currentUrl.protocol}//${currentUrl.hostname}${pathname}`;
    }
    /**
     * Get the parent path of the given url
     */
    getUrlParentPath(url) {
        const urlObj = new URL(url);
        const pathname = urlObj.pathname;
        let lastSlashIndex = pathname.lastIndexOf("/");
        // skip the trailing slash
        if (lastSlashIndex > 0 && lastSlashIndex === pathname.length - 1) {
            lastSlashIndex = pathname.lastIndexOf("/", lastSlashIndex - 1);
        }
        const parentPath = pathname.substring(0, lastSlashIndex + 1);
        return `${urlObj.protocol}//${urlObj.hostname}${parentPath}`;
    }
    /**
     * Load page context
     */
    loadPageContext(onComplete) {
        this.loadContextSequentially(this.pageContextUrls, onComplete);
    }
    /**
     * Load aggregated context from the given urls sequentially  
     */
    loadContextSequentially(urls, onComplete = () => {}, startIndex = 0, aggregatedContext = {}) {
        // Exit if not more urls
        if (startIndex >= urls.length) {
            onComplete(aggregatedContext);
            return;
        }
        // Load the next url
        const url = urls[startIndex];
        this.loadContextFromUrl(url, (context) => {
            aggregatedContext[url] = context;
            // Continue to load the remaining urls
            this.loadContextSequentially(urls, onComplete, startIndex + 1, aggregatedContext);
        });
    }
    /**
     * Parse the context of the given URL with cache
     */
    loadContextFromUrl(url, onResponse = () => {}) {
        if (this.isCurrentPage(url)) {
            // Skip cache if it's the current page
            const currentPageContext = this.parseContextFromDoc(document, url);
            onResponse(currentPageContext);
        } else if (url in this.externalContextCache) {
            // If it's already cached
            onResponse(this.externalContextCache[url]);
        } else {
            // Otherwise, get the content and parse it
            GM.xmlHttpRequest({
                method: "GET",
                url: url,
                onload: (response) => { this.parsePageContext(url, response, onResponse) },
                // In case of error, continue even if the response is empty
                onerror: (response) => {this.parsePageContext(url, response, onResponse)},
            });
        }
    }
    /**
     * parse page context from Http response
     */
    parsePageContext(url, response, onPageContext) {
        // Parse the response content
        const cleanHtml = DOMPurify.sanitize(response.responseText, {
            WHOLE_DOCUMENT: true,  FORBID_TAGS: ['script'],
        });
        const pageDoc = new DOMParser().parseFromString(cleanHtml, "text/html");
        const pageContext = this.parseContextFromDoc(pageDoc, url);
        onPageContext(pageContext);
    }
    /**
     * Get the display name for the given URL
     */
    getUrlDisplayName(url) {
        if (this.isCurrentPage(url)) {
            return "Current Page";
        }
        let displayName = (this.externalContextCache[url] ?? {})["Title"];
        if (!displayName) {
            const urlLength = url.length;
            displayName = (urlLength <= 45) ? url
                : url.substring(0, 20) + "..." + url.substring(urlLength - 22, urlLength)
        }
        return displayName;
    }
    /**
     * @callback onMessageResponse
     * @param {number} status
     * @param {string} message
     */
    /**
     * Send the given message with the page context
     * @param {string} message
     * @param {string} chatHistory
     * @param {onMessageResponse} onMessageResponse
     */
    sendMessageWithContext(message, chatHistory, onMessageResponse) {
        this.loadPageContext((pageContext) => {
            // generate payload
            const data = {
                "Time Zone": Intl.DateTimeFormat().resolvedOptions().timeZone,
                "Page Context": Object.values(pageContext),
                "Chat History": chatHistory,
            };
            // post the request to the server
            this.sendRequestWithAuth(message, data, onMessageResponse);
        })
    }
    /**
     * Send Ajax request with authentication
     * @param {string} message
     * @param {Object} data
     * @param {onMessageResponse} onMessageResponse
     */
    sendRequestWithAuth(message, data, onMessageResponse) {
        const url = this.config.getEndpoint() + "?q=" + encodeURIComponent(message);
        $.ajax({
            method: "POST",
            url: url,
            data: JSON.stringify(data),
            dataType: "text",
            xhr: Amazon.IDP.xhr,
            xhrFields: { withCredentials: true }
        }).done((responseData) => {
            const result = JSON.parse(responseData);
            this.logInteraction(200, message, result.cost);
            onMessageResponse(200, result.completion);
        }).fail((response) => {
            this.logInteraction(response.status, message, 0);
            onMessageResponse(response.status);
        });
    }
    /**
     * Log the interaction including the time and cost
     */
    logInteraction(status, message, cost = 0) {
        // Update total cost
        this.totalCost += cost;
        this.triggerEvent("totalCost", this.totalCost);
        // Update logs
        this.logs.push({
            Time: new Date().toLocaleDateString() + " " + new Date().toLocaleTimeString(),
            Query: message,
            Status: status,
            Cost: "$" + cost.toFixed(3),
        });
    }
    /**
     * Register an event handler on the given event
     */
    onEvent(event, eventHandler) {
        if (!this.eventHandlers[event]) this.eventHandlers[event] = [];
        this.eventHandlers[event].push(eventHandler);
        return this;
    }
    /**
     * Trigger the given event
     */
    triggerEvent(event, ...params) {
        if (this.eventHandlers[event]) {
            this.eventHandlers[event].forEach((handler) => handler.apply(this, params));
        }
    }
}

/*
* ===============================================
* Base UI for common components
* ===============================================
*/
const BaseUI = class {
    /**
     * Render an text area
     */
    newTextArea(placeholder, onEnter) {
        const MAX_HEIGHT = 196;
        return $("<textarea>")
            .prop("placeholder", placeholder)
            .addClass("paInput")
            .on("keypress", (event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    onEnter(event);
                }
            }).on("input", (event) => {
                // auto height increase
                const textarea = event.target;
                textarea.style.height = 0;
                textarea.style.overflowY = (textarea.scrollHeight > MAX_HEIGHT) ? "scroll" : "hidden";
                textarea.style.height = Math.min(textarea.scrollHeight, MAX_HEIGHT) + "px";
            });
    }
    /**
     * Render a anchor
     */
    newAnchor(text, url, onClick) {
        const anchor = $("<a>").text(text).prop("href", url).prop("target", "_blank");
        if (onClick) {
            anchor.on("click", (event) => {
                event.preventDefault()
                event.stopPropagation()
                onClick(event);
            });
        }
        return anchor;
    }
    /**
     * Render a section
     */
    newSection(title, description) {
        return $("<div>").addClass("paSection")
            .append($($("<b>").text(title)))
            .append($("<p>").addClass("paDescription").text(description));
    }
    /**
     * Render a check box
     */
    newCheckbox(text, value, checked, onChange) {
        return $("<label>").prop("for", value)
            .prop("title", value)
            .append($("<input>").prop("type", "checkbox").prop("id", value).prop("checked", checked)
                .val(value).on("change", onChange))
            .append(text);
    }
    /**
     * Render a button with the given text and onClick event
     */
    newButton(text, title, onClick, selectOnClick = false) {
        const button = $('<button>')
            .addClass("paButton")
            .append($("<div>").text(text))
            .prop("title", title)
            .on('click', (event) => {
                if (onClick) onClick(event);
                if (selectOnClick) {
                   button.siblings().removeClass('selected');
                   button.addClass('selected');
                }
                // Stop propagation and prevent default to avoid triggering anything else
                return false;
            });
        return button;
    }
    /**
     * Render a text button (without border)
     */
    newTextButton(text, title, onClick) {
        return this.newButton(text, title, onClick).addClass("noborder");
    }
    /**
     * Render a toggle button with the given text and onClick event
     */
    newToggleButton(text, title, onClick) {
        const button = this.newButton(text, title, () => {
            button.toggleClass("pressed");
            if (onClick) onClick();
        });
        return button;
    }
    /**
     * Render a no-border float-right button on the given parent element
     */
    newFloatButton(parent, buttonText, buttonTitle, onClick){
        parent.on("mouseenter focus", () => {
            floatButton.show();
        }).on("mouseleave blur", () => {
            floatButton.hide();
        })
        const floatButton = this.newTextButton(buttonText, buttonTitle, onClick)
            .addClass("right").hide().prependTo(parent);
        return floatButton;
    }
    /**
     * Render the given object as a table
     */
    newObjectTable(object) {
        const table = $("<table>");
        table.append(
            $("<tr>").append(this.newCell("Key")).append(this.newCell("Value"))
        );
        for (const key in object) {
            // Skip null values
            if (object[key] === null) continue;
            table.append(
                $("<tr>").append(this.newCell(key)).append(this.newCell(object[key]))
            );
        }
        return table;
    }
    /**
     * Render the given array as a table
     */
    newArrayTable(array) {
        const table = $("<table>");
        array.forEach((item, i) => {
            // add the keys as the first row
            if (i === 0) {
                const firstRow = $("<tr>");
                for (const key of Object.keys(item)) {
                    firstRow.append(this.newCell(key));
                }
                table.append(firstRow);
            }
            // add the data
            const row = $("<tr>");
            for (const key of Object.keys(item)) {
                row.append(this.newCell(item[key]));
            }
            table.append(row);
        });
        return table;
    }
    /**
     * Render the given value as a cell (<td>)
     */
    newCell(value) {
        if (value instanceof Object || Array.isArray(value)) {
            value = JSON.stringify(value, null, "  ");
        } else {
            value = `${value}`;
        }
        // Setting the value in html() so that links can be rendered
        return $("<td>").append($("<div>").html(value));
    }
}

/*
* ===============================================
* Base View
* ===============================================
*/
const BaseView = class extends BaseUI{
    constructor(title, description, lazyLoad = false, visible = true) {
        super();
        this.title = title;
        this.description = description;
        this.lazyLoad = lazyLoad;
        this.visible = visible;
    }
    /**
     * Render the view
     */
    render(view) {
    }
}

/*
* ===============================================
* Chat View
* ===============================================
*/
const ChatView = class extends BaseView{
    /**
     * Map from status codes to error messages
     */
    static ERROR_MESSAGE_MAP = {
        "0": "Sorry, this page does not seem to allow your message to be sent.",
        "400": "Sorry, the context of your message is too long. Please remove unnecessary page context or try a different page.",
        "429": "Sorry, you just hit the throttling limit. Please try again later.",
        "503": "Sorry, the service is unavailable at this point. Please try again later.",
    }
    /**
     *  @param {PowerChatConfig} config
     *  @param {PowerChatCore} core
     */
    constructor(config, core) {
        super("Chat", "Let's chat");
        this.config = config;
        this.core = core;
        this.historyWidget = $('<div>').addClass("paHistoryWidget");
        this.shortcutWidget = $('<div>').addClass("paShortcutWidget");
        this.inputWidget = $('<div>').addClass("paInputWidget");
        this.contextWidget = $('<div>').addClass("paContextWidget");
        this.progressBar = $('<div>').addClass('paProgress');
    }
    /**
     * Render the view
     */
    render(view) {
        this.view = view;
        view.empty()
            .append(this.historyWidget)
            .append(this.shortcutWidget)
            .append(this.inputWidget)
            .append(this.contextWidget)
            .append(this.progressBar);
        // Init widgets
        this.initShortcutWidget();
        this.initInputWidget();
        this.initContextWidget();
    }
    /**
     * Initialize the shortcut widget
     */
    initShortcutWidget() {
        // Add new chat button
        this.newButton("New Chat", "Start a new chat", () => {
            this.startNewChat();
        }).appendTo(this.shortcutWidget);
    }
    /**
     * Initialize the input widget
     */
    initInputWidget() {
        this.newTextArea("Type a chat message here. You may also include other page URLs as additional context.", () => {
            const textarea = this.getInput();
            const message = textarea.val().trim();
            // Skipping empty messages
            if (message) this.sendMessage(message);
            this.updateInputMessage("");
        }).appendTo(this.inputWidget);
    }
    /**
     * Initialize context widget
     */
    initContextWidget() {
        // no need to render on init as page context is lazyload
        this.core.onEvent("pageContext", () => {
            this.renderContextWidget();
        });
    }
    /**
     * Render context widget
     */
    renderContextWidget() {
        this.contextWidget.empty();
        const pageContextUrls = this.core.getPageContextUrls();
        this.renderPageContextSummary(pageContextUrls);
        // Get context from history
        const historyUrls = this.config.getAllContextUrlsFromHistory().sort();
        // remove and add back the current page at the top
        if (historyUrls.includes(this.core.getCurrentPageUri())) {
            historyUrls.splice(historyUrls.indexOf(this.core.getCurrentPageUri()), 1);
        }
        historyUrls.unshift(this.core.getCurrentPageUri());
        // show other urls if there is any
        const unusedHistoryUrls = historyUrls.filter((url) => !pageContextUrls.includes(url));
        this.renderHistoryContext(unusedHistoryUrls);
    }
    /**
     * Render page context summary
     */
    renderPageContextSummary(pageContextUrls) {
        if (!pageContextUrls.length) {
            this.contextWidget.append($("<span>").text(`Without context`));
        } else {
            this.contextWidget.append($("<span>").text(`With context: `));
        }
        // Show all page context if any
        pageContextUrls.forEach((url, i) => {
            if (i) this.contextWidget.append(", ")
            const removeButton = $("<span>").text("✕ ").hide();
            this.newAnchor(this.core.getUrlDisplayName(url), url, () => {
                this.core.forgetContextUrlForCurrentPage(url);
                this.core.removeUrlFromPageContext(url);
            }).prop("title", "Click to remove")
                .prepend(removeButton)
                // show/hide on mouse and keyboard events
                .on("mouseenter focusin", () => removeButton.show())
                .on("mouseleave focusout", () => removeButton.hide())
                .appendTo(this.contextWidget);
        });
    }
    /**
     * Render history context
     */
    renderHistoryContext(urls) {
        if (!urls.length) return;
        // prepare a default hidden div for these urls
        const moreUrlsDev = $("<div>").addClass("paHistoryContext").hide();
        urls.forEach((url) => {
            const actions = $("<span>").addClass("right").append("[")
                .append(this.newAnchor("Open", url)).append(", ")
                .append(this.newAnchor("Remove", url, () => {
                    this.config.removeContextUrlFromAllHistory(url);
                    this.renderContextWidget();
                })).append("]").hide();
            this.newHistoryContextUrl(url).append(actions)
                .on("mouseenter", () => actions.show())
                .on("mouseleave", () => actions.hide())
                .appendTo(moreUrlsDev);
        });
        // Add a button to show/hide the div
        this.contextWidget.append(this.newTextButton("+", "Add or manage context from history", (event) => {
            const target = $(event.target);
            if (target.text() === "+") {
                target.text("Hide").prop("title", "Hide context from history");
                moreUrlsDev.show();
            } else {
                target.text("+").prop("title", "Add or manage context from history");;
                moreUrlsDev.hide();
            }
        }).addClass("right")).append(moreUrlsDev);
    }
    /**
     * Render a new history context url
     */
    newHistoryContextUrl(url) {
        const title = this.core.getUrlDisplayName(url);
        const isInPageContext = this.core.isInPageContext(url);
        return this.newCheckbox(title, url, isInPageContext, (event) => {
            if (event.target.checked) {
                this.core.rememberContextUrlsForCurrentPage([url]);
                this.core.addUrlsToPageContext([url]);
                // preload context
                this.core.loadContextFromUrl(url);
            }
        });
    }
    /**
     * Start a new chat
     */
    startNewChat() {
        this.historyWidget.empty();
        this.addMessageFromAssistant("Hi there, how can I help you?");
        this.core.resetPageContext();
        this.getInput().trigger("focus");
    }
    /**
     * Get input textarea
     */
    getInput() {
        return this.inputWidget.find("textarea");
    }
    /**
     * Update input message
     */
    updateInputMessage(message) {
        return this.getInput().val(message).trigger("input").trigger("focus");
    }
    /**
     * Send a message and render the response accordingly
     */
    sendMessage(message) {
        this.disableInputs();
        // Remove previous follow-up buttons
        this.historyWidget.find(".paActions").remove();
        const chatHistory = this.buildChatHistory();
        this.preProcessMessage(message, (processedMessage) => {
            // Add the message before sending to ensure it appears immediately and before the response
            this.addMessageFromUser(message);
            // Send message
            this.core.sendMessageWithContext(processedMessage, chatHistory,
                (status, completion = "") => { 
                    // In case of error, put the original message back
                    if (status != 200) {
                        this.updateInputMessage(processedMessage);
                        completion = ChatView.ERROR_MESSAGE_MAP[status] ?? "Sorry, something went wrong."
                    } 
                    this.addMessageFromAssistant(completion);
                    this.addFollowUpActions();
                    this.enableInputs();
                }
            );
        }, () => {
            this.enableInputs();
        });
    }
    /**
     * Pre process the given message 
     */
    preProcessMessage(message, messageHandler, onlyLinkHandler) {
        // Add urls if any
        const urls = this.findUrls(message);
        this.core.addUrlsToPageContext(urls);
        this.core.rememberContextUrlsForCurrentPage(urls);
        // Try removing the url from the message to see if it is more than url
        let remainingMessage = message;
        urls.forEach((url) => {
            remainingMessage = remainingMessage.replace(url, "");
        })
        const messageIsMoreThanUrls = remainingMessage.trim();
        if (messageIsMoreThanUrls) {
            // If more than urls, continue with the original message
            messageHandler(message);
        } else {
            // Otherwise, preload urls
            this.core.loadContextSequentially(urls, onlyLinkHandler);
        }
    }
    /**
     * Find URLs from message
     */
    findUrls(message) {
        const urlList = [];
        const regex = /\b((?:https?):\/\/[a-zA-Z0-9+&@#\/\-%?=~_|!:,.;]*[a-zA-Z0-9+&@#\/%=~_|])/gi;
        let match;
        while ((match = regex.exec(message)) !== null) {
            urlList.push(match[0]);
        }
        return urlList;
    }
    /**
     * Disable input elements
     */
    disableInputs() {
        this.inputWidget.children().prop('disabled', true);
        this.view.find(".paButton").prop('disabled', true);
        this.progressBar.show();
    }
    /**
     * Enable input elements
     */
    enableInputs() {
        this.inputWidget.children().prop('disabled', false);
        this.view.find(".paButton").prop('disabled', false);
        this.progressBar.hide();
    }
    /**
     * Render a message from the user
     */
    addMessageFromUser(message) {
        const messageDiv = $("<div>").addClass("paHumanMessage")
            .append($("<div>").addClass("paMessageContent").text(message));
        this.addMessageWithMetadata(messageDiv);
    }
    /**
    * Render a message from the assistant
    */
    addMessageFromAssistant(message) {
        const messageDiv = $("<div>").addClass("paAssistantMessage")
            // Setting the message in html() so that links can be rendered
            .append($("<div>").addClass("paMessageContent").html(message));
        this.removeRedundantLineBreaks(messageDiv);
        // Always open links in new tab
        messageDiv.find("a").each((i, node) => $(node).prop("target", "_blank"));
        this.addMessageWithMetadata(messageDiv);
    }
    /**
     * Remove redundant line breaks from the message.
     * This is necessary in order to use white-space: pre-wrap to honer line breaks in text content.
     */
    removeRedundantLineBreaks(messageDiv) {
        const inlineElements = "a, b";
        // Find all text nodes in the message
        messageDiv.find("*").addBack().contents()
            .filter((i, node) => node.nodeType === 3)
            .each((i, node) => {
                // Remove unnecessary spaces between tags
                if (node.textContent.trim() === "") node.textContent = "";
                // and remove unnecessary leading line breaks
                if (!node.previousSibling || !$(node.previousSibling).is(inlineElements)) {
                    node.textContent = node.textContent.replaceAll(/^\n+/g, "");
                }
                // and remove ending line breaks + spaces
                if (!node.nextSibling || !$(node.nextSibling).is(inlineElements)) {
                    node.textContent = node.textContent.replaceAll(/\n[\n\s]*$/g, "");
                }
            });
    }

    /**
     * Render a message with metadata
     */
    addMessageWithMetadata(messageDiv) {
        const time = new Date().toLocaleTimeString("en", {
            timeStyle: "short",
        });
        const dateTime = new Date().toLocaleString();
        const metadataDiv = $("<div>").addClass("paMetadata").prop("title", dateTime).text(time).hide();
        messageDiv.prepend(metadataDiv).appendTo(this.historyWidget)
            .on("mouseenter focusin", () => metadataDiv.show())
            .on("mouseleave focusout", () => metadataDiv.hide());
        this.historyWidget.scrollTop(this.historyWidget.prop("scrollHeight") - messageDiv.outerHeight());
    }
    /**
     * Add follow-up actions on the last message
     */
    addFollowUpActions() {
        if (!this.config.isFollowUpModeEnabled()) {
            return;
        }
        // Find links from the last message
        const messageDiv = $(".paAssistantMessage > .paMessageContent").last();
        const urls = messageDiv.find("a")
            // get the link without hash
            .map((i, element) => element.href.replace(new URL(element.href).hash, ""))
            .filter((i, href) => href.startsWith("http"))
            // skip links that have been included earlier
            .filter((i, href) => !this.core.isInPageContext(href))
            .toArray();
        // Add follow-up actions
        if (urls.length > 0) {
            $("<div>").addClass("paActions").appendTo(messageDiv)
                .append(this.newButton("Dive deeper", "Dive deeper into the links above", () => {
                    this.core.addUrlsToPageContext(urls);
                    this.sendMessage("Please dive deeper into the links you provided and try again.");
                }));
        }
    }
    /**
     * Build the chat history 
     */
    buildChatHistory() {
        const chatHistory = this.historyWidget.children(".paAssistantMessage, .paHumanMessage").map((i, element) => {
            const role = (element.className === "paAssistantMessage") ? "Assistant" : "Human";
            return { "role": role, "message": $(element).children(".paMessageContent").html() }
        }).toArray();
        // remove the first greeting message from assistant which is unnecessary
        if (chatHistory.length && chatHistory[0].role === "Assistant") chatHistory.shift();
        return chatHistory;
    }
}

/*
* ===============================================
* Settings View
* ===============================================
*/
const SettingsView = class extends BaseView {
    /**
     *  @param {PowerChatConfig} config
     *  @param {PowerChatCore} core
     */
    constructor(config, core) {
        super("Settings", "Show Settings", true, config.isDebugModeEnabled());
        this.config = config;
        this.core = core;
    }
    /**
     * Render the view
     */
    render(view) {
        view.empty();
    }
}

/*
* ===============================================
* Context View
* ===============================================
*/
const ContextView = class extends BaseView {
    /**
     *  @param {PowerChatContext} context
     *  @param {PowerChatCore} core
     */
    constructor(config, core) {
        super("Context", "Show Context", true, config.isDebugModeEnabled());
        this.config = config;
        this.core = core;
    }
    /**
     * Render the view
     */
    render(view) {
        view.empty();
        this.core.loadPageContext((pageContext) => {
            Object.keys(pageContext).forEach((url) => {
                this.newSection(this.core.getUrlDisplayName(url))
                    .append(this.newObjectTable(pageContext[url]))
                    .appendTo(view);
            })
        })
    }
}

/*
* ===============================================
* Logs View
* ===============================================
*/
const LogsView = class extends BaseView {
    /**
     *  @param {PowerChatConfig} config
     *  @param {PowerChatCore} core
     */
    constructor(config, core) {
        super("Logs", "Show Logs", true, config.isDebugModeEnabled());
        this.config = config;
        this.core = core;
    }
    /**
     * Render the view
     */
    render(view) {
        view.empty();
        view.append(this.newArrayTable(this.core.logs));
    }
}

/*
* ===============================================
* Main Application
* ===============================================
*/
const PowerChat = class extends BaseUI {
    /**
     * CSS Styles
     */
    static CSS_STYLES = `
.paPageShrink {
    width: calc(100vw - 460px) !important;
    min-width: calc(100vw - 460px) !important;
    box-sizing: border-box;
}
.paPageShift {
    margin-right: 460px !important;
}
.paSidebar {
    background: #313131;
    color: #eee;
    font-family: Tahoma, Verdana;
    font-size: 14px;
    text-align: initial;
    -webkit-font-smoothing: antialiased;
    line-height: normal;
    word-wrap: break-word;
    position: fixed;
    z-index: 99999999;
    bottom: 5px;
    right: 5px;
    width: 30px;
    height: 30px;
    opacity: 0.2;
    border-radius: 15px;
    box-shadow: 0px 0px 10px 5px rgba(0, 0, 0, 0.2);
    overflow: hidden;
    display: flex;
    flex-direction: column;
}
.paSidebar:hover {
    opacity: 0.5;
}
.paSidebar.active {
    display: flex;
    bottom: 0px;
    right: 0px;
    width: 460px;
    height: 100%;
    opacity: 1;
    border-radius: 0;
}
.paSidebar * {
    color: inherit;
    background: inherit;
    line-height: inherit;
    font-size: inherit;
}
.paSidebar *:focus {
    outline: 1px solid #4af !important;
    box-shadow: none;
}
.paSidebar.active .paIcon {
    display: none;
}
.paSidebar .paIcon {
    font-weight: bold;
    font-size: 22px;
    text-align: center;
    min-height: 30px;
    border: 1px solid white;
    border-radius: 15px;
    cursor: default;
}
.paSidebar .paTitleContainer {
    margin: 10px 15px 5px 15px;
    color: #aaa;
}
.paSidebar .paTitle{
    font-size: 24px;
    font-weight: bold;
    margin: 0 10px 0 0;
    color: #eee;
}
.paSidebar .paWindowButton {
    font-size: 16px;
    height: 20px;
}
.paSidebar .paCost {
    float: right;
    padding-top: 7px;
}
.paSidebar .paTipsContainer {
    margin: 5px 15px;
    color: #aaa;
}
.paSidebar .paButtonContainer {
    margin: 10px 15px 0;
    height: 30px;
}
.paSidebar .paButtonContainer .paButton {
    border-radius: 5px 5px 0 0;
}
.paSidebar .paButtonContainer .paButton.selected {
    border-bottom: hidden;
}
.paSidebar .paViewContainer {
    padding: 10px 15px;
    display: flex;
    flex-direction: column;
    flex: auto;
    overflow: auto;
    background: #222;
}
.paSidebar .paView {
    display: none;
}
.paSidebar .paView.selected {
    display: flex;
    flex-direction: column;
    flex: auto;
    overflow: auto;
}
.paSidebar .paHistoryWidget {
    margin: 5px 0;
    flex: auto;
    overflow: auto;
    line-height: 20px;
    color: white;
}
.paSidebar .paShortcutWidget {
    margin: 5px 0;
    min-height: 30px;
}
.paSidebar .paShortcutWidget > * {
    display: inline-block;
    margin-right: 4px;
}
.paSidebar .paInputWidget {
    margin: 5px 0;
    display: flex;
    flex-direction: row;
}
.paSidebar .paContextWidget {
    color: #aaa;
}
.paSidebar .paHistoryContext {
    max-height: 150px;
    overflow-y: auto;
}
.paSidebar .paSection {
    display: flex;
    flex-direction: column;
    margin: 5px 0 10px;
}
.paSidebar .paDescription {
    color: #aaa;
}
.paSidebar .paClickableView {
    cursor: pointer;
    min-height: 40px;
    white-space: pre-line;
}
.paSidebar .paHumanMessage {
    position: relative;
    margin: 10px 10px 10px 40px;
    padding: 5px;
    border: 1px solid #666;
    border-radius: 5px;
    background: #313131;
    white-space: pre-wrap;
}
.paSidebar .paAssistantMessage {
    position: relative;
    margin: 10px 50px 10px 0;
    padding: 5px;
    border: 1px solid #666;
    border-radius: 5px;
    background: #313131;
    white-space: pre-wrap;
}
.paSidebar .paMetadata {
    position: absolute;
    right: -10px;
    top: -6px;
    color: #aaa;
    font-size: 12px;
    border: #555 solid 1px;
    border-radius: 3px;
    padding: 0 5px;
    user-select: none;
}
.paSidebar .paMetadata * {
    font-size: 12px;
}
.paSidebar .paActions {
    margin: 10px 0 0;
}
.paSidebar .paInput {
    font-size: 14px;
    line-height: 20px;
    background: #313131 !important;
    padding: 6px 12px !important;
    border: 1px solid !important;
    border-radius: 5px !important;
    box-shadow: none !important;
    color: #eee !important;
    height: 60px;
    min-height: 60px;
    resize: none;
    flex: auto;
}
.paSidebar .paInput::placeholder {
    color: darkgray;
    opacity: 0.7;
}
.paSidebar .paProgress {
    display: none;
    width: 25%;
    height: 3px;
    bottom: 0px;
    position: absolute;
    background: linear-gradient(to left, #4af 0%, #0ff 100%);
    animation: flash-move 2s linear infinite;
}
@keyframes flash-move {
    0% { transform: translateX(-100%); }
    50% { transform: translateX(400%); }
    100% { transform: translateX(-100%); }
}
.paSidebar ul, .paSidebar ol {
    margin: 0;
    padding-inline-start: 20px;
}
.paSidebar li {
    background: #313131;
    line-height: 20px !important;
}
.paSidebar table {
    border-spacing: unset;
    margin: 5px 0;
}
.paSidebar table tr td, .paSidebar table tr th {
    background: #313131 !important;
    color: #eee !important;
    white-space: normal;
    padding: 10px;
    border: 1px solid #666;
    line-height: 20px;
    font-size: 14px;
}
.paSidebar table tr:first-of-type td, .paSidebar table tr:first-of-type th {
    background: #3c3c3c !important;
    font-weight: bold;
}
.paSidebar table tr td div{
    max-height: 200px; 
    overflow-x: hidden;
    overflow-y: auto;
}
.paSidebar p, .paSidebar a, .paSidebar li, .paSidebar a {
    font-size: 14px !important;
    font-family: Tahoma, Verdana !important;
}
.paSidebar h1, .paSidebar h2, .paSidebar h3, .paSidebar h4, .paSidebar h5, .paSidebar h6 {
    color: white !important;
    margin: 10px 0 !important;
    font-family: Tahoma, Verdana !important;
}
.paSidebar a {
    color: white !important;
    text-decoration: underline;
}
.paSidebar a:visited {
    color: lightgrey !important;
}
.paSidebar a:hover {
    color: white !important;
}
.paSidebar p {
    margin: 5px 0;
    line-height: 20px !important;
}
.paSidebar pre, .paSidebar code {
    background: #111;
    color: #fff;
    border: 0;
    border-radius: 5px;
    padding: 5px;
    font-family: monospace;
    font-size: 12px;
}
.paSidebar pre {
    white-space: pre-wrap;
    margin: 5px 0;
}
.paSidebar sup {
    font-size: 80%;
    top: -0.5em;
}
.paSidebar label {
    font-weight: normal;
    margin: 5px 0 0;
    display: flex;
}
.paSidebar input[type=checkbox] {
    margin: 0 5px 0 0;
}
.paSidebar .paMenu {
    position: relative;
}
.paSidebar .paMenu .paPopupMenu {
    position: absolute;
    background: #313131;
    border: outset white 1px;
    border-radius: 5px;
    left: -1px;
    right: -1px;
    bottom: -1px;
}
.paSidebar .paMenu .paPopupMenu * {
    pointer-events: auto;
    min-width: 100%;
    border: none;
    background: none;
}
button.paButton {
    display: inline;
    margin: 0;
    padding: 3px 10px 3px;
    cursor: pointer;
    border: outset white 1px;
    border-radius: 5px;
    background: #313131;
    color: lightgrey !important;
    font-size: 14px;
    font-weight: normal !important;
    font-family: Tahoma, Verdana;
    text-shadow: none;
    width: initial;
    height: initial;
    min-height: 30px;
    min-width: initial;
}
button.paButton > div {
    overflow: hidden;
    text-overflow: ellipsis;
}
button.paButton:not([disabled]):hover {
    color: white !important;
    background: #313131 !important;
}
button.paButton[disabled] {
    cursor: default;
    color: #999;
}
button.paButton.selected {
    cursor: default;
    color: #ffffff !important;
    background: #222 !important;
    font-weight: bold;
}
button.paButton.pressed {
    border: inset;
}
button.paButton.noborder {
    border: none;
    padding: 0 5px;
    background: none !important;
    color: inherit !important;
    min-height: initial;
    margin: 0 1px 0 5px;
}
.right {
    margin: 0 5px;
    float: right;
}
`;
    constructor() {
        super();
        // Init dependencies
        this.config = new PowerChatConfig();
        this.core = new PowerChatCore(this.config);
        // Create the sidebar
        this.sidebar = $('<div>').addClass("paSidebar").appendTo($('body'));
        this.chatView = new ChatView(this.config, this.core);
        this.settingsView = new SettingsView(this.config, this.core);
        this.contextView = new ContextView(this.config, this.core);
        this.logsView = new LogsView(this.config, this.core);
        // plugins
        this.plugins = [
            new TextSelectionShortcutPlugin(this),
            new CommentShortcutPlugin(this),
            new PredefinedPromptPlugin(this),
            new SavedPromptsPlugin(this),
        ];
        this.init();
    }
    /**
     * Init the sidebar, views and plugins
     */
    init() {
        this.initCss();
        this.setupEvents();
        this.initTitle();
        this.initButtonsAndViews();
        if (this.verify()) {
            this.initPlugins();
        }
    }
    /*
    * Initialize CSS
    */
    initCss() {
        $("head").append($("<style>").prop("type", "text/css").text(PowerChat.CSS_STYLES));
    }
    /**
     * Add events to the sidebar
     */
    setupEvents() {
        let timeoutId;
        // Open the sidebar on mouse enter
        this.sidebar.on('mouseenter', () => {
            // Set a timeout/delay for the activation so that it can be cancelled 
            // if the user moved the mouse away within the timeout period
            timeoutId = setTimeout(() => {
                this.showSidebar();
            }, 500)
        }).on("click", (event) => {
            this.showSidebar();
            event.stopPropagation();
        }).on('mouseleave', () => {
            // Clear the timeout
            clearTimeout(timeoutId);
        });
    }
    /**
     * Show sidebar
     */
    showSidebar() {
        if (this.sidebar.hasClass("active")) return;
        this.keepCenterElementInCenter(); 
        this.sidebar.addClass("active");
        this.adjustOrShiftElements();
        // Lazy load - start new chat only for the first time
        if (this.chatView.historyWidget.is(':empty')) {
            this.chatView.startNewChat();
        }
        // Focus on the input by default
        this.chatView.getInput().trigger("focus");
    }
    /**
     * Adjust/shift website elements as needed
     */
    adjustOrShiftElements() {
        // Find elements that may need to be adjusted
        const fixedPanels = $("div, aside").filter((i, element) =>
            $(element).css("position") === "fixed"
        );
        const headers = $("header, nav");
        const absoluteBodyChildren = $("body>div, body>header, body>aside").filter((i, element) =>
            $(element).css("position") === "absolute"
        );
        const toBeAdjusted = fixedPanels.add(headers).add(absoluteBodyChildren).not(this.sidebar);
        // Shrink elements that are full-width (or close to)
        // Some websites like quip have a full-width div that need to be adjusted
        const shrunk = toBeAdjusted.filter((i, element) => element.offsetWidth / $(document).width() > 0.95)
            .add("body").addClass("paPageShrink");
        // Shift elements that are attached to the right edge (like a sidebar)
        toBeAdjusted.not(shrunk).not(headers).filter((i, element) => parseInt($(element).css("right")) <= 20)
            .addClass("paPageShift");
    }
    /**
     * Hide sidebar
     */
    hideSidebar() {
        if (!this.sidebar.hasClass("active")) return;
        this.keepCenterElementInCenter();
        this.sidebar.removeClass("active");
        $(".paPageShrink").removeClass("paPageShrink");
        $(".paPageShift").removeClass("paPageShift");
    }
    /**
     * Keep the element originally in the center still in the center (after window resize)
     */
    keepCenterElementInCenter() {
        const elementToCenter = document.elementFromPoint($(window).width() / 2, $(window).height() / 2);
        setTimeout(() => {
            elementToCenter.scrollIntoView({ block: "center", inline: "center" })
        }, 0)
    }
    /**
     * Initialize the title section
     */
    initTitle() {
        $("<span>").addClass("paIcon").text("?").appendTo(this.sidebar);
        const titleContainer = $('<div>').addClass("paTitleContainer").appendTo(this.sidebar);
        $("<span>").addClass("paTitle").text("PowerChat").appendTo(titleContainer);
        $("<span>").text('v' + GM_info.script.version).appendTo(titleContainer);
        this.initWindowOperations(titleContainer);
    }
    /**
     * Initialize window operations
     */
    initWindowOperations(titleContainer) {
        // Keyboard operations
        $('body').on('keydown', (event) => {
            if (event.key === "Escape") {
                this.hideSidebar();
            }
        });
        // Init buttons
        this.newTextButton("✕", "Close", () => this.hideSidebar())
            .addClass("right paWindowButton")
            .appendTo(titleContainer);
        this.newTextButton("ⓘ", "Open PowerChat wiki", () =>
            window.open('https://w.amazon.com/bin/view/PowerChat', '_blank'))
            .addClass("right paWindowButton")
            .appendTo(titleContainer);
    }
    /**
     * Initialize all buttons and views
     */
    initButtonsAndViews() {
        const buttonContainer = $('<div>').addClass("paButtonContainer").appendTo(this.sidebar);
        const viewContainer = $('<div>').addClass("paViewContainer").appendTo(this.sidebar);
        this.initView(this.chatView, viewContainer, buttonContainer);
        this.initView(this.settingsView, viewContainer, buttonContainer);
        this.initView(this.contextView, viewContainer, buttonContainer);
        this.initView(this.logsView, viewContainer, buttonContainer);
        // Init cost info
        this.initCostInfo(buttonContainer);
        // select the first view by default
        buttonContainer.children().first().click();
    }
    /**
     * Initialize a view with a button to open and load the view
     * @param {BaseView} view
     */
    initView(view, viewContainer, buttonContainer) {
        // create the view
        const viewWrapper = $('<div>').addClass("paView").appendTo(viewContainer);
        // render the view if needed
        if (!view.lazyLoad) view.render(viewWrapper);
        // create the button
        const button = this.newButton(view.title, view.description, () => {
            viewWrapper.siblings().removeClass("selected");
            viewWrapper.addClass("selected");
            if (view.lazyLoad) {
                view.render(viewWrapper);
            }
        }, true).appendTo(buttonContainer);
        if (!view.visible) button.hide();
    }
    /**
     * Initialize cost info
     */
    initCostInfo(buttonContainer) {
        const costWidget = $("<span>").addClass("paCost")
            .text("$0.00")
            .prop("title", "Estimated cost for the current page view")
            .appendTo(buttonContainer);
        this.core.onEvent("totalCost", (totalCost) => {
            costWidget.text("~$" + totalCost.toFixed(3));
        });
    }
    /**
     * Verify css is working
     */
    verify() {
        if (this.sidebar.css("opacity") === "1") {
            // Avoid showing UI when the desired css is not applied
            console.info("PowerChat is disabled due to blocked css.");
            this.sidebar.remove();
            return false;
        }
        console.info("PowerChat is ready.");
        return true;
    }
    /**
     * Init plugins
     */
    initPlugins() {
        this.plugins.filter((plugin) => plugin.isEnabled()).forEach((plugin) => {
            try {
                plugin.init();
            } catch (error) {
                console.warn("PowerChat: failed to init", plugin.constructor.name, error);
            }
        });
    }
}

/*
* ===============================================
* PowerChat Plugins
* ===============================================
*/
/**
 * Base Plugin
 */
class PowerChatPlugin extends BaseUI{
    /**
     *  @param {PowerChat} powerChat
     */
    constructor(powerChat) {
        super();
        this.powerChat = powerChat;
    }
    /**
     * Check if the plugin is enabled
     */
    isEnabled() { return true; }
    /**
     * Initialize the plugin
     */
    init() { }
}
/**
 * Plugin to enable shortcut buttons via a popup on text selection (e.g., Explain).
 * To get started, select some text on the web page to see the shortcut buttons.
 */
class TextSelectionShortcutPlugin extends PowerChatPlugin {
    /**
     * Css style
     */
    static CSS_STYLES = `
.paSelectionPopup {
    position: fixed;
    z-index: 99999999;
    border-radius: 5px;
    background: #313131;
    padding: 5px 0;
    line-height: initial;
    border: solid #555;
    box-shadow: 0px 0px 5px 0px rgba(0, 0, 0, 0.5);
}
.paSelectionPopup button.paButton {
    border: none;
    padding: 0 5px;
    min-height: initial;
    margin: 0 5px;
}
.paArrowUp {
    position: absolute;
    top: -14px;
    left: 50%;
    transform: translateX(-50%);
    border: solid transparent;
    border-bottom-color: #555;
    border-width: 7px;
}
.paArrowUp:after {
    content: "";
    position: absolute;
    top: -5px;
    left: 50%;
    transform: translateX(-50%);
    border: solid transparent;
    border-bottom-color: #313131;
    border-width: 7px;
}
`;
    /**
     * Popup inactive timeout in ms, after which the popup will be hidden
     */
    static POPUP_INACTIVE_TIMEOUT = 3000;
    /**
     *  @param {PowerChat} powerChat
     */
    constructor(powerChat) {
        super(powerChat);
        this.popup = $("<div>").addClass("paSelectionPopup");
    }
    /**
     * Initialize the plugin
     */
    init() {
        GM_addStyle(TextSelectionShortcutPlugin.CSS_STYLES);
        this.initSelectionPopup();
    }
    /**
     * Init the popup to be shown on text selection
     */
    initSelectionPopup() {
        this.popup.append($("<div>").addClass("paArrowUp")).on("mousedown", () => {
            return false; // cancel mousedown event so that it would not trigger hide()
        }).hide().appendTo("body");
        // hide the popup on resize and scroll
        $(window).on("resize mousedown", () => this.popup.hide());
        document.addEventListener('scroll', () => this.popup.hide(), true);
        // hide the popup after timeout on mouse leave, and clear the timeout on mouse enter
        this.popup.on("mouseleave", () => this.hidePopupAfterDelay())
            .on("mouseenter", () => clearTimeout(this.hidePopupTimer));
        // show the popup on mouse/key up events
        let lastSelectedText = "";
        $(document).on("mouseup keyup", () => {
            // add a bit time to ensure the selection has been updated
            setTimeout(() => { 
                const selectedText = window.getSelection().toString().trim();
                if (selectedText === lastSelectedText) return;
                lastSelectedText = selectedText;
                if (!selectedText) {
                    this.popup.hide();
                    return;
                }
                this.renderPopup(selectedText);
            }, 0);
        });
    }
    /**
     * Render popup for the selected text
     */
    renderPopup(selectedText) {
        this.popup.find("button").remove();
        this.addExplainButtonToPopup(selectedText);
        if (this.popup.find("button").length) {
            // Show popup below the last rect
            const lastRect = [...window.getSelection().getRangeAt(0).getClientRects()].pop();
            if (!lastRect) return;
            const x = Math.max(0, lastRect.left + (lastRect.width - this.popup.outerWidth()) / 2,
                lastRect.right - this.popup.outerWidth());
            const y = lastRect.bottom + 10;
            this.popup.css({ left: x + "px", top: y + "px" }).show();
            this.hidePopupAfterDelay();
        } else {
            this.popup.hide();
        }
    }
    /**
     * Add an explain button to popup for selected text
     */
    addExplainButtonToPopup(selectedText) {
        // Skip if the selected text is too short or has multi lines
        if (selectedText.length < 2 || selectedText.includes("\n")) return;
        this.addButtonToPopup("Explain", `Explain the selected text`, `Please explain: ${selectedText}`);
    }
    /**
     * Add a button to the popup
     */
    addButtonToPopup(buttonText, buttonTitle, message, elementToSelectOnHover) {
        const originalSelection = [window.getSelection().anchorNode, window.getSelection().anchorOffset, window.getSelection().focusNode, window.getSelection().focusOffset];
        const button = this.newButton(buttonText, buttonTitle, () => {
            this.powerChat.showSidebar();
            this.powerChat.chatView.sendMessage(message);
            this.popup.hide();
            // Restore the original selection
            window.getSelection().setBaseAndExtent(originalSelection[0], originalSelection[1],
                originalSelection[2], originalSelection[3])
        }).appendTo(this.popup);
        // Change/restore selection if needed
        if (elementToSelectOnHover) {
            button.on("mouseenter focusin", () => window.getSelection().selectAllChildren(elementToSelectOnHover))
                .on("mouseleave focusout", () => window.getSelection().setBaseAndExtent(originalSelection[0],
                originalSelection[1],originalSelection[2], originalSelection[3]));
        }
    }
    /**
     * Hide the popup after some delay
     */
    hidePopupAfterDelay() {
        clearTimeout(this.hidePopupTimer);
        this.hidePopupTimer = setTimeout(() => {
            this.popup.hide();
        }, TextSelectionShortcutPlugin.POPUP_INACTIVE_TIMEOUT);
    }
}

/**
 * Plugin to enable shortcut buttons for drafting replies to comments. 
 * Only available at quip-amazon.com for now.
 * To get started, open Quip comment box and hover over any comment to see the shortcut buttons.
 */
class CommentShortcutPlugin extends PowerChatPlugin {
    
    /**
     * Mapping from websites to their comment selectors
     */
    static WEBSITE_COMMENT_SELECTORS = {
        "quip-amazon.com": {
            "onMouseover": 'div.spreadsheet-cell[aria-description="Has comment"]',
            "onClick": "annotation, article.clickable, div.clickable",
            "message": "div.popover .thread-message",
            "messageButtons": ".message-buttons-body",
            "messageContent": ".thread-message-content",
        }
    };
    /**
     * Delay to wait for the comments to be loaded before rendering the buttons (in ms)
     */
    static DELAY_1ST_RENDER_ATTEMPT = 600;
    static DELAY_2ND_RENDER_ATTEMPT = 2000;
    /**
     *  @param {PowerChat} powerChat
     */
    constructor(powerChat) {
        super(powerChat);
        this.messageSelector = CommentShortcutPlugin.WEBSITE_COMMENT_SELECTORS[window.location.hostname];
    }
    /**
     * Initialize the plugin
     */
    init() {
        if (!this.messageSelector) return;
        // add buttons after a bit delay on trigger events
        $(this.messageSelector["onMouseover"]).on("mouseover", () => {
            setTimeout(() => this.addShortcutButtons(), CommentShortcutPlugin.DELAY_1ST_RENDER_ATTEMPT);
            setTimeout(() => this.addShortcutButtons(), CommentShortcutPlugin.DELAY_2ND_RENDER_ATTEMPT);
        });
        $(this.messageSelector["onClick"]).on("click", () => {
            setTimeout(() => this.addShortcutButtons(), CommentShortcutPlugin.DELAY_1ST_RENDER_ATTEMPT);
            setTimeout(() => this.addShortcutButtons(), CommentShortcutPlugin.DELAY_2ND_RENDER_ATTEMPT);
        });
    }
    /**
     * Add shortcut buttons for each message
     */
    addShortcutButtons() {
        $(this.messageSelector["message"]).each((i, node) => {
            // For each message, check if the button has been added
            const buttons = $(node).find(this.messageSelector["messageButtons"]);
            if (!buttons.find(".paButton").length) {
                // Add a reply button
                this.newTextButton("Reply", "Draft a reply to this message", () => {
                    const content = $(node).find(this.messageSelector["messageContent"]).text();
                    this.powerChat.showSidebar();
                    this.powerChat.chatView.sendMessage(`Please draft a concise reply to this message:\n${content}`);
                }).appendTo(buttons);
            }
        })
    }
}

/**
 * Plugin to enable predefined prompts on chat tab (e.g., summarize main idea).
 * To get stated, go to the Chat tab and see the predefined prompts next to the New Chat button.
 */
class PredefinedPromptPlugin extends PowerChatPlugin {
    
    /**
     * Default prompt group map from display names to prompts
     */
    static DEFAULT_PROMPT_GROUP_MAP = {
        "Summarize": {
            "FAQ": "Please summarize a concise FAQ based on the current page.",
            "Terms": "Please summarize a list of terminologies and their definitions based on the current page.",
            "Executive Summary": "Please provide an executive summary of the current page including issue summary, status, customer impact, mitigation/resolution and next steps.",
            "Problem / Solution": "Please summarize the key problems and solutions discussed on the current page if any.",
            "Main Idea": "Please summarize the main idea of the current page.",
        },
        "Suggest": {
            "Further Reading": "Please suggest related pages for further reading if any.",
            "Title": "Please suggest a few titles for the current page."
        }
    }
    /**
     * Override prompt group map by website host name
     */
    static WEBSITE_PROMPT_GROUP_OVERRIDES = {
    };
    /**
     *  @param {PowerChat} powerChat
     */
    constructor(powerChat) {
        super(powerChat);
    }
    /**
     * Initialize the plugin
     */
    init() {
        const promptGroupMap = {
            ...PredefinedPromptPlugin.DEFAULT_PROMPT_GROUP_MAP,
            ...PredefinedPromptPlugin.WEBSITE_PROMPT_GROUP_OVERRIDES[window.location.hostname]
        };
        for (const groupName in promptGroupMap) {
            const promptGroup = promptGroupMap[groupName];
            const promptButtons = Object.keys(promptGroup).map((name, i) => {
                const prompt = promptGroup[name];
                return this.newButton(name, prompt, () => {
                    this.powerChat.chatView.sendMessage(prompt);
                });
            });
            const triggerButton = this.newButton(groupName, groupName);
            this.newPopupMenu(triggerButton, promptButtons)
                .appendTo(this.powerChat.chatView.shortcutWidget);
        }
    }
    /**
     * Render a popup menu on the given trigger element on hover/focus
     */
    newPopupMenu(triggerElement, menuElements) {
        triggerElement.addClass("paMenu")
            .on("mouseenter keyup", (event) => {
                // Skip if the trigger element is disabled
                if (triggerElement.prop('disabled')) return;
                // Show the menu on mouseenter
                if (event.type === 'mouseenter') {
                    menuPopup.show();
                }
                // Show and focus on the menu on Enter or Space
                if (event.key === 'Enter' || event.key === ' ') {
                    menuPopup.show();
                    menuPopup.children().last().trigger("focus");
                }
                // Move focus on arrow up or down
                if (event.key === 'ArrowUp') {
                    menuPopup.find(":focus").prev().trigger("focus");
                } else if (event.key === 'ArrowDown') {
                    menuPopup.find(":focus").next().trigger("focus");
                }
            })
            .on("mouseleave focusout", () => setTimeout(() => {
                // Hide the menu if none of the menu item has focus (wait a bit to check the latest focus)
                if (!menuPopup.find(":focus").length) {
                    menuPopup.hide();
                }
            }))
        const menuPopup = $("<div>").addClass("paPopupMenu").append(menuElements).hide()
            .on("mouseup keypress", (event) => {
                // Hide the menu on mouseup or Enter or Space
                if (event.type === 'mouseup' || event.key === 'Enter' || event.key === ' ') {
                    menuPopup.hide();
                }
            });
        return triggerElement.append(menuPopup);
    }
}


/**
 * Plugin to enable saved prompts on chat tab.
 * To save a prompt, hover over a sent message and click ☆. 
 * To use a saved prompt, click "★" button to show all and click one to edit.
 */
class SavedPromptsPlugin extends PowerChatPlugin {
    /**
     * Css style
     */
    static CSS_STYLES = `
.paSavedPrompts {
    white-space: nowrap;
    overflow: auto hidden;
    min-height: 32px;
    padding-top: 4px;
    color: lightgray;
}
.paSavedPrompts > button.paButton {
    max-width: 260px;
    margin: 1px 6px 1px 1px;
}
`;
    /**
     *  @param {PowerChat} powerChat
     */
    constructor(powerChat) {
        super(powerChat);
    }
    /**
     * Initialize the plugin
     */
    init() {
        GM_addStyle(SavedPromptsPlugin.CSS_STYLES);
        this.addSaveButtons(this.powerChat.chatView.historyWidget);
        this.addMyPromptsButton(this.powerChat.chatView.shortcutWidget);
    }
    /**
     * Add the save buttons on all human messages
     */
    addSaveButtons(historyWidget) {
        historyWidget.on("mouseover", () => {
            historyWidget.find(".paHumanMessage").each((i, element) => {
                const metadataDiv = $(element).find(".paMetadata");
                if (metadataDiv.find(".paButton:contains('☆')").length) return;
                // Add save button in the message metadata
                const saveButton = this.newTextButton("☆", "Save as my prompt", () => {
                    this.savePrompt($(element).find(".paMessageContent").text());
                    this.reloadSavedPrompts();
                    saveButton.fadeOut();
                }).appendTo(metadataDiv);
            })
        })
    }
    /**
     * Add a button to show all my prompts
     */
    addMyPromptsButton(shortcutWidget) {
        this.promptDiv = $("<div>").addClass("paSavedPrompts").hide()
            .insertAfter(shortcutWidget);
        this.myPromptsButton = this.newToggleButton("★", "Manage my saved prompts", () => {
            if (this.promptDiv.is(":hidden")) this.reloadSavedPrompts();
            this.promptDiv.toggle();
        }).addClass("right").appendTo(shortcutWidget);
    }
    /**
     * Reload saved prompts
     */
    reloadSavedPrompts() {
        this.promptDiv.empty();
        const prompts = this.getSavedPrompts();
        prompts.forEach((prompt) => {
            // create a button for each prompt
            const promptButton = this.newTextButton(prompt, prompt, () => {
                this.powerChat.chatView.updateInputMessage(prompt);
            }).appendTo(this.promptDiv);
            this.newFloatButton(promptButton, "✕", "Remove", () => {
                this.removePrompt(prompt);
                this.reloadSavedPrompts();
            });
        });
        if (!prompts.length) {
            this.promptDiv.append("To save a prompt here, hover over a sent message and click ☆.");
        }
    }
    /**
     * Get saved prompts as below
     * [<prompt>, ...]
     */
    getSavedPrompts() {
        return GM_getValue("mySavedPrompts", []);
    }
    /**
     * Set saved prompts as below
     * [<prompt>, ...]
     */
    setSavedPrompts(config) {
        return GM_setValue("mySavedPrompts", config);
    }
    /**
     * Save a prompt
     */
    savePrompt(prompt) {
        const prompts = this.getSavedPrompts();
        if (prompts.includes(prompt)) {
            // Remove prompt first if already exist
            const index = prompts.indexOf(prompt);
            if (index >= 0) prompts.splice(prompts.indexOf(prompt), 1);
        }
        // Add the prompt to the beginning
        prompts.unshift(prompt);
        return this.setSavedPrompts(prompts);
    }
    /**
     * Remove a prompt
     */
    removePrompt(prompt) {
        const prompts = this.getSavedPrompts();
        const index = prompts.indexOf(prompt);
        if (index >= 0) prompts.splice(prompts.indexOf(prompt), 1);
        this.setSavedPrompts(prompts);
    }
}

/*
* ===============================================
* Utilities
* ===============================================
*/
/**
 * Transform tables and headings in Quip doc
 */
function transformQuip(jDoc) {
    // Remove outline and deleted contents
    jDoc.find(".editor-outline, .deleted").remove();
    // Transform headings
    jDoc.find("div.section[aria-level='1']").replaceWith((i, html) => {
        return $("<h1>", { html: html });
    });
    jDoc.find("div.section[aria-level='2']").replaceWith((i, html) => {
        return $("<h2>", { html: html });
    });
    jDoc.find("div.section[aria-level='3']").replaceWith((i, html) => {
        return $("<h3>", { html: html });
    });
    // Transform tables
    jDoc.find("div.grid-table").map((i, table) => {
        $(table).find("div.spreadsheet-cell.header").remove();
        $(table).find("div.spreadsheet-cell").toArray().reduce((cellsByIndex, currentCell) => {
            const rowIndex = currentCell.getAttribute("data-spreadsheet-cell-row");
            const cells = cellsByIndex[rowIndex] ?? [];
            cells.push(currentCell);
            cellsByIndex[rowIndex] = cells;
            return cellsByIndex;
        }, []).forEach((cells, i) => {
            const tr = $("<tr>").appendTo($(cells).parent().first());
            $(cells).remove().appendTo(tr).replaceWith((i, html) => {
                return $("<td>", { html: html });
            });
        });
        return table;
    }).replaceWith((i, html) => {
        return $("<table>", { html: html });
    });
    return jDoc;
}
/**
 * Simplify HTML Tags
 */
function simplifyHtml(html) {
    const jNode = $(html ?? "");
    // Remove PowerChat itself from the html (introduced by readability)
    jNode.find("p > span").filter((i, element) => element.textContent === "PowerChat")
        .parent().prev().filter((i, element) => element.textContent === "?")
        .parent().remove();
    const readableHtml = parseReadableHtmlFromNodes(jNode)
        // replace two line breaks with one, and more line breaks with two
        .replace(/\n\s/g, "\n")
        .replace(/\n\s+\n/g, "\n\n");
    return scrubPii(readableHtml);
}
/**
 * Scrub Personal Identifiable Information (PII)
 */
const piiPatterns = {
    "[redacted SSN]": /\b\d{3}[-. ]\d{2}[-. ]\d{4}\b/g, // Social Security Numbers
    "[redacted card number]": /\b\d{4}[-. ]\d{4}[-. ]\d{4}[-. ]\d{4}\b/g, // Card Numbers
    "[redacted email]": /\b[\w-.%+]+@[\w-.]+\.[A-Z|a-z]{2,}\b/g, // Email Addresses
    "[redacted order ID]": /\b\d{3}-\d{7}-\d{7}\b/g, // Order ID
    "[redacted ID]": /(?<=(IDs?|ID\(s\)|Customer|Merchant|Seller):?\s*)\d{7,12}(?=[^-\w]|$)/ig, // Customer/Merchant/Seller ID
    "[redacted phone number]": /(?<=[^-\w])(\+\d{10,14}|\d{4}([ -]\d{3,4}){1,2}|(\(\d{1,3}\)|\d{1,3}[ -])([ -]?\d{2,4}){2,4})(?=[^-\w]|$)/g, // Phone Numbers
};
function scrubPii(text) {
    let scrubbedText = text;
    Object.entries(piiPatterns).forEach(([redacted, regex]) => {
        scrubbedText = scrubbedText.replace(regex, redacted);
    });
    return scrubbedText;
}
/**
 * Parse minimized but readable HTML from nodes
 */
const tagsToRemove = ".paSidebar, head, script, style, link, svg, select, awsui-modal, *[aria-hidden='true']";
const tagsToPreserve = "h1, h2, h3, h4, h5, h6, pre, a, b, strong, button, blockquote, ul, ul > li, img, table, td, tr, th";
const tagsPrependLineBreak = "p, br, div, li";
const tagsWrapSpace = "span";
const tagsPrependSequence = "ol > li";
const tagsCouldBeEmpty = "img, td, th, br";
const attributesToPreserve = ["href", "src"];
const maxAttributeValueLength = 500; // avoid too-long href or src
function parseReadableHtmlFromNodes(nodes) {
    return nodes.map((i, node) => {
        // Keep text nodes
        if (node.nodeType === 3) return node.textContent;
        // Remove unwanted node
        const jNode = $(node);
        if (jNode.is(tagsToRemove)) return "";
        // Look into child nodes
        let readableHtml = parseReadableHtmlFromNodes(jNode.contents());
        // Remove empty tags unless explicitly allowed
        if (!readableHtml.length && !jNode.is(tagsCouldBeEmpty)) return "";
        // Remove all attributes except the allowed ones on the preserved node
        if (jNode.is(tagsToPreserve)) {
            let attributesString = "";
            if (node.hasAttributes()) {
                attributesString = attributesToPreserve.map((attr) => {
                    let value = jNode.prop(attr);
                    // Skip unsupported attribute value and truncate long value
                    if (!value || value.startsWith("data:")) return "";
                    if (value.length > maxAttributeValueLength) value = value.substring(0, maxAttributeValueLength);
                    return ` ${attr}="${value}"`;
                }).join("");
            }
            return `<${node.tagName}${attributesString}>${readableHtml}</${node.tagName}>`;
        } else {
            // Otherwise, only keep the child nodes for not preserved nodes, and add prefix/suffix as needed
            if (jNode.is(tagsPrependSequence)) readableHtml = (i + 1) + ". " + readableHtml;
            if (jNode.is(tagsPrependLineBreak)) return "\n" + readableHtml;
            else if (jNode.is(tagsWrapSpace)) return " " + readableHtml + " ";
            return readableHtml;
        }
    }).toArray().join("").trim();
}
/*
* ===============================================
* Entry point
* ===============================================
*/
$(document).ready(function () {
    const jDocument = $(document);
    // skip initialization for small windows
    if (jDocument.width() < 500 || jDocument.height() < 500) {
        return;
    }
    // Skip initialization for iframes
    if ( window.self !== window.top ) {
        return;
    }
    new PowerChat();
});
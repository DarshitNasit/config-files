// ==UserScript==
// @name         SIM Filter Script
// @namespace    http://tampermonkey.net/
// @version      0.1.2
// @description  filter active sprint base on sprint name.
// @author       desun
// @include     https://sim.amazon.com/*
// @include     https://issues.amazon.com/*
// @include     https://issues-pdx.amazon.com/*
// @include     https://i.amazon.com/*
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_addStyle
// @grant       GM_registerMenuCommand
// @require     https://raw.github.com/odyniec/MonkeyConfig/master/monkeyconfig.js
// @updateURL   https://code.amazon.com/packages/InRxYvrScripts/blobs/mainline/--/tampermonkey/sim_filter_script.user.js?download=1
// @downloadURL https://code.amazon.com/packages/InRxYvrScripts/blobs/mainline/--/tampermonkey/sim_filter_script.user.js?download=1
// ==/UserScript==

(function () {
  'use strict';

  let cfg = new MonkeyConfig({
    title: 'SIM Filter Config',
    menuCommand: true,
    params: {
      sprint_filter_string: {
        type: 'text',
        default: 'InRx YVR'
      },
      punt_filter_string: {
        type: 'text',
        default: 'InRx YVR'
      },
      filter_upcoming_sprints: {
        type: 'checkbox',
         default: true
      }
    }
  });

  let sprint_allow_substring = cfg.get('sprint_filter_string');
  let punt_allow_substring = cfg.get('punt_filter_string');
  let filter_upcoming = cfg.get('filter_upcoming_sprints');

  $(document).ajaxComplete(function (event, request, settings) {
    // hide sprints
    let activeSprint = document.getElementById('active-sprints');
    let sprintList = activeSprint.getElementsByTagName('li');
    let sprintnames = sprint_allow_substring
    filterSprints(sprintnames, sprintList);

    if (filter_upcoming) {
       let upcomingSprint = document.getElementById('upcoming-sprints');
       let upcomingSprintList = upcomingSprint.getElementsByTagName('li');
       filterSprints(sprintnames, upcomingSprintList);
    }

    // hide punts
    let list = document.querySelector("#sprint-board-task-reusable-menu > ul > li.sprint-planning-hidden.dropdown-submenu > ul");
    if (list) {
      let longlist = list.getElementsByTagName("li");
      let puntnames = punt_allow_substring
      filterSprints(puntnames, longlist);
    } else {
      console.log("empty list")
    }
  });

  function filterSprints(allowPrefix, sprintList) {
    for (let i = 0; i < sprintList.length; i++) {
      let currentListItem = sprintList[i];
      let title = currentListItem.getElementsByTagName('a')[0].title

      if (!title.includes(allowPrefix)) {
        currentListItem.style.display = 'none';
      }

    }
  }
})();
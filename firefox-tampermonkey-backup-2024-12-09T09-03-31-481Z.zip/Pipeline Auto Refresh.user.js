// ==UserScript==

// @name        Pipeline Auto Refresh 
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/pipeline-auto-refresh.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/pipeline-auto-refresh.user.js
// @namespace   simschmi
// @description Simple script to automatically refresh pipelines when they're marked as out of date.
// @include     https://pipelines.amazon.com/pipelines/*
// @version     1.1
// @grant       none
// @run-at      document-start
// ==/UserScript==

// avoid race condition where update-bubble exists before this script runs
if (document.getElementById("update-bubble") !== null) {
  location.reload();
}

// Callback function to execute when mutations are observed
var callback = function(mutationsList) {
  if (document.getElementById("update-bubble") !== null) {
    setTimeout(function() {
      location.reload();
    }, 3000); // a short sleep to give the user a chance to notice that the page is about to update
  }
};

// Create an observer instance linked to the callback function
var observer = new MutationObserver(callback);

// Options for the observer (which mutations to observe)
var config = { childList: true,
               subtree: true };

// Start observing the target node for configured mutations
observer.observe(document, config);


// ==UserScript==
// @name         Who Am I?
// @namespace    amazon.com
// @version      2.1.0
// @author       odekirk@
// @grant        GM_getValue
// @grant        GM_setValue
// @match        https://access.amazon.com/aws/*
// @match        https://console.aws.amazon.com/*
// @match        https://conduit.security.a2z.com/*
// @match        https://*.console.aws.amazon.com/*
// ==/UserScript==

const name = 'aws-whoami'

; (async function () {

    const ACCOUNT_NODES = `.awsui-table-container td:nth-child(-n + 2)`
        , BURNER_NODES = 'awsui-table table td:nth-child(-n + 2)'
        , AWS_NODE = '#menu--account [data-testid="aws-my-account-details"]'
        , AWS_NODE_NEW_UI = '#menu--account [data-testid="account-detail-menu"]'

    // Who am I?
    const whoami = JSON.parse(await GM_getValue(name) || '{}')

    // Grab the accounts
    const setAccounts = async (selector, flip = false) => {
        const accounts = [...document.querySelectorAll(selector)].map(n => n.innerText)
            , groupedAccounts = accounts.map((_, i) => 
                flip 
                ? [accounts[i * 2 + 1], accounts[i * 2]] 
                : [accounts[i * 2], accounts[i * 2 + 1]]
            )
            , accountMap = Object.fromEntries(groupedAccounts)
        GM_setValue(name, JSON.stringify({...whoami, ...accountMap}))
    }

    // Grab the account
    const singlePageAccount = async () => {
        const accountMap = {};
        const title = document.querySelector('h1').innerText;
        document.querySelectorAll('.awsui-util-label').forEach(node => {
            if (node.innerText.indexOf('Account Number')) {
                accountMap[node.innerText] = title
            }
        })
        GM_setValue(name, JSON.stringify({...whoami, ...accountMap}))
    }

    // Add the account name in the AWS Console drop down
    const showMeWhoIAm = async () => {
        const target = document.querySelector(AWS_NODE)
        if (target) {
            const account = target.innerText
            target.innerText += ` / ${whoami[account]}`
        } else {
            // New AWS UI
            const newUI = document.querySelector(AWS_NODE_NEW_UI)
                , element = newUI.firstElementChild

            if (element) {
                const accountDiv = element.querySelectorAll('span')[1]
                const account = accountDiv.innerHTML.split('-').join('')
                if (whoami[account])
                    accountDiv.parentElement.insertAdjacentHTML('afterend',`
                        <div>
                            <span>Conduit name: </span>
                            <span> ${whoami[account]}</span>
                        </div>
                    `)
            }
        }

    }

    // Do the right thing in the right place
    const whereAmI = // New UI is on a2z.com
        document.URL.indexOf('conduit.security.a2z.com/accounts/aws/') > 0 && 'single' ||
        document.URL.indexOf('conduit.security.a2z.com/accounts') > 0 && 'conduit' ||
        document.URL.indexOf('conduit.security.a2z.com/burner-accounts') > 0 && 'burner' ||
        // AWS console
        document.URL.indexOf('console.aws.amazon.com') > 0 && 'aws'

    const actions = {
        burner: setAccounts.bind(this, BURNER_NODES, true),
        single: singlePageAccount,
        conduit: setAccounts.bind(this, ACCOUNT_NODES),
    }

    const observer = new MutationObserver(() => {
        if (actions[whereAmI]) actions[whereAmI].call()
    })

    // The new AWS conduit UI loads everything via ajax for all pages now
    if (whereAmI === 'aws') showMeWhoIAm()
    else observer.observe(document.getElementById('root'), {childList: true, subtree: true})
})()
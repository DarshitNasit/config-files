// ==UserScript==
// @name         Show account name in pipeline
// @namespace    cnnj
// @version      0.4
// @description  Queries ConduitAccountService to get names for AWS accounts in NAWS pipelines
// @author       cnnj
// @match        https://pipelines.amazon.com/pipelines/*
// @require      https://internal-cdn.amazon.com/sentry.amazon.com/public/javascripts/openid.xhr.js
// @require	     https://internal-cdn.amazon.com/btk.amazon.com/ajax/libs/jquery/1.12.4/jquery.min.js
// @downloadURL  https://drive.corp.amazon.com/view/cnnj%40/public/greasemonkey_scripts/ShowAccountNameInPipeline.user.js?download=true
// @updateURL    https://drive.corp.amazon.com/view/cnnj%40/public/greasemonkey_scripts/ShowAccountNameInPipeline.user.js?download=true
// @grant        GM.xmlHttpRequest
// ==/UserScript==

(function() {
    const cache = {};
    const details = $('.naws-details');

    const getAndWaitFunction = function(details, index) {
        if (index >= details.length) {
            return;
        }
        const detail = details[index];
        const detailSections = $(detail).find('.naws-detail');

        var nextTimeout = 500;
        const accountDetailSection = $(detail).find('[title="AWS Account"]');
        const accountId = accountDetailSection.text().trim();
        const partition = $(detail).find('[title="Region"]').text().trim().startsWith("cn-") ? "aws-cn" : "aws";

        if (accountId in cache) {
            nextTimeout = 0;
            const accountName = cache[accountId];
            $(accountDetailSection).append(" | " + accountName);
        } else {
            // get data from conduit
            const data = {"identifier":
                          {"partition": partition,
                           "accountId": accountId}};
            GM.xmlHttpRequest({
                method: "POST",
                url: "https://conduitaccountservice-midway-iad.iad.proxy.amazon.com/",
                headers: {
                    "Accept": "application/json, text/javascript, */*",
                    'Content-Encoding': 'amz-1.0',
                    'Content-Type': 'application/json;charset=UTF-8',
                    'X-Amz-Target': 'com.amazon.conduitaccountservice.ConduitAccountService.GetAwsAccount'
                },
                data: JSON.stringify(data),
                onload: function(response) {
                    if (response.status == 200) {
                        const accountName = JSON.parse(response.responseText).account.name;
                        cache[accountId] = accountName;
                        $(accountDetailSection).append(" | " + accountName);
                    }
                }
            });
        }

        // The conduit API has pretty low throttling thresholds, so only call them once per 500ms
        setTimeout(() => getAndWaitFunction(details, index + 1), nextTimeout);
    };

    getAndWaitFunction(details, 0);
})();
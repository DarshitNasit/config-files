// ==UserScript==
// @name         Quip2Wiki
// @namespace    com.amazon.corp.quip2wiki
// @website      https://w.amazon.com/bin/view/Quip2Wiki
// @downloadURL  https://w.amazon.com/rest/wikis/xwiki/spaces/Quip2Wiki/spaces/Releases/pages/WebHome/attachments/Quip2Wiki-beta.user.js
// @updateURL    https://w.amazon.com/rest/wikis/xwiki/spaces/Quip2Wiki/spaces/Releases/pages/WebHome/attachments/Quip2Wiki-beta.user.js
// @version      1.26.5.0
// @description  Greasemonkey script for exporting Quip documents to Amazon Wiki
// @author       Jorge Miguel Ribeiro (jorgemrb@amazon.com)
// @match        https://quip-amazon.com/*
// @match        https://*.quip-amazon.com/*
// @match        https://*.quip-amazon-elements.com/*
// @match        https://w.amazon.com/bin/view/*
// @match        https://w.amazon.com/bin/viewrev/*
// @match        https://w.amazon.com/index.php/*
// @connect      quip-amazon.com
// @connect      platform.quip-amazon.com
// @connect      w.amazon.com
// @connect      maxis-service-prod-iad.amazon.com
// @connect      midway-auth.amazon.com
// @connect      axzile.corp.amazon.com
// @connect      drive.corp.amazon.com
// @connect      drive-render.corp.amazon.com
// @connect      drive-webdav.corp.amazon.com
// @connect      phonetool.amazon.com
// @connect      aea.aka.amazon.com
// @connect      0s62bmu3aj.execute-api.us-east-1.amazonaws.com
// @connect      document-versions-production.s3.us-west-2.amazonaws.com
// @connect      cloudfront.net
// @require      https://m.media-amazon.com/images/I/6122cXQRH3L.js#ver=jquery-3.6.0.min.js
// @require      https://m.media-amazon.com/images/I/71nb5TqP9pL.js#ver=jquery-ui-1.12.1.min.js
// @resource     jquery-ui-css https://m.media-amazon.com/images/I/41AE8Qt0umL.css#ver=jquery-ui-1.12.1.min.css
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_xmlhttpRequest
// @grant        GM_openInTab
// @grant        GM_addStyle
// @grant        GM_getResourceText
// @grant        GM_registerMenuCommand
// @grant        unsafeWindow
// ==/UserScript==

/** FORCE_UPDATE = false */

/**
 * Releases:
 * 1.26.5 - Improved logger and added a in-page log visualizer. Added ability to copy improved log to clipboard or download it to a file.
 * 1.26.4 - Added version information to dialog title bars. Improved performance of toolbar creation and removed no longer necessary retries.
 * 1.26.3 - Improved creation and placement of the export button. Fixed close button in dialog modals, improved resize handling and removed delay to adding the export button. Replaced resource URLs with their corresponding asset freeze URLs
 * 1.26.2 - Fixed "email is undefined" error (thanks huijbers@!). Added workaround for export button not showing in certain documents and spreadsheets.
 * 1.26.1 - Added workaround for space-like chars that are not supported by the Amazon wiki. Thanks xuyuhui@!
 * 1.26.0 - Added error extraction for errors that happen in the wiki. This should show the actual error cause more frequently. Also highlights any unusual chars that may not be supported by the wiki.
 * 1.25.6 - Added workaround to "too much recursion" error when processing "--wiki-ignore--" tags. Not a complete solution, since the complete solution will require refactoring the XHtmlConverter completely to use a DOMParser.
 * 1.25.5 - Fix duplicated HTML content when a column is completely encapsulated in a code block.
 * 1.25.4 - Added an easier way to add a tracker pixel to the exported wiki page. Removed unused toolbox related functions. Removed all uses of the Kerberos service.
 * 1.25.3 - Fix transient error calling the registerQuipUserApiError function. Fixed small bugs with the new option tag.
 * 1.25.2 - Added image size override option. This is useful when putting images inside table cells, to controll their size.
 * 1.25.1 - Improved the update behavior with the new authentication error handling - now we only try to update after an export process (whether it succeeded or not)
 * 1.25.0 - Improved authentication error handling. Now when an authentication error happens, we ask the user to click a link to authenticate in the specific website and then continue the exporting process.
 * 1.24.8 - Added better support for Safari
 * 1.24.7 - Handle tilde '~' characters correctly when the syntax is XWiki
 * 1.24.6 - Improve image centering with the tag '--wiki-options:"fixImageCentering"--'
 * 1.24.5 - Fix "RangeError: invalid date" that happened in some cases.
 * 1.24.4 - Fix possible "Too much recursion" error in Regex. Fixed alt update endpoints.
 * 1.24.3 - Fix edge-case of video blob IDs which break wiki rendering
 * 1.24.2 - Reduce max attachment size to a little bit under 1.9MB (new limit from the wiki since around 2023-07-27). Update prod and beta update endpoints and increased update request timeout (from tests the scripts usually take more than 5 seconds to load)
 * 1.24.1 - Fix invalid XHTML in some cases when aligning images in lists. (beta)
 * 1.24.0 - Improve the conversion of Quip mentions to Phonetool mentions, with a LRU local data cache. Fixed handling attachments with URI-encodable characters in their name. Updated trackers and added trackers to the Quip User API. (beta)
 * 1.23.15 - Add option to fix image centering in some wiki styles (by adding the tag '--wiki-options:"fixImageCentering"--')
 * 1.23.14 - Fix folder export
 * 1.23.13 - Fix image upload
 * 1.23.12 - Retrieve username from midway instead of kerberos, which makes it compatible with AEA / Unfabric
 * 1.23.11 - fix DI inspector issue, prompt for large file attachments, minor bug fixes
 * 1.23.10 - switch to internal CDN, allow dialog close button, fix attachments file ext
 * 1.23.9 - fix minor bugs
 * 1.23.8 - fix tab order, xwiki spreedsheet with tabs, move to how-many metrics
 * 1.23.7 - fix tag change, sort folder index, remove daily ping
 * 1.23.6 - improve recovery from backup, make videos embedded
 * 1.23.5 - fix adding wiki-sync tag on doc, support for di-inspector
 * 1.23.2 - fix api token storage, xwiki styling, and other fixes 
 * 1.23.0 - fix folder index export, comments with unescaped chars, math formulas, list continuation, added support to XWiki syntax via --wiki-syntax-- tag (experimental)
 * 1.22.8 - Fix wiki API endpoint
 * 1.22.7 - Fix image url attachment regex (Q2W-146)
 * 1.22.5/1.22.6 - fix issue with JSON parsing (Q2W-135) and table regex matching
 * 1.22.4 - fix issue with new Drive's webdav endpoints (Q2W-114)
 * 1.22.3 - disable change monitor which was causing Quip backend to throttle API calls (Q2W-110)
 * 1.22.2 - fix empty export, change monitor, quip rate limiter, multiple header/footer, adds wiki-banner, classic toc, syntax fixes
 * 1.22.1 - replaceAll bug fix (Q2W-64)
 * 1.22.0 - adds --wiki-comments-- tag for exporting comments, reduce table output size
 * 1.21.0/1.21.1/1.21.2/1.21.3 - adds --wiki-sheets-- and --wiki-sortable-tables-- tags, fix image and code blocks in lists, change default user space, connection check improvements, add multi-column support
 * 1.20.0/1.20.1 - better dialogs/messages, retry logic, sheets as tabs, better network check, Maxis API over Phonetool API (no Midway required).
 * 1.19.2/1.19.3 - adds --wiki-tracker-- tag (beta), --wiki-toc-- customizations (beta), mentions as link to Phonetool, bug fixes
 * 1.19.0/1.19.1 - adds --wiki-header-- tag, improves macros, and minor fixes
 * 1.18.0 - fix embedded videos, stats helpers at console
 * 1.17/1.17.1/1.17.2 (beta) - adds --wiki-toc-- tag and minor fixes
 * 1.16/1.16.1 (beta) - file/image upload as attachments, image layout, and log dump telemetry
 * 1.14/1.14.1/1.15/1.15.1 (beta) - fix anchors and table improvements (header, styling, remove empty cols/rows)
 * 1.12/1.13 (beta) - adds telemetry and bug fixes
 * 1.11 (beta) - bug fixes and improved folder export experience
 * 1.10 (beta) - improved banner, better folder index appearance, hide banner from print
 * 1.9 (beta) - added support for exporting folder indexes and *wiki-macro* tag (soon)
 * 1.8 (beta) - transition from code.amazon.com (http://code.amazon.com/) to drive.corp.amazon.com (http://drive.corp.amazon.com/) download source
 * 1.7 (beta) - transition from jsbin to code.amazon.com (http://code.amazon.com/)
 * 1.6 (beta) - fixed issues with monospace text, bullet/numbered lists, tag removal
 * 1.5 (beta) - embed images as URI data in base64
 * 1.4 (preview) - first version available
*/

const UPDATE_CHECK_URL = ["https://w.amazon.com/rest/wikis/xwiki/spaces/Quip2Wiki/spaces/Releases/pages/WebHome/attachments/Quip2Wiki-beta.user.js","https://axzile.corp.amazon.com/-/carthamus/download_script/quip2-wiki-1.user.js"];

const TICKET_URL = 'https://tiny.amazon.com/13hdclxxy/Quip2WikiCreateIssue';



class ChangeMonitor {
    constructor (quipClient, wikiClient, action, enabled = false) {
        this.quipClient = quipClient;
        this.wikiClient = wikiClient;
        this.INTERVAL = 5*60*1000; // every 5 minutes
        this.action = action;
        this.isEnabled = enabled; // since 1.22.3, change monitor is disabled by default
        this.docInfo = undefined;
        this.tokenIsValid = undefined;
        this.lastCheck = undefined;
        this.lastTimestamp = undefined;
        this.pageExists = undefined;
        this.status = 'UNKNOWN';

    }

    get isRunning () {
        return this.intervalId != undefined;
    }

    setDocInfo(docId, docType) {
        this.docInfo = { id: docId, type: docType };
        this.lastCheck = undefined;
        this.lastTimestamp = undefined;
        this.pageExists = undefined;
        this.status = 'UNKNOWN';
    }

    start (docId = null, docType = 'document') {
        if (docId) {
            this.setDocInfo(docId, docType);
        }

        if (!this.isRunning && this.isEnabled) {
            log.debug('Enabling change monitor...');

            const now = new Date();
            const elapsed = now - (this.lastCheck || now) + 5000; // 5 extra seconds to account for processing time
            const shouldCheck = elapsed > this.INTERVAL;

            const startTimer = () => this.intervalId = setInterval(() => this.monitor(),  this.INTERVAL);
            if (this.lastCheck && !shouldCheck) {
                startTimer();
            } else {
                this.monitor(this).then(startTimer);
            }
        }
    }

    stop () {
        log.debug('Disabling change monitor...');
        clearInterval(this.intervalId);
        this.intervalId = undefined;
    }

    monitor () {
        log.debug('Trying to detect document change...');

        return this.check()
            .then(() => this.lastCheck = new Date());
    }

    async check () {
        try {
            if (!this.docInfo || !this.docInfo.id) {
                throw 'Nothing to monitor';
            }

            this.tokenIsValid = this.tokenIsValid || await this.quipClient.checkToken();
            if (!this.tokenIsValid) {
                throw 'Invalid quip api token';
            }

            let timestamp;
            let wikiAddr;

            const id = this.docInfo.id;
            if (this.docInfo.type === 'folder') {
                wikiAddr = Settings.loadValue(id, null);
                if (!wikiAddr) {
                    throw 'Quip folder was never exported';
                }

                const folder = await this.quipClient.getFolderInfo(id);
                if (!folder || !folder.id) {
                    throw 'Could not load Quip folder!';
                }

                timestamp = folder.lastUpdated;
            } else {
                const doc = await this.quipClient.getDocument(id);
                if (!doc) {
                    throw 'Error loading doc information';
                }

                wikiAddr = doc.wikiAddr;
                if (!wikiAddr) {
                    throw 'Quip document was never exported';
                }

                timestamp = doc.lastUpdated;
            }

            if (timestamp === this.lastTimestamp) {
                console.debug('Document did not change since last check');
                return;
            }

            this.pageExists = this.pageExists || await this.wikiClient.wikiPageExists(wikiAddr);
            if (!this.pageExists) {
                throw 'Wiki destination page does not exists';
            }

            const wikiTimestamp = await this.wikiClient.getLastUpdated(wikiAddr);
            if (!wikiTimestamp) {
                this.setStatus('DIVERGED');
            } else if (wikiTimestamp !== timestamp) {
                this.setStatus('CHANGED');
            } else {
                this.setStatus('UNCHANGED');
            }

            this.lastTimestamp = timestamp;
        } catch (e) {
            console.error(e);
            this.setStatus('UNKNOWN');
        }
    }

    setStatus (newStatus) {
        if (newStatus !== this.status) {
            this.status = newStatus;
            if (this.action) {
                this.action(newStatus);
            }
        }
    }

    resetStatus () {
        this.setStatus(undefined);
    }

    get currentStatus () {
        return this.status;
    }
}


class LocalDataLruCache {

    constructor(cacheName, cacheSize) {
        this.cacheName = cacheName;
        this.lruCache = new LRU(cacheSize);

        var cachedData = this.getLocalData();
        for (const [key, value] of Object.entries(cachedData).reverse()) {
            // The entries are reversed so that (in most Javascript implementations) the cache ordering is preserved between sessions
            this.lruCache.write(key, value);
        }
    }

    get(key, fn) {
        var cachedValue = this.lruCache.read(key);
        if (cachedValue) return cachedValue;

        console.debug(`Key ${key} was not present in LRU cache (${this.cacheName}). Retrieving value...`);
        var newValue = fn(key);
        if (!newValue) return undefined;

        console.debug(`Retrieved value ${newValue} succesfully for key ${key}. Adding it to cache (${this.cacheName})`);
        this.lruCache.write(key, newValue);
        return newValue;
    }

    async getAsync(key, fn) {
        var cachedValue = this.lruCache.read(key);
        if (cachedValue) return cachedValue;

        console.debug(`Key ${key} was not present in LRU cache (${this.cacheName}). Retrieving value...`);
        var newValue = await fn(key);
        if (!newValue) return undefined;

        console.debug(`Retrieved value ${newValue} succesfully for key ${key}. Adding it to cache (${this.cacheName})`);
        this.lruCache.write(key, newValue);
        return newValue;
    }

    getLocalData() {
        const value = Settings.loadValue(this.cacheName, null);
        if (value) {
            return JSON.parse(value);
        } else {
            return {};
        }
    }

    persistCache() {
        const value = JSON.stringify(this.lruCache.getObjectMap());
        Settings.saveValue(this.cacheName, value);
    }

}

// Implementations of Node and LRU pretty much copied from https://medium.com/dsinjs/implementing-lru-cache-in-javascript-94ba6755cda9 with a few helpers added

class Node {
    constructor(key, value, next = null, prev = null) {
        this.key = key;
        this.value = value;
        this.next = next;
        this.prev = prev;
    }
}

class LRU {
    constructor(limit) {
        this.size = 0;
        this.limit = limit;
        this.head = null;
        this.tail = null;
        this.cacheMap = {};
    }

    write(key, value) {
        const existingNode = this.cacheMap[key];
        if (existingNode) {
            this.detach(existingNode);
            this.size--;
        } else if (this.size === this.limit) {
            delete this.cacheMap[this.tail.key];
            this.detach(this.tail);
            this.size--;
        }

        // Write to head of LinkedList
        if (!this.head) {
            this.head = this.tail = new Node(key, value);
        } else {
            const node = new Node(key, value, this.head);
            this.head.prev = node;
            this.head = node;
        }

        // update cacheMap with LinkedList key and Node reference
        this.cacheMap[key] = this.head;
        this.size++;
    }

    read(key) {
        const existingNode = this.cacheMap[key];
        if (existingNode) {
            const value = existingNode.value;
            // Make the node as new Head of LinkedList if not already
            if (this.head !== existingNode) {
                // write will automatically remove the node from it's position and make it a new head i.e most used
                this.write(key, value);
            }
            return value;
        }

        console.log(`Item not available in cache for key ${key}`);
    }

    detach(node) {
        if (node.prev !== null) {
            node.prev.next = node.next;
        } else {
            this.head = node.next;
        }

        if (node.next !== null) {
            node.next.prev = node.prev;
        } else {
            this.tail = node.prev;
        }
    }

    clear() {
        this.head = null;
        this.tail = null;
        this.size = 0;
        this.cacheMap = {};
    }

    // Invokes the callback function with every node of the chain and the index of the node.
    forEach(fn) {
        let node = this.head;
        let counter = 0;
        while (node) {
            fn(node, counter);
            node = node.next;
            counter++;
        }
    }

    getObjectMap() {
        let m = {};
        this.forEach((node => { m[node.key] = node.value }));
        return m;
    }

    // To iterate over LRU with a 'for...of' loop
    *[Symbol.iterator]() {
        let node = this.head;
        while (node) {
            yield node;
            node = node.next;
        }
    }
}

/**
 * Client for accessing Maxis' APIs.
 */
const Maxis = {

    /**
     * Holds recent successful user name search results, so to avoid API calls within the same session.
     */
    nameCache: { },

    /**
     * Holds recent invalid user name search results, so to avoid API calls within the same session.
     */
    invalidNameCache: [],

    /**
     * Holds recent successful login search results, so to avoid API calls within the same session.
     */
    loginCache: { },

    /**
     * This method finds a user's login by searching its full name using the HR extension from Maxis' user API. The result is successful if the
     * search result contains only one employee that matches given name, otherwise the method fails. The search keyword should be
     * the user's exact full name, as configured in Amazon systems and does not match inactive employees. Requires Midway authentication.
     *
     * @param {string} fullName the user full name, as configured in Amazon systems
     * @returns a promise containing the user login that matches the given full name
     * @throws returns a failed promise if the given full name does not match a user, or if it matches multiple users
     */
    getLoginFromFullName: async function (fullName) {
        const isInvalid = this.invalidNameCache.includes(fullName);
        let login = this.nameCache[fullName];
        if (login) {
            log.debug(`[maxis-client] retrieved login from cache for '${fullName}': ${login}`);
        } else if (isInvalid) {
            log.debug(`[maxis-client] retrieved invalid name from cache for '${fullName}'`);
        } else {
            log.debug(`[maxis-client] finding '${fullName}' user login...`);
            const employees = await this.searchEmployees(fullName);
            for (let employee of employees) {
                if (!employee.extensions || !employee.extensions.hrInfo) {
                    continue;
                }
                if (employee.extensions.hrInfo.fullName === fullName) {
                    const employeeLogin = employee.email.replace(/@[^@]+$/, '');
                    if (!login) {
                        login = employeeLogin;
                    } else if (login === employeeLogin) {
                        continue;
                    } else {
                        log.warn(`[maxis-client] find login error: multiple logins match '${fullName}'`);
                        login = null; // we can't used the first match
                        break; // stop looking
                    }
                }
            }
            if (login) {
                log.info(`[maxis-client] found login for '${fullName}': ${login}`);
            } else {
                log.error(`[maxis-client] find login error: found no employee that matches '${fullName}'`);
                this.invalidNameCache.push(fullName); // did not find, so add to invalid cache
            }
        } 
        if (login) {
            this.nameCache[fullName] = login; // store in cache
            return login;
        } else {
            throw `Could not find the login of '${fullName}'`;
        }
    },


    /**
     * Retrieves an employee information by its Amazon login. The search does not match inactive employees. Requires Midway authentication.
     *
     * @param {string} login Amazon login of desired user
     */
    getEmployeeFromLogin: async function (login) {
        if (login in this.loginCache) {
            log.info(`[maxis-client] found employee data from cache for '${login}'`);
            return this.loginCache[login];
        }
        log.debug(`[maxis-client] get employee '${login}' data...`);
        const employees = await this.searchEmployees(login);
        for (let employee of employees) {
            const employeeLogin = employee.email.replace(/@[^@]+$/, '');
            if (employeeLogin && employeeLogin === login) {
                log.info(`[maxis-client] found employee data for '${login}'`);
                this.loginCache[login] = employee;
                return employee;
            }
        }
        log.info(`[maxis-client] find employee data error: found no employee that matches '${login}'`);
        return null;
    },

    /**
     * Executes a user search and retrieves the employess that match given keyword. The result do not contain inactive employees. Requires Midway authentication.
     *
     * @param {string} searchKeyword keyword to search
     * @pamara {string} filterType defines the type of parameter the search keyword refers to: 'All fields', 'Full name', 'First name', 'Last name', 'Employee login'
     */
    searchEmployees: async function (searchKeyword) {
        log.debug(`[maxis-client] running a user search on keyword '${searchKeyword}'...`);
        var getPromise = () => new Promise((res, rej) => {
            const keyword = encodeURIComponent(searchKeyword);
            const requestUrl = `https://maxis-service-prod-iad.amazon.com/users/?q=${keyword}`;
            GM_xmlhttpRequest({
                method: 'GET',
                url: requestUrl,
                timeout: 10000,
                headers: {
                    'accept': 'application/json',
                    'x-requested-with': 'XMLHttpRequest',
                },
                onerror: () => rej('Maxis HTTP request error'),
                ontimeout: () => rej('Maxis HTTP request timeout'),
                context: null,
                onload: (response) => {
                    if (response.finalUrl != requestUrl && response.finalUrl.startsWith(Utils.MIDWAY_REDIRECT_URL)) {
                        rej(response.finalUrl);
                        return;
                    }
                    if (response.status == 200) {
                        const result = JSON.parse(response.responseText);
                        if (!result.documents) {
                            log.error('[maxis-client] search result error: ' + JSON.stringify(result));
                            rej(`Invalid result while searching for '${searchKeyword}'`);
                        } else {
                            res(result.documents);
                        }
                    } else {
                        log.error('[maxis-client] search error: ' + response.responseText);
                        rej(`Error occurred while searching for '${searchKeyword}'`);
                    }
                }
            });
        });

        return Utils.authAwareRetry(async () => getPromise(), Utils.MAXIS_SERVICE, 2);
    }
};


/**
 * Client for retrieving basic information from Amazon Phonetool.
 */
const Phonetool = {

    /**
     * Holds recent successful user name search results, so to avoid API calls within the same session.
     */
    nameCache: { },

    /**
     * Holds recent invalid user name search results, so to avoid API calls within the same session.
     */
    invalidNameCache: [],

    /**
     * Holds recent successful login search results, so to avoid API calls within the same session.
     */
    loginCache: { },

    /**
     * This method finds a user's login by searching its full name using the Phonetool search API. The result is successful if the
     * search result contains only one employee that matches given name, otherwise the method fails. The search keyword should be
     * the user's exact full name, as configured in Amazon systems and cannot match inactive employees. Requires Midway authentication.
     *
     * @param {string} fullName the user full name, as configured in Amazon systems
     * @returns a promise containing the user login that matches the given full name
     * @throws returns a failed promise if the given full name does not match a user, or if it matches multiple users
     */
    getLoginFromFullName: async function (fullName) {
        const isInvalid = this.invalidNameCache.includes(fullName);
        let login = this.nameCache[fullName];
        if (login) {
            log.debug(`[phonetool-client] retrieved login from cache for '${fullName}': ${login}`);
        } else if (isInvalid) {
            log.debug(`[phonetool-client] retrieved invalid login from cache for '${fullName}'`);
        } else {
            log.debug(`[phonetool-client] serching '${fullName}' user login using full name...`);
            const employees = await Utils.authAwareRetry(this.searchEmployees(fullName, 'Full name'), Utils.PHONETOOL_SERVICE, 2);
            for (let employee of employees) {
                if (employee.name === fullName) {
                    if (!login) {
                        login = employee.login;
                    } else {
                        log.warn(`[phonetool-client] find login error: multiple logins match '${fullName}'`);
                        login = null; // we can't use the first match
                        break; // stop looking
                    }
                }
            }
            if (login) {
                log.info(`[phonetool-client] found login for '${fullName}': ${login}`);
            } else {
                log.error(`[phonetool-client] find login error: found no employee that matches '${fullName}'`);
                this.invalidNameCache.push(fullName); // did not find, so add to invalid cache
            }
        }
        if (login) {
            this.nameCache[fullName] = login; // store in cache;
            return login;
        } else {
            throw `Could not find the login of '${fullName}'`;
        }
    },

    /**
     * Executes a Phonetool search and retrieves the employess that match given keyword. The result do not contain inactive employees. Requires Midway authentication.
     *
     * @param {string} searchKeyword keyword to search
     * @pamara {string} filterType defines the type of parameter the search keyword refers to: 'All fields', 'Full name', 'First name', 'Last name', 'Employee login'
     */
    searchEmployees: async function (searchKeyword, filterType = 'All fields') {
        if (!Phonetool.FILTER_TYPES.includes(filterType)) {
            throw 'Invalid filter type';
        }
        log.debug(`[phonetool-client] running a phonetool search on keyword '${searchKeyword}' as '${filterType}'...`);
        return new Promise((res, rej) => {
            const keyword = encodeURIComponent(searchKeyword);
            const filter = encodeURIComponent(filterType);
            const requestUrl = `https://phonetool.amazon.com/search/search_result_list?search_properties%5Bcurrent_query%5D%5Bfilter_type%5D=${filter}&search_properties%5Bcurrent_query%5D%5Bquery%5D=${keyword}&search_properties%5Bfilter_type%5D=${filter}&search_properties%5Brequest_sort_type%5D=First+name&search_properties%5Bsearch_term%5D=Fernando+Moraes&search_properties%5Bsort_order%5D=ASC&search_properties%5Bsort_type%5D=First+name&search_properties%5Btarget_page%5D=1&search_properties%5Buse_fuzzy_search%5D=false&total_pages=1&page=1`;
            GM_xmlhttpRequest({
                method: 'GET',
                url: requestUrl,
                timeout: 10000,
                headers: {
                    'accept': 'application/json',
                    'x-requested-with': 'XMLHttpRequest',
                },
                onerror: () => rej('Phonetool HTTP request error'),
                ontimeout: () => rej('Phonetool HTTP request timeout'),
                context: null,
                onload: (response) => {
                    if (response.finalUrl != requestUrl && response.finalUrl.startsWith(Utils.MIDWAY_REDIRECT_URL)) {
                        rej(response.finalUrl);
                        return;
                    }
                    if (response.status == 200) {
                        const result = JSON.parse(response.responseText);
                        if (result.status !== "200") {
                            log.error('[phonetool-client] search result error: ' + JSON.stringify(result));
                            rej(`Invalid result while searching for '${searchKeyword}'`);
                        } else {
                            res(result.employees);
                        }
                    } else {
                        log.error('[phonetool-client] search error: ' + response.responseText);
                        rej(`Error occurred while searching for '${searchKeyword}'`);
                    }
                }
            });
        });
    },

    /**
     * Retrieves basic employee information from Phonetool. Requires Midway authentication.
     * @param {string} login Amazon login
     */
    getEmployeeFromLogin: function (login) {
        if (login in this.loginCache) {
            log.debug(`[phonetool-client] retrieved employee from cache for '${login}'`);
            const employee = this.loginCache[login];
            return Promise.resolve(employee);
        }
        log.debug(`[phonetool-client] get employee '${login}' data...`);
        return new Promise((res, rej) => {
            const requestUrl = `https://phonetool.amazon.com/users/${login}.json`;
            GM_xmlhttpRequest({
                method: 'GET',
                url: requestUrl,
                timeout: 5000,
                headers: {
                    'accept': 'application/json',
                    'x-requested-with': 'XMLHttpRequest',
                },
                onerror: () => rej('Phonetool HTTP request error'),
                ontimeout: () => rej('Phonetool HTTP request timeout'),
                context: null,
                onload: (response) => {
                    if (response.status == 200 || response.status == 404) {
                        const result = JSON.parse(response.responseText);
                        if (result.login === login) {
                            this.loginCache[login] = result; // store in cache;
                            res(result);
                            return;
                        } else if (result.error) {
                            log.error(`[phonetool-client] get employee login not found: ${login}`);
                            this.loginCache[login] = null; // store in cache;
                            res(null);
                            return;
                        }
                    }
                    log.error('[phonetool-client] get employee data error: ' + response.responseText);
                    rej(`Error occurred while fetching employee '${login}' data`);
                }
            });
        });
    }
};

Phonetool.FILTER_TYPES = ['All fields', 'Full name', 'First name', 'Last name', 'Employee login', 'Phone', 'Department name', 'Country', 'City'];

/**
 * Common dialogs for prompting the user for information of confirmation.
 */
const Prompts = {

    /**
     * Shows a modal alert dialog with an OK button.
     * @param {string} title dialog title
     * @param {string} text dialog message to be displayed
     * @param {*} width (optional) dialog width in pixels. Set to null for automatic.
     * @param {*} height (optional) dialog height in pixels. Set to null for automatic.
     */
    async showAlert (title, text, width, height) {
        const buttons = { OK: true };
        return await this.showDialog(title, text, buttons, width, height);
    },

    getVersionInfo() {
        const en_dash = "–";
        if (!latestVersion)
            return ` [v${Session.version}]`;

        let currentVersion = Utils.parseVersion(Session.version);
        let versionComparison = Utils.compareVersions(currentVersion, latestVersion);
        if (versionComparison == 0)
            return ` [v${Session.version} ${en_dash} latest version]`;
        if (versionComparison == -1)
            return ` [v${Session.version} ${en_dash} dev version]`;
        return ` [v${Session.version} ${en_dash} NOT LATEST VERSION]`;
    },

    /**
     * Shows a modal dialog with customized buttons and return values.
     * @param {string} title dialog title
     * @param {string} text dialog message to be displayed
     * @param {*} buttons object that describes the button label (key) and its return value (value)
     * @param {*} width (optional) dialog width in pixels. Set to null for automatic.
     * @param {*} height (optional) dialog height in pixels. Set to null for automatic.
     */
    showDialog (title, text, buttons, width, height) {
        let titleWithVersionInfo = title + Prompts.getVersionInfo();
        return new Promise((res, rej) => {
            // make sure every button will close the dialog and return its given value
            const dialog_buttons = {};
            Object.entries(buttons).forEach(([key, value]) => {
                dialog_buttons[key] = {
                    text: key,
                    click: function() {
                        if (typeof(value) == "function") {
                            res(value()); // evaluate function and return button value
                        } else {
                            res(value); // returns button value
                        }
                        $(this).dialog('close');
                    }
                };
            });
            // open the dialog
            $(`<div class="q2w-dialog" id="jquery-dialog" "style="word-wrap: normal; white-space: normal"><p>${text.replace(/\n/g, '<br/>')}</p></div>`).dialog({
                open: function() {
                    // make last button highlighted
                    $(this)
                        .next()
                        .find('button:last')
                        .addClass('ui-priority-primary');
                },
                close: function(event, ui) {
                    res(undefined);
                    $(this).dialog('destroy').remove();
                },
                closeText: "",
                draggable: false,
                height: height ? height : 'auto',
                width: width ? width : 'auto',
                modal: true,
                resizable: false,
                title: titleWithVersionInfo,
                create: function(event, ui) {
                    // maxWidth won't work so we set in the css
                    if (!width) {
                        $(this).css("maxWidth", "1200px");
                    }
                    fixCloseButton(event.target);
                },
                buttons: dialog_buttons
            });
        });
    },

    async promptForNewWikiAddress (suggAddr, wikiClient) {
        const addr = await this.promptForWikiAddress(suggAddr);
        if (addr == null) {
            return null;
        }
        return await this.promptForExistingWikiAddressConfirmation(addr, wikiClient) ? addr : null;
    },

    async promptForExistingWikiAddress (addr, docType, wikiClient) {
        while (true) {
            const title = appTitle;
            const url = WikiClient.VIEW_URL + addr;
            const msg = `The Quip ${docType} will export to the following Wiki page address:<br/><br/>
                        <span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${url}</a></span>`;
            const buttons = {
                "Cancel": null,
                "Change address": false,
                "Export to Wiki": true
            }
            const result = await this.showDialog(title, msg, buttons);
            if (result === true) {
                return addr;
            } else if (result === false) {
                let newAddr = await this.promptForWikiAddress(addr);
                if (newAddr == null) {
                    continue;
                } else if (addr !== newAddr) {
                    return await this.promptForExistingWikiAddressConfirmation(newAddr, wikiClient) ? newAddr : null;
                }
            } else {
                return null;
            }
        }
    },

    async promptForChangedWikiConfirmation (addr) {
        const url = WikiClient.VIEW_URL + addr;
        const msg = `The destination page "<span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${addr}</a></span>" has changed since last export.<br/><br/>
                    If you proceed, THE CURRENT PAGE CONTENT WILL BE OVERWRITTEN!!<br/><br/>
                    Are you sure you want to continue?`;

        const buttons = { 'Cancel': false, 'Overwrite': true };

        return await this.showDialog(appTitle, msg, buttons);
    },

    async promptForWikiAddress (suggAddr) {
        let addr = this.setUpperCaseFirstLetter(suggAddr);
        while (true) {
            const promptMsg = 'Please inform the wiki page relative or full address to save' +
                '\nExamples:' +
                '\n- Quip2Wiki' +
                '\n- Quip2Wiki/Description' +
                '\n' +
                '\n- https://w?Quip2Wiki' +
                '\n- https://w.amazon.com/bin/view/Quip2Wiki' +
                '\n- https://w.amazon.com/bin/view/Quip2Wiki/Description';

            const result = window.prompt(promptMsg, addr);
            if (result == null) {
                return null;
            }

            addr = WikiClient.extractWikiRelativeAddr(result);

            if (!addr) {
                await this.showAlert(appTitle, `The address is not valid!`);
                continue;
            }

            const isInvalid = /^(https?:\/\/|w\.amazon\.com)/.test(addr);
            if (isInvalid) {
                await this.showAlert(appTitle, `The address is not valid!`);
                continue;
            } else if (addr.length <= 3) {
                await this.showAlert(appTitle, `The address should be longer than 3 characters!`);
                continue;
            }

            addr = this.setUpperCaseFirstLetter(addr);

            const fullUrl = WikiClient.VIEW_URL + addr;
            const msg = `You are about to create the following Wiki page:<br/><b><i>${fullUrl}</i></b><br/>This is a "root" page, and it is NOT recommended to create root pages.`;
            const buttons = { 'Cancel': null, 'Proceed Anyway': true };
            if (addr.includes('/') || await this.showDialog(appTitle, msg, buttons)) {
                return encodeURI(addr);
            }
        }
    },

    async promptForAttachmentConfirmation (attachmentName, blob, limit) {

        const limitStr = Utils.formatBytes(limit);
        const sizeStr = Utils.formatBytes(blob.size);

        let suggestion;
        const isSupportedImage = WikiClient.IMAGE_FORMATS.some((type) => blob.type.includes(type)) || blob.type.startsWith('image');
        if (isSupportedImage) {
            suggestion = 'Consider re-uploading a scaled down version of the image to reduce its size or let Quip2Wiki do it for you.';
        } else {
            suggestion = 'Consider uploading to <span style="text-decoration:underline; font-style:italic;"><a href="https://drive.corp.amazon.com/" target="_blank" rel="noopener">Drive</a></span> or <span style="text-decoration:underline; font-style:italic;"><a href="https://amazon.awsapps.com/workdocs" target="_blank" rel="noopener">Workdocs</a></span> and providing the shareable link in your document.';
        }

        const msg = `The attachment '<b>${attachmentName}</b>' size (${sizeStr}) <br/>is <b>too large</b> and above the ${limitStr} limit imposed by Amazon Wiki.<br/><br/>${suggestion}`;

        const buttons = { 'Abort': 'abort', 'Link to Quip': 'link' };
        if (isSupportedImage) {
            buttons['Resize Image'] = 'resize';
        }

        return await this.showDialog(appTitle, msg, buttons);
    },

    async showWikiInSyncDialoig(wikiLink, docType = 'document') {
        const detailLink = `(<span style="text-decoration:underline; font-style:italic;"><a href="${IN_SYNC_FAQ_URL}" target="_blank" rel="noopener">more details</a></span>)`;
        return await Prompts.showDialog(appTitle, `Quip ${docType} is already in sync with Amazon Wiki. Nothing to export. ${detailLink}<br/><br/>${wikiLink}`, { "Export anyway": true, "Cancel": false });
    },

    /**
     * Set first letter to upper case, as wiki seems to prefer page addresses that way.
     */
    setUpperCaseFirstLetter (addr) {
        if (addr.length === 1) {
            return addr.charAt(0).toUpperCase();
        } else if (addr.length > 1) {
            return addr.charAt(0).toUpperCase() + addr.slice(1);
        } else {
            return addr;
        }
    },

    /**
     * Shows a confirmation dialog if the Wiki page already exists.
     *
     * @param {string} wikiAddr wiki page address
     * @param {*} wikiClient Wiki client
     * @returns true if page does not exists or the user confirmed the prompt
     */
    async promptForExistingWikiAddressConfirmation (wikiAddr, wikiClient) {
        const exists = await wikiClient.wikiPageExists(wikiAddr);
        if (!exists) {
            return true;
        }

        const url = WikiClient.VIEW_URL + wikiAddr;
        const msg = `The page "<span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${wikiAddr}</a></span>" already exists.<br/><br/>
                     If you proceed, THE CURRENT PAGE CONTENT WILL BE OVERWRITTEN!!<br/><br/>
                     Are you sure you want to continue?`;

        const buttons = { 'Cancel': false, 'Export to Wiki': true };

        return await this.showDialog(appTitle, msg, buttons);
    },

    /**
     * Shows a modal dialog with customized buttons and return values.
     * @param {string} title dialog title
     * @param {string} text dialog message to be displayed
     * @param {*} buttons object that describes the button label (key) and its return value (value)
     * @param {*} width (optional) dialog width in pixels. Set to null for automatic.
     * @param {*} height (optional) dialog height in pixels. Set to null for automatic.
     */
    showExportFolderForm (input, width, height) {
        return new Promise((res, rej) => {
            // open the dialog
            $(`<div id="jquery-form" "style="word-wrap: normal; white-space: normal">
               <p>Please inform the wiki page (relative or full address) of the Quip folder to be exported:<br/>
               <span style="font-size:x-small; bgcolor:#444; border-width:2px">
               Examples:
               <ul>
                <li>Quip2Wiki</li>
                <li>Quip2Wiki/Description</li>
                <li>https://w?Quip2Wiki</li>
                <li>https://w.amazon.com/bin/view/Quip2Wiki</li>
                <li>https://w.amazon.com/bin/view/Quip2Wiki/Description</li>
               </ul></span></p>
               <p><label for="wikiAddr">Wiki Address </label><input id="wikiAddr" type="text" size="65"/></p>
               <p><table border="0" width="auto"><tr>
                 <td><label>Sorting Field </label><select id="sortType" name="sortType" size="7">
                   <option value="title">Title</option>
                   <option value="updated_usec">Update date</option>
                   <option value="created_usec">Create date</option>
                   <option value="type">Item type</option>
                 </select></td>
                 <td><label for="sortOrder">Sorting Order </label><select id="sortOrder" name="sortOrder" size="5">
                   <option value="asc">Ascending</option>
                   <option value="desc">Descending</option>
                 </select></td>
               </tr></table></p>
               <hr>
               <p style="font-size:x-small"><input id="askAgain" type="checkbox"> Don't ask again</input></p>
               </div>`).dialog({
                open: function() {
                    // make last button highlighted
                    $(this)
                        .next()
                        .find('button:last')
                        .addClass('ui-priority-primary');

                    $('#wikiAddr').val(input.wikiUrl || '');
                    $('#sortType').val(input.sortType || 'title');
                    $('#sortType').selectmenu();
                    $('#sortOrder').val(input.sortOrder || 'asc');
                    $('#sortOrder').selectmenu();
                    $('#askAgain').prop('checked', input.askAgain);
                },
                close: function(event, ui) {
                    res(undefined); // in case user used the close button
                    $(this).dialog('destroy').remove();
                },
                title: appTitle,
                modal: true,
                width: width ? width : 'auto',
                height: height ? height : 'auto',
                create: function(event, ui) {
                    // maxWidth won't work so we set in the css
                    if (!width) {
                        $(this).css("maxWidth", "1200px");
                    }
                },
                buttons: {
                    cancelBtn: {
                        text: 'Cancel',
                        click: function() {
                            res(null); // returns button value
                            $(this).dialog('close');
                        }
                    },
                    exportBtn: {
                        text: 'Export to Wiki',
                        click: function() {
                            const wikiAddrField = $('#wikiAddr');
                            if (!wikiAddrField.val()) {
                                wikiAddrField.addClass('ui-state-error');
                                return;
                            } else {
                                wikiAddrField.removeClass('ui-state-error');
                            }
                            const sortTypeValue = $('#sortType option:selected').attr('value');
                            const sortOrderValue = $('#sortOrder option:selected').attr('value');
                            const askAgainChecked = $('#askAgain').prop('checked');
                            res({
                                wikiAddr: wikiAddrField.val(),
                                sortType: sortTypeValue,
                                sortOrder: sortOrderValue,
                                askAgain: askAgainChecked
                            });
                            $(this).dialog('close');
                        }
                    }
                }
            });
        });
    },
}

function fixCloseButton(modalContentElement) {
    let dialog = modalContentElement.parentElement;
    /**
     * @type {HTMLButtonElement}
     */
    let closeButton = dialog.querySelector(".ui-button");
    if ($(closeButton).hasClass("ui-button-icon-only")) {
        $(closeButton).toggleClass("ui-button-icon-only");
        /**
         * @type {HTMLSpanElement}
         */
        let closeIconSpan = document.createElement("span");
        closeIconSpan.innerHTML = "&#10006;"; // or &#x2715;
        $(closeButton).prepend(closeIconSpan);
    }
}


function updateMinimizeButton(modalContentElement) {
    let dialog = modalContentElement.parentElement;

    // remove original, unavailable close icon if it exists
    /**
     * @type {HTMLButtonElement}
     */
    let closeButton = dialog.querySelector(".ui-button");
    if ($(closeButton).hasClass("ui-button-icon-only")) {
        $(closeButton).toggleClass("ui-button-icon-only");
    }

    // remove all children
    $(closeButton).empty();

    // create the correct icon
    let isMinimized = $(modalContentElement).css("display") == "none";
    /**
     * @type {HTMLSpanElement}
     */
    let iconSpan = document.createElement("span");
    iconSpan.innerHTML = isMinimized ? "&square;" : "&#95;"; // or &#x2715;
    $(closeButton).prepend(iconSpan);
    
    // replace the click event
    $(closeButton).off("click");
    $(closeButton).on("click", () => {
        if (isMinimized) {
            $(modalContentElement).css("display", "block");
        } else {
            $(modalContentElement).css("display", "none");
        }

        // update the position of the dialog
        let position = $(modalContentElement).dialog("option", "position");
        $(modalContentElement).dialog("option", "position", position);

        updateMinimizeButton(modalContentElement);
    });
}

function highlightLastButton(target) {
    $(target)
        .next()
        .find('button:last')
        .addClass('ui-priority-primary');
}

let modalsOpened = 0;
function bringBackdropUp(target) {
    let offset = 2 * modalsOpened;
    let overlay = $(".ui-widget-overlay");
    overlay.css("z-index", 400 + offset);
    $(target.parentElement).css("z-index", 401 + offset);
}

function bringBackdropDown() {
    let offset = 2 * modalsOpened;
    let overlay = $(".ui-widget-overlay");
    overlay.css("z-index", 400 + offset);
}

function createCompliantModal(html, options, onCreate, onOpen, onFocus, onClose) {
    let hasPosition = options.position !== undefined;
    let defaultOptions = {
        closeText: "",
        draggable: false,
        height: 'auto',
        width: 'auto',
        modal: true,
        resizable: false,
        title: "Quip2Wiki dialog" + Prompts.getVersionInfo(),
        create: (event, ui) => {
            // maxWidth JQueryUI property doesn't work so we set it in the CSS
            $(this).css("maxWidth", "900px");
            fixCloseButton(event.target);

            if (onCreate)
                onCreate(event, ui);
        },
        open: (event, ui) => {
            modalsOpened += 1;
            bringBackdropUp(event.target);

            if (onOpen)
                onOpen(event, ui);

            if (!hasPosition) {
                setTimeout(() => {
                    $(event.target).dialog("option", "position", { my: "center", at: "center", of: window });
                }, 50);
            }
        },
        focus: (event, ui) => {
            highlightLastButton(event.target);

            if (onFocus)
                onFocus(event, ui);
        },
        close: (event, ui) => {
            modalsOpened -= 1;
            bringBackdropDown();

            if (onClose)
                onClose(event, ui);
        }
    };

    let mixedOptions = {...defaultOptions, ...options};
    if (options.title && !options.title.includes("[")) {
        mixedOptions.title = options.title + Prompts.getVersionInfo();
    }

    $(html).dialog(mixedOptions);
}

function createTemporaryModal(html, options, onCreate, onOpen, onFocus, onClose) {
    createCompliantModal(html, options, onCreate, onOpen, onFocus,
        (event, ui) => {
            if (onClose)
                onClose(event, ui);
            $(event.target).dialog('close');
            $(event.target).dialog('destroy');
        }
    )
}

function showLogModal() {
    let existingModal = $("#q2w-log-modal");
    if (existingModal.get(0)) {
        existingModal.dialog("open");
        return;
    }

    let logHtml =
`<div class="q2w-dialog" "style="word-wrap: normal; white-space: normal" id="q2w-log-modal">
  <div>
    <p>Log started at <b id="q2w-log-start-time">???</b></p>
  </div>
  <div style="height:200px; overflow-y: scroll; width: 640px; background-color:white;">
    <table style="table-layout: fixed;">
        <thead>
            <tr>
                <th style="width: 70px; font-weight: bold; text-align: center;">Time</th>
                <th style="width: 60px; font-weight: bold; text-align: center;">Level</th>
                <th style="width: 430px; font-weight: bold;">Message</th>
                <th style="width: 80px;"></th>
            </tr>
        </thead>
        <tbody id="q2w-log-receiver"></tbody>
        </div>
    </table>
  </div>
</div>`;

    let options = {
        title: "Quip2Wiki log",
        buttons: [
            {
                text: "Copy log to clipboard",
                click: function() {
                    navigator.clipboard.writeText(getLogForDownload());
                }
            },
            {
                text: "Download log",
                click: function() {
                    downloadFromMemory("Quip2Wiki.log.txt", getLogForDownload());
                }
            },
            {
                text: "Close",
                click: function() {
                    $(this).dialog("close");
                }
            }
        ]
    };

    createCompliantModal(logHtml, options,
        function (event, ui) { // onCreate
            let callbackIndex = log.logCallbacks.length;

            let logEntries = log.structuredLog;
            for (let i = 0; i < logEntries.length; i++) {
                const entry = logEntries[i];
                logModalCallback(entry, callbackIndex, false);
            }

            log.logCallbacks.push(logModalCallback);
        },
        function (event, ui) { // onOpen
            if (log.structuredLog.length > 0)
                $("#q2w-log-start-time").text(log.structuredLog[0].timestamp);
        },
        function (event, ui) { // onFocus
            if (log.structuredLog.length > 0)
                $("#q2w-log-start-time").text(log.structuredLog[0].timestamp);

            let lastChild = $("#q2w-log-receiver").children().last().get(0);
            if (lastChild)
                lastChild.scrollIntoView();
        }
    );
}

function logModalCallback(entry, callbackIndex, forceFocus) {
    if ($("#q2w-log-receiver")) {
        //let message = `${entry.timestamp} [${entry.level}] ${entry.args}`;// at ${entry.stack}`;
        let timeFromStart = convertMilissecondsToMinutesSeconds(entry.timestamp - log.structuredLog[0].timestamp);
        let entryId = `${entry.id}-${callbackIndex}`;
        let btnId = `${entry.id}-btn-${callbackIndex}`;
        let renderedEntry = `<tr id="${entryId}">
<td style="text-align: center;">${timeFromStart}</td>
<td style="text-align: center;">${entry.level}</td>
<td style="word-wrap: anywhere; padding-bottom: 2px;">${entry.args}</td>
<td><span id="${btnId}" style="color: #4e7cc5; opacity: 70%; cursor: pointer;">Details</span></td>
</tr>`;
        $("#q2w-log-receiver").append(renderedEntry);
        $(`#${btnId}`).on("click", (event) => {
            showStacktraceModal(entry);
        });

        if (forceFocus) {
            let renderedEntry = $(`#${entryId}`).get(0);
            if (renderedEntry)
                renderedEntry.scrollIntoView();
        }
    }
}

function getMinistack(entry, max=3) {
    let functionNames = entry.errorObj.stack.split("\n").filter(s => s.includes("Quip2Wiki.user.js")).slice(2).map(s => {
        let functionName = s.split("@")[0];
        if (functionName.includes("[")) functionName = "[internal method]";
        return functionName;
    });

    return functionNames.slice(0, Math.min(max, functionNames.length));
}

function getLogForDownload() {
    let firstTimestamp = log.structuredLog[0].timestamp;
    let messages = []

    for (let i = 0; i < log.structuredLog.length; i++) {
        const entry = log.structuredLog[i];
        let timeFromStart = convertMilissecondsToMinutesSeconds(entry.timestamp - firstTimestamp);
        let level = entry.level;
        let msg = entry.args;
        let stack = getMinistack(entry);

        messages.push({ timeFromStart, level, msg, stack });
    }

    let logToCopy = { firstTimestamp, messages, version: Session.version };
    return JSON.stringify(logToCopy);
}

function downloadFromMemory(filename, text) {
    var element = document.createElement('a');
    element.id = "downloadFromMemory";
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);
  
    element.style.display = 'none';
    element.click();
}

function fillInEntryDetailsInStackModal(entry) {
    // Fill in message details (timestamp, level, message)
    let entryInfo = $("#q2w-stack-entry-info");
    entryInfo.empty();
    let logDetailsHtml = `<p><b>Timestamp:</b> ${entry.timestamp}<br/>
<b>Level:</b> ${entry.level}<br/>
<b>Message:</b> ${entry.args}</p>`;
    entryInfo.append(logDetailsHtml);

    // Create a filtered representation of the stack
    let stack = entry.errorObj.stack.split("\n").filter(s => s.includes("Quip2Wiki.user.js")).slice(2).map(s => {
        let startIndex = s.indexOf("Quip2Wiki.user.js");
        let location = s.substring(startIndex)
            .replace("?id=bf840de5-1818-4c37-8582-cf3f52ca854b", "")
            .replace("id=bf840de5-1818-4c37-8582-cf3f52ca854b", "");
        let functionName = s.split("@")[0];
        if (functionName.includes("[")) functionName = "[internal method]";
        return [functionName,location];
    });

    // Render the stack representation
    let stackContainer = $("#q2w-stack-container");
    stackContainer.empty();
    for (let s = 0; s < stack.length; s++) {
        const stackInfo = stack[s];
        const functionName = stackInfo[0];
        const location = stackInfo[1];
        stackContainer.append(`<tr>
<td style="width: 230px; text-align: right;"><i>${functionName}</i></td>
<td style="width: 25px; text-align: center;">&nbsp;at&nbsp;</td>
<td style="width: 270px;">${location}</td>
</tr>`);
    }

    // Add dynamic buttons
    let stackModal = $("#q2w-stack-modal");
    stackModal.dialog({
        buttons: [
            {
                text: "Print to browser console",
                click: function() {
                    console.debug(entry.errorObj);
                }
            },
            {
                text: "Close",
                click: function() {
                    $(this).dialog("close");
                }
            }
        ]
    });
}

function showStacktraceModal(entry) {
    let existingModal = $("#q2w-stack-modal");
    if (existingModal.get(0)) {
        fillInEntryDetailsInStackModal(entry);
        existingModal.dialog("open");
        return;
    }

    let html =
`<div class="q2w-dialog" id="q2w-stack-modal">
  <div id="q2w-stack-entry-info"></div>
  <p style="padding-top: 14px; margin-bottom: 0px;"><b>Stacktrace:</b></p>
  <div style="max-height:480px; overflow-y: auto;">
    <table>
      <tbody id="q2w-stack-container">
      </tbody>
    </table>
  </div>
</div>`;

    // Note: in the dialog below, the buttons are created dynamically, via the fillInEntryDetailsInStackModal function
    createTemporaryModal(html, { title: "Log message details", width: "600px", autoOpen: false });

    fillInEntryDetailsInStackModal(entry);
    $("#q2w-stack-modal").dialog("open");
}

function changeDevDialogPos(newPosition) {
    $("#q2w-dev-dialog").dialog("option", "position", newPosition);
}

unsafeWindow.changeDevDialogPos = changeDevDialogPos;

// window.changeDevDialogPos({my: "left bottom", at: "left bottom", of: ".navigation-controller-body"})

function showDevDialog() {
    let existingModal = $("#q2w-dev-dialog");
    if (existingModal.get(0)) {
        existingModal.dialog("open");
        return;
    }

    let logHtml =
`<div class="q2w-unmoveable-dialog" "style="word-wrap: normal; white-space: normal" id="q2w-dev-dialog">
  <div>
    <p>Log started at <b id="q2w-dev-log-start-time">???</b></p>
  </div>
  <div style="height:200px; overflow-y: scroll; width: 640px; background-color:white;">
    <table style="table-layout: fixed;">
        <thead>
            <tr>
                <th style="width: 70px; font-weight: bold; text-align: center;">Time</th>
                <th style="width: 60px; font-weight: bold; text-align: center;">Level</th>
                <th style="width: 430px; font-weight: bold;">Message</th>
                <th style="width: 80px;"></th>
            </tr>
        </thead>
        <tbody id="q2w-dev-log-receiver"></tbody>
        </div>
    </table>
  </div>
</div>`;

    let options = {
        title: "Quip2Wiki DevTools",
        buttons: [
            {
                text: "Copy log to clipboard",
                click: function() {
                    navigator.clipboard.writeText(getLogForDownload());
                }
            },
            {
                text: "Download log",
                click: function() {
                    downloadFromMemory("Quip2Wiki.log.txt", getLogForDownload());
                }
            },
            {
                text: "Close",
                click: function() {
                    $(this).dialog("close");
                }
            }
        ],
        modal: false,
        position: {my: "left bottom", at: "left bottom", of: ".navigation-controller-body"}
    };

    createCompliantModal(logHtml, options,
        function (event, ui) { // onCreate
            let callbackIndex = log.logCallbacks.length;

            let logEntries = log.structuredLog;
            for (let i = 0; i < logEntries.length; i++) {
                const entry = logEntries[i];
                devDialogCallback(entry, callbackIndex, false);
            }

            log.logCallbacks.push(devDialogCallback);

            updateMinimizeButton(event.target);
        },
        function (event, ui) { // onOpen
            if (log.structuredLog.length > 0)
                $("#q2w-dev-log-start-time").text(log.structuredLog[0].timestamp);
        },
        function (event, ui) { // onFocus
            if (log.structuredLog.length > 0)
                $("#q2w-dev-log-start-time").text(log.structuredLog[0].timestamp);

            let lastChild = $("#q2w-dev-log-receiver").children().last().get(0);
            if (lastChild)
                lastChild.scrollIntoView();
        }
    );
}


function devDialogCallback(entry, callbackIndex, forceFocus) {
    if ($("#q2w-dev-log-receiver")) {
        //let message = `${entry.timestamp} [${entry.level}] ${entry.args}`;// at ${entry.stack}`;
        let timeFromStart = convertMilissecondsToMinutesSeconds(entry.timestamp - log.structuredLog[0].timestamp);
        let entryId = `${entry.id}-${callbackIndex}`;
        let btnId = `${entry.id}-btn-${callbackIndex}`;
        let renderedEntry = `<tr id="${entryId}" style="border-bottom: 1px gray dotted;">
<td style="text-align: center;">${timeFromStart}</td>
<td style="text-align: center;">${entry.level}</td>
<td style="word-wrap: anywhere; padding-bottom: 2px;">${entry.args}</td>
<td><span id="${btnId}" style="color: #4e7cc5; opacity: 70%; cursor: pointer;">Details</span></td>
</tr>`;
        $("#q2w-dev-log-receiver").append(renderedEntry);
        $(`#${btnId}`).on("click", (event) => {
            showStacktraceModal(entry);
        });

        if (forceFocus) {
            let renderedEntry = $(`#${entryId}`).get(0);
            if (renderedEntry)
                renderedEntry.scrollIntoView();
        }
    }
}

/**
 * Quip API client, for retrieving Quip documents.
 */
class QuipClient {
    constructor (telemetry) {
        this.telemetry = telemetry;
        this.TIMEOUT = 15000;
        this.MAX_ATTEMPTS = 3;
        this.rateLimitWaitUntil = 0;
    }

    static logDocument (document) {
        log.info(`doc: id=${document.id}, timestamp=${document.lastUpdated}, type=${document.type}`);
    }

    static logFolder (document) {
        log.info(`folder: id=${document.folder.id}, timestamp=${document.folder.lastUpdated}, color=${document.folder.color}`);
        log.info('folder children:\n' + [...document.children.map(f => JSON.stringify(f))]);
    }

    checkToken () {
        return this.checkNewToken (Settings.quipApiToken);
    }

    checkNewToken (testToken) {
        log.info('[quip-client] checking if token is valid...');
        
        if (!testToken || testToken.length < 30 || !testToken.includes('=|')) {
            log.error('[quip-client] Provided token does not seem to be a Quip API token');
            return Promise.reject(QuipClient.CHECK_TOKEN_NOT_A_QUIP_TOKEN_ERROR);
        }
        const url = QuipClient.API_URL + '/users/current';
        return this.execute(this.httpGet(url, 'check token', 'json', testToken))
            .then(result => result && result.id && result.name)
            .catch(error => {
                if (error === 'AUTH_ERROR') {
                    return false;
                } else if (error === 'TIMEOUT') {
                    throw QuipClient.CHECK_TOKEN_TIMEOUT_ERROR;
                } else {
                    throw 'Error occurred while checking token';
                }
            });
    }

    getDocument (id) {
        log.info('[quip-client] start document request...');
        const url = QuipClient.API_URL + '/threads/' + id;
        return this.execute(this.httpGet(url, 'get document'))
            .then(result => {
                try {
                    const doc = new QuipDocument(result);
                    QuipClient.logDocument(doc);
                    return doc;
                } catch (err) {
                    log.error('[quip-client] get document error: not a valid quip document json');
                    throw 'PARSING_ERROR';
                }
            })
            .catch(error => {
                if (error === 'TIMEOUT') {
                    /* Ignore the error */
                } else if (error === 'TOO_MANY_CALLS') {
                    throw "Error occurred while retrieving the Quip document - too many calls";
                } else if (error === 'PARSING_ERROR' || error === 'INVALID_JSON') {
                    throw "Error occurred while parsing the Quip document";
                } else {
                    throw "Error occurred while retrieving the Quip document";
                }
            });
    }

    getFolders (ids) {
        if (ids && ids.length == 0) {
            return Promise.resolve([]);
        }

        const url = QuipClient.API_URL + '/folders/?ids=' + ids.join(',');
        return this.execute(this.httpGet(url, 'get folders'))
            .then(result => {
                try {
                    const folders = Object.keys(result).map(id => result[id]).filter(f => !!f.folder);
                    if (folders && folders.length > 0) {
                        folders.forEach(f => QuipClient.logFolder(f));
                        return folders;                    
                    } else {
                        throw 'No folders in the response'
                    }
                } catch (err) {
                    log.error('[quip-client] get document error: not a valid quip folder json');
                    throw 'PARSING_ERROR';
                }
            })
            .catch(error => {
                if (error === 'TIMEOUT') {
                    //throw "Error occurred while retrieving the Quip folder - timeout";
                } else if (error === 'TOO_MANY_CALLS') {
                    throw "Error occurred while retrieving the Quip folder - too many calls";
                } else if (error === 'PARSING_ERROR' || error === 'INVALID_JSON') {
                    throw "Error occurred while parsing the Quip folder";
                } else {
                    throw "Error occurred while retrieving the Quip folder";
                }
            });
    }

    getFolder (id) {
        return this.getFolders([id])
            .then(result => result.find(f => !!f.folder.id))
            .then(f => {
                f.folder.linkId = id;
                return f;
            });
    }

    async getFolderInfo (id) {
        log.info('[quip-client] start get folder info...');
        const f = await this.getFolder(id);
        f.folder.lastUpdated = await this.getFolderTimestamp(f);
        return f.folder;
    }

    async getFolderTimestamp (f) {
        log.info(`[quip-client] start get folder '${f.folder.title}' timestamp...`);

        const childrenIds = f.children
            .filter(fchild => !!fchild.folder_id)
            .map(fchild => fchild.folder_id);

        let timestamp = f.folder.updated_usec;
        const childrenFolders = await this.getFolders(childrenIds);
        for (const fchild of childrenFolders) {
            const childTimestamp = await this.getFolderTimestamp(fchild);
            timestamp = Math.max(timestamp, childTimestamp);
        }

        log.info(`[quip-client] folder timestamp: ${timestamp}`);
        return timestamp;
    }

    async getFolderListing (id, sortParam = null, sortOrder = null) {
        log.info(`[quip-client] start folder '${id}' listing...`);
        const folderItem = (await this.getFolderTree([id]))[0];
        return (await this.buildFolderListing(folderItem, sortParam, sortOrder)).folder;
    }

    /**
     * 
     * @param {*} item folder object from which to build the listing
     * @param {*} sortParam such as 'updated_usec', 'created_usec', 'title', 'type'
     * @param {*} sortOrder such as 'asc' (default) or 'desc'
     * @returns 
     */
    async buildFolderListing (item, sortParam = null, sortOrder = null) {
        if (item.thread_id) {
            const dId = item.thread_id;
            const doc = await this.getDocument(dId);
            return { document: doc.getHeader() };
        } else if (item.folder_id) {
            const folder = item.folder;
            const children = [];
            for (const child of item.children) {
                children.push(await this.buildFolderListing(child));
            }
            if (sortParam) {
                const getParam = (obj, param) => obj?.document?.hasOwnProperty(param) ? obj.document[param] : obj[sortParam];
                children.sort((a, b) => {
                    const aval = getParam(a, sortParam);
                    const bval = getParam(b, sortParam);
                    return (aval < bval) ? -1 : (aval > bval) ? +1 : 0;
                });
                if (sortOrder === 'desc') {
                    children.reverse();
                }
            }
            folder.children = children;
            folder.type = 'FOLDER';
            return { folder: folder };
        } else {
            return item;
        }
    }

    async getFolderTree (ids, onlyFolders = false) {
        if (ids && ids.length == 0) {
            return [];
        }

        log.info(`[quip-client] start folder '${ids}' listing...`);
        const folders = await this.getFolders(ids);

        const childrenFoldersIds = folders
            .map(f => f.children)
            .flat()
            .filter(fchild => !!fchild.folder_id)
            .map(fchild => fchild.folder_id);

        const allChildrenFolders = await this.getFolderTree(childrenFoldersIds);
        const allChildrenFoldersMap = Object.fromEntries(
            allChildrenFolders.map(fchild => [fchild.folder.id, fchild]));

        const shouldFilter = (item) => !onlyFolders || !!item.folder_id;
        folders.forEach(f => {
            f.folder_id = f.folder.id;
            f.children = f.children
                .filter(shouldFilter)
                .map(child => {
                    if (child.folder_id) {
                        return allChildrenFoldersMap[child.folder_id];
                    } else {
                        return child;
                    }
                })
        });

        return folders;
    }

    getCurrentUser () {
        return this.getUser('current');
    }

    async getUser (id) {
        log.info('[quip-client] start get user info...');
        const url = QuipClient.API_URL + '/users/' + id;
        try {
            telemetry.registerQuipUserApiAttempt();
            const result = await this.execute(this.httpGet(url, 'get user'))
                .catch(error => {
                    if (error === 'TIMEOUT') {
                        //throw "Error occurred while retrieving the Quip user - timeout";
                    } else if (error === 'TOO_MANY_CALLS') {
                        throw "Error occurred while retrieving the Quip user - too many calls";
                    } else if (error === 'PARSING_ERROR' || error === 'INVALID_JSON') {
                        throw "Error occurred while parsing the Quip user";
                    } else {
                        throw "Error occurred while retrieving the Quip user: " + error;
                    }
                });

            telemetry.registerQuipUserApiSuccess();
            return result;
        } catch(err) {
            console.info(`[quip-client] Error calling getUser: ${err}. Returning undefined`);
            telemetry.registerQuipUserApiError();
            return undefined;
        }
    }

    appendToEnd (id, content, timeout) {
        return this.writeSection(id, content, null, null, timeout);
    }

    appendAfterSection (id, content, sectionId, timeout) {
        return this.writeSection(id, content, 'AFTER_SECTION', sectionId, timeout);
    }

    replaceSection (id, content, sectionId, timeout) {
        return this.writeSection(id, content, 'REPLACE_SECTION', sectionId, timeout);
    }

    deleteSection (id, sectionId, timeout) {
        return this.writeSection(id, null, 'DELETE_SECTION', sectionId, timeout);
    }

    writeSection (id, content, location, sectionId, timeout) {
        if (id == null || content == null) {
            return Promise.reject();
        }
        if (location == null) {
            location = 'APPEND';
        }
        if (!QuipClient.LOCATION.hasOwnProperty(location)) {
            log.error(`[quip-client] write section error: invalid location ${location}`);
            return Promise.reject(`Error occurred while writing section: invalid location ${location}`);
        }
        if (sectionId == null && location !== 'APPEND' && location !== 'PREPEND') {
            log.error(`[quip-client] write section error: section ID cannot be null for location ${location}`);
            return Promise.reject(`Error occurred while writing section: section ID is null`);
        }

        log.info(`[quip-client] start writing section: ${location}...`);

        const editData = {
            'thread_id': id,
            'format': 'html',
            'location': QuipClient.LOCATION[location]
        };
        if (content) {
            editData.content = content;
        }
        if (sectionId) {
            log.info(`[quip-client] writing ${location} ${sectionId}`);
            editData.section_id = sectionId;
        }

        const editUrl = QuipClient.API_URL + '/threads/edit-document';
        log.info('[quip-client] calling endpoint: ' + editUrl);
        const updateRateLimit = (r) => this.updateRateLimit(r);

        return this.execute((res, rej) => {
            GM_xmlhttpRequest({
                method: 'POST',
                url: editUrl,
                data: Utils.getEncodedQueryData(editData),
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': 'Bearer ' + Settings.quipApiToken,
                },
                timeout: timeout || this.TIMEOUT,
                ontimeout: () => rej('Write section timeout'),
                onload: function (response) {
                    log.info('[quip-client] write section response: ' + response.status);
                    updateRateLimit(response);
                    if (response.status == 503 || response.status == 429) {
                        log.error('[quip-client] exceeded limit of calls per minute: ' + response.responseText);
                        rej("Error occurred while writing section - too many calls");
                    } else if (response.status != 200 && response.status != 304) {
                        log.error('[quip-client] write section error: ' + response.responseText);
                        rej("Error occurred while writing section");
                    } else {
                        res();
                    }
                },
                onerror: function (response) {
                    const cause = response.responseText || 'unknown';
                    log.error('[quip-client] write section error: ' + cause);
                    rej("Error occurred while writing section");
                }
            });
        });
    }

    async getBlob (id, blobId) {
        log.info('[quip-client] start document request...');
        const url = QuipClient.API_URL + `/blob/${id}/${blobId}`;
        return this.execute(this.httpGet(url, 'get blob', 'raw'))
            .catch(error => {
                if (error === 'TIMEOUT') {
                    //throw "Error occurred while retrieving the attachment - timeout";
                } else if (error === 'TOO_MANY_CALLS') {
                    throw "Error occurred while retrieving the attachment - too many calls";
                } else if (error === 'PARSING_ERROR' || error === 'INVALID_JSON') {
                    throw "Error occurred while parsing the attachment metadata";
                } else {
                    throw "Error occurred while retrieving the attachment";
                }
            });
    }

    async getAllMessages (id, messageType = 'message') {
        let result = undefined;
        let lastTimestamp = undefined;
        let messages = [];
        do {
            result = await this.getMessages(id, null, lastTimestamp, messageType);
            if (result && result.length > 0) {
                lastTimestamp = result.slice(-1)[0].created_usec - 1;

                messages = messages.concat(result);
            }
        } while (result && result.length > 0);

        // find all mentioned users and get their full name
        const userNames = messages.reduce((map, msg) => {
            map[msg.author_id] = msg.author_name, map;
            return map;
        }, {});

        // replace mentions with fullname
        for (let msg of messages) {
            const sanitizedText = Utils.sanitizeHTMLText(msg.text);
            msg.text = await Utils.replaceAsyncSequence(sanitizedText, /https:\/\/quip\.com\/(\w{11})/g, async (url, userId) => {
                let name = userId;
                try {
                    if (userNames[userId]) {
                        name = userNames[userId];
                    } else {
                        name = (await this.getUser(userId)).name;
                        userNames[userId] = name;
                    }
                    return `<a href="${url}" target="_blank" rel="noopener">${name}</a>`;
                } catch (ignore) {
                    return url;
                }
            });
        }

        return messages;
    }

    getMessages (id, count, maxTimestamp, messageType = 'message') {
        log.info('[quip-client] start get messages...');
        const requestUrl = QuipClient.API_URL + '/messages/' + id + '?' + Utils.getEncodedQueryData({
            count: count,
            max_created_usec: maxTimestamp,
            message_type: messageType,
        });

        return this.execute(this.httpGet(requestUrl, 'get messages'))
            .then(messages => {
                console.log(`[quip-client] get messages: found ${messages.length} messages`);
                return messages;
            })
            .catch(error => {
                if (error === 'TIMEOUT') {
                    /* Ignore the error */
                } else if (error === 'TOO_MANY_CALLS') {
                    throw "Error occurred while retrieving Quip messages - too many calls";
                } else if (error === 'PARSING_ERROR' || error === 'INVALID_JSON') {
                    throw "Error occurred while parsing Quip messages";
                } else {
                    throw "Error occurred while retrieving Quip messages";
                }
            });
    }

    httpGet (url, logLabel, responseType = 'json', apiToken = null) {
        log.info(`[quip-client] ${logLabel}: calling endpoint ` + url);
        const updateRateLimit = (h) => this.updateRateLimit(h);
        return (res, rej) => {
            GM_xmlhttpRequest({
                method: 'GET',
                url: url,
                headers: {
                    'Authorization': 'Bearer ' + (apiToken || Settings.quipApiToken)
                },
                responseType: responseType,
                timeout: this.TIMEOUT,
                ontimeout: () => {
                    log.error(`[quip-client] ${logLabel} error: timeout`);
                    rej('TIMEOUT');
                },
                onload: function (response) {
                    log.info(`[quip-client] ${logLabel} response: ${response.status}`);
                    const headers = QuipClient.parseResponseHeaders(response);
                    if (response.status == 400) {
                        log.error(`[quip-client] ${logLabel}: bad request`);
                        rej('BAD_REQUEST');
                    } else if (response.status == 401) {
                        log.error(`[quip-client] ${logLabel}: authentication error, invalid or expired token`);
                        rej('AUTH_ERROR');
                    } else if (response.status == 403) {
                        log.error(`[quip-client] ${logLabel}: resource access forbidden`);
                        rej('FORBIDDEN');    
                    } else if (response.status == 404) {
                        log.error(`[quip-client] ${logLabel}: resource not found`);
                        rej('NOT_FOUND');
                    } else if (response.status == 500) {
                        log.error(`[quip-client] ${logLabel}: resource not found`);
                        rej('SERVER_ERROR');    
                    } else if (response.status == 503 || response.status == 429) {
                        log.error(`[quip-client] ${logLabel} exceeded limit of calls per minute: ${response.responseText}`);
                        updateRateLimit(headers);
                        rej('TOO_MANY_CALLS');
                    } else if (response.status == 200 || response.status == 304) {
                        updateRateLimit(headers);
                        try {
                            if (responseType === 'raw') {
                                const contentDisposition = headers['content-disposition'].split(';');
                                const disposition = contentDisposition[0].trim();
                                const filename = contentDisposition[1].trim().match(/(?:^filename|[\s;,|]filename)\s*=\s*"(.+?)"/)[1];
                                res({
                                    blob: response.response,
                                    disposition: disposition,
                                    type: headers['content-type'],
                                    name: filename,
                                    length: headers['content-length']
                                });
                            } else {
                                const responseJson = (typeof response.responseText === 'string') ? 
                                    JSON.parse(response.responseText) : 
                                    response.responseText;
                                if (responseJson) {
                                    res(responseJson);
                                } else {
                                    log.error(`[quip-client] ${logLabel} error: not a valid json`);
                                    rej('INVALID_JSON');
                                }
                            }
                        } catch (ex) {   
                            log.error(`[quip-client] ${logLabel} error: ${JSON.stringify(ex)}`);
                            rej('PARSING_ERROR');
                        }
                    } else {
                        log.error(`[quip-client] ${logLabel} error: ${response.responseText}`);
                        rej('UNKOWN_RESPONSE');
                    }
                    
                },
                onerror: function (response) {
                    const cause = response.responseText || 'unknown';
                    log.error(`[quip-client] ${logLabel} error: ${cause}`);
                    rej('UNKOWN_ERROR');
                }
            });
        };
    }

    /**
     * Private method to execute an Wiki API call, respecting its TPS limits read/write call per second limit.
     *
     * @param {*} promise executor method
     */
    async execute (call) {
        // execute the API call
        return Utils.retry(async () => {
            const wait = this.rateLimitWaitUntil ? Math.max(0, this.rateLimitWaitUntil - new Date()) : 0;
            if (wait > 0) {
                log.info(`[quip-client] throttling quip client call: waiting ${wait} ms`);
                await Utils.sleep(wait);
            }
            return await new Promise(call);

        }, this.MAX_ATTEMPTS);
    }

    updateRateLimit (headers) {
        if (!headers) {
            return;
        }
        // X-Ratelimit-Limit: The number of requests/min the user can make
        // X-Ratelimit-Remaining: The number of requests remaining this user can make within the minute - this number changes with each request.
        // X-Ratelimit-Reset: The UTC timestamp for when the rate limit will reset
        const limit = parseInt(headers['x-ratelimit-limit']);
        const remaining = parseInt(headers['x-ratelimit-remaining']);
        const reset = parseInt(headers['x-ratelimit-reset']);
        log.info(`[quip-client] rate-limit: limit=${limit}, remaining=${remaining}, reset=${reset}`);
        if (remaining > 1) {
            this.rateLimitWaitUntil = null;
        } else {
            this.rateLimitWaitUntil = reset * 1000; // reset time in milliseconds
        }
    }

    static parseResponseHeaders (response) {
        if (!response && !response.responseHeaders) {
            return {};
        }
        const regex = /^([\w-]+):\s*(")?(.+)\2\s*$/;
        return response.responseHeaders.split('\n')
            .map(line => line.match(regex))
            .filter(m => !!m)
            .map(m => {
                const obj = {};
                obj[m[1]] = m[3];
                return obj;
            })
            .reduce((a, b) => ({...a, ...b}));
    }
}

QuipClient.API_URL = 'https://platform.quip-amazon.com/1';
QuipClient.LINK_REGEX = /https?:\/\/.*quip-amazon.com\/(\w{12})\/?/;
QuipClient.CHECK_TOKEN_TIMEOUT_ERROR = 'Check token timeout';
QuipClient.CHECK_TOKEN_NOT_A_QUIP_TOKEN_ERROR = 'Check token timeout';
QuipClient.LOCATION = {
    'APPEND': 0,          // Append to the end of the document.
    'PREPEND': 1,         // Prepend to the beginning of the document.
    'AFTER_SECTION': 2,   // Insert after the section specified by sectionId.
    'BEFORE_SECTION': 3,  // Insert before the section specified by sectionId.
    'REPLACE_SECTION': 4, // Delete the section specified by sectionId and insert the new content at that location.
    'DELETE_SECTION': 5   // Delete the section specified by sectionId (no content required).
};
/**
 * Models a Quip Document, allowing for basic data extraction such as sections, tags, etc.
 */
class QuipDocument {
    constructor (d) {
        if (!d || !d.thread || !d.thread.id || !d.thread.title || !d.html) {
            throw 'Invalid Quip document';
        }
        const validTypes = [ QuipDocument.TYPE_DOCUMENT, QuipDocument.TYPE_SPREADSHEET, QuipDocument.TYPE_SLIDES ];
        if (!validTypes.includes(d.thread.type)) {
            throw `${d.thread.type} is not a Quip document, spreadsheet, or slides`;
        }
        this.doc = d;
        this.parse();
        this.doc.thread.wikiAddr = this.getWikiSyncAddress();
        if (this.doc.thread.link) {
            const match = this.doc.thread.link.match(QuipClient.LINK_REGEX);
            if (match && match[1]) {
                this.doc.thread.linkId = match[1];
            }
        }
        this.sheets = null;
    }

    parse () {
        this.html = new DOMParser().parseFromString(this.doc.html, 'text/html');
    }

    get id () {
        return this.doc.document_id || this.doc.thread.id;
    }

    get linkId () {
        return this.doc.thread.linkId || this.id;
    }

    get title () {
        return this.doc.thread.title;
    }

    /**
     * Retrieves a Wiki compatible title, to be used as path
     * Reference from Wiki: https://tiny.amazon.com/2wsxuzu7
     */
    get titleAsUrl () {
        const suggestedTitle = this.doc.thread.title
            .replace(/\s+/g, '')
            .replace(/\\/g, '/')
            .replace(/\/+/g, '/')
            .replace(/[^\w\-]/g, '')
            .replace(/^_+|_+$/g, '');
        log.info('suggested title: ' + suggestedTitle);
        return suggestedTitle;
    }

    get lastUpdated () {
        return this.doc.thread.updated_usec;
    }

    get wikiAddr () {
        return this.doc.thread.wikiAddr;
    }

    get type () {
        return this.doc.thread.type;
    }

    get isDocument () {
        return this.type === QuipDocument.TYPE_DOCUMENT;
    }

    get isSpreadsheet () {
        return this.type === QuipDocument.TYPE_SPREADSHEET;
    }

    get isSlides () {
        return this.type === QuipDocument.TYPE_SLIDES;
    }

    get htmlContent () {
        return this.doc.html;
    }

    set htmlContent (html) {
        this.doc.html = html;
        this.parse();
    }

    get sheetsDesiredOrder () {
        return this.sheets;
    }

    set sheetsDesiredOrder (desiredOrder) {
        if (!Utils.arraysEqual(this.getSheetNames(), desiredOrder)) {
            log.warn("the sheets in editor do not match sheets in doc");
        }
        if (Utils.arraysEqualSameOrder(this.sheets, desiredOrder)) {
            return;
        }
        this.sheets = desiredOrder;
    }

    getHeader () {
        return Object.assign({}, this.doc.thread); // clone document header
    }

    getLastSectionId () {
        const content = this.doc.html;
        // find last section in quip document
        const regex = /id=(["'])(.+?)\1/g
        let sectionId;
        let result;
        while (result = regex.exec(content)) {
            sectionId = result[2];
        }
        log.info('Last section_id: ' + sectionId);
        return sectionId;
    }

    /**
     * Finds the section in the Quip document where the given Quip2Wiki tag available in the Quip document.
     * If 'tagName' is provided, it will match the exact tag. If 'tagName' is null, it will match the first
     * valid tag.
     *
     * Quip2Wiki tag must have the following patterns:
     *   --<tag-name>: "<tag_value>"--
     *
     * @param {string} tagName name of the Quip2Wiki tag
     * @returns the section id where the tag is (null if not found)
     */
    findTagSection (tagName) {
        let tagPattern;
        if (tagName) {
            log.info(`finding '${tagName}' tag section...`);
            tagPattern = `--${tagName}(:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*)?--`;
        } else {
            log.info(`finding first tag section...`);
            // except wiki-macro and wiki-ignore which can be in the middle of the doc
            tagPattern = `--wiki-(?!macro|ignore)\\w+?(:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*)?--`;
        }

        const tagRegex = new RegExp(tagPattern);
        const sectionRegex = /id=(["'])(.+?)\1/;

        const elements = this.html.getElementsByTagName('body')[0].querySelectorAll('p,pre');

        for (let element of elements) {
            const elHtml = element.outerHTML;
            const content = elHtml.replace(/<[^>]*?>/g, '');

            const tagMatch = content.match(tagRegex);
            if (tagMatch == null || tagMatch[1] == null) {
                continue;
            }

            const tag = tagMatch[0].trim();
            log.info(`tag found: '${tag}'`);

            // get section_id
            const result = elHtml.match(sectionRegex);
            if (result == null || result[2] == null) {
                continue;
            }

            return result[2];
        }

        log.info(`tag not found!`);
        return null;
    }

    /**
     * Finds if given Quip2Wiki tag is available in the Quip document.
     * If 'tagName' is provided, it will match the exact tag. If 'tagName' is null, it will match the first
     * valid tag.
     *
     * Quip2Wiki tag must have the following patterns:
     *   --<tag-name>: "<tag_value>"--
     *
     * @param {string} tagName name of the Quip2Wiki tag
     * @returns true when the tag is found somewhere in the document
     */
    findTag (tagName) {
        log.info(`finding '${tagName}' tag...`);
        const tagPattern = `--${tagName}(:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*)?--`;
        const tagRegex = new RegExp(tagPattern);

        const elements = this.html.getElementsByTagName('body')[0].querySelectorAll('p,pre');

        for (let element of elements) {
            const elHtml = element.outerHTML;
            const content = elHtml.replace(/<[^>]*?>/g, '');

            const tagMatch = content.match(tagRegex);
            if (tagMatch) {
                const tag = tagMatch[0].trim();
                log.info(`tag found: '${tag}'`);
                return true;
            }
        }

        log.info(`tag not found!`);
        return false;
    }

    /**
     * Reads a given Quip2Wiki tag value. If not present, it will return the given default value.
     *
     * Tags must have one of the following patterns:
     * > --<tag-name>--
     * > --<tag-name>:"<tagValue>"--
     *
     * @param {string} tagName name of the Quip2Wiki tag
     * @param {string} defaultValue value to be returned if tag is not found
     */
    readTagValue (tagName, defaultValue) {
        const tagRegex = new RegExp(`--${tagName}:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*--`);

        log.info(`get '${tagName}' tag value...`);
        const elements = this.html.getElementsByTagName('body')[0].querySelectorAll('p,pre');

        for (let element of elements) {
            const elHtml = element.innerHTML;
            const content = elHtml.replace(/<[^>]*?>/g, '');

            const tagMatch = content.match(tagRegex);
            if (tagMatch == null || tagMatch[1] == null) {
                continue;
            }

            const tagValue = tagMatch[1].trim();
            log.info(`'${tagName}' tag found: value='${tagValue}'`);

            return tagValue;
        }

        log.info(`'${tagName}' tag not found!`);
        return defaultValue;
    }

    /**
     * Reads all occurencies of a given Quip2Wiki tag value and returns their value as an array.
     *
     * Tags must have the following pattern:
     * > --<tag-name>:"<tagValue>"--
     *
     * @param {string} tagName name of the Quip2Wiki tag
     * @param {string} defaultValue value to be returned if tag is not found
     */
    readTagValues (tagName) {
        const tagRegex = new RegExp(`--${tagName}:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*--`);

        const output = [];

        log.info(`get '${tagName}' tag value...`);
        const elements = this.html.getElementsByTagName('body')[0].querySelectorAll('p,pre');

        for (let element of elements) {
            const elHtml = element.innerHTML;
            const content = elHtml.replace(/<[^>]*?>/g, '');

            const tagMatch = content.match(tagRegex);
            if (tagMatch == null || tagMatch[1] == null) {
                continue;
            }

            const tagValue = tagMatch[1].trim();
            if (!tagValue) {
                continue;
            }

            log.info(`'${tagName}' tag found: value='${tagValue}'`);
            output.push(tagValue);
        }

        log.info(`Found ${output.length} occurencies of '${tagName}' tag`);
        return output;
    }

    /**
     * Retrieves all instances of a given tag and validates their value as a relative Wiki Page address.
     */
    readTagValuesWithArguments (tagName) {
        return this.readTagValues(tagName)
            .map(value => value.split(/\|(.*)/)) // split only on the first '|'
            .map(parts => ({ value: parts[0], args: parts[1]}))
            .filter(obj => !!obj.value || !!obj.args);
    }

    /**
     * Retrievies the Wiki Page TAGs from the 'tags' tag in the document.
     *
     * The 'tags' tag follows the pattern as shown in the example:
     * > --wiki-tags: "tag1; tag2; tag3"--
     */
    getWikiTags () {
        const tagValue = this.readTagValue(QuipDocument.TAGS_TAG, null);
        if (tagValue == null) {
            return [ ];
        }

        const tags = tagValue.split(/\s*[;,]\s*/);

        log.info('wiki tags: ' + tags);
        return tags;
    }

    /**
     * Retrievies the Wiki Page address from the 'wiki-sync' tag in the document.
     */
    getWikiSyncAddress () {
        const tagValue = this.readTagValue(QuipDocument.SYNC_TAG, null);
        if (!tagValue) {
            return null;
        }
        const addr = this.validateWikiAddress(tagValue);
        if (addr) {
            log.info('wiki sync page: ' + addr);
        }
        return addr;
    }

    /**
     * Retrievies the Wiki Syntax from the 'syntax' tag in the document. If tag is not available, returns
     * default 'xhtml' syntax.
     *
     * The 'syntax' tag follows the pattern as shown in the example:
     * > --wiki-syntax:"xhtml"--
     * > --wiki-syntax:"xwiki"--
     * > --wiki-syntax:"markdown"--
     */
    getWikiSyntax () {
        const defaultSyntax = 'xhtml';
        const value = this.readTagValue(QuipDocument.SYNTAX_TAG);
        const syntax = (value || defaultSyntax).trim().toLowerCase();
        if (!['xhtml', 'xwiki', 'markdown'].includes(syntax)) {
            throw `Invalid wiki syntax: ${syntax}`;
        }
        return syntax;
    }

    /**
     * Gets all header tags from the document.
     */
    getWikiHeaders () {
        return this.readRelativeWikiAddressTags(QuipDocument.HEADER_TAG);
    }

    /**
     * Gets all footer tags from the document.
     */
    getWikiFooters () {
        return this.readRelativeWikiAddressTags(QuipDocument.FOOTER_TAG);
    }

    /**
     * Retrieves all instances of a given tag and validates their value as a relative Wiki Page address.
     */
    readRelativeWikiAddressTags (tagName) {
        return this.readTagValuesWithArguments(tagName)
            .filter(obj => !!obj.value)
            .map(obj => (
                {
                    addr: WikiClient.extractWikiRelativeAddr(this.validateWikiAddress(obj.value)),
                    args: obj.args
                }
            ));
    }

    /**
     * Validates and extracts the Wiki Page address from the given value.
     *
     * The value should follow the pattern as shown in the examples:
     * > https://w.amazon.com/bin/view/Quip2Wiki/HTML
     * > w?Quip2Wiki/HTML
     * > Quip2Wiki/HTML
     */
    validateWikiAddress (value) {
        if (value == null) {
            return null;
        }
        const match = value.match(WikiClient.WIKI_URL_REGEX);
        if (match == null || match[1] == null) {
            log.info(tag + ' tag value is invalid: ' + value);
            return null;
        }
        return match[1];
    }

    /**
     * Retrievies the Wiki Page title (override) from the 'title' tag in the document. If tag is not available, returns
     * the document title.
     *
     * The 'sync' tag follows the pattern as shown in the example:
     * > --wiki-title:"title of the wiki"--
     */
    getWikiTitle () {
        const defaultTitle = this.title;
        return this.readTagValuesWithArguments(QuipDocument.TITLE_TAG).map(obj => obj.value)[0] || defaultTitle;
    }

    /**
     * Set the default value for some configurations when necessary
     * 
     * @param {object} options 
     */
    setDefaultOptions(options) {
        if (options.fixImageCentering === undefined) {
            options.fixImageCentering = false;
        }
    }

    /**
     * Retrievies the wiki options.
     *
     * The 'wiki-options' tag follows the pattern as shown in the example:
     * > --wiki-options:"fixImageCentering,fixSomethingElse"--
     * or the equivalent form that is also supported:
     * > --wiki-options:"fixImageCentering=true,fixSomethingElse=true"--
     */
    getWikiOptions() {
        let q2wOptionsB64 = this.readTagValues(QuipDocument.Q2W_OPTIONS_TAG);
        let options = { };
        if (q2wOptionsB64.length > 0) {
            options = base64ToObj(q2wOptionsB64[0]);
        }
        this.setDefaultOptions(options);

        var optionsInDoc = this.readTagValues(QuipDocument.OPTIONS_TAG);

        if (!optionsInDoc) return options;

        for (const opt of optionsInDoc) {
            const docOptionsArray = opt.split(",");
            for (const keyValuePair of docOptionsArray) {
                if (!keyValuePair.includes("=")) {
                    // if only the keyword appears, we default to true
                    options[keyValuePair] = true;
                    continue;
                }

                // else we look at which value is present
                var temp = keyValuePair.split("=");
                const key = temp[0];
                var value = temp[1];
                if (value == "true" || value == "True")
                    value = true;
                if (value == "false" || value == "False")
                    value = false;
                
                options[key] = value;
            }
        }

        return options;
    }

    /**
     * Retrievies the presense of not of the wiki-commenst tag in the document. Returns true If tag is available.
     */
    getWikiComments () {
        return this.findTag(QuipDocument.COMMENTS_TAG, false);
    }

    /**
     * Returns sorted list of sheets/tables of the document.
     *
     */
    getSheetNames () {
        if (!this.isSpreadsheet && !this.isDocument) {
            return [];
        }

        return [...this.html.querySelectorAll('table')].map(table => table.title);
    }

    /**
     * Rearanges elements based on layout extracted from Quip page (not Quip API).
     *
     */
    fixMultiColumnLayout (layout) {
        if (!this.isDocument) {
            return;
        }

        log.info("fix multi-column layout...");

        let content = this.doc.html
            .replace(/<div class='empty'>(<img src='data:image\/gif;base64.*?'[^<>]*?><\/img>)<\/div>/g, '$1') // remove extra div of videos without poster
            .replace(/<div style='display:flex;[^<>]*>(<div[^<>]*data-section-style='11'[^<>]*><img src=[^<>]*?><\/img>)<\/div>(<span>.*?<\/span><\/div>)/g, '$1<br/>$2'); // remove outer div of videos

        for (const container of layout) {
            let containerHTML = container.outerHTML;
            let begin = undefined;
            let end  = undefined;

            // find all related sections in document and move them to container
            const elements = container.getElementsByTagName('span');
            for (let el of elements) {
                const id = el.getAttribute('id');

                const sId = Utils.escapeRegExp(id);
                const sectionRegex1 = new RegExp(`<(h1|h2|h3|hr|p|blockquote|q)[^<>]*id='${sId}'[^<>]*>[\\s\\S]*?<\\/\\1>`);
                const sectionRegex2 = new RegExp(`<div [^<>]*data-section-style=[^<>]*><(img|ul|span)[^<>]*?id='${sId}'[\\s\\S]*?<\\/\\1>[\\s\\S]*?<\\/div>`);
                let match = content.match(sectionRegex1) || content.match(sectionRegex2);
                if (match && match[0]) {
                    let matchedSection = match[0];

                    if (matchedSection.startsWith("<pre id='" + id)) {
                        // fix duplicated html content when a column is completely encapsulated in a code block
                        matchedSection = matchedSection.substring(0, matchedSection.indexOf("</pre>") + 6);
                    }

                    // save section position in content
                    const pos = content.indexOf(matchedSection);
                    if (!begin) {
                        begin = pos;
                    }
                    end = pos + matchedSection.length;

                    // add section to container
                    containerHTML = containerHTML.replace(`<span id="${id}"></span>`, '\n' + matchedSection); // replace in the container
                } else {
                    containerHTML = containerHTML.replace(`<span id="${id}"></span>`, ''); // remove section
                    log.warn(`section with id=${id} not found!`);
                }
            }

            if (begin && end) {
                // place container in document
                content = content.replace(content.substring(begin, end), containerHTML);
            }
        }

        // update document content
        this.htmlContent = content.replace(/(<img[^<>]*?>)(?!<\/img>)/g, '$1</img><br/>'); // fix end tag and add new line to adjust text placement
    }

    /**
     * Rearanges elements based on layout extracted from Quip page (not Quip API).
     *
     */
    fixMathFormulas (controls) {
        if (!this.isDocument) {
            return;
        }

        log.info("fix math formulas...");

        let content = this.htmlContent;

        controls.forEach((controls, sectionId, map) => {
            const sId = Utils.escapeRegExp(sectionId);
            const sectionRegex = new RegExp(`<(h1|h2|h3|hr|p|blockquote|div|span)\\s[^<>]*id=(["'])${sId}\\2[^<>]*>[\\s\\S]*?<\\/\\1>`);
            let match = content.match(sectionRegex);
            if (match && match[0]) {
                // add section to container
                let index = 0;
                const fixedSection = match[0].replace(/<control((?!\S)[^<>]*?)?>[\s\S]*?<\/control>/g, (match) => {
                    const mathEq = controls[index++];
                    if (mathEq) {
                        return `<math>${mathEq}</math>`;
                    } else {
                        return match;
                    }
                }); // replace in the container

                if (index > 0) { // at least one math formula fixed
                    content = content.replace(match[0], fixedSection);
                }
            }
        });

        // update document content
        this.htmlContent = content;
    }

    /**
     * Add design-inspector URL to the matching div based on data extracted from Quip page (not Quip API).
     *
     */
    fixDesignInspectorDiagrams (diagrams) {
        log.info("fix design-inspector diagrams...");

        let content = this.htmlContent;

        diagrams.forEach((diData, key) => {
            const divRegex = new RegExp(`<div\\s[^<>]*data-unique-id=(["'])${key.section}-.*?\\1\\s*data-live-app-id=(["'])${key.id}\\2[^<>]*>[\\s\\S]*?<\\/div>`);
            let match = content.match(divRegex);
            if (match && match[0]) {
                // replace by a design-inspector specific tag
                content = content.replace(match[0], `<design-inspector src='${diData.diUrl}' width='${diData.width}' height='${diData.height}' />`);
            } else {
                log.error(`could not find div section for di-inspector '${JSON.stringify(key)}'`);
            }
        });

        // update document content
        this.htmlContent = content;
    }

    /**
     * Match a video section and replace with a <video> tag with a link to blob in Quip doc.
     *
     */
    fixVideos () {
        log.info("fix videos...");

        let content = this.htmlContent;

        // replace video poster
        content = content.replace(/<div data-section-style='11'[^<>]*><img src='(data:image\/gif;base64,.*?)'[^<>]*>/g, // replace default video poster image
            (m, imgData) => m.replace(imgData, XHtmlConverter.VIDEO_POSTER));

        // convert videos in <video>
        content = content.replace(QuipDocument.VIDEO_PATTERN, (m, q1, imgSrc, q2, videoUrl, title) => {
            const imgUrl = imgSrc.startsWith('/blob/') ? `https://quip-amazon.com${imgSrc}`: imgSrc
            const sanitizedVideoUrl = Utils.sanitizeHTMLAttribute(videoUrl);
            const sanitizedImgUrl = Utils.sanitizeHTMLAttribute(imgUrl);
            const sanitizedTitle = Utils.sanitizeHTMLAttribute(title);
            return `<video src="${sanitizedVideoUrl}" width="auto" height="auto" controls="true" poster="${sanitizedImgUrl}" title="${sanitizedTitle}"/>`;
        });

        // update document content
        this.htmlContent = content;
    }

    fixTableIds () {
        /*
        log.info("adding ids to tables...");

        let content = this.htmlContent;

        // determine ids and set same order as in Spreadsheet
        const sheetOrder = this.sheetsDesiredOrde?.map(title => Utils.sanitizeHTMLText(title));
        const getSheetOrder = (title) => {
            const index = sheetOrder?.indexOf(title);
            return index >= 0 ? index : null;
        };

        this.html.querySelectorAll('table').forEach((table, index) => {
            const id = 'table' + (getSheetOrder(table.title) || index);
            content = content.replace(new RegExp(`<table ([^<>]*title=(['\"])${Utils.escapeRegExp(table.title)}\\1[^<>]*>)`), `<table id='${id}' $1`);
        });

        // update document content
        this.htmlContent = content;
        */
    }

    getAttachments () {
        const content = this.htmlContent;
        // extract images and file attachments
        log.info("get image attachments...");
        const imagesTable = QuipDocument.getAttachmentsWithPattern(content, QuipDocument.IMAGE_PATTERN);
        log.info("get file attachments...");
        const filesTable = QuipDocument.getAttachmentsWithPattern(content, QuipDocument.FILE_PATTERN);
        return new Map([...imagesTable, ...filesTable])
    }

    /**
     * Extract attached items as a Map() where key is the filename and value is the URL, based on a given pattern.
     *
     * @param {string} content of the document being saved.
     * @param {RegExp} pattern of the attachment, containing 5 capturing groups: url (attachment url), id (blob id), name (filename), value (name/title)
     */
    static getAttachmentsWithPattern (content, pattern) {
        const files = new Map();
        let match;
        do {
            match = pattern.exec(content);
            if (match && match.groups) {
                const { url, id, name, value } = match.groups;
                const validName = this.getValidAttachmentName(name || value)
                // title will have a prefix with blob id
                // Since title len cannot more than 255 we truncate to account for blob id and dash chars
                const validNameTrunc = validName.substring(0, 232);
                const title = `${id}_${validNameTrunc}`;
                files.set(title, { name: validName, url: url });
            }
        } while (match);

        log.info(Utils.mapToString(files));
        return files;
    }

    static getValidAttachmentName (name) {
        if (name.includes(".png")) return "image.png";
        if (name.includes(".jpg")) return "image.jpg";
        if (name.includes(".jpeg")) return "image.jpeg";
        if (name.includes(".gif")) return "image.gif";
        if (name.includes(".svg")) return "image.svg";
        if (!name || name.length > 16) {
            return "image";
        } else {
            return decodeURI(name)
                .replace(/[\/:\+]|&lt;|&gt;|&amp;|&quot;|&#x27;/g, '') // remove invalid chars
                .replace(/\u202f/g, ' ') // remove space-like chars that are not supported by wiki (thanks @xuyuhui)
                .replace(/[^\p{L}\p{N}\p{P}\p{Z}^$\n]/gu, '') // remove emojis
                .replace(/[^\S\r\n]{2}/g, ' '); // remove double spacces
        }
    }
}

// document types
QuipDocument.TYPE_DOCUMENT = "document";
QuipDocument.TYPE_SPREADSHEET = "spreadsheet";
QuipDocument.TYPE_SLIDES = "slides";

// attachment patterns (blob is capturing group 3 and title is group 5)
// <img src='/blob/eAI9AAsEDXW/avrCFDc4PdEndk2cjeDsLR' alt='image-name'></img>
// <img src='/blob/aUd9AAeLQcz/02TA-HUs-OE7_QMeGbv7JA' id='aUd9CAZgwim'></img>
QuipDocument.IMAGE_PATTERN = /<img src=(["'])(?<url>\/blob\/.{11}\/(?<id>.{22}))\1(?: [^<>]*alt=(["'])(?<name>.*?)\4)?[^<>]*>(?<value>.*?)<\/img>/g;
// <a href="https://quip-amazon.com/-/blob/aUd9AAeLQcz/ruVea4Yon2C5TxaXcdvmvA?name=Attachment-PDF.pdf">Attachment-PDF.pdf</a>
// <a href="https://quip-amazon.com/-/blob/aUd9AAeLQcz/ruVea4Yon2C5TxaXcdvmvA?s=UGb4AxAgFwmB&amp;name=Attachment-PDF.pdf">Attachment-PDF.pdf</a>
// <a href="https://quip-amazon.com/-/blob/AUS9AALzbrm/STXrHVBmOffwHM_lKJVYjg?name=Attachment.docx&amp;s=mna2AaApi1MN">Attachment.docx</a>
QuipDocument.FILE_PATTERN = /<a href=(["'])(?<url>https?:\/\/quip-amazon\.com\/-\/blob\/.{11}\/(?<id>.{22})\?(?:.*?)?name=(?<name>.+?)(?:&amp;.+?)?)\1[^<>]*?>(?<value>.*?)<\/a>/g;

// <div class='empty'><img src='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==' id='eAI9CAuhlKb' alt='' class='image'></img></div></div><span>Video: <a href=https://quip-amazon.com/blob/eAI9AAsEDXW/jMbiJaHK0hrJHlp052eL0Q target='_blank'>SampleVideo_360x240_10mb.mp4</a></span>
// <img src='/blob/eAI9AAsEDXW/iaSCFbc5PdEndk2cj_DWLw00001-png' id='eAI9CAvGDJt' alt=''></img></div><span>Video: <a href=https://quip-amazon.com/blob/eAI9AAsEDXW/iaSCFbc5PdEndk2cj_DWLw target='_blank'>Pexels Videos 1181911.mp4</a></span>
QuipDocument.VIDEO_PATTERN = /<img src=(["'])(.*?)\1[^<>]*?><\/img><br\/><span[^<>]*>Video: <a href=(["'])(.*?)\3 [^<>]*>(.*?)<\/a><\/span>/g;

// Quip2Wiki tags (--tag--)
QuipDocument.SYNC_TAG = 'wiki-sync';
QuipDocument.TAGS_TAG = 'wiki-tags';
QuipDocument.TITLE_TAG = 'wiki-title';
QuipDocument.OPTIONS_TAG = 'wiki-options';
QuipDocument.Q2W_OPTIONS_TAG = 'quip2wiki-options';
QuipDocument.SYNTAX_TAG = 'wiki-syntax';
QuipDocument.HEADER_TAG = 'wiki-header';
QuipDocument.FOOTER_TAG = 'wiki-footer';
QuipDocument.TOC_TAG = 'wiki-toc';
QuipDocument.MACRO_TAG = 'wiki-macro';
QuipDocument.COMMENTS_TAG = 'wiki-comments';
QuipDocument.SHEETS_TAG = 'wiki-sheets';
QuipDocument.SORTABLE_TABLES_TAG = 'wiki-sortable-tables';
QuipDocument.IGNORE_TAG = 'wiki-ignore';
QuipDocument.TRACKER_TAG = 'wiki-tracker';
QuipDocument.BANNER_TAG = 'wiki-banner';
// Quip2Wiki inline tags (<<tag>>)
QuipDocument.TABLE_SORTABLE_INLINE_TAG = 'sortable';
QuipDocument.TABLE_SORT_ONLY_INLINE_TAG = 'sort-only';
QuipDocument.TABLE_FILTER_ONLY_INLINE_TAG = 'filter-only';

/**
 * Basic operations associated to the current loaded Quip Document web page (user inteface).
 */
class QuipEditor {

    /**
     * Retrieves the document id from the URL of the current loaded page.
     *
     * The URL pattern for extracting the id must be as follows:
     * https://quip-amazon.com/UGb4AxAgFwmB/title-of-the-quip-doc-or-folder
     */
    static getId () {
        const url = window.location.href;
        const match = url.match(QuipClient.LINK_REGEX);
        if (match && match[1]) {
            return match[1];
        } else {
            return null;
        }
    }

    static isLoginPage () {
        return document.location.href.startsWith('https://quip-amazon.com/account/login?next=');
    }

    static isDocument () {
        return !QuipEditor.isLoginPage() && !QuipEditor.isFolder();
    }

    static isFolder () {
        return !QuipEditor.isLoginPage() && !!document.body.querySelector('div.nav-path-folder');
    }

    static getDocumentType () {
        if (QuipEditor.isDocument()) {
            const mainMenuName = document.querySelector('button.navigation-controller-menu>div.button-text')?.textContent;
            const hasSpreadsheetMenu = mainMenuName === 'Spreadsheet' || (mainMenuName !== 'Document' && mainMenuName !== 'Folder');
            const hasSheetNames = QuipEditor.extractSheetNames().length > 0;
            if (hasSpreadsheetMenu && hasSheetNames) {
                return 'spreadsheet';
            } else {
                return 'document';
            }
        } else if (QuipEditor.isFolder()) {
            return 'folder';
        } else {
            return null;
        }
    }

    static getDocumentId () {
        const id = QuipEditor.isDocument() ? QuipEditor.getId() : null;
        if (!id) {
            return null;
        }
        log.info('doc id: ' + id);
        return id;
    }

    static getFolderId () {
        const id = QuipEditor.isFolder() ? QuipEditor.getId() : null;
        if (!id) {
            return null;
        }
        log.info('folder id: ' + id);
        return id;
    }

    static isTokenPage () {
        return window.location.href.startsWith(QuipEditor.TOKEN_PAGE_URL);
    }

    static async showTokenPage () {
        log.info('Opening token page');
        return await GM_openInTab(QuipEditor.TOKEN_PAGE_URL, { active: true });
    }

    static hasListOfDocuments () {
        return document.getElementsByClassName('nav-path-folder')[0] != null;
    }

    static getBaseButtonForExportButton() {
        let selector = "[aria-label='Focus Mode']";
        let baseButtonLoc = $(selector)[0];
        if (!baseButtonLoc) {
            selector = "[aria-label='Add to Favorites']";
            let favoriteElements = $(selector);
            if (favoriteElements.length === 1)
                baseButtonLoc = favoriteElements[0];
        }
        return baseButtonLoc;
    }

    static createQuip2WikiButtons(onclick) {
        if ($("#export-wiki-button-group")[0]) return; // button has already been added to the toolbar

        log.log("Trying to insert export button...");

        let baseButtonLoc = this.getBaseButtonForExportButton()

        if (baseButtonLoc) {
            let exportButtonHtml = 
`<div class="change-access-button-group button-group" id="export-wiki-button-group">
    <div class="button-group-border"></div>
    <div class="button-group-buttons">
        <button class="change-access-button button button-flex clickable dark" style="background-color: rgb(var(--quipAction)); height: 32px; padding-left: 8px; padding-right: 4px; color: rgb(255, 255, 255); fill: rgb(255, 255, 255);"
                data-mousedown="no-caret-move" aria-describedby="change-access-button-text" id="export-doc-button">
            <div class="button-text" style="font-size: 14px; line-height: 32px; margin-right: 4px;" id="export-wiki-button-text">Export to Wiki</div>
        </button>
        <button class="button button-flex clickable icon-only dark" style="background-color: rgb(var(--quipAction)); height: 32px; padding-left: 8px; padding-right: 8px; color: rgb(255, 255, 255); fill: rgb(255, 255, 255);"
            data-mousedown="no-caret-move" aria-label="Quip2Wiki configurations" id="q2w-config-button">
            <div class="button-text" style="font-size: 14px; line-height: 32px;">
                <span style='font-family: "Neue Haas Grotesk Display Web", Helvetica, sans-serif, "Quip Glyphs";font-size: 28px;'>&#9881;</span>
            </div>
        </button>
    </div>
</div>`;

            $(exportButtonHtml).insertAfter(baseButtonLoc);

            let exportButton = $("#export-doc-button");
            exportButton.click(onclick);

            $("#q2w-config-button").click(showLogModal);
            $("#q2w-config-button").remove();

            log.log("Export button successfully inserted");
        } else {
            log.error("Base location for export button not found");
        }
    }

    static getToolbar () {
        return document.querySelector('#export-wiki-button-group');
    }

    /**
     * Creates a label in Quip's footer section.
     *
     * @param {string} id identifier of the label to be created
     * @param {string} label button label
     * @param {function} onclick action to be executed when the butotn is clicked
     */
    static createAppFooter (id, label, onclick) {
        let footerLabel = document.getElementById(id);
        if (footerLabel != null) {
            footerLabel.innerHTML = label;
        } else {
            const appBody = document.getElementsByClassName('navigation-controller-body scrollable')[0];
            if (appBody == null) {
                return;
            }

            const footerLabel = document.createElement("div");
            footerLabel.id = id;
            footerLabel.innerHTML = label;

            if (onclick) {
                Utils.addListener(footerLabel, 'click', onclick);
            }

            appBody.appendChild(footerLabel);
        }
    }

    static removeElement (id) {
        const element = document.getElementById(id);
        if (element) {
            element.parentNode.removeChild(element);
        }
    }

    static async writeWikiAddressTag (doc, wikiAddr, quipClient) {
        const wikiUrl = WikiClient.VIEW_URL + wikiAddr; // wiki full address
        const tagName = QuipDocument.SYNC_TAG;
        const tagValue = `<a href="${wikiUrl}" target="_blank" rel="noopener">${wikiAddr}</a>`;
        await QuipEditor.writeTag(doc, tagName, tagValue, quipClient);
    }

    static async writeTag (doc, tagName, tagValue, quipClient) {
        if (doc == null || tagName == null) {
            return;
        }

        const docId = doc.id;

        // find current tag
        let sectionId = doc.findTagSection(tagName);

        const tag = `<p><i>--${tagName}: "${tagValue}"--</i></p>`;
        if (sectionId) {
            log.info(`replacing tag '${tagName}' on quip, at sectionId '${sectionId}'...`);
            await quipClient.replaceSection(docId, tag, sectionId);
        } else {            
            // find any tag (except macro tag)
            log.info(`appending tag '${tagName}' on quip...`);
            const separatorLine = !doc.findTagSection() ? '<p><hr></hr></p>\n' : '';
            const sectionContent = separatorLine + tag;
            await quipClient.appendToEnd(docId, sectionContent); // append at end of document
        } 
    }

    /**
     * Extracts the list of sheets of a spreadsheet
     * @returns list of sheets
     */
    static extractSheetNames () {
        return [...document.querySelectorAll('div[role=tablist]>div[role=tab]>span')].map(span => span.textContent);
    }

    /**
     * Extracts multi-column layout from Quip Editor page with sizing and column width. Internal content is included as `span` tags with the `id` from their original content.
     *
     * The Layout is composed of a list of `div` containers that contain multiple `content` elements such as paragraph, images, etc.
     *
     */
    static extractMultiColumnLayout () {
        log.info('find mult-column layout containers...');
        const layoutOutput = [];

        // build layout based on flexbox containers
        const containers = document.querySelectorAll('.flexbox-layout-container');
        for (const element of containers) {
            const elContainer = document.createElement('div');
            elContainer.setAttribute('class', 'flexbox-layout-container');
            elContainer.setAttribute('style', 'max-width:100%; display: flex;');

            let hasElements = false;
            const columns = element.getElementsByClassName('flexbox-layout-column');

            const getColWidth = (c) => Number(c.style.width.replace('px', ''));

            // determine full width based on columns sizes
            const width = Array.from(columns)
                .map(getColWidth)
                .reduce((acc, w) => acc + w, 0);

            // determine column content
            for (let col of columns) {
                const colWidth = getColWidth(col);
                const colWidthPercent = Math.round(colWidth * 100 / width);

                const elColumn = document.createElement('div');
                elColumn.setAttribute('class', 'flexbox-layout-column');
                elColumn.setAttribute('style', `max-width:100%; flex: ${colWidthPercent}%; padding-right: 14px;`);

                // find all content items and add to column
                const elContentElements = col.getElementsByClassName('content');
                for (const content of elContentElements) {
                    const elColItem = document.createElement('span');
                    elColItem.setAttribute('id', content.getAttribute('data-id'));

                    elColumn.appendChild(elColItem);
                    hasElements = true;
                }

                elContainer.appendChild(elColumn);
            }

            if (hasElements) {
                layoutOutput.push(elContainer);
                log.info('Multi-column layout: ' + elContainer.outerHTML);
            } else {
                log.error('Container has no elements: ' + elContainer.outerHTML);
            }
        }
        return layoutOutput;
    }

    /**
     * Extracts math formula controls from Quip Editor page. Math formulares are available in `annotation` tags (under a `math` tags).
     *
     * The output is a map of doc section ids to a list math equations. Since we can't differentiate math controls from others, we export a list
     * with the math content of all controls within that section. When value is null, it means the control is another not a math equation type of control.
     *
     */
    static extractMathFormulas () {
        log.info('find math equations...');

        const output = new Map();

        // find all math equations and return their parent section
        const sections = [...document.querySelectorAll('math > semantics > annotation[encoding="application/x-tex"]')]
            .map(el => Utils.getAncestorWithAttribute(el, 'data-id'));
        // for each section, find the list math equations from existing controls (value is null, control is not a math equation)
        sections.forEach(elSection => {
            const id = elSection.getAttribute('data-id');
            if (!output.has(id)) {
                const controls = [...elSection.querySelectorAll('control')]
                    .map(elControl => {
                        const elMath = elControl.querySelectorAll('math > semantics > annotation[encoding="application/x-tex"]');
                        return elMath.length > 0 ? elMath[0].textContent : null;
                    });
                output.set(id, controls);
            }
        });

        log.info(Utils.mapToString(output));
        return output;
    }

    /**
     * Extracts design-inspector frames from Quip Editor page.
     *
     * The output is a map of doc section ids to a list math equations. Since we can't differentiate math controls from others, we export a list
     * with the math content of all controls within that section. When value is null, it means the control is another not a math equation type of control.
     *
     */
    static extractDesignInspectorDiagrams () {
        log.info('find design-inspector diagrams...');

        const output = new Map();

        iframeData.forEach((diData, key) => {
            const diElement = document.querySelector(`iframe[title="DI Viewer"][name="${key.view}"][data-element-config-id],iframe[title="Design Inspector Viewer"][name="${key.view}"][data-element-config-id]`);
            if (diElement) {
                const section = { 
                    id: diElement.getAttribute('data-element-config-id'), 
                    section: diElement.getAttribute('data-section-element-id')
                };
                output.set(section, diData);
            } else {
                log.error(`could not find di-inspector element for url '${key.domain}'`);
            }
        });

        log.info(Utils.mapToString(output));
        return output;
    }
}

QuipEditor.QUIP_URL = 'https://quip-amazon.com';
QuipEditor.TOKEN_PAGE_URL = 'https://quip-amazon.com/dev/token';

/**
 * Holds temporary information from current session.
 */
const Session = {
    version: GM_info.script.version,
    gmVersion: GM_info.version,
    currentUser: undefined,
    tokenTestResult: false,
    wikiAddr: undefined,

    /**
     * Retrieves the Amazon login of current user.
     */
    getUser: async function () {
        if (this.currentUser) {
            return this.currentUser;
        }
        for (let i=0; i < 3; i++) { // try 3 times
            try {
                this.currentUser = await Utils.getMidwayUser();
                return this.currentUser;
            } catch (ex) { /* Ignore the error */ }
        }
        const err = 'Could not retrieve Midway user';
        throw err;
    },

    /**
     * Returns true when the Quip API token has been tested.
     */
    isTokenTested: function () {
        return this.tokenTestResult;
    },

    /**
     * Sets the result of the Quip API token test.
     * @param {boolean} testResult
     */
    setTokenTest: function (testResult) {
        this.tokenTestResult = testResult;
    },

    /**
     * Retrieves the user's browser information. Reference: https://stackoverflow.com/a/5918791
     */
    getBrowser: function () {
        try {
            const ua = navigator.userAgent;
            let tem; 
            let M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
            if(/trident/i.test(M[1])){
                tem =  /\brv[ :]+(\d+)/g.exec(ua) || [];
                return 'IE '+(tem[1] || '');
            }
            if (M[1] === 'Chrome'){
                tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
                if(tem != null) return tem.slice(1).join(' ').replace('OPR', 'Opera');
            }
            M = M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
            if ((tem = ua.match(/version\/(\d+)/i)) != null) M.splice(1, 1, tem[1]);
            return M.join(' ');
        } catch (ex) {
            return 'unknown';
        }
    },

    /**
     * Returns the latest version available for download.
     */
    getLatestVersion: async function(checkNow = false) {
        const now = new Date();
        const lastValue = Settings.loadValue('LastestVersion');
        if (!checkNow && lastValue && lastValue.timestamp) {
            const elapsed = (now - new Date(lastValue.timestamp));
            const TWELVE_HOURS = 12*60*60*1000; // 12 hours in milliseconds
            if (elapsed < TWELVE_HOURS) {
                this.setIsNew(lastValue);
                return lastValue; // no need to check for updated version
            }
        }

        let found;
        for (const url of UPDATE_CHECK_URL) {
            const result = await this.getFileVersion(url);
            if (result.version) {
                found = result;
                break;
            }
        }

        if (!found) {
            throw 'Could not fetch latest version';
        }

        Settings.saveValue('LastestVersion', found); // persist to avoid unnecessary checks
        return found;       
    },

    /**
     * Fetch deployed userscript and extract version.
     *
     * @param {string} url where the userscript is deplyed
     */
    getFileVersion: async function(url) {
        log.info(`Fetching latest update from ${url}...`)
        const maxRetries = 3;
        const waitInterval = 2500; // 2.5 seconds, then 5 seconds, then 10 seconds
        const exponential = true;
        
        let service = Utils.WIKI_SERVICE;
        if (url.includes("axzile"))
            service = Utils.AXZILE_SERVICE;

        const content = await Utils
            .authAwareRetry(async () => Utils.fetchUrl(url, 10000), service, maxRetries, waitInterval, exponential)
            .catch(() => '')
            .then(resultText => resultText.slice(0, 2500)); // we only need the header

        const versonMatch = content.match(/^\/\/\s+@version\s+.*$/gm) || [];

        const version = versonMatch
            .map(Utils.parseVersion)
            .find(v => !!v);

        const now = new Date();

        if (!version) {
            return {
                version: null,
                timestamp: now,
            };
        }

        const curVersion = Utils.parseVersion(Session.version); // script version
        version.isNew = Utils.compareVersions(version, curVersion) < 0;
        version.forceUpdate = /\/\*\* FORCE_UPDATE = true \*\//.test(content);
        version.timestamp = now;
        version.url = url;

        log.info('Latest version: ' + JSON.stringify(version));
        return version;
    },
};

/**
 * Determines basic position for placing auto-generated messages.
 */
const BannerPosition = {
    TOP: 0,
    BOTTOM: 1,
    HIDDEN: 2,
    NONE: 3
}

/**
 * Utiliy class for loading and persisting Quip2Wiki settings such as Quip API token.
 */
const Settings = {
    quipApiToken: undefined,
    bannerPosition: BannerPosition.TOP,
    changeMonitorEnabled: false,
    wikiBlockEnabled: true,
    exportDialogEnabled: true,

    load: function () {
        return new Promise((res, rej) => {
            this.quipApiToken = GM_getValue('quip_api_token', undefined);
            this.bannerPosition = GM_getValue('banner_position', BannerPosition.TOP);
            this.changeMonitorEnabled = GM_getValue('change_monitor_enabled', false);
            this.wikiBlockEnabled = GM_getValue('wiki_block_enabled', true);
            this.exportDialogEnabled = GM_getValue('export_dialog_enabled', true);
            log.info('Settings loaded');
            res();
        });
    },

    save: function () {
        return new Promise((res, rej) => {
            if (this.quipApiToken) {
                GM_setValue('quip_api_token', this.quipApiToken);
            }
            GM_setValue('banner_position', this.bannerPosition);
            GM_setValue('change_monitor_enabled', this.changeMonitorEnabled);
            GM_setValue('wiki_block_enabled', this.wikiBlockEnabled);
            GM_setValue('export_dialog_enabled', this.exportDialogEnabled);
            log.info('Settings saved');
            res();
        });
    },

    loadValue: function (key, defaultValue = null) {
        return GM_getValue(key, defaultValue);
    },

    saveValue: function (key, value) {
        GM_setValue(key, value);
    }
}

/**
 * Basic functions for gathering user usage information.
 */
class Telemetry {
    constructor (currentUser) {
        this.user = currentUser;
        this.loadLocalUserData();
    }

    get version () {
        return this.userData.version;
    }

    registerInstallation () {
        if (this.userData.install && this.userData.version && this.userData.version === Session.version) {
            log.info(`[telemetry] Quip2Wiki already registered version ${this.userData.version} on ${this.userData.update || this.userData.install}.`);
            return;
        }
        log.info(`[telemetry] registering Quip2Wiki version ${Session.version} ${this.userData.update ? 'update' : 'installation'}...`);
        return this.callTracker(Telemetry.UPDATE_TRACKER, { user: this.user, version: Session.version })
            .then(() => {
                if (this.userData.install) {
                    this.userData.update = this.now;
                } else {
                    this.userData.install = this.now;
                }
                this.userData.version = Session.version;
                this.saveLocalUserData();
                log.info(`[telemetry] Quip2Wiki installation of version ${this.userData.version} registered on ${this.userData.install}`);
            }).catch(err => {
                log.error(`[telemetry] error while registering Quip2Wiki installation: ${err}`);
            });
    }

    registerTokenInstallation () {
        if (this.userData.tokenInstall) {
            log.info(`[telemetry] Quip token already registered on ${this.userData.tokenInstall}.`);
            return;
        }
        log.info('[telemetry] registering Quip token installation...');
        return this.callTracker(Telemetry.EXPORT_TRACKER, { user: this.user, step: 'TOKEN_INSTALL' })
            .then(() => {
                this.userData.tokenInstall = this.now;
                this.saveLocalUserData();
                log.info(`[telemetry] token installation registered on ${this.userData.tokenInstall}`);
            }).catch(err => {
                log.error(`[telemetry] error while registering Quip API token installation: ${err}`);
            });
    }

    registerExportAttempt () {
        if (this.userData.exportAttempt) {
            return;
        }
        log.info('[telemetry] registering first export attempt...');
        return this.callTracker(Telemetry.EXPORT_TRACKER, { user: this.user, step: 'EXPORT_ATTEMPT' })
            .then(() => {
                this.userData.exportAttempt = this.now;
                this.saveLocalUserData();
                log.info(`[telemetry] first export attempt registered on ${this.userData.exportAttempt}`);    
            }).catch(err => {
                log.error(`[telemetry] error while registering first export attempt: ${err}`);
            });
    }

    registerSuccessfulExport () {
        if (this.userData.firstExport) {
            return;
        }
        log.info('[telemetry] registering first successful export...');
        return this.callTracker(Telemetry.EXPORT_TRACKER, { user: this.user, step: 'EXPORT_SUCCESS' })
            .then(() => {
                this.userData.firstExport = this.now;
                this.saveLocalUserData();
                log.info(`[telemetry] successful export registered on ${this.userData.firstExport}`);
            }).catch(err => {
                log.error(`[telemetry] error while registering successful export: ${err}`);
            });
    }

    registerQuipUserApiAttempt() {
        log.info('[telemetry] registering Quip User Api usage attempt...');
        return this.callTracker(Telemetry.QUIP_USER_API_SUCCESS, { user: this.user, step: 'QUIP_USER_ATTEMPT' })
            .then(() => {
                log.info(`[telemetry] successfully registered Quip User Api usage attempt`);
            }).catch(err => {
                log.error(`[telemetry] error while registering Quip User Api usage attempt: ${err}`);
            });
    }

    registerQuipUserApiSuccess() {
        log.info('[telemetry] registering Quip User Api usage success...');
        return this.callTracker(Telemetry.QUIP_USER_API_SUCCESS, { user: this.user, step: 'QUIP_USER_SUCCESS' })
            .then(() => {
                log.info(`[telemetry] successfully registered Quip User Api usage success`);
            }).catch(err => {
                log.error(`[telemetry] error while registering Quip User Api usage success: ${err}`);
            });
    }

    registerQuipUserApiError() {
        log.info('[telemetry] registering Quip User Api usage failure...');
        return this.callTracker(Telemetry.QUIP_USER_API_FAILURE, { user: this.user, step: 'QUIP_USER_ERROR' })
            .then(() => {
                log.info(`[telemetry] successfully registered Quip User Api usage failure`);
            }).catch(err => {
                log.error(`[telemetry] error while registering Quip User Api usage failure: ${err}`);
            });
    }

    async registerUsage (docType, error = null) {
        log.info('[telemetry] registering export...');
        const tracker = error ? Telemetry.USAGE_ERROR_TRACKER : Telemetry.USAGE_SUCCESS_TRACKER;
        const args = {};
        args.docType = docType;
        args.user = await Utils.digestMessage(this.user); // use hash to avoid tracking logins
        args.version = Session.version;
        if (error) {
            args.error = `${error}`.substring(0, 75); // max 75 characters for error message
        }
        await this.callTracker(tracker, args).catch(err => {
            log.error(`[telemetry] error while registering usage metric: ${err}`);
        });

        log.info(`[telemetry] usage metric registered`);
    }

    get now () {
        return new Date().toISOString();
    }

    loadLocalUserData () {
        const value = Settings.loadValue("user_data", null);
        if (value) {
            this.userData = JSON.parse(value);
        } else {
            this.userData = {
                version: null,
                install: null,
                update: null,
                tokenInstall: null,
                exportAttempt: null,
                firstExport: null,
                lastExport: null,
                ping: null,
            }
        }
    }

    saveLocalUserData () {
        const value = JSON.stringify(this.userData);
        Settings.saveValue("user_data", value);
    }

    callTracker (pixelID, params = {}) {
        params.PixelID = pixelID;
        const endpoint = Telemetry.HOW_MANY_ENDPOINT;
        return Utils.fetchUrl(`${endpoint}/pixel/tracker?${Utils.getEncodedQueryData(params)}`);
    }
}

Telemetry.HOW_MANY_ENDPOINT = 'https://0s62bmu3aj.execute-api.us-east-1.amazonaws.com/PROD';
Telemetry.UPDATE_TRACKER = '610de354-b665-2356-de4e-db8bb1d80bea';
Telemetry.EXPORT_TRACKER = '4feac57b-36c4-75cd-74ca-f895fb89435e';
Telemetry.USAGE_SUCCESS_TRACKER = '97c4fb5c-ccf0-7722-420b-912304c80cf8';
Telemetry.USAGE_ERROR_TRACKER = 'e4c67283-a943-1be5-9823-b3d1816418a3';
Telemetry.QUIP_USER_API_SUCCESS = 'c7d639e8-171f-11d1-3f9d-68b78d9914fa';
Telemetry.QUIP_USER_API_FAILURE = '87a02e6d-333e-8315-18a0-6f92bb804368';

/**
 * Helper methods.
 */
const Utils = {

    MIDWAY_REDIRECT_URL: "https://midway-auth.amazon.com/SSO/redirect?",

    /**
     * Sets function handlers for specific events.
     *
     * @param {*} element html element
     * @param {string} eventName name of the event
     * @param {*} handler function to be executed
     */
    addListener: function (element, eventName, handler) {
        if (element.addEventListener) {
            element.addEventListener(eventName, handler, false);
        }
        else if (element.attachEvent) {
            element.attachEvent('on' + eventName, handler);
        }
        else {
            element['on' + eventName] = handler;
        }
    },

    /**
     * Encondes parameters as an encoded URI.
     * @param {*} data binary content to be encoded
     */
    getEncodedQueryData: function (data) {
        return Object.entries(data || {}).map(kv => kv.map(encodeURIComponent).join("=")).join("&");
    },

    sanitizeHTMLText: function (unsafe) {
        return unsafe
            .replace(/&(?!amp;|lt;|gt;|quot|#039;)/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    },

    sanitizeHTMLAttribute: function (attrValue) {
        return attrValue
            .replace(/[&<>"']/g, '')
            .replace(/-/g, '&#45;')
            .trim();
    },

    escapeRegExp: function (string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
    },

    /**
     * Utility method to retrieve the currently authenticated amazonian's username by making a request to a Midway status page.
     */
    getMidwayUser: function () {
        const midway_call = (res, rej) => {
            GM_xmlhttpRequest({
                method: 'GET',
                url: "https://midway-auth.amazon.com/api/session-status",
                timeout: 5000,
                ontimeout: () => rej('Get user timeout'),
                onload: function(response) {
                    if (response.status == 200) {
                        const responseObj = JSON.parse(response.responseText);
                        if (responseObj) {
                            if (responseObj.authenticated || (window.navigator.userAgent.includes("Safari") && responseObj.user_name)) {
                                log.info(`getMidwayUser response: authenticated=${responseObj.authenticated}, login=${responseObj.user_name}`);
                                res(responseObj.user_name);
                                return;
                            } else {
                                log.debugError(`getMidwayUser response error: ${JSON.stringify(responseObj)}`);
                                rej("You are not authenticated to Midway");
                                return;
                            }
                        }
                    }
                    log.debugError(`getMidwayUser response error: ${response.status}`);
                    rej("Error occurred while retrieving Midway status");
                },
                onerror: function(response) {
                    log.debugError("getMidwayUser unkown error: " + response.responseText);
                    rej("Error occurred while retrieving Midway status");
                }
            });
        };

        return Utils.retry(() => new Promise(midway_call), 2, 1000);
    },

    /**
     * Check if two arrays are equal (same content), regardless of the order.
     * @param {Array} _arr1
     * @param {Array} _arr2
     */
    arraysEqual: function(_arr1, _arr2) {
        if (!Array.isArray(_arr1) || ! Array.isArray(_arr2) || _arr1.length !== _arr2.length) {
            return false;
        }

        var arr1 = _arr1.concat().sort();
        var arr2 = _arr2.concat().sort();

        for (var i = 0; i < arr1.length; i++) {
            if (arr1[i] !== arr2[i]) {
                return false;
            }
        }

        return true;

    },

    arraysEqualSameOrder: function(arr1, arr2) {
        return Array.isArray(arr1) &&
               Array.isArray(arr2) &&
               arr1.length === arr2.length &&
               arr1.every((val, index) => val === arr2[index]);
    },

    /**
     * Compares two objects for same fields and same values - ONE-LEVEL OMLY
     * @param {*} o1 object 1
     * @param {*} o2 object 2
     * @returns true when both objects have same fields and values
     */
    compareObjects: function(o1, o2) {
        if (!!o1 != !!o2) {
            return false;
        }
        for(var p in o1){
            if(o1.hasOwnProperty(p)){
                if(o1[p] !== o2[p]){
                    return false;
                }
            }
        }
        for(var p in o2){
            if(o2.hasOwnProperty(p)){
                if(o1[p] !== o2[p]){
                    return false;
                }
            }
        }
        return true;
    },

    /**
     * Formats the given date, based on the ISO String format, as a valid file name.
     *
     * @param {*} date
     */
    formatDate: function (date) {
        return date.toISOString().replace(/:/g,'-').replace('T', '_').slice(0, 19);
    },

    /**
     * Recursevly finds a parent of a given element that contains the given class. Returns null if no parent is found.
     *
     * @param {*} element the base element
     * @param {*} className the class name to match
     */
    getAncestorWithClassName: function (element, className) {
        let node = element.parentNode;
        while (node) {
            if (node.classList && node.classList.contains(className)) {
                return node;
            }
            node = node.parentNode;
        }
        return null;
    },

    /**
     * Recursevly finds a parent of a given element that contains the given attribute. When attributeValue is null, will match if attribute exists.
     * Returns null if no parent is found.
     *
     * @param {*} element the base element
     * @param {string} attributeNme the attribute name to match
     * @param {*} attributeValue (optional) the attribute value to match
     */
    getAncestorWithAttribute: function (element, attributeName, attributeValue = null) {
        let node = element.parentNode;
        while (node) {
            if (node.hasAttribute(attributeName) && (!attributeValue || node.getAttribute(attributeName) === attributeValue)) {
                return node;
            }
            node = node.parentNode;
        }
        return null;
    },

    sleep: function (milliseconds) {
        return new Promise(resolve => setTimeout(resolve, milliseconds))
    },

    /**
     * Transforms the input text (arbitrarily large block of data) into a fixed-size output using the SHA-256 hash function.
     * Source: https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/digest
     *
     * @param {*} message arbitrarily large block of data
     */
    digestMessage: async function (message) {
        const msgUint8 = new TextEncoder().encode(message);
        const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        return hashHex;
    },

    replaceAsync: async function (str, regex, asyncFn, inParallel = true) {
        if (inParallel) {
            return await Utils.replaceAsyncParallel(str, regex, asyncFn);
        } else {
            return await Utils.replaceAsyncSequence(str, regex, asyncFn);
        }
    },

    replaceAsyncParallel: async function (str, regex, asyncFn) {
        const promises = [];
        str.replace(regex, (match, ...args) => {
            const promise = asyncFn(match, ...args);
            promises.push(promise);
        });
        const data = await Promise.all(promises);
        return str.replace(regex, () => data.shift());
    },

    replaceAsyncSequence: async function (str, regex, asyncFn) {
        const data = [];
        let p = Promise.resolve(null);
        str.replace(regex, (match, ...args) => {
            p = p.then(result => {
                data.push(result); // add previous result
                return asyncFn(match, ...args);
            });
        });
        await p.then(result => data.push(result)); // add last result
        data.shift();
        return str.replace(regex, () => data.shift());
    },

    /**
     * Tests if a certain regex pattern matches in given string. Given regex can have state,
     * this method makes sure previous state is cleared.
     * @param {ReExp} regex 
     * @param {String} text 
     */
    test: function (regex, text) {
        regex.lastIndex = 0;
        return regex.test(text);
    },

    /**
     * Retries the given function until it succeeds given a number of retries and an interval between them. They are set
     * by default to retry 5 times with 1sec in between. There's also a flag to make the cooldown time exponential
     *
     * @author Daniel Iñigo <danielinigobanos@gmail.com>
     * @param {Function} fn - Returns a promise
     * @param {Number} retriesLeft - Number of retries. If -1 will keep retrying
     * @param {Number} waitInterval - Millis between retries. If exponential set to true will be doubled each retry
     * @param {Boolean} isExponentialWait - Flag for exponential back-off mode
     * @return {Promise<*>}
     */
    retry: async function (fn, retriesLeft = 5, waitInterval = 1000, isExponentialWait = false) {
        try {
            const val = await fn();
            return val;
        } catch (error) {
            if (retriesLeft) {
                log.error(error);
                log.info(`Retrying execution (${retriesLeft - 1} attempts left)...`);
                await this.sleep(waitInterval);
                const nextWaitInterval = isExponentialWait ? waitInterval * 2 : waitInterval;
                return this.retry(fn, retriesLeft - 1, nextWaitInterval, isExponentialWait);
            } else {
                log.error('Max retries reached');
                throw error;
            }
        }
    },


    /**
     * Improvement on the simple retry function above, but "service" and "authorization" aware
     *
     * @author Jorge Miguel Ribeiro <jorgemrb@amazon.com>
     * @param {Function} fn - Returns a promise
     * @param {String} serviceName - The name of the service that is being called
     * @param {Number} retriesLeft - Number of retries. If -1 will keep retrying
     * @param {Number} waitInterval - Millis between retries. If exponential set to true will be doubled each retry
     * @param {Boolean} isExponentialWait - Flag for exponential back-off mode
     * @param {Boolean} allowAuthPrompt - If true (the default), allows showing the auth prompt
     * @return {Promise<*>}
     */
    authAwareRetry: async function (fn, serviceName, retriesLeft = 5, waitInterval = 1000, isExponentialWait = false) {
        try {
            retriesLeft = retriesLeft - 1; // we immediatelly decrease the ammount of retries left
            const val = await fn();
            return val;
        } catch (error) {
            if (retriesLeft) {
                log.error(error);

                let errorMessage = error.toString();
                let authPromptWasShown = false;
                var startTime = new Date();

                if (errorMessage.startsWith(this.MIDWAY_REDIRECT_URL)) {
                    if (serviceName == this.AXZILE_SERVICE) {
                        // For now we are not asking for the users to login in Axzile, and we know that the user is not logged in to Axzile. So we stop the process.
                        log.info("Auth error in Axzile. Stoping retries.");
                        throw "Auth error in Axzile. Stoping retries.";
                    }

                    log.info("Reached an authentication error, showing auth prompt to the user");
                    let authUrl = errorMessage;
                    var shouldContinue = await this.promptForAuthentication(authUrl, serviceName);
                    if (!shouldContinue) {
                        log.info(this.ABORTED_BY_USER);
                        throw this.ABORTED_BY_USER;
                    }

                    authPromptWasShown = true;
                }

                if (!authPromptWasShown) {
                    // usually we only need to wait if the auth prompt was not shown to the user
                    await this.sleep(waitInterval);
                } else {
                    var endTime = new Date();
                    var millisecondsElapsed = endTime - startTime; // time elapsed in ms

                    if (millisecondsElapsed < waitInterval) {
                        // if the prompt was shown to the user, we only need to wait the remaining time
                        await this.sleep(waitInterval - millisecondsElapsed);
                    }
                }

                log.info(`Retrying execution (${retriesLeft - 1} attempts left)...`);
                const nextWaitInterval = isExponentialWait ? waitInterval * 2 : waitInterval;
                return this.authAwareRetry(fn, serviceName, retriesLeft, nextWaitInterval, isExponentialWait);
            } else {
                log.error('Max retries reached');
                throw error;
            }
        }
    },

    mapToString: function (map, delimiter = ' ') {
        const out = ['{'];
        for (let [k,v] of map) {
            out.push(`${JSON.stringify(k)}: ${JSON.stringify(v)},`);
        }
        out.push('}');
        return out.join(delimiter);
    },

    resizeImage: function (blob, maxSizeInBytes, securityFactor = 1.0) {
        if (maxSizeInBytes < 1024) {
            return blob; // unchanged
        }
        return new Promise((res, rej) => {
            const blobURL = window.URL.createObjectURL(blob);
            const image = new Image();
            image.src = blobURL;
            image.onload = () => {
                // define the new size
                const percentage = (securityFactor * maxSizeInBytes) / blob.size; // desired reduce percentage
                const factor = Math.sqrt(percentage); // factor is one dimension
                log.debug(`Attempting to downsize by a factor of ${factor.toFixed(3)}`)
                const width = image.width * factor;
                const height = image.height * factor;
                const canvas = document.createElement('canvas');
                // resize the canvas and draw the image data into it
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext("2d");
                ctx.drawImage(image, 0, 0, width, height);
                // convert to blob
                const callback = (b) => {
                    log.debug(`Image downsized to ${Utils.formatBytes(b.size)}`)
                    if (b.size < maxSizeInBytes) {
                        res(b);
                    } else {
                        res(this.resizeImage(b, maxSizeInBytes, securityFactor * 0.95));
                    }
                };
                canvas.toBlob(callback, blob.type);
            };
        });
    },

    formatBytes: function (bytes, decimals = 2) {
        if (bytes === 0) {
            return '0 Bytes';
        }

        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    },

    parseVersion: function (version) {
        const versionPattern = /(\d+)\.(\d+)(?:\.(\d+)(?:[\.-](\d+))?)?(-test)?/g;
        const match = versionPattern.exec(version);
        if (!match) {
            throw 'No version matched';
        }

        const isBeta = !!match[4];
        const isTest = !!match[5];
        const stage = isTest ? 'test' :
            isBeta ? 'beta' :
                'prod';
        return {
            major: parseInt(match[1], 10),
            minor: parseInt(match[2], 10),
            release: parseInt(match[3], 10),
            testRelease: (match[4] ? parseInt(match[4], 10) : null),
            stage: stage,
            version: match[0],
        }
    },

    /**
     * Compares two version structures:
     * - Returns -1 if 'v1' is newer than 'v2'
     * - Returns  0 if 'v1' equals 'v2'
     * - Returns +1 if 'v1' is older than 'v2'
     */
    compareVersions: function (v1, v2, compareTestRelease = false) {
        if (!v1 || !v2) {
            return v1 ? -1 : 1;
        } else if (v1.major !== v2.major) {
            return v1.major > v2.major ? -1 : 1;
        } else if (v1.minor !== v2.minor) {
            return v1.minor > v2.minor ? -1 : 1;
        } else if (v1.release !== v2.release) {
            return v1.release > v2.release ? -1 : 1;
        } else if (compareTestRelease && v1.testRelease !== v2.testRelease) {
            return v1.testRelease > v2.testRelease ? - 1 : 1;
        } else {
            return 0;
        }
    },

    colorRgbToHex: function (attrValue) {
        return attrValue.replace(/rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)/, (m, r, g, b) => {
            let rHex = (+r).toString(16),
                gHex = (+g).toString(16),
                bHex = (+b).toString(16);

            if (rHex.length == 1)
                rHex = "0" + r;
            if (gHex.length == 1)
                gHex = "0" + g;
            if (bHex.length == 1)
                bHex = "0" + b;

            return '#' + rHex + gHex + bHex;
        });
    },

    fetchUrl: function (requestUrl, timeoutMillis = 5000) {
        return new Promise((res, rej) => {
            GM_xmlhttpRequest({
                method: 'GET',
                url: requestUrl,
                headers: {
                    credentials: 'include',
                },
                timeout: timeoutMillis,
                ontimeout: () => rej(`GET: timeout`),
                onload: function (response) {
                    if (response.finalUrl != requestUrl) {
                        console.debug('GET: redirected to ' + response.finalUrl);
                        if (response.finalUrl.startsWith(this.MIDWAY_REDIRECT_URL)) {
                            rej(response.finalUrl);
                            return;
                        }
                    }
                    if (response && response.status >= 200 && response.status < 300) {
                        res(response.responseText);
                    } else {
                        log.error(response.responseText);
                        if (response.finalUrl.startsWith(Utils.MIDWAY_REDIRECT_URL)) {
                            rej(response.finalUrl);
                            return;
                        }
                        rej(`error ${response.status}`);
                    }
                },
                onerror: () => rej(response.responseText || 'error unknown'),
            });
        });
    },

    putUrl: function (requestUrl, data, timeoutMillis = 5000) {
        return new Promise((res, rej) => {
            GM_xmlhttpRequest({
                method: 'PUT',
                url: requestUrl,
                data: JSON.stringify(data || {}),
                headers: {
                    'credentials': 'include',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                timeout: timeoutMillis,
                ontimeout: () => rej(`PUT: timeout`),
                onload: function (response) {
                    if (response.finalUrl != requestUrl) {
                        console.debug('PUT: redirected to ' + response.finalUrl);
                    }
                    if (response && response.status >= 200 && response.status < 300) {
                        res(response.responseText);
                    } else {
                        rej(`error ${response.status}`);
                    }
                },
                onerror: () => rej(response.responseText || 'error unknown'),
                context: null    
            });
        });
    },

    postUrl: function (requestUrl, data, timeoutMillis = 5000) {
        return new Promise((res, rej) => {
            GM_xmlhttpRequest({
                method: 'POST',
                url: requestUrl,
                data: JSON.stringify(data || {}),
                headers: {
                    credentials: 'include',
                    accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                timeout: timeoutMillis,
                ontimeout: () => rej(`POST: timeout`),
                onload: function (response) {
                    if (response.finalUrl != requestUrl) {
                        console.debug('POST: redirected to ' + response.finalUrl);
                    }
                    if (response && response.status >= 200 && response.status < 300) {
                        res(response.responseText);
                    } else {
                        rej(`error ${response.status}`);
                    }
                },
                onerror: () => rej(response.responseText || 'error unknown'),
            });
        });
    },

    parseCSV: function (content) {
        const allLines = content.split(/\r\n|\n/);
        const headers = allLines[0].split(',').map(h => h.slice(1,-1));
        const values = allLines.slice(1).map(line => line.split(',').map(item => item.slice(1,-1)));
        return { headers, values };
    },

    ABORTED_BY_USER: "Aborted by user when asking for authentication",

    MAXIS_SERVICE: "MAXIS_SERVICE",
    PHONETOOL_SERVICE: "PHONETOOL_SERVICE",
    AXZILE_SERVICE: "AXZILE_SERVICE",
    WIKI_SERVICE: "WIKI_SERVICE",

    SERVICE_NAME_MAPPING: {
        MAXIS_SERVICE: "SIM/Maxis",
        PHONETOOL_SERVICE: "Phonetool",
        AXZILE_SERVICE: "Axzile",
        WIKI_SERVICE: "Amazon Wiki",
    },

    SERVICE_URL_MAPPING: {
        MAXIS_SERVICE: "https://issues.amazon.com/issues/Q2W-343",
        PHONETOOL_SERVICE: "https://phonetool.amazon.com/",
        AXZILE_SERVICE: "https://axzile.corp.amazon.com/-/carthamus/script/quip2-wiki",
        WIKI_SERVICE: "https://w.amazon.com/bin/view/Quip2Wiki/AuthenticateWithMidway/",
    },

    SERVICE_CANCEL_OPERATION_MAPPING: {
        MAXIS_SERVICE: "Continue without authenticating",
        PHONETOOL_SERVICE: "Continue without authenticating",
        AXZILE_SERVICE: "Abort",
        WIKI_SERVICE: "Abort",
    },

    promptForAuthentication: async function(midwayUrl, service) {
        if (!midwayUrl.startsWith(this.MIDWAY_REDIRECT_URL)) return false;

        let serviceUrl = this.SERVICE_URL_MAPPING[service];
        let serviceName = this.SERVICE_NAME_MAPPING[service];
        let cancelOperation = this.SERVICE_CANCEL_OPERATION_MAPPING[service];

        const msg = 'Authentication via Midway is necessary.<br/><br/>' +
        `<span style="text-decoration:underline"><a href="${serviceUrl}" target="_blank" rel="noopener">` +
        `Click here to authenticate on <b>${serviceName}</b> via Midway</a></span>, then click on the "Continue" button below.<br/><br/>`;

        var options = { }; // here we have to create an empty object first and then fill it in - otherwise the cancel operation is last and gets highlighted
        options[cancelOperation] = false;
        options["Continue"] = true;

        return await Prompts.showDialog(`The ${serviceName} Midway cookie is not available or has expired...`, msg, options);
    },
};

/**
 * Amazon Wiki API client, with basic operations such as get and save wiki pages.
 */
class WikiClient {
    constructor() {
        // Wiki API settings
        this.TIMEOUT = 15000;
        this.MAX_ATTEMPTS = 3;
        this.READ_MIN_WAIT = 350; // minimum wait time between read calls (wiki client API only allows 3 TPS for read calls)
        this.WRITE_MIN_WAIT = 1000; // minimum wait time between write calls (wiki client API only allows 1 TPS for write calls)

        // attachment settings
        this.ATTACH_TIMEOUT = 30000;
        this.ATTACH_MAX_ATTEMPTS = 2;
        this.UPLOAD_MIN_WAIT = 1000; // minimum wait time between upload attachment calls
        this.DELETE_MIN_WAIT = 250; // minimum wait time between delete attachment calls
        this.UPLOAD_SIZE_LIMIT = 1.9*1024*1024; // The limit was 2MB, but was changed to 1.9MB some day around 2023-07-27

        this.lastCall = null;
    }

    async testConnection()  {
        const xml = await this.getWikiPageXml('Quip2Wiki', null, WikiClient.TEST_TIMEOUT);
        return !!xml; // valid XML means we can connect to Wiki API
    }

    /**
     * Private method to execute an Wiki API call, respecting its TPS limits read/write call per second limit.
     *
     * @param {*} promise executor method
     */
    async execute (call, minWait) {
        const elapsed = this.lastCall ? (new Date() - this.lastCall) : minWait;
        const wait = minWait - elapsed;

        if (wait > 0) {
            log.info(`[wiki-client] throttling wiki client call: waiting ${wait} ms`);
            await Utils.sleep(wait);
        }

        // execute the API call
        const res = await new Promise(call);

        this.lastCall = new Date();
        return res;
    }

    /**
     * Returns the Wiki API endpoint for Page requests as an URI. The 'type' parameter defines the different pages
     * for the Wiki API endpoint.
     *
     * @param {string} wikiAddr wiki url address (or relative address)
     * @param {*} params additional url parameters as an object
     * @param {string} type the page type, such as home, tags, history, comments, or attachments
     */
    getRestEndpoint (wikiAddr, params, type) {
        const page = WikiClient.extractWikiRelativeAddr(wikiAddr)
            .replace(/&amp;/g, '&'); // Quip saves '&' in content as '&amp;' including URLs. API calls should use '&' instead

        if (page == null) {
            return null; // invalid wiki address
        }
        const pathParts = page.includes('/') ? page.split('/') : [page];
        // base page target
        let targetPath = WikiClient.API_URL + pathParts.join('/spaces/');
        // other page types
        if (type === 'home') {
            targetPath += '/pages/WebHome';
        } else if (type === 'tags') {
            targetPath += '/pages/WebHome/tags'; // does not work!
        } else if (type === 'history') {
            targetPath += '/pages/WebHome/history';
        } else if (type === 'comments') {
            targetPath += '/pages/WebHome/comments';
        } else if (type === 'attachments') {
            targetPath += '/pages/WebHome/attachments';
        }
        // encode parameters in url
        if (params) {
            targetPath += '?' + Utils.getEncodedQueryData(params);
        }
        log.info('[wiki-client] wiki endpoint: ' + targetPath);
        return targetPath;
    }

    /**
     * Returns the Wiki URL for Page requests as an URI. The 'type' parameter defines the different pages
     * interfaces for requests.
     *
     * @param {string} wikiAddr wiki url address (or relative address)
     * @param {string} type of request such as 'view', 'upload', 'download', and 'delattachment'
     * @param {string} the sub page name or section
     */
    getWikiEndpoint (wikiAddr, type, subPage) {
        const relativeUrl = wikiAddr.replace(/&amp;/g, '&');  // Quip saves '&' in content as '&amp;' including URLs. Calls should use '&' instead
        if (type == 'view') {
            return WikiClient.VIEW_URL + encodeURI(relativeUrl) + '/' + subPage;
        } else if (type == 'upload') {
            return WikiClient.UPLOAD_URL + encodeURI(relativeUrl) + '/' + subPage;
        } else if (type == 'download') {
            return WikiClient.DOWNLOAD_URL + encodeURI(relativeUrl) + '/' + subPage;
        } else if (type == 'delattachment') {
            return WikiClient.DELETE_ATTACHMENT_URL + encodeURI(relativeUrl) + '/' + subPage;
        } else {
            throw 'Invalid wiki page type';
        }
    }

    /**
     * Extracts the destination wiki relative address from a user input or full wiki URL (enconded or not).
     * Reference from Wiki: https://tiny.amazon.com/2wsxuzu7
     *
     * Valid chars: ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~:/?#[]@!$&'()*+,;=
     *
     * @param {*} wikiAddr destination wiki address (full or relative, encoded or not)
     */
    static extractWikiRelativeAddr (wikiAddr) {
        if (!wikiAddr) {
            return null;
        }

        // user:         /Quip2Wiki/SpecialChars_~!@$%&*()-_=+{}|.,<>'"`
        // wiki-created: /Quip2Wiki/SpecialChars_~!@$%5E%25&*()-_=+%7B%7D%7C.,<>'"%60
        // encodeURI:    /Quip2Wiki/SpecialChars_~!@$%5E%25&*()-_=+%7B%7D%7C.,%3C%3E'%22%60

        const decodedAndSanitized = wikiAddr
            .replace(/^\//g, '') // remove '/' at the beginning
            .replace(/\s+/g, '') // remove spaces
            .replace(/\\/g, '/')
            .replace(/%[0-9A-Fa-f]{2}/g, m => decodeURIComponent(m))
            .replace(/&amp;/g, '&') // remove temporarily to avoid having ';' removed
            .replace(/[^a-zA-Z0-9\._~:\/?#@!$&()*,=-]/g, '')  // clean up undesired chars
            .replace(/&/g, '&amp;'); // reinstate '&amp;' to avoid issues in wiki

        const match = decodedAndSanitized.match(WikiClient.WIKI_URL_REGEX);

        if (match == null || match[1] == null) {
            log.info('invalid page match: ' + match);
            return null;
        }
        const page = encodeURI(match[1])
            .trim()
            .replace(/^User:(.*)/, 'Users/$1')
            .replace(/\/+/g, '/')
            .replace(/\/$/, '');
        return page;
    }

    async wikiPageExists (wikiAddr, timeout) {
        log.info('[wiki-client] checking if page exists...');
        try {
            const wikiXml = await this.getWikiPageXml(wikiAddr, null, timeout);
            if (wikiXml == null) {
                throw "No XML content";
            }
            return wikiXml.getElementsByTagName('home').length > 0;
        } catch (e) {
            let errorMessage = e.toString();
            if (errorMessage == Utils.ABORTED_BY_USER) {
                throw e;
            }

            log.error('[wiki-client] check page exists error: ' + e);
            throw "Error occurred while checking if wiki page exists. Make sure you are connected to Amazon network directly or via VPN.";
        }
    }

    getWikiPageXml (wikiAddr, type, timeout) {
        const get_call = (res, rej) => {
            const typeLabel = type || "root";
            log.info(`[wiki-client] start get xml (${typeLabel})...`);
            const requestUrl = this.getRestEndpoint(wikiAddr, null, type);
            GM_xmlhttpRequest({
                method: 'GET',
                url: requestUrl,
                headers: {
                    'Content-Type': 'application/xml',
                    'User-Agent': 'Quip2Wiki/' + Session.version
                },
                timeout: timeout || this.TIMEOUT,
                ontimeout: () => rej(`Timeout while retrieving page XML`),
                onload: function (response) {
                    if (response.finalUrl != requestUrl) {
                        if (response.finalUrl.startsWith(Utils.MIDWAY_REDIRECT_URL)) {
                            rej(response.finalUrl);
                            return;
                        }

                        log.error('[wiki-client] redirected to ' + response.finalUrl);
                        rej("Error occurred while retrieving page XML [redirected]");
                    } else if (response.status != 200) {
                        log.error('[wiki-client] get xml error: ' + response.responseText);
                        rej("Error occurred while retrieving page XML");
                    } else {
                        try {
                            log.info('[wiki-client] get xml result: ' + response.status);
                            const parser = new DOMParser();
                            const xml = (typeof response.responseText === 'string') ? parser.parseFromString(response.responseText, "text/xml") : response.responseText;
                            res(xml);
                        } catch (err) {
                            log.error('[wiki-client] get xml error: ' + err);
                            rej("Error occurred while retrieving page XML");
                        }
                    }
                },
                onerror: function (response) {
                    const cause = response.responseText || 'unknown';
                    log.error('[wiki-client] get xml error: ' + cause);
                    rej("Error occurred while retrieving page XML");
                }
            });
        };

        return Utils.authAwareRetry(async () => this.execute(get_call, this.READ_MIN_WAIT), Utils.WIKI_SERVICE, this.MAX_ATTEMPTS);
    }

    createXmlPageDocument (title, content, syntax, comment) {
        log.info('[wiki-client] creating page...');

        const xmlDoc = new DOMParser().parseFromString(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
            '<page xmlns="http://www.xwiki.org">' +
            '  <title></title>' +
            '  <content></content>' +
            '  <comment></comment>' +
            '  <syntax></syntax>' +
            '</page>', 'application/xml');

        const titleCData = xmlDoc.createCDATASection(title);
        const contentCData = xmlDoc.createCDATASection(content);

        xmlDoc.getElementsByTagName('title')[0].appendChild(titleCData);
        xmlDoc.getElementsByTagName('content')[0].appendChild(contentCData);
        xmlDoc.getElementsByTagName('comment')[0].textContent = comment;
        xmlDoc.getElementsByTagName('syntax')[0].textContent = WikiClient.SYNTAX[syntax];

        return new XMLSerializer().serializeToString(xmlDoc);

        // return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
        //     '<page xmlns="http://www.xwiki.org">' +
        //     '  <title><![CDATA[' + title + ']]></title>' +
        //     '  <content><![CDATA[' + content + ']]></content>' +
        //     '  <comment>' + comment + '</comment>' +
        //     '  <syntax>' + WikiClient.SYNTAX[syntax] + '</syntax>' +
        //     '</page>';
    }

    createXmlTagsDocument (tags) {
        log.info('[wiki-client] creating tags page...');
        if (!tags) {
            tags = [];
        }
        let content = '';
        tags.forEach(tag => {
            content += `<tag name="${tag}" />`;
        });
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
            '<tags xmlns="http://www.xwiki.org">' + content + '</tags>';
    }

    /**
     * Creates or saves a wiki page using Wiki API.
     *
     * - HTTP 201 CREATED if page doesn't exist
     * - HTTP 202 ACCEPTED if page exists
     * - HTTP 400 BAD REQUEST if validation of page path failed
     * - HTTP 401 UNAUTHORIZED if permission check failed
     * - HTTP 500 SERVER ERROR probably content bigger than 2 MB
     *
     * @param {*} wikiAddr the page path
     * @param {*} content the page content
     * @param {*} type the page type, such as home, tags, history, comments, or attachments
     */
    putXmlContent (wikiAddr, content, type) {
        const pageType = type || "root";
        const writingWhat = type == 'tags' ? 'tags to the page' : 'wiki page content';
        const providedWhat = type == 'tags' ? 'one of the tags' : 'the page address';
        const sizeLimit = Utils.formatBytes(this.UPLOAD_SIZE_LIMIT);
        const put_call = (res, rej) => {
            log.info(`[wiki-client] start PUT xml of ${pageType}...`);
            const requestUrl = this.getRestEndpoint(wikiAddr, null, type);
            GM_xmlhttpRequest({
                method: 'PUT',
                url: requestUrl,
                data: content,
                headers: {
                    'Content-Type': 'application/xml',
                    'User-Agent': 'Quip2Wiki/' + Session.version
                },
                timeout: (3 * this.TIMEOUT),
                ontimeout: () => rej(`Put wiki ${type} timeout`),
                onload: function (response) {
                    if (response.finalUrl != requestUrl) {
                        log.debug('[wiki-client] redirected to ' + response.finalUrl);

                        if (response.finalUrl.includes(Utils.MIDWAY_REDIRECT_URL)) {
                            rej(response.finalUrl);
                            return;
                        }
                    }
                    if (response.status == 201 || response.status == 202) {
                        log.info('[wiki-client] put xml result: ' + response.status);
                        res();
                    } else if (response.status == 400) {
                        log.error('[wiki-client] put xml error: [400 - bad request]');
                        rej(`Error occurred while writing ${writingWhat}: ${providedWhat} you have provided contains an invalid character`);
                    } else if (response.status == 401) {
                        log.error('[wiki-client] put xml error: [401 - unauthorized]');
                        rej(`Error occurred while writing ${writingWhat}: you don't have permission to change the page`);
                    } else if (response.status == 500) {
                        log.error('[wiki-client] put xml error: [500 - server error]');
                        rej(`Error occurred while writing ${writingWhat}: the document is too big and exceeds Wiki ${sizeLimit} limit`);
                    } else if (response.status == 504) {
                        log.error('[wiki-client] put xml error: [504 - gateway timeout]');
                        rej(`Error occurred while writing ${writingWhat}: did not get a response in time from server`);
                    } else {
                        log.error(`[wiki-client] put xml error: [${response.status} - unknown]`);
                        rej(`Error occurred while writing ${writingWhat} with cause "${response.status} - unknown"`);
                    }
                },
                onerror: function (response) {
                    const cause = response.responseText || 'unknown';
                    log.error('[wiki-client] put xml error: ' + cause);
                    rej(`Error occurred while writing ${writingWhat} with cause "${cause}"`);
                }
            });
        };

        return Utils.retry(async () => this.execute(put_call, this.WRITE_MIN_WAIT), this.MAX_ATTEMPTS);
    }

    async getLastUpdated (wikiAddr) {
        log.info('[wiki-client] start get last updated...');
        try {
            const wikiXml = await this.getWikiPageXml(wikiAddr, 'history');
            if (wikiXml == null) {
                throw "No XML content";
            }
            const timestamp = WikiClientHelper.getLastUpdated(wikiXml);
            log.info(`[wiki-client] wiki page timestap: ${timestamp || 'none (page changed)'}`);
            return timestamp;
        } catch (e) {
            log.error('[wiki-client] get last updated error: ' + e);
            throw "Error while checking page last change date";
        }
    }

    async getTags (wikiAddr) {
        log.info('[wiki-client] start get tags...');
        try {
            const wikiXml = await this.getWikiPageXml(wikiAddr, 'tags');
            if (wikiXml == null) {
                throw "No XML content";
            }
            const tags = [];
            for (let element of wikiXml.getElementsByTagName('tag')) {
                const tagName = element.getAttribute('name');
                log.info('[wiki-client] tag element: ' + tagName);
                tags.push(tagName);
            }
            return tags;
        } catch (e) {
            log.error('[wiki-client] get tags error: ' + e);
            throw "Error while retrieving page tags";
        }
    }

    /**
     * Retrieves the form token from a existing Wiki Page. The token is required for attachment uploads.
     *
     * The token is extracted from the 'attachment' section of the wiki page, defined by the following URL:
     * https://w.amazon.com/bin/view/Quip2Wiki/?viewer=attachments
     *
     * The token is extracted from the following HTML tag pattern:
     * > <html data-xwiki-form-token="cbKxheYoR12LlTnkcQeIAg">
     * > <input type="hidden" name="form_token" value="cbKxheYoR12LlTnkcQeIAg">
     *
     * @param {string} wikiAddr wiki url address (or relative address)
     * @retuns the wiki page's form token
     */
    getFormToken (wikiAddr) {
        const getToken_call = (res, rej) => {
            log.info('[wiki-client] start get form token...');
            const requestUrl = this.getWikiEndpoint(wikiAddr, 'view', '?viewer=attachments');
            log.info(`[wiki-client] calling endpoint: ${requestUrl}`);
            GM_xmlhttpRequest({
                method: 'GET',
                url: requestUrl,
                headers: {
                    'Content-Type': 'application/html',
                    'User-Agent': 'Quip2Wiki/' + Session.version
                },
                timeout: this.TIMEOUT,
                ontimeout: () => rej('Get form token timeout'),
                onload: function (response) {
                    log.info('[wiki-client] get form token result: ' + response.status);
                    if (response.status != 200 && response.status != 304) {
                        log.error('[wiki-client] get form token error: ' + response.responseText);
                        rej('Could not retrieve form token');
                    } else {
                        try {
                            if (response.finalUrl != requestUrl) {
                                log.debug('[wiki-client] redirected to ' + response.finalUrl);
                            }
                            const parser = new DOMParser();
                            const document = (typeof response.responseText === 'string') ? parser.parseFromString(response.responseText, "text/html") : response.responseText;
                            const token = document.getElementsByTagName("html")[0].getAttribute("data-xwiki-form-token");
                            log.info('[wiki-client] form token: ' + token);
                            res(token);
                        } catch (err) {
                            log.error('[wiki-client] get form token error: ' + err);
                            rej('Could not parse form token');
                        }
                    }
                },
                onerror: function (response) {
                    const cause = response.responseText || 'unknown';
                    log.error('[wiki-client] get form token error: ' + cause);
                    rej('Could not retrieve form token');
                }
            });
        };

        return Utils.retry(async () => this.execute(getToken_call, this.READ_MIN_WAIT), this.MAX_ATTEMPTS);
    }

    /**
     * Retrieves the list of attachments from an existing Wiki Page.
     *
     * @param {string} wikiAddr wiki url address (or relative address)
     */
    async getAttachmentsList (wikiAddr) {
        log.info('[wiki-client] start get attachment list...');
        try {
            const wikiXml = await this.getWikiPageXml(wikiAddr, 'attachments');
            if (wikiXml == null) {
                throw "No XML content";
            }
            return WikiClientHelper.getAttchments(wikiXml);
        } catch (e) {
            log.error('[wiki-client] get attachment list error: ' + e);
            return null;
        }
    }

    uploadAttachmentBlob (blob, wikiAddr, formToken, attachmentName) {
        // kcurl -X POST -F 'form_token=ShJF3DN84tijQuX7zI2EWA' -F 'filepath=@amazon.png'  https://w.amazon.com/bin/upload/Quip2Wiki/HTML/WebHome
        log.info(`[wiki-client] start upload attachment '${attachmentName}'...`);
        const name = attachmentName.substring(23); // friendly name
        const limit = this.UPLOAD_SIZE_LIMIT;

        if (blob.size > limit) {
            const limitStr = Utils.formatBytes(this.UPLOAD_SIZE_LIMIT);
            log.error(`[wiki-client] attachment '${attachmentName}' upload error: above ${limitStr} limit`);
            throw `The attachment '${name}' is too large (above the ${limitStr} limit imposed by Amazon Wiki).`;
        }

        // create form data
        const formData = new FormData();
        formData.append('form_token', formToken);
        formData.append('filepath', blob, attachmentName);
        formData.append('extravar', 'extravar');

        // upload to wiki
        const upload_call = (res, rej) => {
            const requestUrl = this.getWikiEndpoint(wikiAddr, 'upload', 'WebHome');
            GM_xmlhttpRequest({
                method: "POST",
                url: requestUrl,
                headers: {
                    'User-Agent': 'Quip2Wiki/' + Session.version
                },
                data: formData,
                timeout: this.ATTACH_TIMEOUT,
                ontimeout: () => rej(`Upload attachment timeout: '${attachmentName}'`),
                onload: function(response) {
                    if (response.finalUrl != requestUrl) {
                        log.debug('[wiki-client] redirected to ' + response.finalUrl);

                        if (response.finalUrl.includes(Utils.MIDWAY_REDIRECT_URL)) {
                            rej(response.finalUrl);
                            return;
                        }
                    }
                    log.info('[wiki-client] upload attachment result: ' + response.status);
                    if (response.status == 200) {
                        log.info(`[wiki-client] '${attachmentName}' uploaded successfully`);
                        res();
                    } else if (response.status == 403) {
                        log.error(`[wiki-client] attachment '${attachmentName}' upload error: 403 Forbidden`);
                        rej(`Error occurred while uploading attachment '${name}': you don't have permission to change the page`);
                    } else if (response.status == 500) {
                        log.error(`[wiki-client] attachment '${attachmentName}' upload error: ${response.responseText}`);

                        try {
                            let parser = new DOMParser();
                            let internalPageError = parser.parseFromString(response.responseText, "text/html");
                            let errorElement = internalPageError.children[0].children.body.firstElementChild.firstElementChild.children.contentcontainer.firstElementChild.firstElementChild.firstElementChild.children[1];
                            errorElement = errorElement.firstElementChild.children.latestRevisionSummaryStore.nextElementSibling.nextElementSibling;
                            let innerErrorMessage = tagSpecialChars(errorElement.innerText);
                            if (errorElement) {
                                rej(`Error occurred while uploading attachment '${name}': ${innerErrorMessage}`);
                                return;
                            }
                        }
                        catch (e) {
                            log.info(`Failure while extracting internal error message: ${e.toString()}`);
                        }

                        rej(`Unknown error occurred while uploading attachment '${name}'`);
                    } else {
                        log.error(`[wiki-client] attachment '${attachmentName}' upload error (status=${response.status}): ${response.responseText}`);
                        rej(`Unexpected error occurred while uploading attachment '${name}'`);
                    }
                },
                onerror: function(response) {
                    log.error(`[wiki-client] attachment '${attachmentName}' upload error: ${response.responseText}`);
                    rej(`Error occurred while uploading attachment '${name}' with cause "${response.responseText}"`);
                },
            });
        };

        return Utils.retry(async () => this.execute(upload_call, this.UPLOAD_MIN_WAIT), this.ATTACH_MAX_ATTEMPTS);
    }

    deleteAttachment (wikiAddr, formToken, attachmentName) {
        // https://w.amazon.com/bin/delattachment/Quip2Wiki/HTML/WebHome/amazon.png?form_token=ShJF3DN84tijQuX7zI2EWA&xredirect=%2Fbin%2Fview%2FQuip2Wiki%2FHTML%2F%23Attachments
        const name = attachmentName.substring(23); // friendly name
        const delete_call = (res, rej) => {
            log.info(`[wiki-client] start delete of '${attachmentName}'...`);
            const requestUrl = this.getWikiEndpoint(wikiAddr, 'delattachment', 'WebHome') + `/${attachmentName}?form_token=${formToken}`;
            GM_xmlhttpRequest({
                method: "POST",
                url: requestUrl,
                headers: {
                    'User-Agent': 'Quip2Wiki/' + Session.version
                },
                timeout: this.ATTACH_TIMEOUT,
                ontimeout: () => rej(`Attachment '${attachmentName}' delete timeout`),
                onload: function (response) {
                    if (response.finalUrl != requestUrl) {
                        log.debug('[wiki-client] redirected to ' + response.finalUrl);

                        if (response.finalUrl.includes(Utils.MIDWAY_REDIRECT_URL)) {
                            rej(response.finalUrl);
                            return;
                        }
                    }
                    log.info('[wiki-client] delete attachment result: ' + response.status);
                    if (response.status == 403) {
                        log.error(`[wiki-client] attachment '${attachmentName}' delete error: 403 Forbidden`);
                        rej(`Error occurred while deleting attachment '${name}': you don't have permission to change the page`);
                    } else if (response.status != 200 && response.status != 202) {
                        log.error(`[wiki-client] attachment '${attachmentName}' delete error: ${response.responseText}`);
                        rej(`Error occurred while deleting attachment '${name}'`);
                    } else {
                        res();
                    }
                },
                onerror: function (response) {
                    const cause = response.responseText || 'unknown';
                    log.error(`[wiki-client] attachment '${attachmentName}' delete error: ${cause}`);
                    rej(`Error occurred while deleting attachment '${name}' with cause "${cause}"`);
                }
            });
        };

        return Utils.retry(async () => this.execute(delete_call, this.DELETE_MIN_WAIT), this.ATTACH_MAX_ATTEMPTS);
    }

    /**
     * Search template: https://w.amazon.com/rest/wikis/xwiki/search?q={keywords}(&scope={content|name|title|spaces|objects})*(&number={number})(&start={start})(&orderField={fieldname}(&order={asc|desc}))(&prettyNames={false|true})
     */
    search (keywords, scope = 'spaces', number, start, orderField, order, prettyNames) {
        const get_call = (res, rej) => {
            log.info(`[wiki-client] searching: keyword='${keywords}', scope=${scope}...`);
            const requestUrl = WikiClient.API_URL + 'search/search?' + Utils.getEncodedQueryData({
                q: keywords,
                scope: scope,
                number: number,
                start: start,
                orderField: orderField,
                order: order,
                prettyNames: prettyNames
            });
            log.info(`[wiki-client] search endpoint: ${requestUrl}`);
            GM_xmlhttpRequest({
                method: 'GET',
                url: requestUrl,
                headers: {
                    'Content-Type': 'application/xml',
                    'User-Agent': 'Quip2Wiki/' + Session.version
                },
                timeout: 2*this.TIMEOUT,
                ontimeout: () => rej(`Timeout while searching`),
                onload: function (response) {
                    if (response.finalUrl != requestUrl) {
                        log.error('[wiki-client] redirected to ' + response.finalUrl);

                        if (response.finalUrl.includes(Utils.MIDWAY_REDIRECT_URL)) {
                            rej(response.finalUrl);
                            return;
                        }

                        rej("Error occurred while searching [redirected]");
                    } else if (response.status != 200) {
                        log.error('[wiki-client] search error: ' + response.responseText);
                        rej("Error occurred while searching");
                    } else {
                        try {
                            log.info('[wiki-client] search result: ' + response.status);
                            const parser = new DOMParser();
                            const xml = (typeof response.responseText === 'string') ? parser.parseFromString(response.responseText, "text/xml") : response.responseText;
                            const result = WikiClientHelper.getSearchResult(xml);
                            res(result);
                        } catch (err) {
                            log.error('[wiki-client] search error: ' + err);
                            rej("Error occurred while searching");
                        }
                    }
                },
                onerror: function (response) {
                    const cause = response.responseText || 'unknown';
                    log.error('[wiki-client] search error: ' + cause);
                    rej("Error occurred while searching");
                }
            });
        };

        return Utils.retry(async () => this.execute(get_call, this.READ_MIN_WAIT), this.MAX_ATTEMPTS);
    }

}

WikiClient.API_URL = 'https://w.amazon.com/rest/wikis/xwiki/spaces/';
WikiClient.TEST_TIMEOUT = 7500;
WikiClient.VIEW_URL = 'https://w.amazon.com/bin/view/';
WikiClient.DOWNLOAD_URL = 'https://w.amazon.com/bin/download/';
WikiClient.UPLOAD_URL = 'https://w.amazon.com/bin/upload/';
WikiClient.DELETE_ATTACHMENT_URL = 'https://w.amazon.com/bin/delattachment/';
WikiClient.WIKI_URL_REGEX = /^(?:(?:https?:\/\/)?w\.amazon\.com\/(?:bin\/view|bin\/edit|index\.php)\/|w\?)?([^#?\s]*[^#?\s\/])\/?/;
WikiClient.WIKI_TAG = "Quip2Wiki";
WikiClient.SYNTAX = {
    'xwiki': 'xwiki/2.1',
    'xwiki/2.0': 'xwiki/2.0',
    'xwiki/2.1': 'xwiki/2.1',
    'xhtml': 'xhtml/1.0',
    'xhtml/1.0': 'xhtml/1.0',
    'markdown': 'markdown/1.2',
    'markdown/1.2': 'markdown/1.2',
    'mediawiki': 'mediawiki/1.16',
    'mediawiki/1.16': 'mediawiki/1.16'
};
WikiClient.IMAGE_FORMATS = ['jpeg', 'bmp', 'tiff', 'png']; // we will not add 'gif' to avoid resizing and loosing animation
WikiClient.DEFAULT_USER_SPACE = 'Users/';

/**
 * Basic operations associated to for extracting information from a XML document obtained from WikiClient.
 */
class WikiClientHelper {

    static getLastUpdated (wikiXml) {
        const historyEntries = wikiXml.getElementsByTagName('comment');
        for (let item of historyEntries) {
            const wikiComment = item.innerHTML;
            const isSummaryToIgnore = (summary) => wikiComment.includes(summary);
            if (WikiClientHelper.SUMMARIES_TO_IGNORE.some(isSummaryToIgnore)) {
                continue;
            }
            if (wikiComment.includes('Created with Quip2Wiki')) {
                return WikiClientHelper.PAGE_CREATED_TIMESTAMP;
            }
            const commentMatch = wikiComment.match(/\(timestamp=(.*?)\)/);
            if (commentMatch && commentMatch[1]) {
                return parseInt(commentMatch[1]);
            } else {
                return null;
            }
        }
        return null;
    }

    static getAttchments (wikiXml) {
        const output = new Map();

        const items = wikiXml.getElementsByTagName('attachment');
        for (let item of items) {
            const name = item.getElementsByTagName('name')[0].textContent;
            const links = item.getElementsByTagName('link');
            let url = '';
            for (let link of links) {
                if (link.getAttribute('rel') == 'http://www.xwiki.org/rel/attachmentData') {
                    url = link.getAttribute('href');
                    break;
                }
            }
            output.set(name, url);
        }

        return output;
    }

    static getSearchResult (wikiXml) {
        const output = [];

        const resultEntries = wikiXml.getElementsByTagName('searchResult');
        for (let item of resultEntries) {
            output.push({
                id: item.getElementsByTagName('id')[0].innerHTML,
                title: item.getElementsByTagName('title')[0].innerHTML,
                type: item.getElementsByTagName('type')[0].innerHTML,
                syntax: item.getElementsByTagName('wiki')[0].innerHTML,
                space: item.getElementsByTagName('space')[0].innerHTML,
            })
        }

        log.info(`[wiki-client] search result: found ${output.length} pages`);
        return output;
    }
}

WikiClientHelper.SUMMARIES_TO_IGNORE = [
    'Added tag',
    'Removed tag',
    'Added comment',
    'Edited comment',
    'Deleted object',
    'Added annotation on',
    'Updated annotations',
    'Deleted annotation',
];

WikiClientHelper.SUMMARIES_ALL = WikiClientHelper.SUMMARIES_TO_IGNORE.concat([
    'Upload new image',
    'Deleted image',
    'Uploaded new attachment',
    'Deleted attachment',
]);

/**
 * This is magic number to indicate page was just created, but failed first update for some reason.
 */
WikiClientHelper.PAGE_CREATED_TIMESTAMP = 1;

class WikiEditor {

    static IsWikiPage () {        
        return window.location.href.startsWith('https://w.amazon.com/');
    }

    static getWikiUrlInfo () {

        const match = window.location.href.match(WikiEditor.WIKI_URL_PAGE_REGEX);
        if (!match) {
            return null;
        }

        const page = match[1] || 'view'; // if missing we have 'index.php' which is a 'view'
        const addr = match[2].replace('/WebHome', '');
        const section = match[3] || '';
        const parameters = match[4] || '';

        const regex = WikiEditor.WIKI_URL_PARAMS_REGEX;
        let pmatch;
        let editor = '';
        let viewer = '';
        let revision = '';

        while (pmatch = regex.exec(parameters)) {
            editor = pmatch[1] || editor;
            viewer = pmatch[2] || viewer;
            revision = pmatch[3] || revision;
        }

        return {
            page: page,
            addr: addr,
            section: section,
            editor: editor,
            viewer: viewer,
            revision: revision
        };
    }

    static async blockEdit () {
        // check if valid wiki page
        const urlInfo = WikiEditor.getWikiUrlInfo();
        if (!urlInfo) {
            return;
        }

        // there are only 3 wiki pages in which we can change edit buttons:
        // - view: no viewer or viewer=code
        // - viewrev: no viewer or viewers=code (only latest revision)
        const page = urlInfo.page;
        const viewer = urlInfo.viewer;
        const pageHasButtons = (page === 'view' || page === 'viewrev') && (!viewer || viewer === 'code');
        if (!pageHasButtons) {
            return;
        }

        // check if page is generated by Quip2Wiki
        let isGeneratedByQuip2Wiki = await WikiEditor.hasQuip2WikiTag().catch(() => false);
        if (!isGeneratedByQuip2Wiki) {
            return;
        }

        // find tools menu
        const toolsMenu = document.querySelector('#contentmenu > #tmMoreActions > ul.dropdown-menu');
        if (!toolsMenu || !toolsMenu.children) {
            return;
        }

        const firstMenu = toolsMenu.children[0];

        // copy of edit and edit-source buttons as tools menu
        const editMenu = WikiEditor.copyButtonAsToolsMenu('tmEdit');
        if (editMenu) {
            toolsMenu.insertBefore(editMenu, firstMenu);
        }
        const editSourceMenu = WikiEditor.copyButtonAsToolsMenu('tmEditWiki');
        if (editSourceMenu) {
            toolsMenu.insertBefore(editSourceMenu, firstMenu);
        }
        // create separator
        if (editMenu || editSourceMenu) {
            const separator = document.createElement('li');
            separator.classList.add('divider');
            separator.setAttribute('role', 'separator');     
            toolsMenu.insertBefore(separator, firstMenu);
        }

        // disable edit-source button
        WikiEditor.disableButton('tmEditWiki');

        // change edit button to edit in Quip
        const quipUrl = await WikiEditor.getOriginalDocUrl().catch(() => null);
        if (quipUrl) {
            WikiEditor.changeButton('tmEdit', quipUrl, 'Edit in Quip', WikiEditor.EDIT_IN_QUIP_BUTTON_ICON, WikiEditor.EDIT_IN_QUIP_BUTTON_TOOLTIP);
        } else {
            WikiEditor.disableButton('tmEdit');
        }

        // run script to update tooltips
        // the below code was extracted from a <script> tag: document.querySelector('#contentmenu > script')
        // the reason we are pasting the code is that the tag may not be added to page
        eval(`
            require(['jquery', 'jquery-ui', 'bootstrap'], function($) {
                $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
                });
            });`
        )
    }

    static async hasQuip2WikiTag () {
        const urlInfo = WikiEditor.getWikiUrlInfo();
        const page = urlInfo.page;
        const viewer = urlInfo.viewer;
        const isView = (page == 'view' || page === 'viewrev') && !viewer;
        if (isView) {
            return [...document.querySelectorAll('#xdocTags > span.tag-wrapper > span.tag > a')]
                .map(a => a.innerText)
                .some(tagName => tagName === 'Quip2Wiki');
        } else {
            return (await wikiClient.getTags(urlInfo.addr)).includes('Quip2Wiki');
        }
    }

    static async getOriginalDocUrl () {
        const urlInfo = WikiEditor.getWikiUrlInfo();
        const isSourceViewer = urlInfo.viewer === 'code';

        let quipUrl;
        if (isSourceViewer) {
            const codeElement = document.querySelector('textarea.wiki-code');
            const pageSourceCode = codeElement ? codeElement.textContent : '';
            const match = pageSourceCode.match(/<(div|p) [^<>]*class=["']hidden-print["'][^<>]*>[\s\S]*?<a href="(https:\/\/quip-amazon.com\/[\w-_]{11,12})">See original<\/a>[\s\S]*?<\/\1>/) ||
                          pageSourceCode.match(/\(% class=["']hidden-print["'] %\)\(\(\([\s\S]*?\[\[See original>>(https:\/\/quip-amazon.com\/[\w-_]{11,12})\]\][\s\S]*?\)\)\)/);
            quipUrl = match && match[2] ? match[2] : null;
        } else {
            quipUrl = [...document.querySelectorAll('p.hidden-print *, div.hidden-print *, span.hidden-print *')]
                .filter(element => element.tagName === 'A')
                .map(a => a.href)
                .find(url => url.startsWith('https://quip-amazon.com'));
        }

        log.debug(`Original quip doc URL: ${quipUrl || 'not found'}`);
        return quipUrl;
    }

    static copyButtonAsToolsMenu (id) {
        const buttonSpan = document.querySelector(`#contentmenu > #${id}`);
        const buttonLink = document.querySelector(`#contentmenu > #${id} > a.btn`);
        if (!buttonSpan || !buttonLink) {
            return null;
        }

        const isDisabled = buttonLink.classList.contains('disabled');

        const menuItem = document.createElement('li');
        menuItem.id = id + '-menu';
        menuItem.classList.toggle('disabled', isDisabled);

        const menuLink = document.createElement('a'); 
        menuLink.href = buttonLink.href;
        menuLink.target = '_blank';
        menuLink.title = isDisabled ? buttonSpan.getAttribute('data-title') : buttonLink.innerText;
        const glyph = buttonLink.querySelector('span.glyphicon, span.fa').clone();
        const label = document.createElement('span');
        label.innerText = buttonLink.innerText;

        menuLink.appendChild(glyph);
        menuLink.appendChild(label);
        menuItem.appendChild(menuLink);

        return menuItem;
    }

    static disableButton (id) {
        const buttonSpan = document.querySelector(`#contentmenu > #${id}`);
        const buttonLink = document.querySelector(`#contentmenu > #${id} > a.btn`);
        if (!buttonSpan || !buttonLink) {
            return;
        }

        buttonSpan.setAttribute('data-toggle', 'tooltip');
        buttonSpan.setAttribute('data-original-title', WikiEditor.DISABLED_EDIT_BUTTON_TOOLTIP);
        buttonSpan.removeAttribute('data-title', WikiEditor.DISABLED_EDIT_BUTTON_TOOLTIP);

        buttonLink.classList.toggle('disabled', true);
        buttonLink.setAttribute('title', WikiEditor.DISABLED_EDIT_BUTTON_TOOLTIP);
    }

    static changeButton (id, linkUrl, name, iconUrl, tooltip) {
        const buttonSpan = document.querySelector(`#contentmenu > #${id}`);
        const buttonLink = document.querySelector(`#contentmenu > #${id} > a.btn`);
        if (!buttonSpan || !buttonLink) {
            return;
        }

        // enable link
        buttonLink.classList.toggle('disabled', false);

        // set link
        buttonLink.href = linkUrl || buttonLink.href;

        // set name
        const label = buttonLink.querySelector('span:nth-child(2)');
        label.textContent = name || label.textContent;

        // set icon
        const icon = buttonLink.querySelector('span:nth-child(1)');
        if (icon && iconUrl) {
            const img = document.createElement('img');
            img.src = iconUrl;
            img.style.width = '12px';
            img.style.marginRight = '4px';

            buttonLink.removeChild(icon);
            buttonLink.insertBefore(img, label);
        }

        const tooltipValue = tooltip || name || buttonSpan.getAttribute('title');

        // set title
        buttonLink.setAttribute('title', tooltipValue);

        // set tooltip
        buttonSpan.setAttribute('data-toggle', 'tooltip');
        buttonSpan.setAttribute('data-original-title', tooltipValue);
        buttonSpan.removeAttribute('data-title');

    }
}

/**
 * Regex pattern that matches all wiki url, including view/edit pages and different viewers and sections.
 * 
 * The regex should match all the following links:
 * 
 * https://w.amazon.com/index.php/Quip2Wiki
 * https://w.amazon.com/index.php/Quip2Wiki/Test
 * 
 * https://w.amazon.com/index.php/Quip2Wiki/
 * https://w.amazon.com/index.php/Quip2Wiki/Test/
 * 
 * https://w.amazon.com/bin/view/Quip2Wiki/
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#Comments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#Attachments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#History
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#Information
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#HSomesectioninwikipage
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/WebHome/#HSomesectioninwikipage
 * 
 * https://w.amazon.com/bin/view/Quip2Wiki
 * https://w.amazon.com/bin/view/Quip2Wiki/Test
 * https://w.amazon.com/bin/view/Quip2Wiki#Comments
 * https://w.amazon.com/bin/view/Quip2Wiki#Attachments
 * https://w.amazon.com/bin/view/Quip2Wiki#History
 * https://w.amazon.com/bin/view/Quip2Wiki#Information
 * https://w.amazon.com/bin/view/Quip2Wiki/Test#HSomesectioninwikipage
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/WebHome#HSomesectioninwikipage
 * 
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=comments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=attachments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=history
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=information
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=children
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=code
 * 
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=comments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=attachments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=history
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=information
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=children
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=code
 * 
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome/
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome/?editor=wysiwyg
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome/?editor=wiki
 * 
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome?editor=wysiwyg
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome?editor=wiki
 * 
 * https://w.amazon.com/bin/preview/Quip2Wiki/Test/WebHome/
 * https://w.amazon.com/bin/preview/Quip2Wiki/Test/WebHome
 * 
 * https://w.amazon.com/bin/viewrev/Quip2Wiki/Test/WebHome/?rev=10.1
 * https://w.amazon.com/bin/viewrev/Quip2Wiki/Test/WebHome/?viewer=code&rev=10.1
 * 
 * https://w.amazon.com/bin/viewrev/Quip2Wiki/Test/WebHome?rev=10.1
 * https://w.amazon.com/bin/viewrev/Quip2Wiki/Test/WebHome?viewer=code&rev=10.1
 * 
 */
WikiEditor.WIKI_URL_REGEX = /https:\/\/w\.amazon\.com\/(index\.php|bin\/(view|viewrev|edit|preview))\/([^#?\s]+[^\/#?\s])(?:\/WebHome|\/)?(#[^#?\s]*)?(?:\?(?:&?editor=(wysiwyg|wiki)|&?viewer=(comments|attachments|history|information|children|code)|&?rev=(\d+.\d+))*)?/;
WikiEditor.WIKI_URL_PAGE_REGEX = /https:\/\/w\.amazon\.com\/(?:index\.php|bin\/(view|viewrev|edit|preview))\/([^#?\s]+[^\/#?\s])(?:\/WebHome|\/)?(#[^#?\s]*)?(?:\?(&?(?:editor|viewer|rev)=.*)*)?/
WikiEditor.WIKI_URL_PARAMS_REGEX = /&?(?:editor=(wiki|wysiwyg)|viewer=(comments|attachments|history|information|children|code)|rev=(\d+\.\d+))/g
WikiEditor.DISABLED_EDIT_BUTTON_TOOLTIP = 'The Wiki editor is disabled because the content was generated from a Quip document. To edit in Wiki, use the Tools menu (not recommended)';
WikiEditor.EDIT_IN_QUIP_BUTTON_TOOLTIP = 'Edit in Quip as the content of this page was generated from a Quip document. To edit in Wiki, use the Tools menu (not recommended)';
WikiEditor.EDIT_IN_QUIP_BUTTON_ICON = '/bin/download/Favicons/WebHome/quip.png';
/**
 * Holds logic for retrievieng, converting, and saving a Quip document to Amazon Wiki.
 */
class WikiExport {
    constructor(quipClient, wikiClient) {
        this.quipClient = quipClient;
        this.wikiClient = wikiClient;
    }

    async exportDocument(doc, wikiAddr, timestamp) {
        if (doc.isSpreadsheet) {
            // in spreadsheets, the order of sheets do not match order of tables in the doc's html, so we will extract from Quip page the correct order and update the doc with this info
            doc.sheetsDesiredOrder = QuipEditor.extractSheetNames();
        }
        if (doc.isDocument) {
            // layout is broken in the doc's html, so we will extract from Quip page and fix it using div tags
            const layout = QuipEditor.extractMultiColumnLayout();
            doc.fixMultiColumnLayout(layout);
            // design inspector diagrams are not available in doc's html, so we extract from Quip page and add as "design-inspector" tag
            const diDiagrams = QuipEditor.extractDesignInspectorDiagrams();
            doc.fixDesignInspectorDiagrams(diDiagrams);
        }
        if (doc.isDocument || doc.isSpreadsheet) {
            // videos have a complex html pattern in the doc's html, so we will replace them with simple "video" tags
            doc.fixVideos();
            // table do not have an id (just title) in the doc's html, so we will add an id based on the order of the table in the doc
            doc.fixTableIds();
            // math formulas are not available in doc's html, so we extract from Quip page and add as "math" tag
            const mathControls = QuipEditor.extractMathFormulas();
            doc.fixMathFormulas(mathControls);
        }

        // get messages
        let messages = undefined;
        if (doc.findTag(QuipDocument.COMMENTS_TAG)) {
            messages = await quipClient.getAllMessages(doc.linkId);
        }

        const attachments = await doc.getAttachments();

        // determine the wiki page title and tags
        const pageTitle = doc.getWikiTitle();
        const pageTags = doc.getWikiTags();
        const syntax = doc.getWikiSyntax();

        const hasContent = await wikiClient.wikiPageExists(wikiAddr);
        if (!hasContent) {
            await this.createPage(wikiAddr, syntax, pageTitle);
        }

        // we save tags and upload attachments first because the xml schema does not support the 'comment' section, used for storing the timestamp
        await this.saveTags(wikiAddr, pageTags, syntax, hasContent);
        const saveResult = await this.saveAttachments(attachments, wikiAddr);
        if (!saveResult) {
            return false; // user aborted
        }

        let content;
        if (!syntax || syntax === 'xhtml') {
            // convert document to XHTML
            content = await XHtmlConverter.convertQuipHTMLToXHTML(doc, attachments, messages, this.quipClient);
        } else if (syntax === 'xwiki') {
            // convert document to XWiki
            content = await XWikiConverter.convertQuipHTMLToXWiki(doc, attachments, messages);
        } else if (syntax === 'markdown') {
            // convert document to Markdown
            content = await XWikiConverter.convertQuipHTMLToMarkdown(doc, attachments, messages);
        } else {
            throw `Invalid wiki syntax: ${syntax}`;
        }

        log.info(`[wiki-export] start save page as ${syntax}...`);

        // verify content size
        const limit = wikiClient.UPLOAD_SIZE_LIMIT *  1.01;
        const contentSize = content.length; // since we use UTF-8, each char is 1 byte
        const contentSizeStr = Utils.formatBytes(contentSize)
        log.info(`[wiki-export] page content size: ${contentSizeStr}`)
        if (contentSize > limit) {
            throw `The document content is approximatedly ${contentSizeStr} in size and exceeds the Wiki ${Utils.formatBytes(limit)} limit.\nTry breaking the content into two separate documents.`;
        }

        await this.savePage(wikiAddr, content, syntax, timestamp, pageTitle);
        return true; // succeeded
    }

    async exportFolder(folderList, wikiAddr, timestamp) {
        // save the page to the wiki
        const pageTitle = `${folderList.title} Index`;
        const syntax = 'xhtml'; // only XHTML is supported for now
        if (syntax !== 'xhtml') {
            throw `Invalid wiki synxtax: ${syntax}`;
        }
        // convert folder listing to XHTML
        const content = XHtmlConverter.convertQuipFolderListingToXHTML(folderList);
        await this.savePage(wikiAddr, content, syntax, timestamp, pageTitle);
    }

    async createPage (wikiAddr, syntax, title) {
        // if page content does not exist, we will create it, so saving tags does not fail
        log.info('[wiki-export] page have no content. Writing empty content');
        const version = Session.version;
        const comment = `Created with Quip2Wiki Tampermonkey script version ${version}`;
        const message = 'This is a placeholder content for a Quip Document being exported by Quip2Wiki tool';
        const contentNew = syntax === 'xwiki' ? `=== ${message} ===`.replaceAll('Quip2Wiki', '[[Quip2Wiki>>Quip2Wiki.]]') :
                           syntax === 'markdown' ? `### ${message} ===`.replaceAll('Quip2Wiki', '[Quip2Wiki](/bin/view/Quip2Wiki)') :
                        /* syntax === 'xhtml' ? */ `<html><body><h3>${message}</h3></body></html>`.replaceAll('Quip2Wiki', '<a href="/bin/view/Quip2Wiki">Quip2Wiki</a>');
        if (!contentNew) {
            throw `Invalid syntax: ${syntax}`;
        }
        const xmlContentNew = wikiClient.createXmlPageDocument(title, contentNew, syntax, comment);
        await wikiClient.putXmlContent(wikiAddr, xmlContentNew, 'home');
    }

    async saveTags (wikiAddr, tags, syntax, hasContent = false) {
        const syntaxTag = WikiClient.WIKI_TAG + ':' + syntax;
        const newTags = [WikiClient.WIKI_TAG, syntaxTag]; // mandatory tags for monitoring
        if (tags) {
            // user defined tags
            tags.forEach(tag => {
                if (!newTags.includes(tag)) {
                    newTags.push(tag);
                }
            });
        }

        // get current tags
        const curTags = hasContent ? await wikiClient.getTags(wikiAddr) : [];

        // update wiki tags
        const shouldUpdate = !Utils.arraysEqual(curTags, newTags);
        if (shouldUpdate) {
            const tagsContent = wikiClient.createXmlTagsDocument(newTags);
            await wikiClient.putXmlContent(wikiAddr, tagsContent, 'tags');
        }
    }

    async saveAttachments (attachments, wikiAddr) {
        // get attached images and files and upload
        if (!attachments || attachments.size == 0) {
            return true;
        }

        log.info('[wiki-export] start attachments upload...');

        const formToken = await wikiClient.getFormToken(wikiAddr)

        const curAttachments = await wikiClient.getAttachmentsList(wikiAddr);
    
        const limit = wikiClient.UPLOAD_SIZE_LIMIT;
        const limitStr = Utils.formatBytes(limit);

        // add/update document attachments
        for (const [title, value] of attachments.entries()) {
            const { name, url } = value;
            if (curAttachments.has(title)) { // names have a prefix of their blob id, so we won't need to upload if it's already there
                log.info(`[wiki-export] skipped upload of '${title}'`);
                continue;
            }

            let blob = await this.getAttachmentBlob(title, url);
    
            if (blob.size > limit) {
                const promptResult = await Prompts.promptForAttachmentConfirmation(name, blob, limit);
                switch (promptResult) {
                    case 'resize':
                        blob = await this.resizeImage(title, blob, limit);
                        break; // upload
                    case 'abort':
                        log.info(`[wiki-export] user cancelled attachment '${title} upload': above ${limitStr} limit`);
                        return false; // abort
                    default:
                    case 'link':
                        log.info(`[wiki-export] user chose to not upload '${title}': above ${limitStr} limit`);
                        value.skip = true;
                        continue; // skip
                }
            }

            await wikiClient.uploadAttachmentBlob(blob, wikiAddr, formToken, title);
        }

        // delete attachments not in document
        for (const [title, value] of curAttachments.entries()) {
            if (!attachments.has(title)) {
                await wikiClient.deleteAttachment(wikiAddr, formToken, encodeURI(title));
                await Utils.sleep(100); // server might reject if too many requests are made in a short period of time
            }
        }

        return true;
    }

    async resizeImage(attachmentName, blob, targetSize) {
        log.info(`[wiki-export] downsizing image '${attachmentName}'...`);
        const ublob = await Utils.resizeImage(blob, targetSize);
        const percent = Math.round(ublob.size * 100.0 / blob.size);
        log.info(`[wiki-export] downsized image '${attachmentName}' from ${Utils.formatBytes(blob.size)} to ${Utils.formatBytes(ublob.size)} (${percent}%)`);
        return ublob;
    }

    async getAttachmentBlob (attachmentName, attachmentUrl) {
        log.info(`[wiki-export] start download attachment '${attachmentName}'...`);

        // download attachment
        const response = await fetch(attachmentUrl);
        if (!response.ok) {
            throw `Failed to download attachment ${attachmentName}.`;
        }

        let blob = await response.blob();
        log.info(`[wiki-export] fetched attachment '${attachmentName}': size=${Utils.formatBytes(blob.size)}, type=${blob.type}`);

        return blob;
    }

    async savePage (wikiAddr, content, syntax, timestamp, title) {
        // create page content
        const version = Session.version;
        const comment = `Updated with Quip2Wiki Tampermonkey script version ${version} (timestamp=${timestamp})`;
        const xmlContent = wikiClient.createXmlPageDocument(title, content, syntax, comment);

        // save wiki content
        await wikiClient.putXmlContent(wikiAddr, xmlContent, 'home');
    }
}

/**
 * Utility class for basic document convertions, such as Quip API HTML to XHTML.
 */
class XHtmlConverter {
    static async convertQuipHTMLToXHTML(document, attachments, messages, quipClient) {

        // pre-cleaning
        let content = document.htmlContent
            .replace(/^(\s*<p( [^<>]*)?><\/p>\s*)+/g, '') // remove any empty space or empty line at the beggining of the doc
            .replace(/<hr[^<>]*?>/g, '<hr/>') // fix lines: <hr> => <hr/> and remove attribute "width=100% that breaks floating table of contents
            .replace(/<br>/g, '<br/>') // fix line breaks to avoid issues with XHTML
            .replace(/<a data-nolink=[^<>]*>([\s\S]*?)<\/a>/g, '$1'); // remove weird 'no-link' in <a> tags (not visible in Quip), but keep content

        // quip tags: -wiki-title-
        const titleOverride = document.readTagValuesWithArguments(QuipDocument.TITLE_TAG)
            .map(obj => ({
                title: obj.value.trim(),
                isVisible: XHtmlConverter.getBooleanArgValue(obj.args, 'visible', false)
            }))[0];
        if (!titleOverride || !titleOverride.isVisible) {
            content = content.replace(/^<h1[^<>]*?>.*?<\/h1>\s*/g, '') // remove first heading (Title)
        } else {
            log.info('Making h1 header visible on page body');
            if (titleOverride.title) {
                content = content.replace(/^(<h1[^<>]*?>).*?<\/h1>/g, `$1${titleOverride.title}</h1>`) // replace first heading value (Title)
            }
        }

        // find all anchors within document
        const anchorsInUse = new Set();
        content.replace(/<a href="https?:\/\/quip-amazon\.com\/(\w{12})(?:\/.*?)?#([^<>]*?)">/g, (m, docId, id) => {
            const isSameDoc = docId === document.id || docId === document.linkId;
            if (isSameDoc) {
                anchorsInUse.add(id);
            }
        });

        // generate messages/comments
        const messagesContent = await XHtmlConverter.convertQuipMessagesToXHTML(messages, document);

        // find all anchors from messages
        for (let item of messagesContent.references) {
            anchorsInUse.add(item.sectionId); // include mentioned sections
        }

        // attributes
        content = content
            .replace(/ class=(''|"")/g, '') // remove empty 'class' attributes
            .replace(/ style=(''|"")/g, '') // remove empty 'style' attributes
            .replace(/<(\w+?[^<>]*?) id='([^<>]*?)'([^<>]*?)>/g, // remove quip ids not being used
                (m, p1, id, p2) => anchorsInUse.has(id) ? m : `<${p1}${p2}>`)
            .replace(/<(h\d[^<>]*?) (id='[^<>]*?')([^<>]*?)>/g, "<a $2/><$1$3>"); // fix headings' anchors by adding html <a> tag

        // image border
        content = content.replace(/<div data-section-style='11'[^<>]*(?:class='.*?show-border.*?')[^<>]*><img[^<>]*/g, match => `${match} style='border:1px solid #555'`); // set image border

        const options = document.getWikiOptions();

        let imageStyle = "";

        // force images to be all the same size.
        // It is necessary to change the 'display' property to 'block' so the size properly applies when inside table cells.
        if (options.forceImageSize && options.forcedImageSize) {
            imageStyle += "display: block; width: " + options.forcedImageSize + ";";
        }

        // fix image centering if the option is active
        if (options.fixImageCentering) {
            imageStyle += "text-align:center;";
        }

        if (imageStyle != "") {
            content = content.replaceAll("<div data-section-style='11' style='max-width:100%'", "<div data-section-style='11' style='" + imageStyle + "'");
            content = content.replaceAll("<span data-section-style='11' style='max-width:45%'", "<span data-section-style='11' style='" + imageStyle + "'");
            content = content.replaceAll("<span data-section-style='11' style='max-width:44%'", "<span data-section-style='11' style='" + imageStyle + "'");
        }

        // text alignment
        content = content.replace(/<(?:h\d|p|pre|blockquote)\s[^<>]*(?:class='.*?align-(center|right).*?')[^<>]*/g, (match, align) => `${match} style='text-align: ${align}'`) // set text alignment center

        // video tag must be within html macro
        content = content.replace(/(<video [^<>]*>)/g, '<!--startmacro:html|-||-|$1--><!--stopmacro-->');

        // quip mentions
        const knownUsers = {};
        const quipUserCache = new LocalDataLruCache("quipUserCache", 100);
        content = await Utils.replaceAsyncSequence(content, XHtmlConverter.QUIP_MENTION_FULLNAME_REGEX, async (m, m1, url, name) => {
            var urlParts = url.split("/");
            var quipId = urlParts.at(urlParts.length - 1);

            var userLogin = await quipUserCache.getAsync(quipId, async (userId) => {
                var userInfo = await quipClient.getUser(userId);
                if (userInfo != undefined && userInfo != null && userInfo.emails != null && userInfo.emails.length > 0) {
                    let email = typeof userInfo.emails[0] === 'string' ? userInfo.emails[0] : userInfo.emails[0].address;
                    return email.split("@")[0];
                }

                await Utils.sleep(500);
                return undefined;
            });

            if (userLogin) {
                return `<a href="https://phonetool.amazon.com/users/${userLogin}">${name}</a>`;
            }

            const login = await XHtmlConverter.getUserLogin(name, knownUsers);
            if (login) {
                return `<a href="https://phonetool.amazon.com/users/${login}">${name}</a>`;
            } else {
                return m1 + name + '</a>';
            }
        });
        quipUserCache.persistCache();

        // amazon login mentions (ex: @siljonas or siljonas@)
        const knownLogins = [];
        content = await Utils.replaceAsyncSequence(content, XHtmlConverter.QUIP_MENTION_LOGIN_REGEX2, async (m, login1, login2) => {
            const login = login1 || login2;
            const isValid = await XHtmlConverter.checkUserLogin(login, knownLogins);
            if (isValid) {
                return `<a href="https://phonetool.amazon.com/users/${login}">${m}</a>`;
            } else {
                return m;
            }
        });

        // links
        content = content
            .replace(/<a href="https?:\/\/w\.amazon\.com(\/bin\/view\/[^<>]*?)"/g, '<a href="$1"') // to relative wiki address
            .replace(/<a href="https?:\/\/w\.amazon\.com\/index\.php\/([^<>]*?)"/g, '<a href="/bin/view/$1"') // from legacy to relative wiki address
            .replace(/<control data-remapped="true"[^<>]*?>(<a href="https?:\/\/quip-amazon\.com\/\w{12}(?:\/.*?)?">[^<>]+?<\/a>)<\/control>/g, '$1') // fix quip doc url
            .replace(/<control data-remapped="true"[^<>]*?>(<a href="https?:\/\/quip-amazon\.com\/-\/blob\/.{11}\/.{22}\?(?:s=\w{12}&)?name=.+?"[^<>]*?>.*?<\/a>)<\/control>/g, '&#x1F4CE;$1') // fix attachment url and add paper clip emoji
            .replace(/<a href="https?:\/\/quip-amazon\.com\/(\w{12})(?:\/.*?)?#([^<>]*?)">/g, (m, docId, id) => { // fix links to anchors within the document
                const isSameDoc = docId === document.id || docId === document.linkId;
                if (isSameDoc && anchorsInUse.has(id)) {
                    return `<a href="#${id}">`;
                } else {
                    return m; // links to anchors outside document are kept as is
                }
            });

        // empty lines
        const emptyLineRegex = /(<p[^<>]*?>.+?<\/p>)\s*?<p[^<>]*?>.?<\/p>(\s*?<p[^<>]*?>.+?<\/p>)/g;
        while (emptyLineRegex.test(content)) {
            content = content.replace(emptyLineRegex, '$1\n$2'); // remove empty lines between paragraphs
        }

        // fix non-paragraph code blocks
        content = XHtmlConverter.fixCodeBlocks(content);

        // lists
        content = XHtmlConverter.fixLists(content);

        // style
        content = content
            .replace(/(<td(?!\S)[^<>]*?class='.*?bold.*?'[^<>]*?>)([\s\S]*?)((?:\s*<br\/>\s*)?<\/td>)/g, '$1<b>$2</b>$3') // fix bold format of spreadsheet cells
            .replace(/(<td(?!\S)[^<>]*?class='.*?italic.*?'[^<>]*?>)([\s\S]*?)((?:\s*<br\/>\s*)?<\/td>)/g, '$1<i>$2</i>$3') // fix italic format of spreadsheet cells
            .replace(/(<td(?!\S)[^<>]*?class='.*?underline.*?'[^<>]*?>)([\s\S]*?)((?:\s*<br\/>\s*)?<\/td>)/g, '$1<u>$2</u>$3') // fix underline format of spreadsheet cells
            .replace(/(<td(?!\S)[^<>]*?class='.*?strikethrough.*?'[^<>]*?>)([\s\S]*?)(<\/td>)/g, '$1<del>$2</del>$3') // fix strikethrough format of spreadsheet cells
            .replace(/<(\w+?)([^<>]*?) class='[^<>]*?'([^<>]*?)>/g, '<$1$2$3>') // remove any 'class' attributes
            .replace(/<f([^<>]*?)>/g, '<span$1>') // fix highlighting
            .replace(/<\/f>/g, '</span>')
            .replace(/ textcolor="#[0-9]{6}"/g, '') // remove textcolor attribute
            .replace(/<code>/g, "<span class='monospace'>") // fix code font
            .replace(/<\/code>/g, '</span>')
            .replace(/<q((?!\S)[^<>]*?)?>/g, '<blockquote$1>') // make pull quote equal block quote
            .replace(/<\/q>/g, '</blockquote>')
            .replace(/<(?!\/)blockquote(?:([^<>]*?)(?: style='(.*?)')|([^<>]*?))([^<>]*)>/g, "<blockquote$1$3 style='font-size: inherit; $2'$4>") // fix block quote font size
            .replace(/(<img [^<>]*?)(?: width=(["']).*?\2)([^<>]*>)/g, '$1$3') // remove width attribute of images
            .replace(/(<img [^<>]*?)(?: height=(["']).*?\2)([^<>]*>)/g, '$1$3') // remove height attribute of images
            .replace(/(<li[^<>]*><span(?:[^<>]*( style='(.*?)')|[^<>]*))([^<>]*>(\<.*?\>){0,1}?(<img src=[^<>]*>)+?)/g, (m, left, attr, attrValue, right) => { // align images at the top in lists
                if (attr) {
                    const newAttr = attrValue ? attr.replace(attrValue, attrValue + '; vertical-align: top;') : ` style='vertical-align: top;'`;
                    return left.replace(attr, newAttr) + right;
                } else {
                    return left + ` style='vertical-align: top;'` + right;
                }
            });

        // fix attachment links
        content = XHtmlConverter.fixAttachmentLinks(content, document.wikiAddr, attachments);

        // decorate comments and highlights
        content = XHtmlConverter.decorateComments(content, messagesContent.references);

        // quip tags: -wiki-sortable-tables-
        let sortableTablesTag = '';

        // extract sortable tables
        const sortableTables = XHtmlConverter.getSortableTables(document, content);

        // fix tables/sheets
        content = XHtmlConverter.fixTables(content);

        // add sortable styling
        if (sortableTables.size > 0) {
            content = XHtmlConverter.setSortableTables(content, sortableTables);
            sortableTablesTag = `<!--startmacro:enableSortableTables|-||-|--><!--stopmacro-->\n`;
        }

        // macros
        content = content
            .replace(/<math>([\s\S]*?)<\/math>/g, (match, eq) => `<!--startmacro:formula|-||-|${eq.replace(/\\/g, '\\\\')}--><!--stopmacro-->`) // set math equations with formula macro (and escape '\')
            .replace(/<design-inspector src='(.*?)' width='(.*?)' height='(.*?)'\s*\/>/g, (match, diUrl, width, height) =>
                `<!--startmacro:iframe|-|url="${diUrl}" width="1100px" height="${Math.trunc(1.375 * parseInt(height))}px"--><!--stopmacro-->`) // set design-inspector diagrams with iframe macro
            .replace(/<(p|td)(?:(?!\S)[^<>]*)?>([\s\S]*?)<\/\1>/g, (section, tagName, innerSection) => {
                const regex = /--wiki-macro:\s*["“”](.*?)["“”]\s*--/g;
                let outputMacros = '';
                let outputInline = innerSection;
                let nonMacroContent = innerSection;
                let match;
                while (match = regex.exec(innerSection)) {
                    const tag = match[0];
                    const tagArgs = match[1];
                    const macro = XHtmlConverter.createMacro(tag, tagArgs);
                    outputMacros = outputMacros + macro;
                    outputInline = outputInline.replace(tag, macro);
                    nonMacroContent = nonMacroContent.replace(tag, '');
                }
                const hasInlineMacros = !!(nonMacroContent.replace(/<[^<>]+>/g, '').trim());
                if (outputMacros) {
                    const output = hasInlineMacros ? outputInline : outputMacros;
                    if (tagName === 'td' || hasInlineMacros) {
                        return section.replace(innerSection, output);
                    } else {
                        return output;
                    }
                } else {
                    return section;
                }
            });

        // quip tags: wiki-header and wiki-footer
        let headerTag = XHtmlConverter.getHeaderContent(document);
        let footerTag = XHtmlConverter.getFooterContent(document);

        // quip tags: wiki-toc
        let tocTag = '\n';
        let isTocFloating = true;
        const tocTagExists = document.findTag(QuipDocument.TOC_TAG);
        if (tocTagExists) {
            const tocArgs = document.readTagValue(QuipDocument.TOC_TAG, '');
            const isTocClassic = XHtmlConverter.getBooleanArgValue(tocArgs, 'classic', false);
            isTocFloating = !isTocClassic && XHtmlConverter.getBooleanArgValue(tocArgs, 'floating', true);
            tocTag = XHtmlConverter.getTableOfContentsXHTML(tocArgs);
        }

        // quip tags: wiki-tracker
        let trackTag = '';
        const trackId = document.readTagValue(QuipDocument.TRACKER_TAG, null);
        if (trackId && Utils.test(XHtmlConverter.GUID_REGEX, trackId.trim())) {
            const pixelId = trackId.trim();
            const wikiAddr = document.wikiAddr.replace(/\//g, '.');
            trackTag = `<!--startmacro:transclude|-|name="HowMany" args="PixelID=${pixelId}|Page=${wikiAddr}|Param=QuipDocId:${document.linkId}"--><!--stopmacro-->`;
        }

        // quip tags: -wiki-banner-
        let bannerPosition = Settings.bannerPosition || BannerPosition.TOP;
        const bannerTagExists = document.findTag(QuipDocument.BANNER_TAG);
        if (bannerTagExists) {
            const bannerTagArgs = document.readTagValue(QuipDocument.BANNER_TAG, '');
            const bannerTagDisplayValue = XHtmlConverter.getArgValue(bannerTagArgs, 'display', 'top') || '';
            const newPosition = bannerTagDisplayValue.trim();
            if (newPosition === 'top') {
                bannerPosition = BannerPosition.TOP;
            } else if (newPosition === 'bottom') {
                bannerPosition = BannerPosition.BOTTOM;
            } else if (newPosition === 'hidden') {
                bannerPosition = BannerPosition.HIDDEN;
            } else if (newPosition === 'none') {
                bannerPosition = BannerPosition.NONE;
            }
        }

        if (content.includes("--wiki-ignore--")) {
            // quip tags: -wiki-ignore-
            content = content
                .replace(/<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--wiki-ignore--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>[\s\S]+?<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--wiki-ignore--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>/g, '') // remove block of text between '--wiki-ignore--' tags
                .replace(/<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--wiki-ignore--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>[\s\S]*/g, ''); // remove anything after '--wiki-ignore--' tag
        }

        // spreadsheet sheets as tabs
        if (document.type == 'spreadsheet') {
            const selectedSheets = document.readTagValue(QuipDocument.SHEETS_TAG, '').split(/\s*[;,]\s*/).filter(s => s && s.length > 0);
            content = XHtmlConverter.transformAsTabXHTML(content, selectedSheets, document.sheetsDesiredOrder);
        }

        // quip tags: clean-up
        content = content
            //.replace(/(<p(?: [^<>]*)?>)((<[^<>]*>|\s)*?--wiki-[\w-]+?(:.*?)?--(<[^<>]*>|\s)*?(?=<br\/>)<br\/>)+/g, '$1');
            .replace(/<p( [^<>]*)?>(<(?!\/p)[^<>]*>|\s)*?--wiki-[\w-]+?(:.*?)?--(<[^<>]*>|\s)*?<\/p>/g, '') // remove any quip2wiki tag
            .replace(/<p( [^<>]*)?>(<(?!\/p)[^<>]*>|\s)*?--quip2wiki-[\w-]+?(:.*?)?--(<[^<>]*>|\s)*?<\/p>/g, ''); // remove the new quip2wiki-options tag

        // line spacing
        content = content.replace(/<\/p>\n\n<p>/g, '\n<br/>');

        // remove line at end of doc
        content = content.replace(/<hr\/>(\s*<p>\s*<\/p>)*\s*$/g, '');

        const bannerContent = XHtmlConverter.getBannerXHTML(document.type, document.linkId, bannerPosition);

        const headerBanner = bannerPosition === BannerPosition.TOP ? bannerContent : '';
        const footerBanner = bannerPosition !== BannerPosition.TOP ? bannerContent : ''; // if BOTTOM or HIDDEN

        const trackerPixel = options.trackerPixel ? `<img src="${options.trackerPixel}" />` : '';

        const tocTagBefore = isTocFloating ? tocTag : '';
        const tocTagAfter = !isTocFloating ? tocTag : '';

        const quipUrl = `${QuipEditor.QUIP_URL}/${document.linkId}`;
        const warning = XHtmlConverter.EDIT_IN_QUIP_COMMENT
            .replace(/\{\{docType\}\}/g, document.type)
            .replace(/\{\{quipUrl\}\}/g, quipUrl);

        return [`<!-- \n\n\n${warning}\n\n\n -->\n`,
            '<html>\n<body>\n',
            headerTag,
            tocTagBefore,
            headerBanner,
            trackerPixel,
            tocTagAfter,
            sortableTablesTag,
            content,
            messagesContent.htmlContent,
            trackTag,
            footerBanner,
            footerTag,
            '</body>\n</html>']
            .join('')
            .replace(/\n\n\n/g, '\n\n');
    }

    static getTableOfContentsXHTML(args) {
        const isClassic = XHtmlConverter.getBooleanArgValue(args, 'classic', false);
        const isFloating = XHtmlConverter.getBooleanArgValue(args, 'floating', true);
        const isNumbered = XHtmlConverter.getBooleanArgValue(args, 'numbered', false);
        const startValue = XHtmlConverter.getNumericArgValue(args, 'start', 2);
        const depthValue = XHtmlConverter.getNumericArgValue(args, 'depth', 3);

        const start = Math.max(1, Math.min(startValue, 6)); // allowed values: 1-6
        const depth = Math.max(1, Math.min(depthValue, 6)); // allowed values: 1-6, even though Quip only has 3 levels

        const tocHtml = isClassic ? XHtmlConverter.TOC_CLASSIC : XHtmlConverter.TOC_BOXED;

        return tocHtml
            .replace('{{boxClass}}', isFloating ? XHtmlConverter.FLOATING_BOX_CLASS : XHtmlConverter.BOX_CLASS)
            .replace('{{isNumbered}}', isNumbered ? 'true' : 'false')
            .replace('{{start}}', start)
            .replace('{{depth}}', depth);
    }

    static getArgValue(args, name, defaultValue) {
        try {
            const sName = Utils.escapeRegExp(name);
            return args.match(new RegExp(`(?:^${sName}|[\\s;,|]${sName})\\s*=\\s*(?:(\\w+)|'([\\w ]+)')((?=[\\s;,|])|$)`))[1];
        } catch (ignore) {
            return defaultValue;
        }
    }

    static getBooleanArgValue(args, name, defaultValue) {
        try {
            const sName = Utils.escapeRegExp(name);
            const defaultIsTrue = !!defaultValue;
            if (defaultIsTrue) {
                const foundFalse = new RegExp(`(?:^${sName}|[\\s;,|]${sName})\\s*=\\s*(false|'false')(?:(?=[\\s;,|])|$)`).test(args);
                return !foundFalse;
            } else {
                const foundTrue = new RegExp(`(?:^${sName}|[\\s;,|]${sName})\\s*=\\s*(true|'true')(?:(?=[\\s;,|])|$)`).test(args);
                return foundTrue;
            }
        } catch (ignore) {
            return !!defaultValue;
        }
    }

    static getNumericArgValue(args, name, defaultValue) {
        try {
            const sName = Utils.escapeRegExp(name);
            const valueStr = args.match(new RegExp(`(?:^${sName}|[\\s;,|]${sName})\\s*=\\s*(?:(\\d+)|'(\\d+)')(?:(?=[\\s;,|])|$)`))[1];
            const value = parseInt(valueStr);
            if (!Number.isFinite(value)) {
                throw 'invalid number';
            }
            return value;
        } catch (ignore) {
            return defaultValue;
        }
    }

    static getBannerXHTML(docType, id, bannerPosition = BannerPosition.TOP) {
        if (bannerPosition === BannerPosition.NONE) {
            return '';
        }

        const quipUrl = QuipEditor.QUIP_URL;
        const now = new Date().toUTCString();
        const msg = `This page was created by <a href="/bin/view/Quip2Wiki">Quip2Wiki</a> ` +
            `from a Quip ${docType} (<a href="${quipUrl}/${id}">See original</a>) at '${now}'`;

        const clazz = (bannerPosition === BannerPosition.HIDDEN ? 'hidden-print hidden' : 'hidden-print');
        const prefix = (bannerPosition !== BannerPosition.TOP ? `<hr/>\n` : '');
        const suffix = (bannerPosition === BannerPosition.TOP ? `\n<hr/>` : '');

        return `<div class='${clazz}'>\n${prefix}` +
            `<p><i style='color:#888888; font-size:small;'>${msg}</i></p>` +
            `${suffix}\n</div>\n`;
    }

    static fixCodeBlocks(content) {
        const regex = /<span[^<>]*class='prettyprint'[^<>]*>/gi;
        var match;
        do {
            match = regex.exec(content);
            if (match) {
                const begin = match.index + match[0].length;
                let end = content.indexOf('</span>', begin);

                while (true) {
                    const part = content.substring(begin, end);
                    let spanCount = (part.match(/<span/gi) || []).length;
                    let spanCloseCount = (part.match(/<\/span>/gi) || []).length;
                    if (spanCount == spanCloseCount) {
                        break;
                    } else {
                        end = content.indexOf('</span>', end + 1);
                    }
                }

                const innerBlock = content.substring(begin, end);
                const outerBlock = content.substring(match.index, end + 7);

                content = content.replace(outerBlock, `<pre>${innerBlock}</pre>`);
            }
        } while (match);

        return content;
    }

    static fixLists(content) {
        const continuationInfo = { start: 1, count: 0 };
        return content
            .replace(/<div[^<>]*?data-section-style='5'[^<>]*?>([\s\S]*?)<\/div>/g, XHtmlConverter.fixBulletList)
            .replace(/<div[^<>]*?data-section-style='7'[^<>]*?>([\s\S]*?)<\/div>/g, XHtmlConverter.fixTaskList)
            .replace(/<div([^<>]*?data-section-style='6'[^<>]*?)>([\s\S]*?)<\/div>/g, (match, divContent, list) => {
                const listContent = XHtmlConverter.fixNumberedList(match, list);
                return XHtmlConverter.fixNumberedListContinuation(listContent, divContent, continuationInfo);
            });
    }

    static fixBulletList(match, list) {
        const ulStack = [];
        return list
            .replace(/<\/span>\s*?<br\/>\s*?<\/li>/gm, '</span></li>\n')
            .replace(/(?:<\/li>)?(\s*<ul>)|(<\/ul>)/g, (match, p1) => {
                if (p1 && p1.includes('<ul>')) {
                    const shouldFix = match.includes('<\/li>');
                    ulStack.push(shouldFix);
                    return p1;
                } else {
                    const shouldFix = ulStack.pop();
                    return match + (shouldFix ? '<\/li>' : '');
                }
            });
    }

    static fixNumberedList(match, list) {
        const numberedList = XHtmlConverter.fixBulletList(match, list)
            .replace(/<ul>/g, '<ol>')
            .replace(/<\/ul>/g, '</ol>');
        return XHtmlConverter.setNumberedListStyle(numberedList, 0);
    }

    static fixNumberedListContinuation(listContent, divContent, continuationInfo) {
        const listHtml = new DOMParser().parseFromString(listContent, 'text/html');
        const itemCount = [...listHtml.querySelectorAll('body > ol > li, body > ul > li')].length;

        const isContinuation = /class=(["']).*list-numbering-continue.*\1/.test(divContent);
        if (isContinuation) {
            const startValue = continuationInfo.start + continuationInfo.count;
            continuationInfo.count = continuationInfo.count + itemCount;
            return listContent.replace(/^([\s\S]*?)<ol([^<>]*?)>/, `$1<ol$2 start="${startValue}">`);
        } else {
            let startValue = 1;
            const hasStartNumber = /class=(["']).*list-numbering-restart-at.*\1/.test(divContent);
            if (hasStartNumber) {
                const startMatch = divContent.match(/style="--indent0: (\d+)"/)[1];
                startValue = Number.parseInt(startMatch);
            }
            continuationInfo.start = startValue;
            continuationInfo.count = itemCount;
            if (startValue > 1) {
                return listContent.replace(/^([\s\S]*?)<ol([^<>]*?)>/, `$1<ol$2 start="${startValue}">`);
            } else {
                return listContent;
            }
        }
    }

    static setNumberedListStyle(list, level) {
        const types = XHtmlConverter.NUMBERED_LIST_STYLES;
        const len = XHtmlConverter.NUMBERED_LIST_STYLES.length;

        const first = list.indexOf('<ol>');
        if (first < 0) {
            return list;
        }

        const listBegin = list.substring(0, first + 4).replace('<ol>', `<ol type="${types[level % len]}">`);
        const listRest = list.substring(first + 4);

        const next = listRest.indexOf('<ol>');
        if (next < 0) {
            return listBegin + listRest;
        } else {
            const end = listRest.indexOf('</ol>');
            let nextLevel = level + 1;
            if (end < next) {
                const upLevel = (listRest.substring(0, next).match(/<\/ol>/g) || []).length;
                nextLevel -= upLevel;
            }
            return listBegin + XHtmlConverter.setNumberedListStyle(listRest, nextLevel)
        }
    }

    static fixTaskList(match, list) {
        let content = XHtmlConverter.fixBulletList(match, list)
            .replace(/<li[^<>]*?(?:class='(.*?)'[^<>]*?)?>\s*<span[^<>]*>(.*?)<\/span>\s*(<\/li>|<ul>)/g, (m, classVal, value, closeTag) => {
                if (!classVal || !classVal.includes('checked')) {
                    return `<li><span style="font-weight: bold; font-size: large;">&#9744;</span> ${value}${closeTag}`; // uncompleted
                } else {
                    return `<li><span style="font-weight: bold; font-size: large;">&#9745;</span> <del>${value}</del>${closeTag}`; // completed tasks
                }
            })
            .replace(/<ul[^<>]*>/g, '<ul style="list-style-type:none;">') // force list style to 'none' (hidden);
        return content;
    }

    static getSortableTables(document, content) {
        const sortableTables = new Map();

        const containsSortableTablesTag = document.findTag(QuipDocument.SORTABLE_TABLES_TAG);
        if (containsSortableTablesTag) {
            // get all tables
            const allTables = [...content.matchAll(/<table(?: [^<>]*)? title='(.*?)'(?:[^<>]*?)>/g)].map(m => m[1]);

            // extract sortable sheets
            const tablesInTag = document.readTagValue(QuipDocument.SORTABLE_TABLES_TAG, '').split(/\s*[;,]\s*/).filter(s => s && s.length > 0);

            // add to sotableTables map
            const tablesToAdd = tablesInTag.length > 0 ? tablesInTag : allTables;
            tablesToAdd.forEach(title => sortableTables.set(title, 'sortable'));
        }

        // extract table tags
        [...content.matchAll(XHtmlConverter.SORTABLE_TABLE_TAGS_REGEX)].forEach(m => {
            const title = m[2];
            const tag = m[3];
            sortableTables.set(title, tag);
        });

        return sortableTables;
    }

    static setSortableTables(content, sortableTables) {
        // enable sorting (requires class and id attribues)
        content = content.replace(/<table([^<>]*)? title='(.*?)'([^<>]*?)>\s*<thead><tr( [^<>]*)?>/g, (m, attr1, title, attr2, headerAttr) => {
            const type = sortableTables.get(title);
            let tableClass;
            if (type === QuipDocument.TABLE_SORTABLE_INLINE_TAG) {
                tableClass = XHtmlConverter.CLASS_SORTABLE;
            } else if (type === QuipDocument.TABLE_SORT_ONLY_INLINE_TAG) {
                tableClass = XHtmlConverter.CLASS_SORT_ONLY;
            } else if (type === QuipDocument.TABLE_FILTER_ONLY_INLINE_TAG) {
                tableClass = XHtmlConverter.CLASS_FILTER_ONLY;
            } else {
                return m; // do not change
            }

            const headerClass = !!type ? ' class="sortHeader"' : '';

            const idAttr = m.match(/(?<= )id='.+?'/) || `id='${title}'`;
            const attr = (attr1 || '') + (attr2 || '').replace(idAttr, '');
            return `<table title='${title}' ${idAttr} class='${tableClass}'${attr}><thead><tr${headerAttr}${headerClass}>`;
        });

        return content;
    }

    static fixTables(content) {
        const thStyle = 'background-color:#E1E1E1;';

        return content
            .replace(/\u200b/g, '') // clean unwanted chars
            .replace(/<table[^<>]*?title='(.*?)'[^<>]*?>/g, (m, sheet) => m.replace(`title='${sheet}'`, `title='${Utils.sanitizeHTMLText(sheet)}'`)) // fix unescaped sheet name
            .replace(/<table[^<>]*?>\s*<tbody[^<>]*?><tr[^<>]*?>[\s\S]*?<\/tr>/g, m => { // convert first row into a thead if thead is missing
                return m.replace(/<tbody([^<>]*?)>/g, '<thead$1>')
                    .replace(/<td([^<>]*?)>/g, '<th$1>')
                    .replace(/<\/td>/g, '</th>')
                    .replace(/<\/tr>/g, '</tr></thead><tbody>');
            })
            .replace(/<table ([^<>]*?)>/g, "<table $1 border='1px' borderColor='#c7cbd1'>") // set table basic style
            .replace(/<thead><tr><th(?:(?!\S)[^<>]*?)?\/>/g, '<thead><tr>') // remove row number header
            .replace(/<tr><td(?:(?!\S)[^<>]*?)?>\d+<\/td>/g, '<tr>')        // remove row number column
            .replace(XHtmlConverter.SORTABLE_TABLE_TAGS_REGEX, (m, left, title, tag, right) => {  // remove inline sortable tags
                return left + right;
            })
            .replace(/<thead><tr>(?:<th\s+style='[^<>]*?'>[A-Z]+<br\/><\/th>)+<\/tr><\/thead><tbody><tr>([\s\S]+?)<\/tr>/g, (match, p1) => { // detect header in first line
                const widths = [];
                match.replace(/<th\s+style='([^<>]*?)'>/g, (m, g1) => widths.push(g1));

                let count = 0;
                const header = p1
                    .replace(/<td\s+style='([^<>]*?)'>/g, (m, g1) => `<th style='${widths[count++]}; ${g1}'>`)
                    .replace(/<td>/g, `<th style='${widths[count++]};'>`)
                    .replace(/<\/td>/g, '</th>');

                return `<thead><tr>${header}</tr></thead><tbody>`;
            })
            .replace(/(<tr>(<td(?:(?!\S)[^<>]*?)?>((?:<[bui]>|<span>)\s*?)*((?:<\/[bui]>|<\/span>)\s*?)*<br\/><\/td>)+<\/tr>)*<\/tbody>/g, '</tbody>') // remove empty lines at the end
            .replace(/<table[^<>]*?>[\s\S]*?<\/table>/g, (match) => { // extract each table
                let maxCols = 0;
                match.replace(/<tr>([\s\S]*?)(?:<td(?:(?!\S)[^<>]*?)?><span><\/span>\s*<br\/><\/td>)*<\/tr>/g, (m, p1) => { // count non-empty columns
                    const count = ((p1 || '').match(/<td/g) || []).length
                    maxCols = Math.max(count, maxCols);
                });
                if (maxCols == 0) {
                    return match;
                }
                return match
                    .replace(new RegExp(`<tr>((?:<th(?:(?!\S)[^<>]*?)?>[\\s\\S]*?<\\/th>){${maxCols}})(?:<th(?:(?!\S)[^<>]*?)?>[\\s\\S]*?<\\/th>)*<\\/tr>`, 'g'), '<tr>$1</tr>') // remove empty columns in table header
                    .replace(new RegExp(`<tr>((?:<td(?:(?!\S)[^<>]*?)?>[\\s\\S]*?<\\/td>){${maxCols}})(?:<td(?:(?!\S)[^<>]*?)?>[\\s\\S]*?<\\/td>)*<\\/tr>`, 'g'), '<tr>$1</tr>'); // remove empty columns in table rows
            })
            .replace(/<thead( [^<>]*)?><tr>/g, `<thead$1><tr style='${thStyle}'>`)
            .replace(/(<th(?:(?!\S)[^<>]*?)?>[\s\S]*?)<br\/>\s*(<\/th>)/g, '$1$2') // clean up <br/> in th
            .replace(/(<td(?:(?!\S)[^<>]*?)?>[\s\S]*?)<br\/>\s*(<\/td>)/g, '$1$2') // clean up <br/> in td
            .replace(/(<td(?:(?!\S)[^<>]*?)?>)((?:<[bui]>|<span>)\s*?)*((?:<\/[bui]>|<\/span>)\s*?)*(<\/td>)/g, '$1$4'); // clean up empty td
    }

    static getHeaderContent(doc) {
        const headerValues = doc.getWikiHeaders();
        return XHtmlConverter.convertHeaderOrFooterToXHTML(headerValues);
    }

    static getFooterContent(doc) {
        const footerValues = doc.getWikiFooters();
        return XHtmlConverter.convertHeaderOrFooterToXHTML(footerValues);
    }

    static convertHeaderOrFooterToXHTML(values) {
        if (values.length == 0) {
            return '';
        }
        return values
            .map(tag => {
                const url = tag.addr.replace(/\//g, '.');
                const name = `name="space:${url}"`;
                const args = tag.args ? `args="${tag.args}"` : '';
                return `<!--startmacro:transclude|-|${name} ${args}--><!--stopmacro-->`;
            })
            .join('') // for some reason, a line break between macros appears as an empty line between them
            .concat('\n');
    }

    /**
     * Creates an XHTML macro tag.
     *
     * Macros are defined using Quip2Wiki tag as follows:
     * > --wiki-macro: "macro_name=transclude, name='space:Quip2Wiki.SyntaxXHTML', section='HFormattedLines'"--
     *
     * The created tag will work with the following patterns:
     * > <!--startmacro:macro_name--><!--stopmacro-->
     * > <!--startmacro:macro_name|-||-|content--><!--stopmacro-->
     * > <!--startmacro:macro_name|-|parameter_name1=parameter1_value parameter_name2=parameter2_value--><!--stopmacro-->
     * > <!--startmacro:macro_name|-|parameter_name=parameter_value|-|content--><!--stopmacro-->
     * See: https://w.amazon.com/bin/view/AmazonWiki/API/Client#HSyntax
     *
     * @param {string} the matched macro tag
     * @param {string} the content of macro tag (arguments)
     */
    static createMacro(tag, tagContent) {
        const request = {};

        const regex = /\s*([a-zA-Z-_]+)\s*=([^\s'",]+|'.*?')\s*(?:,|$)/g;
        let part;
        while (part = regex.exec(tagContent)) {
            try {
                const key = part[1];
                const value = part[2]
                    .replace(/<[^<>]+?>/g, '')
                    .replace(/\\n/g, '\n')
                    .replace(/\\t/g, '\t')
                    .replace(/\\"/g, '"')
                    .replace(/&lt;/g, '<')
                    .replace(/&gt;/g, '>')
                    .replace(/&amp;/g, '&')
                    .replace(/^\s*'|'\s*$/g, '"');
                request[key] = value;
            } catch (e) {
            }
        }

        const macroName = request.macro_name;
        const macroContent = request.content ? request.content.replace(/^\s*"|"\s*$/g, '') : null;

        const isUnsupportedMacro = ['box'].includes(macroName) || XHtmlConverter.BANNER_TYPES.includes(macroName);

        if (!macroName) {
            log.error(`Invalid macro tag: ${tag}`);
            return tag;
        } else if (isUnsupportedMacro) {
            const macroContentHtml = macroContent.replace(/\n/g, '<br/>');
            let bannerClass = '';
            if (XHtmlConverter.BANNER_TYPES.includes(macroName)) {
                bannerClass = `${macroName}message`;
            }
            return `<p class="box ${bannerClass}">${macroContentHtml}</p>`;
        } else {
            let macro = `<!--startmacro:${macroName}|-|`;
            for (let key in request) {
                if (key == 'macro_name' || key == 'content') {
                    continue;
                }
                macro += `${key}=${request[key]} `;
            }
            macro = macro.trimEnd();
            if (macroContent) {
                macro += `|-|${macroContent}`;
            }
            macro = macro.replace(/(.*)\|-\|$/g, '$1'); // if there is no params or content
            macro += '--><!--stopmacro-->';

            return macro;
        }
    }

    static fixAttachmentLinks(content, wikiAddr, attachments) {
        // fix images and attachments urls
        const wikiUrl = WikiClient.DOWNLOAD_URL + wikiAddr + '/WebHome';
        for (const [title, value] of attachments.entries()) {
            const url = Utils.escapeRegExp(value.url);
            if (value.skip) {
                content = content.replace(new RegExp(`<img src=(["'])${url}\\1`, 'g'), `<img src="${QuipEditor.QUIP_URL}${url}"`);
            } else {
                content = content
                    .replace(new RegExp(`<a href=(["'])${url}\\1`, 'g'), `<a href="${wikiUrl}/${title}"`)
                    .replace(new RegExp(`<img src=(["'])${url}\\1`, 'g'), `<img src="${title}"`);
            }
        }
        return content;
    }

    static transformAsTabXHTML(content, selectedSheets, sheetsOrder) {
        // <!--startmacro:tabs|-|idsToLabels='tabId1=Tab One, tabId2=Tab Two'--><!--stopmacro-->
        // <div id="tabId1" style="display: block;"><p>My tab 1 content goes here.</p></div>
        // <div id="tabId2" style="display: block;"><p>My tab 2 content goes here.</p></div>

        // if selectedSheets is null or empty, we export all sheets
        const canExportSheet = (title) => !selectedSheets || selectedSheets.length == 0 || selectedSheets.includes(title);

        const sheets = new Map();

        const parts = content.split(/(?=<div data-section-style='13'><table)/);
        let before = '';
        for (const part of parts) {
            const match = part.match(/<table(?:[^<>]*)? title='(.+?)'[^<>]*?>/);
            if (match && match[1]) {
                sheets.set(match[1], part);
            } else {
                before += part;
            }
        }

        const exportableSheets = Array.from(sheets.entries())
            .filter(([title, table]) => canExportSheet(title));

        if (exportableSheets.length == 1) {
            const sheetTitle = exportableSheets[0][0];
            if (/(Sheet|Folha|Feuille|Hoja|Foglio|Blatt|床单|床單)\d+|/.test(sheetTitle)) {
                const sheetContent = exportableSheets[0][1];
                return sheetContent;
            }
        }

        // generate contents
        const tabContent = exportableSheets
            .map(([title, table], index) => `<div id="id${index}" style="display: block;">${table}</div>\n`)
            .join('');

        // determine ids and set same order as in Spreadsheet
        const escapedSheetsOrder = sheetsOrder?.map(title => Utils.sanitizeHTMLText(title));
        const getSheetOrder = (title) => {
            const index = escapedSheetsOrder?.indexOf(title);
            return index >= 0 ? index : null;
        };

        const ids = exportableSheets
            .map(([title,], index) => ({ id: `id${index}=${title}`, sortOder: getSheetOrder(title) || index }))
            .sort((a, b) => a.sortOder - b.sortOder)
            .map(item => item.id)
            .join(',');

        return before + `<!--startmacro:tabs|-|idsToLabels='${ids}'--><!--stopmacro-->\n` + tabContent + '\n';
    }

    static async convertQuipMessagesToXHTML(messages, doc, knownUsers) {
        if (!messages || messages.length == 0) {
            return { htmlContent: '', references: [] };
        }

        // test functions for valid messages
        const isChatMesage = msg => !msg.annotation;
        const sectionExists = msg => {
            const sectionId = XHtmlConverter.getAnnotationSectionId(msg);
            return !!doc.html.getElementById(sectionId);
        };

        // filter and sort valid messages
        const sortedMessages = messages
            .filter(msg => msg.visible)
            .filter(msg => isChatMesage(msg) || sectionExists(msg))
            .sort((a, b) => a.created_usec - b.created_usec);

        for (const msg of sortedMessages) {
            // decorate with author login
            msg.author_login = await XHtmlConverter.getUserLogin(msg.author_name, knownUsers);

            // fix user mentions
            msg.text = await Utils.replaceAsyncSequence(msg.text, XHtmlConverter.QUIP_MENTION_IN_COMMENT_REGEX, async (m, name) => {
                let login = await XHtmlConverter.getUserLogin(name, knownUsers);
                if (login) {
                    return `<a href="https://phonetool.amazon.com/users/${login}">${name}</a>`;
                } else {
                    return m;
                }
            });
        }

        // extract comments
        const commentIds = [...new Set(
            sortedMessages
                .map(m => m.annotation)
                .filter(ann => ann)
                .map(ann => ann.id)
        )];

        // convert comments
        let content = '<hr/>\n';
        const references = [];
        commentIds.forEach((annId, index) => {
            const comments = sortedMessages
                .filter(msg => msg.annotation && msg.annotation.id == annId);

            const id = index + 1;
            const commId = `comment-${id}`;
            const isHighlight = XHtmlConverter.isHighlightMessage(comments[0]);
            const commName = 'Comment #' + id + (isHighlight ? ' (Highlight)' : '');
            const commAuthor = comments[0].author_name;
            const sectionId = XHtmlConverter.getAnnotationSectionId(comments[0]);

            const textContent = comments.map(XHtmlConverter.getMessageText).join('&#10;');
            const xhtmlContent = comments.map(XHtmlConverter.getMessageXHTML).join('<br/>');

            content += `<div id="${commId}" class="box"><span style="color: transparent; text-shadow: 0 0 0 #ffdf99;">&#x1F4AC;</span><a href="#${sectionId}">${commName}:</a><br/>${xhtmlContent}\n</div>\n`;

            references.push({
                id: id,
                ref: commId,
                name: commName,
                author: commAuthor,
                sectionId: sectionId,
                isHighlight: isHighlight,
                popup: textContent
            });
        })

        // extract chat messages
        const chatMessages = sortedMessages
            .filter(msg => !msg.annotation)
            .map(XHtmlConverter.getMessageXHTML);

        // convert chat messages
        if (chatMessages.length > 0) {
            const chatContent = chatMessages.join('<br/>');
            content += `<div class="box"><b>Chat messages:</b><br/>${chatContent}\n</div>\n`;
        }

        return {
            htmlContent: content,
            references: references
        };
    }

    static async getUserLogin(fullName) {
        try {
            // get user login from full name
            const cleanFullName = fullName.replace(/[^a-zA-Z\s]/g, '').trim();
            return await Maxis.getLoginFromFullName(cleanFullName);
        } catch (ignore) {
            return null;
        }
    }

    static async checkUserLogin(login) {
        try {
            // get employee information from login
            const employee = await Maxis.getEmployeeFromLogin(login);
            const isValid = !!employee;
            return isValid;
        } catch (ignore) {
            return null;
        }
    }

    static isHighlightMessage(message) {
        return message.annotation && message.annotation.highlight_section_ids && message.annotation.highlight_section_ids.length > 0;
    }

    static getAnnotationSectionId(message) {
        const highlightSectionId = message.annotation.highlight_section_ids;
        if (highlightSectionId && highlightSectionId.length > 0) {
            return highlightSectionId[0].replace(';', '_'); // ids in thead do not contain ';'
        } else {
            return message.annotation.id;
        }
    }

    static getMessageXHTML(message) {
        const dateStr = XHtmlConverter.getDate(message.created_usec);
        const authName = message.author_name;
        const authLogin = message.author_login;
        let author;
        if (authLogin) {
            author = `<a href="https://phonetool.amazon.com/users/${authLogin}" style="text-decoration: none">${authName}</a>`;
        } else {
            author = authName;
        }
        return `<span>[${dateStr}] ${author} - ${message.text}</span>`;
    }

    static getMessageText(message) {
        const dateStr = XHtmlConverter.getDate(message.created_usec);
        const msgText = message.text.replace(/<[^<>]*?>|<\/[^<>]*?>/g, ''); // remove any html tag
        return Utils.sanitizeHTMLText(`[${dateStr}] ${message.author_name} - ${msgText}`);
    }

    static getDate(usec_timestamp) {
        const timestamp = Math.round(usec_timestamp / 1000.0);
        return new Date(timestamp).toISOString().slice(0, 19).replace('T', ' ') + ' UTC';
    }

    static decorateComments(docContent, comments) {
        const showComments = comments && comments.length > 0;
        if (!showComments) {
            // remove annotation highlight
            return docContent
                .replace(/<annotation[^<>]*>/g, '')
                .replace(/<\/annotation>/g, '');
        }
        const cellHighlight = (showComments ? XHtmlConverter.CELL_HIGHLIGHT_STYLE : '');
        for (let comment of comments) {
            const sectionId = Utils.escapeRegExp(comment.sectionId);
            if (sectionId.startsWith('s:')) {
                // table/spreadsheet cells
                const regex = new RegExp(`(<(?:td|th)[^<>]*id='${sectionId}'[^<>]*?)(?: style='(.*?);?')?([^<>]*>)`, 'g');
                const title = `Highlight #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                const link = XHtmlConverter.ON_CLICK_TO_URL.replace('{{url}}', `#${comment.ref}`);
                docContent = docContent.replace(regex, `$1 style='$2;${cellHighlight}; cursor:pointer' title='${title}' ${link}$3`);
            } else {
                // paragraph (no highlight)
                const pRegex = new RegExp(`(<p[^<>]*id='${sectionId}'[^<>]*>)`, 'g');
                const pTitle = `Comment #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                const pLink = XHtmlConverter.ON_CLICK_TO_URL.replace('{{url}}', `#${comment.ref}`);
                const pIcon = `<span title='${pTitle}' ${pLink} style="color: transparent; text-shadow: 0 0 0 #ffdf99; position:absolute; margin-left:-20px; cursor:pointer">&#x1F4AC;</span>`;
                docContent = docContent.replace(pRegex, `$1${pIcon}`);

                // span (no highlight)
                const sRegex = new RegExp(`(<span[^<>]*id='${sectionId}'[^<>]*>)`, 'g');
                const sTitle = `Comment #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                const sLink = XHtmlConverter.ON_CLICK_TO_URL.replace('{{url}}', `#${comment.ref}`);
                const sIcon = `<span title='${sTitle}' ${sLink} style="color: transparent; text-shadow: 0 0 0 #ffdf99; position:absolute; margin-left:-20px; cursor:pointer">&#x1F4AC;</span>`;
                docContent = docContent.replace(sRegex, `$1${sIcon}`);

                // text highlight
                const tRegex = new RegExp(`<annotation[^<>]* id=(["'])${sectionId}\\1[^<>]*>`, 'g');
                const tTitle = `Highlight #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                const tLink = XHtmlConverter.ON_CLICK_TO_URL.replace('{{url}}', `#${comment.ref}`);
                docContent = docContent.replace(tRegex, `<annotation id='${sectionId}' style='background-color:#ffdf99; cursor:pointer;' title='${tTitle}' ${tLink}>`);

                // image (no highlight)
                const iRegex = new RegExp(`(<img[^<>]*id='${sectionId}'[^<>]*?)(?: title='([\\s\\S]*?)')?([^<>]*>)`, 'g');
                docContent = docContent.replace(iRegex, (m, left, title, right) => {
                    const newTitle = `Highlight #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                    return left + " title='" + (title ? `${title}&#10;` : '') + newTitle + "'" + right;
                });
            }
        }

        return docContent
            .replace(/<annotation([^<>]*)>/g, '<span$1>')
            .replace(/<\/annotation>/g, '</span>');
    }

    static convertQuipFolderListingToXHTML(folder) {

        const quipUrl = QuipEditor.QUIP_URL;

        const fId = folder.id;
        const url = `${quipUrl}/${fId}`;
        const title = folder.title;
        const listing = XHtmlConverter.convertQuipFolderListingToList(folder.children);
        const content = `<h3><span>All subfolders and documents in <a href="${url}"><i>${title}</i></a></span></h3>\n${listing}`;

        const msg = XHtmlConverter.getBannerXHTML('Folder', fId, Settings.bannerPosition);

        const header = Settings.bannerPosition === BannerPosition.TOP ? msg : '';
        const footer = Settings.bannerPosition !== BannerPosition.TOP ? msg : ''; // if BOTTOM or HIDDEN

        return ['<html>\n<body>', header, content, footer, '</body>\n</html>'].join('');
    }

    static convertQuipFolderListingToList(itemList) {
        if (!itemList || itemList.length == 0) {
            return '';
        }

        const quipUrl = QuipEditor.QUIP_URL;
        const circle = XHtmlConverter.CIRCLE;
        const resUrl = XHtmlConverter.RESOURCE_URL;

        let output = '<ul style="list-style-type:none;">\n';
        for (let item of itemList) {
            if (item.document) {
                //const type = item.document.type;
                const quipDocUrl = `${quipUrl}/${item.document.linkId || item.document.document_id || item.document.id}`;
                const wikiPageAddr = item.document.wikiAddr;
                const title = Utils.sanitizeHTMLText(item.document.title);
                const url = wikiPageAddr ? `/bin/view/${wikiPageAddr}` : quipDocUrl;
                const link = wikiPageAddr ? ` [<a href="${quipDocUrl}">Quip</a>]` : '';
                output += `<li><img src="${resUrl}/page_white_text.png" /> <a href="${url}">${title}</a>${link}</li>\n`;
            } else if (item.folder) {
                const title = Utils.sanitizeHTMLText(item.folder.title);
                const quipDocUrl = `${quipUrl}/${item.folder.id}`;
                const fcolor = circle.replace('{{color}}', XHtmlConverter.convertQuipColor(item.folder.color));
                const children = item.folder.children;
                output += `<li><img src="${resUrl}/folder.png" /> <a href="${quipDocUrl}">${title}</a> ${fcolor}`;
                if (children) {
                    output += XHtmlConverter.convertQuipFolderListingToList(children);
                }
                output += '</li>\n';
            }
        }
        output += '</ul>\n';
        return output;
    }

    static convertQuipColor(color) {
        switch (color) {
            case 'dark_yellow':
                return 'DarkGoldenrod';
            case 'manila':
                return 'Gold';
            case 'purple':
                return 'Purple';
            case 'light_purple':
                return 'Plum';
            case 'blue':
                return 'DodgerBlue';
            case 'light_blue':
                return 'LightBlue';
            case 'orange':
                return 'DarkOrange';
            case 'light_orange':
                return 'Orange';
            case 'red':
                return 'IndianRed';
            case 'light_red':
                return 'LightCoral';
            case 'green':
                return 'LimeGreen';
            case 'light_green':
                return 'LightGreen';
            default:
                return color;
        }
    }
}

XHtmlConverter.RESOURCE_URL = 'https://w.amazon.com/bin/download/Quip2Wiki/resources/WebHome';
XHtmlConverter.CIRCLE = '<span style="color:{{color}}">&#9724;</span>';
XHtmlConverter.NUMBERED_LIST_STYLES = ["1", "a", "i", "A", "I"];
XHtmlConverter.GUID_REGEX = /^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}$/;
XHtmlConverter.QUIP_MENTION_FULLNAME_REGEX = /<control data-remapped="true"[^<>]*?>(<a href="(https?:\/\/quip-amazon\.com\/.{11})">)\1([^<>]+?)<\/a><\/a><\/control>/g;
XHtmlConverter.QUIP_MENTION_LOGIN_REGEX = /(?<!https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,4}\b(?:[-a-zA-Z0-9@:%_\+.~#?&//=]*))(?:(?<!\w)(?!@\w+(?:\.\w+))@([\w]+)|(?!\.\w+@)(\w+)@(?=[^\w]))/g; // not within an URL or email
XHtmlConverter.QUIP_MENTION_LOGIN_REGEX2 = /(?:<a [^<>]*>.*?(?:(?<!\w)@\w+|(?!\.\w+@)\w+@(?=[^\w]))(?![^<]*?>).*?(?!<a )<\/a>)|(?:(?<!\w)@(\w+)|(?!\.\w+@)(\w+)@(?=[^\w]))(?![^<]*?>)/g; // not within an URL or email
XHtmlConverter.QUIP_MENTION_IN_COMMENT_REGEX = /<a href="https?:\/\/quip(?:-amazon)?\.com\/.{11}"[^<>]*>([^<>]+?)<\/a>/g;
XHtmlConverter.TOC_BOXED = '\
<div class="{{boxClass}}" style="max-width: 550px">\nTable of Contents\n\
    <!--startmacro:toc|-|numbered={{isNumbered}} start={{start}} depth={{depth}}--><!--stopmacro-->\n\
</div>\n';
XHtmlConverter.TOC_CLASSIC = '<!--startmacro:toc|-|numbered={{isNumbered}} start={{start}} depth={{depth}}--><!--stopmacro-->\n';
XHtmlConverter.TOC_NUMBERED_CLASS = 'amazon-wiki-toc-numbered';
XHtmlConverter.BOX_CLASS = 'box';
XHtmlConverter.FLOATING_BOX_CLASS = 'box floatinginfobox';
XHtmlConverter.CLASS_SORTABLE = 'sortable filterable';
XHtmlConverter.CLASS_SORT_ONLY = 'sortable';
XHtmlConverter.CLASS_FILTER_ONLY = 'filterable';
XHtmlConverter.SORTABLE_TABLE_TAGS_REGEX = /(<table[^<>]*?title='(.*?)'[^<>]*?>[\s\S]*?)&lt;&lt;(sortable|sort-only|filter-only)&gt;&gt;([\s\S]*?<\/table>)/g;
XHtmlConverter.VIDEO_POSTER = 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHdpZHRoPSIxMDAzcHgiIGhlaWdodD0iNTIzcHgiIHZpZXdCb3g9Ii0wLjUgLTAuNSAxMDAzIDUyMyIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTsiPjxkZWZzLz48Zz48cmVjdCB4PSIxLjI1IiB5PSIwLjc1IiB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI1MjAiIGZpbGw9IiNlNmU2ZTYiIHN0cm9rZT0ibm9uZSIgcG9pbnRlci1ldmVudHM9ImFsbCIvPjxlbGxpcHNlIGN4PSI1MDEuMjUiIGN5PSIyNjAuNzUiIHJ4PSIxMjEuMjUiIHJ5PSIxMjEuMjUiIGZpbGw9IiNmZmZmZmYiIHN0cm9rZT0iIzk5OTk5OSIgc3Ryb2tlLXdpZHRoPSI4IiBwb2ludGVyLWV2ZW50cz0iYWxsIi8+PHBhdGggZD0iTSA0NDkuNjEgMTkxLjE0IEwgNTc0LjkgMjYwLjc1IEwgNDQ5LjYxIDMzMC4zNiBaIiBmaWxsPSIjOTk5OTk5IiBzdHJva2U9Im5vbmUiIHBvaW50ZXItZXZlbnRzPSJhbGwiLz48L2c+PC9zdmc+';
XHtmlConverter.CELL_HIGHLIGHT_STYLE = 'background-image: linear-gradient(225deg, #ffdf99, #ffdf99 10px, transparent 10px, transparent);';
XHtmlConverter.ON_CLICK_TO_URL = "onclick=\"location.href='{{url}}';\"";
XHtmlConverter.BANNER_TYPES = ['success', 'info', 'warning', 'error'];
XHtmlConverter.EDIT_IN_QUIP_COMMENT = '\
    DO NOT change the content of this Wiki\n\n\
    The content of this Wiki page was generated by Quip2Wiki tool from a Quip {{docType}}, so any change using Wiki editor can be lost when new updates from Quip2Wiki are submitted.\n\
    Please consider changing the original Quip {{docType}} at {{quipUrl}}';

class XWikiConverter {
    static async convertQuipHTMLToXWiki (document, attachments, messages) {
        const props = {
            wikiAddr: document.getWikiSyncAddress(),
            docId: document.linkId,
            type: document.type,
            toc: XWikiConverter.getToc(document),
            bannerPosition: XWikiConverter.getBannerPosition(document),
            wikiTags: document.getWikiTags(),
            headers: document.getWikiHeaders(),
            footers: document.getWikiFooters(),
            showComments: document.getWikiComments(),
            isSortableTables: document.findTag(QuipDocument.SORTABLE_TABLES_TAG) || Utils.test(XHtmlConverter.SORTABLE_TABLE_TAGS_REGEX, document.htmlContent),
            sheets: XWikiConverter.getSheetsInOrder(document),
            titleOverride: XWikiConverter.getTitleOverride(document),
        };

        const cleanHtmlContent = this.handleTilde(document.htmlContent)
            // remove block of text between '--wiki-ignore--' tags
            .replace(new RegExp(String.raw`<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--${QuipDocument.IGNORE_TAG}--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>[\s\S]+?<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--${QuipDocument.IGNORE_TAG}--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>`), '')
            // remove anything after '--wiki-ignore--' tag
            .replace(new RegExp(String.raw`<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--${QuipDocument.IGNORE_TAG}--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>[\s\S]*`), '')
            // remove horizontal ruler at end of doc
            .replace(/<hr\/>(\s*<p>\s*<\/p>)*\s*$/g, '');

        const html = new DOMParser().parseFromString(cleanHtmlContent.replace(/\n/g, ''), 'text/html');
    
        // replace page title with override - first header is always the name of the document/sheet
        const showTitleInBody = props.titleOverride && props.titleOverride.isVisible;
        let firstHeader = html.body.querySelector('h1,h2,h3,h4,h5,h6');
        if (showTitleInBody && firstHeader) {
            const title = props.titleOverride.title || document.title;
            firstHeader.textContent = title;
        } else {
            firstHeader?.remove();
            firstHeader = null;
        }

        // make tabs for each sheet in a spreadsheet
        let tabsMacroStart = '';
        let tabsMacroEnd = '';
        if (props.type === 'spreadsheet') {
            // add tab separation markers
            XWikiConverter.insertTabElements(html, firstHeader);
            // create tab macro
            tabsMacroStart = XWikiConverter.getTabsMacro(props.sheets);
            tabsMacroEnd = '\n)))\n';
        }

        let content = [...html.body.children]
            .map(element => XWikiConverter.convertTags(element))
            .map(element => XWikiConverter.convert(element))
            .join('\n');

        content = await XWikiConverter.fixMentions(content);
        content = await XWikiConverter.fixAttachmentLinks(content, props.wikiAddr, attachments);
        
        const bannerContent = XWikiConverter.getBanner(props, props.bannerPosition);
        const headerBanner = props.bannerPosition === BannerPosition.TOP ? bannerContent : '';
        const footerBanner = props.bannerPosition !== BannerPosition.TOP ? bannerContent : '';

        const tocTag = XWikiConverter.getTocContent(props)
        const isTocFloating = props.toc && props.toc.isFloating && !props.toc.isClassic;
        const tocTagBefore = isTocFloating ? tocTag : '';
        const tocTagAfter = !isTocFloating ? tocTag : '';

        const headerTag = XWikiConverter.getHeaderOrFooterContent(props.headers);
        const footerTag = XWikiConverter.getHeaderOrFooterContent(props.footers);

        const sortableTablesTag = props.isSortableTables ? '{{enableSortableTables/}}\n' : '';

        const quipUrl = `${QuipEditor.QUIP_URL}/${document.linkId}`;
        const warning = XHtmlConverter.EDIT_IN_QUIP_COMMENT
            .replace(/\{\{docType\}\}/g, document.type)
            .replace(/\{\{quipUrl\}\}/g, quipUrl);

        return [`{{comment}}\n\n\n${warning}\n\n\n{{/comment}}\n\n`,
                headerTag,
                tocTagBefore,
                headerBanner,
                tocTagAfter,
                sortableTablesTag,
                tabsMacroStart,
                content,
                //messagesContent.htmlContent,
                //trackTag,
                tabsMacroEnd,
                footerBanner,
                footerTag
               ].join('');
    }

    static handleTilde(source) {
        if (source.includes("~")) {
            return source.replaceAll("~", "~~");
        }

        return source;
    }

    static getSheetsInOrder(document) {
        const getSheetOrder = (title) => {
            const index = document.sheetsDesiredOrder?.indexOf(title);
            return index >= 0 ? index : null;
        };

        return document.getSheetNames()
            .map((t, index) => ({ title: Utils.sanitizeHTMLText(t), sortOrder: getSheetOrder(t) || index }))
            .sort((a, b) => a.sortOder - b.sortOder);
    }

    static async convertQuipHTMLToMarkdown (document, attachments, messages) {
        return '### not implemented!';
    }

    static async convertQuipFolderListingToXWiki (folder) {
        return '=== not implemented! ===';
    }

    static async convertQuipFolderListingToMarkdown (folder) {
        return '### not implemented!';
    }

    static convert (element, level = 0, listType = null) {
        if (!element) {
            return '';
        }

        const tagName = (element.tagName || '').toUpperCase();
        const innerContent = () => XWikiConverter.getInnerContent(element, level, listType);
        const styling = (toplevel) => XWikiConverter.getElementStyling(element, toplevel);
        const newLine = () => level == 0 ? '\n' : '';

        let output = '';

        if (/H\d+/.test(tagName)) { // headings
            const level = parseInt(tagName.replace('H', ''));
            const marker = '='.repeat(level);
            output = styling() + `${marker} ${innerContent()} ${marker}` + newLine();
        } else if (tagName === 'P') { // paragraph
            output = styling() + innerContent();
        } else if (tagName === 'BR') {
            if (listType) {
                output = innerContent() + '\n';
            } else {
                output = innerContent() + '\\\\';
            }
        } else if (tagName === 'HR') { // line
            output = '----';
        } else if (tagName === 'B') { // bold
            output = `**${innerContent()}**`;
        } else if (tagName === 'U') { // underline
            output = `__${innerContent()}__`;
        } else if (tagName === 'I') { // italic
            output = `//${innerContent()}//`;
        } else if (tagName === 'DEL') { // strikethrough
            output = `--${innerContent()}--`;
        } else if (tagName === 'CODE') { // code/monospace
            output = `##${innerContent()}##`;
        } else if (tagName === 'SUP') { // superscript
            output = `^^${innerContent()}^^`;
        } else if (tagName === 'SUB') { // subscript
            output = `,,${innerContent()},,`;
        } else if (tagName === 'A') {
            output = XWikiConverter.getLinkInnerContent(element, level, listType);
        } else if (tagName === 'IMG') {
            const url = element.getAttribute('src')
                .replace(/data:image\/gif;base64.*/, XHtmlConverter.VIDEO_POSTER);
            //const alt = element.getAttribute('alt');
            const hasBorder = element.parentNode.classList.contains('show-border');
            if (hasBorder) {
                output = `[[image:${url}||style="border: 1px solid #555"]]`;
            } else {
                output = `[[image:${url}]]`;
            }
        } else if (tagName === 'BLOCKQUOTE' || tagName === 'Q') { // block quote or pull quote
            output = styling() + `> ${innerContent()}`;
        } else if (tagName === 'DIV') {
            const dataSectionStyle = element.getAttribute('data-section-style') || '';
            if (dataSectionStyle === '5') { // formatted list
                output = XWikiConverter.getInnerContent(element, 0, 'bullet');
            } else if (dataSectionStyle === '6') { // numbered list
                output = XWikiConverter.getInnerContent(element, 0, 'numbered');
            } else if (dataSectionStyle === '7') { // checklist
                output = XWikiConverter.getInnerContent(element, 0, 'checklist');
            } else if (dataSectionStyle === '11') { // image or video
                output = innerContent() + '\n';
            } else {
                const isMultiColumnContainer = (el) => el.classList.contains('flexbox-layout-container') &&
                    el.querySelectorAll('div.flexbox-layout-column').length > 1;

                const isColumnContainer = (el) => el.classList.contains('flexbox-layout-column') &&
                    isMultiColumnContainer(el.parentNode);

                if (isMultiColumnContainer(element)) {
                    output = `\n{{container layoutStyle="columns"}}\n${innerContent()}\n{{/container}}\n`;
                } else if (isColumnContainer(element)) {
                    output = `\n(((${innerContent()}\n)))\n`;
                } else {
                    output = innerContent();
                }
            }
        } else if (tagName === 'SPAN' || tagName === 'PRE') {
            const isCodeBlock = element.classList.contains('prettyprint') || tagName === 'PRE';
            if (isCodeBlock) {
                output = `\n{{box}}\n${styling()}${innerContent()}\n(%%)\n{{/box}}`;
            } else {
                const styleStart = styling(false);
                const styleEnd = !!styleStart ? '(%%)' : '';
                output = styleStart + innerContent() + styleEnd;
            }
        } else if (tagName === 'ANNOTATION') { // highlight
            output = innerContent();
        } else if (tagName === 'UL' || tagName === 'OL') { // list/sublist (Quip API never returns OL for numbered lists)
            const listContent = XWikiConverter.getInnerContent(element, level+1, listType);
            const hasItems = [...element.querySelectorAll(':scope > li')].length > 0;
            if (listType === 'checklist' && hasItems) {
                output = `(% type="none" %)\n${listContent}`;
            } else if (listType === 'numbered' && hasItems) {
                const parentNode = element.parentNode;
                const hasStartNumber = parentNode.classList.contains('list-numbering-restart-at');
                const isContinuation = parentNode.classList.contains('list-numbering-continue');
                if (level > 0) {
                    const types = XHtmlConverter.NUMBERED_LIST_STYLES;
                    const len = XHtmlConverter.NUMBERED_LIST_STYLES.length;
                    output = `(% type="${types[level%len]}" %)\n${listContent}`;
                } else if (hasStartNumber) {
                    const startValue = parentNode.style.getPropertyValue('--indent0').trim();
                    output = `(% start="${startValue}" %)\n${listContent}`;
                } else if (isContinuation) {
                    const startValue = XWikiConverter.findListContinuationStartValue(parentNode);
                    output = `(% start="${startValue}" %)\n${listContent}`;
                } else {
                    output = listContent
                }
            } else {
                output = listContent;
            }
        } else if (tagName === 'LI') { // list item
            if (XWikiConverter.isInnerCodeBlock(element)) {
                output = innerContent();
            } else if (listType === 'bullet') {
                const prefix = '*'.repeat(level) + ' ';
                output = prefix + innerContent();
            } else if (listType === 'numbered') {
                const prefix = '1'.repeat(level) + '. ';
                output = prefix + innerContent();
            } else if (listType === 'checklist') {
                const isChecked = element.classList.contains('checked');
                const checkbox = '{{html}}' + (isChecked ? '&#9745;' : '&#9744;' ) + '{{/html}} ';
                const prefix = '*'.repeat(level) + ' ' + checkbox;
                output = prefix + innerContent();
            } else {
                console.warn('List type not provided or invalid');
                output = innerContent();
            }
        } else if (tagName === 'TABLE') { // spreadsheet or table
            output = styling(true) + XWikiConverter.getTableContent(element);
        } else if (tagName === 'TH' || tagName === 'TD') {
            if (XWikiConverter.isStandaloneTag(element)) {
                return XWikiConverter.convertStandaloneTag(element);
            }
            const isBold = element.classList.contains('bold');
            const isItalic = element.classList.contains('italic');
            const isUnderline = element.classList.contains('underline');
            const isStrikethrough = element.classList.contains('strikethrough');

            let cellContent = styling(false) + innerContent();
            if (isStrikethrough) {
                cellContent = `--${cellContent}--`;
            }
            if (isItalic) {
                cellContent = `//${cellContent}//`;
            }
            if (isUnderline) {
                cellContent = `__${cellContent}__`;
            }
            if (isBold) {
                cellContent = `**${cellContent}**`;
            }
            return cellContent;
        } else if (tagName === 'VIDEO') {
            const isInlineEq = element.parentNode && element.parentNode.innerHTML !== element.outerHTML;
            const newLine = isInlineEq ? '' : '\n';
            // video exported as HTML within html macro
            output = newLine + newLine + `{{html}}${element.outerHTML}{{/html}}` + newLine;
        } else if (tagName === 'MATH') {
            const isInlineEq = element.parentNode && element.parentNode.innerHTML !== element.outerHTML;
            const newLine = isInlineEq ? '' : '\n';
            // set math formulas with 'formula' macro
            output = newLine + newLine + `{{formula}}${innerContent()}{{/formula}}` + newLine;
        } else if (tagName === 'DESIGN-INSPECTOR') {
            const diUrl = element.getAttribute('src');
            const width = 1100; // increase width as element.getAttribute('width') is always 800
            const height = Math.trunc(parseInt(element.getAttribute('height'))*1.375); // adjust height based on increase of width
            const isInlineEq = element.parentNode && element.parentNode.innerHTML !== element.outerHTML;
            const newLine = isInlineEq ? '' : '\n';
            // set design-inspector diagrams with 'iframe' macro
            output = newLine + newLine + `{{iframe url="${diUrl}" width="${width}px" height="${height}px" /}}` + newLine;
        } else if (tagName === 'TAB') {
            const id = element.getAttribute('id');
            const isFirst = parseInt(id.replace('id','')) == 0;
            const previousTabClosure = isFirst ? '' : '\n)))\n';
            const nextTabOpen = '\n(((\n';
            output = previousTabClosure + `(% id="${id}" %)` + nextTabOpen;
        } else if (tagName === 'CONTROL') { // icons, mentions, date mentions
            output = innerContent();
        } else {
            if (tagName) {
                console.error(`untreated tag: ${tagName}`);
            }
            output = innerContent();
        }

        return output;
    }

    static getInnerContent (element, level, listInfo) {

        const isQuip2WikiTag = element.getAttribute?.('isQuip2WikiTag') || false;
        if (isQuip2WikiTag) {
            return element.textContent;
        } else if (!element.hasChildNodes()) {
            // escape XWiki syntax elements
            return element.textContent
                .replace(/^(\s*?)(=+)(.+?)(\1)(\s*?)$/gm, (m, s1, h1, c, h2, s2) => s1 + h1.replace(/(?<!~)=/g, '~=') + c + h2.replace(/(?<!~)=/g, '~=') + s2)
                .replace(/^(\*+(\d+\.)?)( .*?)$/gm, (m, l1, c) => l1.replace(/(?<!~)(\*|\d)/g, '~$1') + c)
                .replace(/^(\d+\**\d*\.)( .*?)$/gm, (m, l1, c) => l1.replace(/(?<!~)(\*|\d)/g, '~$1') + c)
                .replace(/\*\*/g, '~*~*') // bold
                .replace(/\/\//g, '~/~/') // italic
                .replace(/--/g, '~-~-') // striked
                .replace(/__/g, '~_~_') // underline
                .replace(/##/g, '~#~#') // monospace
                .replace(/\^\^/g, '~^~^') // superscript
                .replace(/,,/g, '~,~,') // subscript
                .replace(/\\\\/g, '~\\~\\') // line break
                .replace(/\{\{(.+?\/?)\}\}/g, '~{~{$1~}~}') // macros
                .replace(/\(\%(.*?)%\)/g, '~(%$1%~)') // styling
                .replace(/\[\[(.+?(>>.+?)?(\|\|.+?)*?)\[\]/g, '~[~[$1~]~]'); // links
                // TODO: images, lists, quotation, tables, verbatim, QA, grouping
        } else {
            return [...element.childNodes]
                .map(child => XWikiConverter.convert(child, level, listInfo))
                .join('') || '';
        }
    }

    static getLinkInnerContent (element, level, listType) {
        const isUserOrFolder = (src) => /https?:\/\/quip-amazon\.com\/.{11}\/?$/.test(src);
        const isQuipDocument = (src) => /https?:\/\/.*quip-amazon.com\/.{12}\/?/.test(src);
        const isAttachment = (src) => /https?:\/\/quip-amazon\.com\/-\/blob\/.{11}\/.{22}\?(s=.{12}&)?name=(.+)/.test(src);
        const isVideo = (src) => /https?:\/\/quip-amazon\.com\/blob\/.{11}\/.{22}/.test(src);
        const innerContent = () => this.handleTilde(XWikiConverter.getInnerContent(element, level, listType));

        const url = element.getAttribute('href');
        console.log(`<a> url: ${url}`);

        const isNoLink = element.hasAttribute('data-nolink'); // remove weird 'no-link' in <a> tags (not visible in Quip), but keep content
        if (isNoLink) {
            return innerContent();
        } else if (isUserOrFolder(url)) {
            const prev = element.previousSibling;
            const isAfterMention = prev && prev.tagName.toUpperCase() === 'A' && isUserOrFolder(prev.getAttribute('href'));
            const next = element.nextSibling;
            const isBeforeMention = next && next.tagName.toUpperCase() === 'A' && isUserOrFolder(next.getAttribute('href'));

            if (isAfterMention) {
                // user mention
                return `👤[[${innerContent()}>>${url}]]`;
            } else if (!isBeforeMention) {
                // quip folder
                return `📂[[${innerContent()}>>${url}]]`;
            } else {
                return innerContent();
            }
        } else if (isAttachment(url)) {
            return `📎[[${innerContent()}>>${url}]]`;
        } else if (isQuipDocument(url)) {
            return `📄[[${innerContent()}>>${url}]]`;
        } else {
            return `[[${innerContent()}>>${url}]]`;
        }
    }

    static getElementStyling (element, toplevel = true) {

        const classes = new Set();
        const styles = new Map();

        const tagName = (element.tagName || '').toUpperCase();
        if (tagName == 'SPAN') {

            // if there is a parent node with same content that is a span, 
            // assume it will contain all styling of this element
            let node = element;
            while (node && node.parentNode.textContent == element.textContent) {
                const parentTagName = (element.parentNode.tagName || '').toUpperCase();
                if (parentTagName == 'SPAN') {
                    return '';
                }
                node = node.parentNode;
            }

            // extract element styling
            XWikiConverter.extractElementStyling(element, classes, styles);

            // also add styling of any child span element which contains exact same content (merge)
            [...element.querySelectorAll('span')]
                .filter(el => el.textContent == element.textContent)
                .forEach(el => XWikiConverter.extractElementStyling(el, classes, styles));
        } else {
            // extract element styling
            XWikiConverter.extractElementStyling(element, classes, styles);
        }

        // generate class/style override markup

        const classValues = [...classes].join(' ');
        const clazz = !!classValues ? `class="${classValues}"` : '';

        const styleValues = [...styles.entries()].map(([key, value]) => `${key}:${value}`).join(';');
        const style = !!styleValues ? `style="${styleValues}"` : '';

        if (clazz || style) {
            const output = ['(%', clazz, style, '%)'].filter(item => !!item).join(' ');
            return output + (toplevel ? '\n' : '');
        } else {
            return '';
        }
    }

    static extractElementStyling (element, classes, styles) {
        const tagName = (element.tagName || '').toUpperCase();
        const isQuote = tagName === 'BLOCKQUOTE' || tagName === 'Q';

        const bgcolor = element.getAttribute('bgcolor');
        const textcolor = element.getAttribute('textcolor');

        // convert known quip classes to appropriate wiki classes/styles
        const isCodeBlock = element.classList.contains('prettyprint');
        const isCenterAligned = element.classList.contains('align-center');
        const isRightAligned = element.classList.contains('align-right');

        // get current styles
        [...element.style].forEach(s => styles.set(s, element.style[s]));

        if (isCodeBlock) {
            classes.add('monospace');
        }
        if (bgcolor) {
            styles.set('background-color', Utils.colorRgbToHex(bgcolor));
        }
        if (textcolor) {
            styles.set('color', Utils.colorRgbToHex(textcolor));
        }
        if (isQuote) {
            styles.set('fontSize', 'inherit');
        }
        if (isCenterAligned) {
            styles.set('text-align', 'center');
        }
        if (isRightAligned) {
            styles.set('text-align', 'right');
        } 
    }

    static isInnerCodeBlock (element) {
        return element.hasChildNodes() && element.childNodes[0].classList.contains('prettyprint');
    }

    static convertTags (element) {
        const foundElements = XWikiConverter.findElementsWithTag(element);
        if (foundElements.length > 0) {
            console.log('found elements: ' + foundElements.map(el => `${el.tagName}="${el.textContent}"`).join(','));
            foundElements.forEach(el => {
                el.textContent = XWikiConverter.convertStandaloneTag(element)
                el.setAttribute('isQuip2WikiTag', true);
            });
        }
        return element;
    }

    static findElementsWithTag (element) {
        const tagName = element.tagName;
        const ignoreElement = ['TABLE', 'THEAD', 'TBODY', 'TR', 'A', 'ANNOTATION', 'MATH'].includes(tagName);
        const hasStandaloneTag = XWikiConverter.isStandaloneTag(element);
        const hasInlineTag = XWikiConverter.hasInlineTag(element);
        if (ignoreElement) {
            return [];
        } else if (hasStandaloneTag) {
            return [element];
        } else if (hasInlineTag) {
            const onlyParentHasTag = XWikiConverter.isStandaloneTag(element.cloneNode(false));
            if (onlyParentHasTag) {
                return [element];
            } else {
                const foundChildElements = [...element.childNodes].flatMap(el => XWikiConverter.findElementsWithTag(el));
                return foundChildElements;
            }
        } else {
            return [];
        }
    }

    static hasInlineTag (element) {
        const tagPattern = /--wiki-[\w-]+?(\s*:.*?)?--/g
        return tagPattern.test(element.textContent.trim());
    }

    static isStandaloneTag (element) {
        const tagPattern = /^--wiki-[\w-]+?(\s*:.*?)?--$/g
        return tagPattern.test(element.textContent.trim());
    }

    static convertStandaloneTag (element) {
        const tagPattern = /--(wiki-[\w-]+?)(?:\s*:\s*["“”](.*?)["“”]\s*)?--/g
        const textContent = element.textContent.trim();
        const match = tagPattern.exec(textContent);
        if (!match) {
            console.error(`[xwiki-convert] Expected single line tag, but couldn't parse it`);
            return textContent;
        }

        const tag = match[0];
        const tagName = match[1];
        const tagArgs = match[2];

        if (tagName === 'wiki-ignore') {
            return textContent;
        }
        
        if (tagName !== 'wiki-macro') {
            return ''; // clean line
        }

        return this.convertMacro(tag, tagArgs);
    }

    static convertInlineTag (element) {
        return "<placeholder for inline macro>";
    }

    /**
     * Creates an XWiki macro tag.
     *
     * Macros are defined using Quip2Wiki tag as follows:
     * > --wiki-macro: "macro_name=transclude, name='space:Quip2Wiki.SyntaxXHTML', section='HFormattedLines'"--
     *
     * The created tag will work with the following patterns:
     * > {{macro_name/}}
     * > {{macro_name}}content{{/macro_name}}
     * > {{macro_name parameter_name1=parameter1_value parameter_name2=parameter2_value/}}
     * > {{macro_name parameter_name=parameter_value}}content{{/macro_name}}
     * See: https://w.amazon.com/bin/view/AmazonWiki/API/Client#HSyntax
     *
     * @param {string} the matched macro tag
     * @param {string} the content of macro tag (arguments)
     */
     static convertMacro (tag, tagContent) {
        const request = {};

        const regex = /\s*([a-zA-Z-_]+)\s*=([^\s'",]+|'.*?')\s*(?:,|$)/g;
        let part;
        while (part = regex.exec(tagContent)) {
            try {
                const key = part[1];
                const value = part[2]
                    .replace(/\\n/g, '\n')
                    .replace(/\\t/g, '\t')
                    .replace(/\\"/g, '"')
                    .replace(/&lt;/g, '<')
                    .replace(/&gt;/g, '>')
                    .replace(/&amp;/g, '&')
                    .replace(/^\s*'|'\s*$/g, '"');
                request[key] = value;
            } catch (e) {
            }
        }

        const macroName = request.macro_name;
        const macroContent = request.content ? request.content.replace(/^\s*"|"\s*$/g, '') : null;

        if (!macroName) {
            log.error(`Invalid macro tag: ${tag}`);
            return tag;
        } else {
            let macroArgs = '';
            for (let key in request) {
                if (key == 'macro_name' || key == 'content') {
                    continue;
                }
                macroArgs += ` ${key}=${request[key]}`;
            }

            const extraLine = ['box','toc','success','info','warning','error','code','html'].includes(macroName);
            const linesBefore = extraLine ? '\n\n' : '\n';
            const linesAfter = extraLine ? '\n' : '';
            if (macroContent) {
                return `${linesBefore}{{${macroName}${macroArgs}}}\n${macroContent}\n{{/${macroName}}}${linesAfter}`;
            } else if (macroArgs) {
                return `${linesBefore}{{${macroName}${macroArgs}/}}${linesAfter}`;
            }
        }
    }

    static fixAttachmentLinks (content, wikiAddr, attachments) {
        // fix images and attachments urls
        const wikiUrl = WikiClient.DOWNLOAD_URL + wikiAddr + '/WebHome';
        for (const[title, value] of attachments.entries()) {
            const url = Utils.escapeRegExp(value.url.replace('&amp;', '&'));
            if (value.skip) {
                content = content.replace(new RegExp(`\\[\\[image:${url}(\\|\\|.*?)?\\]\\]`, 'g'), `[[image:${QuipEditor.QUIP_URL}${url}$1]]`);
            } else {
                content = content
                    .replace(new RegExp(`\\[\\[(.*?)>>${url}\\]\\]`, 'g'), `[[$1>>${wikiUrl}/${title}]]`)
                    .replace(new RegExp(`\\[\\[image:${url}(\\|\\|.*?)?\\]\\]`, 'g'), `[[image:${title}$1]]`);
            }
        }
        return content;
        
    }

    static async fixMentions (content) {
        // amazon login mentions (ex: @siljonas or siljonas@)
        return await Utils.replaceAsyncSequence(content, XHtmlConverter.QUIP_MENTION_LOGIN_REGEX2, async (m, login1, login2) => {
            const login = login1 || login2;
            const isValid = await XHtmlConverter.checkUserLogin(login);
            if (isValid) {
                return `[[${m}>>https://phonetool.amazon.com/users/${login}]]`;
            } else {
                return m;
            }
        });
    }

    static findListContinuationStartValue (list) {
        // select all sibling numbered lists
        const allNumberedLists = [...list.parentNode.querySelectorAll('div[data-section-style="6"]')];

        // initialize item start and count
        let start = 1;
        let count = 0;
        
        // iterate over all numbered lists until current continuation list
        for (const curList of allNumberedLists) {
            if (curList === list) {
                break;
            }

            // count number of items in current list
            const itemCount = [...curList.querySelectorAll(':scope > ul > li, :scope > ol > li')].length;

            const isContinuation = curList.classList.contains('list-numbering-continue');
            if (!isContinuation) { // reset as this could be the last list before current list
                const hasStartNumber = curList.classList.contains('list-numbering-restart-at');
                if (hasStartNumber) {
                    const startValue = curList.style.getPropertyValue('--indent0').trim();
                    start = Number.parseInt(startValue);
                } else {
                    start = 1;
                }
                count = itemCount; // start the count again
            } else {
                count = count + itemCount; // aggregate as this could be a preceding continuation list
            }
        }

        return start + count;
    }

    static getBannerPosition (document) {
        let bannerPosition = Settings.bannerPosition || BannerPosition.TOP;
        const bannerTagExists = document.findTag(QuipDocument.BANNER_TAG);
        if (bannerTagExists) {
            const bannerTagArgs = document.readTagValue(QuipDocument.BANNER_TAG, '');
            const bannerTagDisplayValue = XHtmlConverter.getArgValue(bannerTagArgs, 'display', 'top') || '';
            const newPosition = bannerTagDisplayValue.trim();
            if (newPosition === 'top') {
                bannerPosition = BannerPosition.TOP;
            } else if (newPosition === 'bottom') {
                bannerPosition = BannerPosition.BOTTOM;
            } else if (newPosition === 'hidden') {
                bannerPosition = BannerPosition.HIDDEN;
            } else if (newPosition === 'none') {
                bannerPosition = BannerPosition.NONE;
            }
        }
        return bannerPosition;
    }

    static getToc (document) {
        const tocTagExists = document.findTag(QuipDocument.TOC_TAG);
        if (tocTagExists) {
            const args = document.readTagValue(QuipDocument.TOC_TAG, '');
            const startValue = XHtmlConverter.getNumericArgValue(args, 'start', 2);
            const depthValue = XHtmlConverter.getNumericArgValue(args, 'depth', 3);

            return {
                isClassic: XHtmlConverter.getBooleanArgValue(args, 'classic', false),
                isFloating: XHtmlConverter.getBooleanArgValue(args, 'floating', true),
                isNumbered: XHtmlConverter.getBooleanArgValue(args, 'numbered', false),
                start: Math.max(1, Math.min(startValue, 6)), // allowed values: 1-6
                depth: Math.max(1, Math.min(depthValue, 6)), // allowed values: 1-6, even though Quip only has 3 levels
            }
        } else {
            return null;
        }
    }

    static getTocContent (props) {
        const toc = props.toc;
        if (!toc) {
            return '';
        }

        const tocMacro = `{{toc numbered=${toc.isNumbered} start=${toc.start} depth=${toc.depth}/}}\n`;
        if (toc.isClassic) {
            return `${tocMacro}\n`;
        } else if (toc.isFloating) {
            return `{{box floating=${toc.isFloating}}}\n` +
                   `(% style="max-width: 550px" %)` +
                   `Table of Contents\n` +
                   `\n${tocMacro}\n` +
                   `(%%)\n` +
                   `{{/box}}\n`;
        } else {
            return `{{box}}\n` +
                   `Table of Contents\n` +
                   `\n${tocMacro}\n` +
                   `{{/box}}\n`;
        }
    }

    static getTitleOverride (document) {
        return document.readTagValuesWithArguments(QuipDocument.TITLE_TAG)
            .map(obj => ({
                title: obj.value.trim(),
                isVisible: XHtmlConverter.getBooleanArgValue(obj.args, 'visible', false)
            }))[0];
    }

    static getBanner (props) {
        const bannerPosition = props.bannerPosition;
        if (bannerPosition === BannerPosition.NONE) {
            return '';
        }

        const docUrl = `${QuipEditor.QUIP_URL}/${props.docId}`;
        const now = new Date().toUTCString();
        const content = `//This page was created by [[Quip2Wiki>>Quip2Wiki.]] from a Quip ${props.type} ([[See original>>${docUrl}]]) at '${now}'//`;
        const clazz = bannerPosition === BannerPosition.HIDDEN ? 'hidden-print hidden' : 'hidden-print';
        const prefix = bannerPosition !== BannerPosition.TOP ? `----\n` : '';
        const suffix = bannerPosition === BannerPosition.TOP ? `\n----` : '';  // if BOTTOM or HIDDEN

        return `(% class="${clazz}" %)(((\n` + 
               `${prefix}(% style="color:#888888; font-size:small;" %)\n${content}${suffix}\n` +
               ')))\n';
    }

    static getHeaderOrFooterContent (values) {
        if (values.length == 0) {
            return '';
        }
        return values
            .map(tag => {
                const url = tag.addr.replace(/\//g,'.');
                const name = `name="space:${url}"` ;
                const args = tag.args ? `args="${tag.args}"` : '';
                return `{{transclude ${name} ${args} /}}`;
            })
            .join('\n\n')
            .concat('\n\n');
    }

    static getTableContent (tableElement, asHtml = false) {
        const fixedTableElement = XWikiConverter.fixTable(tableElement);
        if (asHtml) {
            const tableContent = "<table><tr><td>Placeholder for HTML table</td></tr></table>"
            return `{{html}}\n${tableContent}\n{{/html}}\n`;
        } else {
            return XWikiConverter.convertTable(fixedTableElement); //
        }
    }

    static getTabsMacro (sheets) {
        // determine ids and set same order as in Spreadsheet
        const ids = sheets
            .map((sheet, index) => ({ id: `id${index}=${sheet.title}`, sortOrder: sheet.sortOrder }))
            .sort((a, b) => a.sortOrder - b.sortOrder)
            .map(item => item.id)
            .join(',');

        return `{{tabs idsToLabels='${ids}' /}}\n`;
    }

    static insertTabElements (html, firstHeader) {
        const tables = [...html.body.querySelectorAll('table')];
            
        tables.forEach((table, index) => {
            // create tab element
            const tabElement = html.createElement('TAB');
            tabElement.id = `id${index}`
            tabElement.title = table.title;

            // place in correct position
            if (index == 0) { // is first
                if (firstHeader) { // add after first header, if available
                    firstHeader.parentNode.insertBefore(tabElement, firstHeader.nextSibling)
                } else {
                    html.body.insertBefore(tabElement, html.body.firstElementChild);
                }
            } else {
                table.parentNode.insertBefore(tabElement, table);
            }
        });
    }

    static fixTable (tableElement) {
        const newTable = tableElement.cloneNode(true);

        // fix unescaped sheet name
        const title = newTable.getAttribute('title');
        newTable.setAttribute('title', Utils.sanitizeHTMLText(title));

        // set basic style
        newTable.setAttribute('border', '1px');
        newTable.setAttribute('borderColor', '#c7cbd1');

        // helper methods
        const removeElement = el => el.parentNode.removeChild(el);
        const cleanText = t => t.replace(/[^\P{C}\n]+/u, '').trim();
        const isNumericRow = el => /^\d+$/.test(cleanText(el.textContent));
        const isDefaultHeader = el => el.classList.contains('empty'); //el => /^[A-Z]+$/.test(cleanText(el.textContent));
        const isEmptyCell = el => /^\s*$/.test(cleanText(el.textContent));
        const rowHasWidth = (row) => [...row.querySelectorAll('td, th')].every(td => td.style.width && /width:/.test(td.style.width));

        const hasHeader = !!newTable.querySelector('table > thead');
        if (hasHeader) {
            // remove column of row numbers
            const firstHeader = newTable.querySelector('table > thead > tr > th.empty:first-child');
            const firstColumnCells = Array.from(newTable.querySelectorAll('table > tbody > tr > td:first-child'));
            const hasNumberColumn = firstHeader && isEmptyCell(firstHeader) && firstColumnCells.every(el => isNumericRow(el));
            if (hasNumberColumn) {
                // delete first column header
                removeElement(firstHeader);
                // delete first column cells
                firstColumnCells.forEach(td => removeElement(td));
            }

            // remove default header if it is default (e.g: A, B, C, ..., AA, AB, AC, etc...)
            const headerRow = newTable.querySelector('table > thead > tr');
            const headerCells = Array.from(newTable.querySelectorAll('table > thead > tr > th'));
            const hasDefaultHeader = headerCells.every(th => isDefaultHeader(th));
            if (hasDefaultHeader) {
                // copy header cells' width
                const firstRowCells = Array.from(newTable.querySelectorAll('table > tbody > tr:first-child > td'));
                firstRowCells.forEach((td, index) => {
                    td.style.cssText += (headerCells[index].style.cssText || '');
                });
                // remove header
                removeElement(headerRow);
            } else {
                // set header background color as gray
                headerRow.style.backgroundColor = 'background-color:#E1E1E1';
            }
        }

        // remove empty columns
        const numColumns = newTable.querySelectorAll('table > tbody > tr > td').length;
        let colRemoveAttempts = 0;

        while (colRemoveAttempts < numColumns) {
            colRemoveAttempts++;

            const lastColumnHeader = newTable.querySelector('table > thead > tr > th:last-child');
            const lastColumnCells = Array.from(newTable.querySelectorAll('table > tbody > tr > td:last-child'));

            // check if last column is empty
            const isLastHeaderEmpty = !lastColumnHeader || isDefaultHeader(lastColumnHeader);
            const isLastColumnEmpty = lastColumnCells.length > 0 && lastColumnCells.every(td => isEmptyCell(td)) && isLastHeaderEmpty;
            if (!isLastColumnEmpty) {
                break;
            }

            // delete last column's header
            if (lastColumnHeader) {
                removeElement(lastColumnHeader);
            }
            // delete last column's cells
            lastColumnCells.forEach(td => removeElement(td));
        }

        // remove empty rows
        const numRows = newTable.querySelectorAll('table > tbody > tr').length;
        let rowRemoveAttempts = 0;

        while (rowRemoveAttempts < numRows) {
            rowRemoveAttempts++;

            // check if last row is empty
            const lastRowCells = Array.from(newTable.querySelectorAll('table > tbody > tr:last-child > td'));
            const isLastRowEmpty = lastRowCells.length > 0 && lastRowCells.every(td => isEmptyCell(td));
            if (!isLastRowEmpty) {
                break;
            }

            // delete last row
            const lastRow = newTable.querySelector('table > tbody > tr:last-child');
            removeElement(lastRow);
        }

        // remove unecessary line breaks (<br>) at end of each cell
        const lineBreaks = newTable.querySelectorAll('table > thead > tr > th > br:last-child, table > tbody > tr > td > br:last-child');
        lineBreaks.forEach(td => removeElement(td));

        // remove unecessary width style in all cells
        const tableWidth = newTable.style.width;
        if (tableWidth) {
            // find first row with width
            const allRows = Array.from(newTable.querySelectorAll('table > thead > tr > th > br:last-child, table > tbody > tr > td > br:last-child'));
            const firstRowWithWidth = allRows.find(row => rowHasWidth(row));
            if (firstRowWithWidth) {
                // remove width of cells in remaining rows
                allRows.filter(row => row !== firstRowWithWidth).forEach(td => td.style.width = null);
            }
        }

        // remove text-align class span (as td cell already contains text-align style)
        newTable.querySelectorAll('table > tbody > tr > td[style*="text-align"] > span:first-child.align-center')
            .forEach(span => span.classList.remove('align-center'));

        newTable.querySelectorAll('table > tbody > tr > td[style*="text-align"] > span:first-child.align-right')
            .forEach(span => span.classList.remove('align-right'));

        return newTable;
    }

    static convertTable (tableElement) {
        // |=Title 1|=Title 2
        // |Word 1|Word 2
        let output = '';

        // convert table header if present
        const headerRow = tableElement.querySelector('table > thead > tr:first-child');
        if (headerRow) {
            const headerCells = Array.from(tableElement.querySelectorAll('table > thead > tr > th'));
            for (const th of headerCells) {
                const innnerContent = XWikiConverter.convert(th, 1); // set as level=1 to avoid new line at end
                output += `|=${innnerContent}`;
            }
            output += '\n';
        }

        // convert table body
        const rows = tableElement.querySelectorAll('table > tbody > tr');
        rows.forEach(tr => {
            const cells = Array.from(tr.querySelectorAll('td'));
            let rowContent = '';
            for (const td of cells) {
                const innnerContent = XWikiConverter.convert(td, 1); // set as level=1 to avoid new line at end
                rowContent += `|${innnerContent}`;
            }
            output += rowContent + '\n';
        });

        return output;
    }
}



/**
 * Creates an interface for the console.debug(), console.warn() and console.error() methods in order to
 * store the log message into an array, so it can be sent for investigation.
 *
 * To avoid logging messages and to only print in the console, use log.debug() method.
 */
const logger = {
    logEntries: [],
    structuredLog: [],
    logCallbacks: [],
    logCounter: 0,
    MAX_LENGTH: 500,

    /**
     * Prints the message only in the console.
     * @param {string} message
     */
    debug: function (message) {
        console.debug(message);
        this.saveLogEntry("DEBUG", message);
    },

    /**
     * Prints the error message only in the console.
     * @param {string} message
     */
    debugError: function (message) {
        console.error(message);
        this.saveLogEntry("DEBUG_ERROR", message);
    },

    info: function (message) {
        const entry = String(message).slice(0, this.MAX_LENGTH);
        this.logEntries.push(`${this.now()} [INFO] ${entry}`);
        this.saveLogEntry("INFO", message);
        console.info(message);
    },

    log: function (message) {
        const entry = String(message).slice(0, this.MAX_LENGTH);
        this.logEntries.push(`${this.now()} [INFO] ${entry}`);
        this.saveLogEntry("INFO", message);
        console.log(message);
    },

    warn: function (message) {
        const entry = String(message).slice(0, this.MAX_LENGTH);
        this.logEntries.push(`${this.now()} [WARN] ${entry}`);
        this.saveLogEntry("WARN", message);
        console.warn(message);
    },

    error: function (message) {
        const entry = String(message).slice(0, this.MAX_LENGTH);
        this.logEntries.push(`${this.now()} [ERROR] ${entry}`);
        this.saveLogEntry("ERROR", message);
        console.error(message);
    },

    clear: function () {
        this.logEntries = [];
    },

    entries: function () {
        return this.logEntries;
    },

    now: function () {
        return new Date().toISOString();
    },

    saveLogEntry(level, args) {
        this.logCounter += 1;
        let id = `q2w-log-${this.logCounter}`;

        let timestamp = new Date();
        let errorObj = Error();
        let entry = {
            id,
            errorObj,
            timestamp,
            level,
            args
        }

        this.structuredLog.push(entry);
        this.renderLogEntry(entry);
    },

    renderLogEntry(entry, forceFocus=true) {
        if (this.logCallbacks.length > 0) {
            for (let i = 0; i < this.logCallbacks.length; i++) {
                const c = this.logCallbacks[i];
                c(entry, i, forceFocus);
            }
        }
    },

    registerLogDump: async function () {
        const LOG_FOLDER_URL_PUT = "https://drive-webdav.corp.amazon.com/mnt/siljonas@/quip2wiki/metrics/logs/";
        const LOG_FOLDER_URL_VIEW = "https://drive.corp.amazon.com/view/siljonas@/quip2wiki/metrics/logs/";

        const user = await Session.getUser();
        const date = Utils.formatDate(new Date());
        const putUrl = LOG_FOLDER_URL_PUT + `${user}_${date}.txt`;
        const viewUrl = LOG_FOLDER_URL_VIEW + `${user}_${date}.txt`;

        log.info(`Registering log dump on '${putUrl}'...`);
        await Utils.putUrl(putUrl, { user: user, date: date, logs: log.entries() }, 60000);

        return viewUrl;
    }
};

var log = logger;

function convertMilissecondsToMinutesSeconds(milliseconds) {
    let millis = (milliseconds % 1000).toString();
    let totalSeconds = Math.floor(milliseconds / 1000);
    let seconds = (totalSeconds % 60).toString();
    let minutes = (Math.floor(totalSeconds / 60)).toString();

    return `${minutes.padStart(2, "0")}:${seconds.padStart(2, "0")}.${millis.padStart(3, "0")}`;
}
// script initilization and main export functions

(function () {
    'use strict';

    init().catch(ex => {
        log.error(ex);
        const msg = `Error loading Quip2Wiki: ${ex}.\n\nIf this error persists, Quip2Wiki installation may be corrupted and you will need to re-install the script.\n\nPress 'OK' to open a guide on how to fix this issue on Quip2Wiki page.`;
        if (window.confirm(msg)) {
            GM_openInTab(REINSTALL_FAQ_URL, { active: true });
        }
    });
})();

// resize the modal dialogs when the window is resized
$(window).resize(function() {
    $(".q2w-dialog").dialog("option", "position", {my: "center", at: "center", of: window});
});

var appTitle = 'Export to Wiki...';

var lastPageUrl = window.location.href;
var shiftKeyIsPressed;
var altKeyIsPressed;
var iframeData = new Map();

var telemetry;
var quipClient;
var wikiClient;
var wikiExport;
var changeMonitor;
var latestVersion;

const BUTTON_TEXT = 'Export to Wiki'
const BUTTON_ID = 'export-wiki-button';
const BUTTON_LABEL_ID = 'export-wiki-button-text';
const LABEL_ID = 'export-wiki-label';
const DOC_DIVERGED_LABEL = ' <span style="height: 8px; width: 8px; background-color: #ff373c; border-radius: 50%; display: inline-block;"/>';
const DOC_CHANGED_LABEL = ' <span style="height: 8px; width: 8px; background-color: #fff; border-radius: 50%; display: inline-block;"/>';
const KNOWN_ISSUES_URL = 'https://w.amazon.com/bin/view/Quip2Wiki#HKnownIssues';
const REINSTALL_FAQ_URL = 'https://w.amazon.com/bin/view/Quip2Wiki#HHowtofixissueof22ErrorloadingQuip2Wiki223F';
const IN_SYNC_FAQ_URL = 'https://tiny.amazon.com/x9wk3li7/DocumentInSyncAfterChanges';


var tagKeys = {
    '\n': '<br>',
    '\u0009': '<b>[Tab]</b>',
    '\u2029': '<b>[Line Separator]</b>'
    /* add any other chars here that may be better represented some other way instead of char code */
};

function tagSpecialChars(str) {
    let output = "";
    for (let i = 0; i < str.length; i++) {
        let ch = str.charAt(i);
        if (ch < ' ' || ch > '~') {
            let replacement = tagKeys[ch];
            if (replacement) {
                ch = replacement;
            } else {
                // show char as [\uZZZZ] in bold
                ch = "<b>[\\u" + ch.charCodeAt().toString(16).padStart(4,'0') + "]</b>";
            }
        }
        output += ch;
    }
    return output;
}


function removeButtonIfNecessary() {
    let path = document.location.pathname;
    const showExportButton = !(path === "/" || path === "/browse" || path === "/all");
    if (!showExportButton) {
        $("#export-wiki-button-group").remove();
    }
}

/*
 * Quip2Wiki initialization.
 */
async function init () {

    // if we are running inside an iframe, monitor for Design Inspector links and send messge to top window
    if (window.top !== window.self) {
        const domain = document.domain;
        const view = document.defaultView.name;
        log.debug(`Running on iframe '${domain}', view '${view}'`);

        const isDiInspectorMutation = (mutation) => {
            // check iframe has changed src, width or height attributes
            const isAttrChange = mutation.type === 'attributes' && mutation.target.tagName === 'IFRAME' && ['src','width','height'].includes(mutation.attributeName);
            // check iframe has been created
            const isNewNode = mutation.type === 'childList' && [...mutation.addedNodes].find(n => n.tagName === 'IFRAME');
            return isAttrChange || isNewNode;
        }

        const notifyDiInspector = async (mutantionList) => {
            if (mutantionList != null && !mutantionList.find(m => isDiInspectorMutation(m))) {
                return;
            }

            [...document.body.querySelectorAll('iframe[src^="https://design-inspector.a2z.com/"')]
                .filter(diElement => !!diElement.src)
                .forEach(diElement => {
                    if (diElement && diElement.src) {
                        log.info(`Detected Design Inspector iframe '${domain}' '${view}': ${diElement.src}`);
                        window.top.postMessage({
                            content: { domain: domain, view: view, diUrl: diElement.src, width: diElement.width, height: diElement.height }
                        }, "*");
                    } else {
                        log.info(`Could not detect Design Inspector iframe on domain '${document.domain}'`);
                    }
                });
        };

        await notifyDiInspector();

        // create observer to detect a design-inspector was loaded
        const iframeObserver = new MutationObserver(notifyDiInspector);
        //iframeObserver.observe(document, { attributeFilter: [ "src", "width", "height" ], childList: true, subtree: true });
        iframeObserver.observe(document, { attributes: true, childList: true, subtree: true });

        return;
    }

    printBasicInfo();

    initCss();

    await Settings.load();

    showSettingsMenus();

    // configure log override with SHIFT key down
    document.onkeydown = onKeyUpOrDown;
    document.onkeyup = onKeyUpOrDown;
    
    if (WikiEditor.IsWikiPage()) {
        log.debug('wiki page info: ' + JSON.stringify(WikiEditor.getWikiUrlInfo()));
        if (Settings.wikiBlockEnabled) {
            await WikiEditor.blockEdit();
        }
        return;
    }

    log.debug('Execute toolbox.help() for telemetry statistics functions');

    showExportButton();

    // Setup message event listener to persist Design Inspector data coming from iframes
    window.addEventListener("message", (event) => {
        const { content } = event.data;
        if (content && content.domain && content.diUrl) {
            log.debug(`Received data from iframe: ${JSON.stringify(content)}`);
            const key = { domain: content.domain, view: content.view }
            iframeData.set(key, content);
        }
    }, false);

    // create observer to detect new document/folder was loaded
    const pageObserver = new MutationObserver(async () => {
        addExportButtonsIfNecessary();
        fixExportButtonPosition();
        removeButtonIfNecessary();

        const currentPageUrl = window.location.href;
        if (lastPageUrl !== currentPageUrl) {
            onNewDocumentLoaded();
            lastPageUrl = currentPageUrl;
        }
    });
    pageObserver.observe(document, { attributes: false, childList: true, subtree: true });

    await initTelemetry();

    // init quip and wiki clients
    quipClient = new QuipClient(telemetry)
    wikiClient = new WikiClient();
    wikiExport = new WikiExport(quipClient, wikiClient);

    // configure change monitor
    changeMonitor = new ChangeMonitor(quipClient, wikiClient, (status) => updateExportButton(BUTTON_TEXT, null, status), Settings.changeMonitorEnabled);
    if (QuipEditor.isDocument()) {
        changeMonitor.start(QuipEditor.getDocumentId());
    } else if (QuipEditor.isFolder()) {
        changeMonitor.start(QuipEditor.getFolderId(), 'folder');
    }
    if (Settings.changeMonitorEnabled) {
        window.addEventListener('focus', () => changeMonitor.start());
        window.addEventListener('blur', () => changeMonitor.stop());
        log.debug('Change monitor is enabled');
    }
}

function fixExportButtonPosition() {
    let toolbar = QuipEditor.getToolbar();
    if (toolbar) {
        /**
         * @type {HTMLElement}
         */
        let previousElement = toolbar.previousElementSibling;
        let isExportButtonInTheRightPlace = previousElement != undefined &&
            (previousElement.ariaLabel == "Focus Mode" || previousElement.ariaLabel == "Add to Favorites");
        if (!isExportButtonInTheRightPlace) {
            let baseButton = QuipEditor.getBaseButtonForExportButton();
            if (baseButton)
                $("#export-wiki-button-group").insertAfter(baseButton);
        }
    }
}

function addExportButtonsIfNecessary() {
    let toolbar = QuipEditor.getToolbar();
    let basePosition = QuipEditor.getBaseButtonForExportButton();
    if (!toolbar && basePosition) {
        showExportButton();
    }
}

function showAppFooter() {
    const folderId = QuipEditor.getFolderId();
    const wikiAddr = Settings.loadValue(folderId, null);
    if (!wikiAddr) {
        QuipEditor.removeElement(LABEL_ID);
        return;
    }

    const wikiUrl = WikiClient.VIEW_URL + wikiAddr;
    const html = `<span style="font-size:small; margin-left:35px;">--wiki-sync:` +
                    `"<span style="text-decoration:underline; font-style:italic;">` +
                    `<a href="${wikiUrl}" target="_blank" style="color:#5C6470" rel="noopener">${wikiAddr}</a>` +
                    `</span>"--</span>`;
    QuipEditor.createAppFooter(LABEL_ID, html, null);
}

function initCss () {
    var newCSS = GM_getResourceText("jquery-ui-css");
    GM_addStyle(newCSS);
}

function onKeyUpOrDown (e) {
    const evtobj = window.event ? event : e
    shiftKeyIsPressed = !!evtobj.shiftKey;
    //ctrlKeyIsPressed = !!evtobj.ctrlKey;
    altKeyIsPressed = !!evtobj.altKey;
}

function printBasicInfo (printer = m => log.debug(m)) {
    printer(`Browser: ${Session.getBrowser()}`);
    printer(`Tampermonkey Version: ${Session.gmVersion}`);
    printer(`Quip2Wiki Version: ${Session.version}`);
}

function logBasicInfo () {
    printBasicInfo(m => log.info(m));
}

function showSettingsMenus () {
    const wikiBlockActionText = Settings.wikiBlockEnabled ? 'Disable' : 'Enable';
    GM_registerMenuCommand(`${wikiBlockActionText} Wiki editor block`, () => {
        Settings.wikiBlockEnabled = !Settings.wikiBlockEnabled; // switch value
        Settings.save();
        const newState = Settings.wikiBlockEnabled ? 'enabled' : 'disabled';
        Prompts.showAlert('Quip2Wiki', `Wiki editor block successfully ${newState}.</br>Refresh the page for the change to take effect`);
    });


    const exportDialogEnabledActionText = Settings.exportDialogEnabled ? 'Disable' : 'Enable';
    GM_registerMenuCommand(`${exportDialogEnabledActionText} export confirmation dialog`, () => {
        Settings.exportDialogEnabled = !Settings.exportDialogEnabled; // switch value
        Settings.save();
        const newState = Settings.exportDialogEnabled ? 'enabled' : 'disabled';
        Prompts.showAlert('Quip2Wiki', `Export confirmation dialog successfully ${newState}.</br>Refresh the page for the change to take effect</br></br>Press ALT key (Option key in Mac) before clicking on "Export to Wiki" button to show the confirmation dialog`);
    });
}

function showExportButton () {
    // update document related settings

    const showExportButton = QuipEditor.isDocument() || QuipEditor.isFolder();

    if (showExportButton) {
        QuipEditor.createQuip2WikiButtons(exportToWiki);
        if (QuipEditor.isFolder()) {
            showAppFooter();
        } else {
            QuipEditor.removeElement(LABEL_ID);
        }
    } else {
        log.debug('not an exportable Quip document or folder');
        QuipEditor.removeElement(BUTTON_ID);
        QuipEditor.removeElement(LABEL_ID);
    }
}

function onNewDocumentLoaded () {
    if (!changeMonitor) {
        return;
    }

    changeMonitor.resetStatus();
    changeMonitor.stop();
    if (showExportButton && QuipEditor.isDocument()) {
        changeMonitor.start(QuipEditor.getDocumentId());
    } else if (showExportButton && QuipEditor.isFolder()) {
        changeMonitor.start(QuipEditor.getFolderId(), 'folder');
    }
}

function updateExportButton(label, isRunningValue, statusValue) {
    const buttonLabel = document.getElementById(BUTTON_LABEL_ID);
    if (!buttonLabel) {
        return;
    }

    if (isRunningValue != null) {
        buttonLabel.setAttribute('data-is-running', isRunningValue.toString());
    }

    const isRunning = isRunningValue || buttonLabel.getAttribute('data-is-running') == 'true';
    const hasDiverged = statusValue === 'DIVERGED';
    const hasChanged = statusValue === 'CHANGED';

    if (!isRunning && hasDiverged) {
        buttonLabel.innerHTML = label + DOC_DIVERGED_LABEL;
        buttonLabel.setAttribute('title', 'Destination wiki has changed and diverged from Document. Exporting will overwrite those changes');
    } else if (!isRunning && hasChanged) {
        buttonLabel.innerHTML = label + DOC_CHANGED_LABEL;
        buttonLabel.setAttribute('title', 'Document has changed since last export');
    } else {
        buttonLabel.innerHTML = label;
        buttonLabel.removeAttribute('title');
    }
}

async function checkForUpdates() {
    if (window.location.href.startsWith("https://quip-amazon.com/account")) return;

    try {
        const versionInfo = await Session.getLatestVersion();
        if (versionInfo && versionInfo.version) {
            if (versionInfo.isNew) {
                log.info(`A new version is available: ${versionInfo.version}`);
            } else {
                log.info(`No update available`);
            }
            latestVersion = versionInfo;
    
            // we will show a dialog if there is a mandatory update
            await promptForScriptUpdate(); 
        } else {
            log.error('Unknown error determining latest version available');
        }
    } catch (err) {
        log.error(`Unable to determine latest version available: ${err}`);
    }
}

async function checkNetwork () {
    log.info('Checking network connection..');

    try {
        const userResult = await Utils.getMidwayUser(); // check midway authentication
        if (!userResult) {
            throw `Midway test result: ${userResult}`;
        }
    } catch (ex) {
        log.error(`Network connection error [midway]: ${ex}`);
        return false;
    }

    try {
        const wikiResult = await wikiClient.testConnection(); // check wiki API connection
        if (!wikiResult) {
            throw `Wiki API test result: ${wikiResult}`;
        }
    } catch (ex) {
        log.error(`Network connection error [wiki-api]: ${ex}`);
        return false;
    }

    return true;
}

async function initTelemetry () {
    try {
        if (!telemetry) {
            const user = await Session.getUser();
            telemetry = new Telemetry(user);
            telemetry.registerInstallation();
        }
    } catch (err) {
        telemetry = null;
        log.debugError(`Could not initialize telemetry: ${err}`);
    }
}

async function promptQuipApiToken () {
    let token = Settings.quipApiToken; // fetch current token

    while (true) {
        let tokenValid = false;

        try {
            if (token != null) {
                tokenValid = Session.isTokenTested() || await quipClient.checkNewToken(token);
            }
        } catch (err) {
            if (err === QuipClient.CHECK_TOKEN_NOT_A_QUIP_TOKEN_ERROR) {
                throw 'Could not initialize Quip Client: the provided token does not seem to be a Quip API token.';
            } else if (err === QuipClient.CHECK_TOKEN_TIMEOUT_ERROR) {
                throw 'Could not initialize Quip Client (timeout): check your connection or VPN.';
            }
            tokenValid = false; // token is invalid and we should ask the user for a new one
        }

        if (token != null && tokenValid) {
            log.debug("Quip API token: " + token); // for privacy, only show token on console (do not store for telemetry)
            if (token != Settings.quipApiToken) {
                // save token
                Settings.quipApiToken = token;
                await Settings.save();
            }
            // save test result on session
            Session.setTokenTest(true);
            break;
        } else {
            const buttons = {
                "Cancel": null,
                "Get a new token": true,
                "I have a token": false
            }
            const dialogResult = token ?
                await Prompts.showDialog('Quip API', `Invalid or expired Quip API Token:\n\n'${token}'!`, buttons, 800) :
                await Prompts.showDialog('Quip API', 'Missing Quip API Token!', buttons, 500);

            if (dialogResult == null) {
                return false; // user cancelled
            } else if (dialogResult === true) {
                await Prompts.showAlert(appTitle, `You will be redirected to Quip API Token page.<br/><br/>
                                                   Please copy the token and in the input dialog that will be shown.`);
                await QuipEditor.showTokenPage();
            }

            token = window.prompt('Please inform the Quip API Token:', token);
            if (token == null) {
                return false; // user cancelled
            }
            log.info('User entered an API token!');
        }
    }

    telemetry?.registerTokenInstallation();

    return true; // check token succeeded
}

async function getUserSpace (user) {
    if (!user) {
        return 'ApiTesting/Quip2Wiki/';
    }

    const findUserSpace = async () => {
        const recommended = WikiClient.DEFAULT_USER_SPACE + user;

        const recommendedSpaceResult = await wikiClient.search(`Users.${user}`, 'spaces', number = 1);
        if (recommendedSpaceResult.length > 0)  {
            return recommended;
        }

        const legacySpaceResult = await wikiClient.search(`User.${user}`, 'spaces', number = 1);
        if (legacySpaceResult.length > 0) {
            return `User/` + user;
        }

        return recommended;
    };

    const key = `${user}:space`;
    const addr = Settings.loadValue(key, null) || await findUserSpace().catch(err => `Users/${user}`);
    Settings.saveValue(key, addr);

    return addr + '/Quip/';
}

async function promptForScriptUpdate (onlyForcedUpdate = false) {
    if (!latestVersion || !latestVersion.isNew) {
        return; // no update available
    }

    if (onlyForcedUpdate && !latestVersion.forceUpdate) {
        return; // update is not mandatory
    }

    const now = new Date();
    const lastUpdatedPromptString = Settings.loadValue('LastUpdatePrompt')
    if (!lastUpdatedPromptString) {
        // The lastUpdatedPrompt string wasn't saved properly or was corrupted somehow
        // Thus we override it in the hopes that the new value is saved correctly - this will make the prompt appear 2 days later for these users
        Settings.saveValue('LastUpdatePrompt', now.toISOString());
    }

    var lastPrompt = now;
    try {
        lastPrompt = new Date(lastUpdatedPromptString)
    } catch (error) {
        // if an error still happens here, we save the LastUpdatePrompt property to try and correct the problem
        console.debug(error);
        Settings.saveValue('LastUpdatePrompt', now.toISOString());
    }

    const elapsed = (now - lastPrompt);
    const TWO_DAYS = 2*24*60*60*1000; // 2 days in milliseconds
    if (elapsed && elapsed < TWO_DAYS && elapsed > 0) {
        log.info(`Will not prompt for an update until ${new Date(lastPrompt + TWO_DAYS).toISOString()}`);
        return; // let's not bug the user for now
    }

    Settings.saveValue('LastUpdatePrompt', now.toISOString());

    const buttons = { 
        "Remind me later": false,
        "Update now": true 
    };

    const updateUrl = latestVersion.url;

    const updateNow = await Prompts.showDialog(
        'Quip2Wiki Update', 
        'There is a new release of Quip2Wiki available:\n\n' +
        `<code>- Current version: <b>${Session.version}</b></code>\n`+
        `<code>- New version: &nbsp;&nbsp;&nbsp;&nbsp;<b>${latestVersion.version}</b></code>\n\n` +
        '<span style="font-style:italic; font-size: x-small">The latest version is available for ' + 
        `<span style="text-decoration:underline; font-style:italic; font-size: x-small"><a href="${updateUrl}" target="_blank" rel="noopener">download here</a></span>` +
        '</span>',
        buttons);

    if (updateNow) {
        log.info('Opening latest script at ${updateUrl}');
        GM_openInTab(updateUrl, { active: true, setParent: true });
        alert('After updating Quip2Wiki, all open Quip tabs should be reloaded');
        location.reload();
        return false; // will cause export process to be canceled
    } else {
        Settings.saveValue('LastUpdatePrompt', now.toISOString());
        return true; // export process can continue
    }
}

/**
 * Exports the current Quip document to a Wiki page.
 */
async function exportToWiki () {
    const buttonLabel = document.getElementById(BUTTON_LABEL_ID);

    try {
        const isRunning = buttonLabel.getAttribute('data-is-running') == 'true';
        if (isRunning) {
            return; // task is already running
        }

        const isSendLogs = shiftKeyIsPressed;
        if (isSendLogs) {
            const dialogResult = await Prompts.showDialog(appTitle, 'You are about to send telemetry information and logs for analysis...', { Cancel: false, Continue: true });
            if (!dialogResult) {
                return;
            }
            updateExportButton('Sending logs...', true);
            sendLogs();
            return;
        }

        log.clear();
        logBasicInfo();

        updateExportButton('Checking Network...', true);

        await checkNetwork();

        updateExportButton('Preparing...', true);

        await initTelemetry();

        const isQuipClientInitialized = await promptQuipApiToken();
        if (!isQuipClientInitialized) {
            return; // user canceled
        }

        telemetry?.registerExportAttempt();

        const isFolder = QuipEditor.isFolder();
        if (isFolder) {
            if (QuipEditor.hasListOfDocuments()) {
                log.info("Current page contains a list of folders/documents")
            }
            await exportFolderToWiki();
        } else {
            await exportDocumentToWiki();
        }

        changeMonitor.resetStatus();
    } catch (ex) {
        const errorMessage = ex.toString();
        if (errorMessage == Utils.ABORTED_BY_USER) {
            // if the user stopped the operation, we don't do anything other than stopping the operation
            return;
        }

        const docType = QuipEditor.getDocumentType();

        log.error(ex);

        telemetry?.registerUsage(docType, ex);

        let message = `Reason: ${ex}`;
        let options = { 'Upload logs': true, OK: false };
        if (errorMessage.startsWith(Utils.MIDWAY_REDIRECT_URL)) {
            authUrl = errorMessage;
            message = `<span>Midway authentication is required. Click <b><a href="${authUrl}" target="_blank" rel="noopener">here</a></b> to authenticate, then try exporting again.</span>
<br><span><i>If authenticating doesn't work, disconnect from VPN, <b>reload</b></i> and try exporting again.</span>`;
            options = { 'Open Midway to authenticate': () => { unsafeWindow.open(authUrl, "_blank").focus() ; return false; }, OK: false };            
        }
        
        const isSendLogs = await Prompts.showDialog(appTitle, `An error occurred while exporting the Quip ${docType}. ` +
            `If the error persists, please <span style="text-decoration:underline; font-style:italic;"><a href="${KNOWN_ISSUES_URL}" target="_blank" rel="noopener">check for known issues</a></span>, ` +
            `ask for help at <span style="text-decoration:underline;"><a href="https://slack.com/app_redirect?channel=quip2wiki" target="_blank" rel="noopener">#quip2wiki</a></span> Slack channel, or ` +
            `<span style="text-decoration:underline; font-style:italic;"><a href="${TICKET_URL}" target="_blank" rel="noopener">open a ticket</a></span><br/><br/>${message}`, options);

        if (isSendLogs) {
            updateExportButton('Sending logs...', true);
            sendLogs();
        }
    } finally {
        if (!changeMonitor.isRunning) {
            changeMonitor.start();
        }
        updateExportButton(BUTTON_TEXT, false, changeMonitor.currentStatus);

        checkForUpdates();
    }
}

async function exportDocumentToWiki () {
    const docId = QuipEditor.getDocumentId();
    let doc = await quipClient.getDocument(docId);
    if (!doc) {
        throw 'Could not load Quip document!';
    }

    let wikiAddr = doc.getWikiSyncAddress();

    let newWikiAddr = wikiAddr;
    if (!wikiAddr) {
        const user = await Session.getUser();
        const title = doc.titleAsUrl;
        const suggAddr = await getUserSpace(user) + title;
        newWikiAddr = await Prompts.promptForNewWikiAddress(suggAddr, wikiClient);
        if (!newWikiAddr) {
            return;
        }
        log.info(`User selected wiki page: ${wikiAddr}`);
    } else if (Settings.exportDialogEnabled || altKeyIsPressed) {
        newWikiAddr = await Prompts.promptForExistingWikiAddress(wikiAddr, doc.type, wikiClient);
        if (!newWikiAddr) { // prompt was cancelled
            return;
        }
        log.info(`Selected wiki page from tag: ${wikiAddr}`);
    }

    // save wiki address
    if (newWikiAddr !== wikiAddr) {
        wikiAddr = newWikiAddr;
        await QuipEditor.writeWikiAddressTag(doc, wikiAddr, quipClient);
        // reload doc
        doc = await quipClient.getDocument(docId);
    }

    const url = `${WikiClient.VIEW_URL}${wikiAddr}`;
    const wikiLink = `<span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${url}</a></span>`;

    const timestamp = doc.lastUpdated;
    const wikiExists = await wikiClient.wikiPageExists(wikiAddr);
    if (wikiExists) {
        const wikiTimestamp = await wikiClient.getLastUpdated(wikiAddr);
        if (!wikiTimestamp) {
            const dialogResult = await Prompts.promptForChangedWikiConfirmation(wikiAddr);
            if (!dialogResult) {
                return; // cancelled
            }
        } else if (timestamp === wikiTimestamp) {
            const dialogResult = await Prompts.showWikiInSyncDialoig(wikiLink, doc.type);
            if (!dialogResult) {
                return; // cancelled
            }
        }
    }

    updateExportButton('Exporting...', true);

    const success = await wikiExport.exportDocument(doc, wikiAddr, timestamp);
    if (!success) {
        return; // user aborted
    }

    telemetry?.registerSuccessfulExport();
    telemetry?.registerUsage(doc.type);

    const msg = `Quip ${doc.type} successfully exported to Amazon Wiki<br/><br/>${wikiLink}`;
    await Prompts.showAlert(appTitle, msg);
}

async function exportFolderToWiki () {
    const id = QuipEditor.getFolderId();
    const folder = await quipClient.getFolderInfo(id);
    if (!folder || !folder.id) {
        throw 'Could not load Quip folder!';
    }

    const title = folder.title;

    let wikiAddr = Settings.loadValue(id, null);
    if (!wikiAddr) {
        const user = await Session.getUser();
        const suggAddr = await getUserSpace(user) + title + 'Index';
        wikiAddr = await Prompts.promptForNewWikiAddress(suggAddr, wikiClient);
    } else if (Settings.exportDialogEnabled || altKeyIsPressed) {
        wikiAddr = await Prompts.promptForExistingWikiAddress(wikiAddr, 'folder', wikiClient);
    }
    if (!wikiAddr) { // prompt was cancelled
        return;
    }

    // save wiki address
    await Settings.saveValue(id, wikiAddr);
    showAppFooter();

    const url = `${WikiClient.VIEW_URL}${wikiAddr}`;
    const wikiLink = `<span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${url}</a></span>`;

    const timestamp = folder.lastUpdated;
    const wikiExists = await wikiClient.wikiPageExists(wikiAddr);
    if (wikiExists) {
        const wikiTimestamp = await wikiClient.getLastUpdated(wikiAddr);
        if (!wikiTimestamp) {
            const dialogResult = await Prompts.promptForChangedWikiConfirmation(wikiAddr);
            if (!dialogResult) {
                return; // cancelled
            }
        } else if (timestamp === wikiTimestamp) {
            const dialogResult = await Prompts.showWikiInSyncDialoig(wikiLink, 'folder');
            if (!dialogResult) {
                return; // cancelled
            }
        }
    }

    updateExportButton('Exporting...', true);

    // get documents on the folder and all its subfolders, sorted by last updated (newer to older)
    const folderList = await quipClient.getFolderListing(id, 'updated_usec', 'desc');
    if (!folderList || !folderList.id) {
        throw 'Could not load Quip folder listing!';
    }

    await wikiExport.exportFolder(folderList, wikiAddr, timestamp);

    telemetry?.registerSuccessfulExport();
    telemetry?.registerUsage('folder');

    const msg = `Quip folder successfully exported to Amazon Wiki<br/><br/>${wikiLink}`;
    await Prompts.showAlert(appTitle, msg);
}

async function sendLogs () {
    try {
        const midway = await Utils.getMidwayUser();
        if (!midway) {
            throw 'Please authenticate to Midway at https://midway-auth.amazon.com/login';
        }

        const logUrl = await log.registerLogDump();
        await Prompts.showAlert(appTitle, `Successfuly sent log dump:</br>Log URL: <span style="text-decoration:underline; font-style:italic;"><a href="${logUrl}" target="_blank" rel="noopener">${logUrl}</a></span>`);
        log.clear(); 
        return true;
    } catch (ex) {
        log.error(`Error while registering log dump: ${ex}`);
        await Prompts.showAlert(appTitle, `Failed to send log dump.<br/>Reason: ${ex}.<br/><br/>Please try again by clicking the "Export to Wiki" button with the SHIFT key pressed.`);
        return false;
    }
}

function base64ToBytes(base64) { // copied from https://developer.mozilla.org/en-US/docs/Glossary/Base64
    const binString = atob(base64);
    return Uint8Array.from(binString, (m) => m.codePointAt(0));
}
    
function bytesToBase64(bytes) { // copied from https://developer.mozilla.org/en-US/docs/Glossary/Base64
    const binString = String.fromCodePoint(...bytes);
    return btoa(binString);
}

function objToBase64(obj) {
    return bytesToBase64(new TextEncoder().encode(JSON.stringify(obj)))
}

function base64ToObj(b64) {
    return JSON.parse(new TextDecoder().decode(base64ToBytes(b64)));
}

let isDevMode = Settings.loadValue("devMode", false);
if (isDevMode) {
    showDevDialog();
}


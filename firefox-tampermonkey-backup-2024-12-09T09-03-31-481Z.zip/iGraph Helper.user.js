// *******************************************************
// For all changes run through the test steps at:
// https://w.amazon.com/index.php/IGraphHelper/Testing
// *******************************************************
//
// ==UserScript==
// @name           iGraph Helper
// @downloadURL    https://improvement-ninjas.amazon.com/GreaseMonkey/iGraphHelper.amazon.user.js
// @updateURL      https://improvement-ninjas.amazon.com/GreaseMonkey/iGraphHelper.amazon.user.js
// @namespace      http://amazon.com/dept/monitoring
// @description    Version 2.5.19 - Added support for Quip2Wiki macro
// @version        2519
// @icon           https://monitorportal.amazon.com/favicon.ico
// @grant          GM_addStyle
// @grant          GM_getValue
// @grant          GM_log
// @grant          GM_openInTab
// @grant          GM_registerMenuCommand
// @grant          GM_setClipboard
// @grant          GM_setValue
// @grant          GM_xmlhttpRequest
// @grant          GM_notification
// @grant          GM_info
// @grant          unsafeWindow
// @require        https://m.media-amazon.com/images/I/61N6qD3NeaL.js#ver=jquery-1.9.1.min.js
// @require        https://m.media-amazon.com/images/G/01/envImprovement/js/paste.js/0.0.21/paste._CB1538399281_.js
// @include        http*://*.amazon.*/*
// @include        http*://*.*.amazon.*/*
// @include        http*://*.amazon.*:*/*
// @include        http*://*.aws-border.*/*
// @include        http*://*.aws.dev/*
// @include        http*://*.a2z.com/*
// @include        http*://*.a2z.org.cn/*
// @include        https://*.amazonaws-us-gov.com/*
// @include        https://*.amazonaws.cn/*
// @include        https://*c2shome.ic.gov/*
// @include        https://*.c2s-border.ic.gov/*
// @include        https://*.c2s-border.ic.gov/*
// @include        https://*.c2s-aws.ic.gov/*
// @include        https://*.c2s-a2z.ic.gov/*
// @include        https://*.sc2s-a2z.sgov.gov/*
// @include        https://*.sc2shome.sgov.gov/*
// @include        http*://wiki.imdb.*/*
// @include        http*://*awsdashboard*.a2z.com/*
// @include        http*://*.premonition.a2z.com/*
// @include        https://*.c2s.ic.gov/*
// @include        https://*.sc2s.sgov.gov/*
// @include        https://*.amazonaws.ic.gov/*
// @include        https://*.hci.ic.gov/*
// @include        https://*.adc-e.uk/*
// @include        https://*.amazonaws.eu/*
// @include        https://*.aws-border.eu/*
// @exclude        http*://amazon.tld/*
// @exclude        http*://www.amazon.*/*
// @exclude        http*://aws.amazon.com/marketplace*
// @exclude        http*://ad-jira.amazon.*/*
// @exclude        http*://s9-puma-*.amazon.*/*
// @exclude        http*://blueprints.amazon.*/*
// @exclude        http*://evolution.amazon.*/*
// @include        http*://wiki.labcollab.*/*
// @exclude        http*://peopleportal.amazon.*/*
// @exclude        http*://peopleportal.hr.corp.amazon.com*
// @exclude        http*://apollo.amazon.*/r/*
// @exclude        http*://timeoff.amazon.com/*
// @exclude        http*://*xwiki*.amazon.*/*
// @exclude        http*://intranet-analytics.amazon.com*
// @exclude        http*://ballard.amazon.com/*
// @exclude        http*://aws-blogs-*.amazon.com/*
// @exclude        http*://approvalbouncer.*.amazon.com/*
// @exclude        http*://docs.aws.amazon.com/*
// @exclude        http*://docs.amazonaws.cn/*
// @exclude        http*://*docs-aws*amazon.com/*
// @exclude        http*://*idp.amazon.work/*
// @exclude        http*://atv-pex-tools-*.amazon.com/*
// @exclude        http*://collator-items.*.amazon.com/*
// @exclude        http*://sonar-*.amazon.com/*
// ==/UserScript==


function codeWrapper(extraCode) {
    var log, setValue, getValue, addStyle;

    function testGM() {
        var isGM = typeof GM_getValue != 'undefined' && typeof GM_getValue('a', 'b') != 'undefined';
        if(!isGM) { log = function(msg) { try { window.console.log(msg); } catch(e) {} }; } else { log = GM_log; }
        if(window.opera) log = opera.postError;
        setValue = isGM ? GM_setValue : function (name, value) { return localStorage.setItem(name, value) };
        getValue = isGM ? GM_getValue : function(name, def){ var s = localStorage.getItem(name); return s == null ? def : s };
        addStyle = styles => {
            GMUtils.addStyle(styles);
        };
    }
    testGM();

    extraCode(window, window);

    let MonitorPortalRoot = "https://monitorportal.amazon.com";
    if (/(dca|apa)\.(amazon\.com|c2s-border\.ic\.gov)$/.test(window.location.hostname)) {
        MonitorPortalRoot = "https://monitorportal.dca.c2s-border.ic.gov";
    } else if (/((lck|ffz)\.amazon\.com|(lck|ffz)\.aws\-border(\.com|\.sgov\.gov))/.test(window.location.hostname)) {
        MonitorPortalRoot = "https://monitorportal.lck.aws-border.sgov.gov";
    } else if (/ncl\.aws\-border\.adc\-e\.uk$/.test(window.location.hostname)) {
        MonitorPortalRoot = "https://monitorportal.ncl.aws-border.adc-e.uk";
    } else if (/(ale|ltw)\.aws-border\.hci\.ic\.gov$/.test(window.location.hostname)) {
        MonitorPortalRoot = "https://monitorportal.ale.aws-border.hci.ic.gov";
    } else if (/(bjs\.(amazon|aws\-border)\.(com|cn))/.test(window.location.hostname)) {
        MonitorPortalRoot = "https://monitorportal.bjs.aws-border.cn";
    } else if (/(zhy\.(amazon|aws\-border)\.(com|cn))/.test(window.location.hostname)) {
        MonitorPortalRoot = "https://monitorportal.zhy.aws-border.cn";
    }

    const IGH = {};
    const GET_GRAPH_LINK = MonitorPortalRoot + "/mws?";
    const METRIC_WIDGET_URL_PARAM = 'metricWidget';
    const IGRAPH_LINK = {
        id: "igr",
        url: MonitorPortalRoot + "/igraph?",
        title: "View this graph in iGraph",
        category: "Monitoring",
        color: "black", backgroundColor: "yellow"
    };

    const IGRAPH_ZOOMER_LINK = {
        id: "zm",
        url: MonitorPortalRoot + "/igraph?GraphType=zoomer&",
        title: "iGraph Zoomer",
        category: "Monitoring",
        color: "white", backgroundColor: "blue"
    };

    const IGRAPH_MAXIMIZE_LINK = {
        id: "max",
        url: "",
        title: "Maximize Graph",
        category: "Monitoring",
        color: "white", backgroundColor: "blue"
    };

    const IGRAPH_CSV_LINK = {
        id: "csv",
        url: MonitorPortalRoot + "/mws?OutputFormat=CSV_TRANSPOSE&",
        title: "Download data in CSV format",
        category: "Monitoring",
        color: "black", backgroundColor: "yellow"
    };

    const IGRAPH_DATA_TABLE_LINK = {
        id: "dt",
        url: MonitorPortalRoot + "/mws/data?",
        title: "View data for graph in tabular format",
        category: "Monitoring",
        color: "black", backgroundColor: "yellow"
    };

    const STYLES = '\
        .MPWcart {\
            font-family: Verdana;\
            font-size: x-small;\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANAAAAClCAMAAAAalYM0AAABIFBMVEV8ss19scyCtc+Ft9GFt9KIudKLu9SOvdWOvdaQvtaRv9eSvtWTwNeUwNeVwdeWwtiXwteXwtiZw9iaw9mbxNmcxNmcxdmdxdqextmfxtefxtqgx9agx9egx9mgx9qhx9Shx9Whx9ahx9ehx9mhx9qhyNWiyNWiyNaiyNqiydaiydejydejytijytmky9qlzNulzNymzNymzd2mzd6nzt+oz+Cp0OGq0OGr0eKs0uOu0+Sv1OSx1eWy1eW01+a21+a32Oe42Oe62ui82+m+2+m/3OrB3uvC3uvE3+zG4OzI4u3K4+7M5O/O5fDQ5O7Q5/HS6PLV6fPX5/DX6fLX6vPY6/TZ6/Ta7PXb7fbb7vbc7vbd7vbd7/ff7/ff8Pjh8fgIXhPUAAABaUlEQVR42u3dQUrEQBAF0EpsGPCS3n8tKDOTTrsYFBcOKAomP69v8FJVP52QJtNTBa3Rn9uaBKq5tREFGlNYhcYcBqo4UOWBehpoAJkhFQICAgICAgICAgICAgL6+ZpLhYCAgJJDQcqpkAqpkAoBAZkhLQcE9N+hsLXsmNJSbhyn5Sqs5YSClpNyv7vAYtsMie1jPuCZof3eh9xY3ViFgncKYtvWx9bnD2Nby4W0XNxLkq2dm3o4Tih889KfNwY6paXc/Rk6V9bK+wCwwkLB4wOQGTJDERW63HueEApAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQDtcLUozaTkgICAgICA7hbtraDkgIKCvU25Soc1WaK76fKJtZ6X6OCz5fnr/tZ2qqvb/p+b5NjvX3l4yOu1ya7KxtCVqgtYl7L/g6zUMNHrYb7R7b+sU5FmuvfUk0KXPrSftFdb++AYPU3GRDx3i6QAAAABJRU5ErkJggg==) no-repeat;\
            position: fixed;\
            z-index: 10000;\
            right: 20px;\
            top: 40px;\
            width: 135px;\
            height: 230px;\
            opacity: 0.9;\
            display: none;\
            border-radius: 15px;\
            border-bottom: 2px solid #58838ab3;\
            border-right: 2px solid #58838ab3;\
            background-size: cover;\
            line-height: normal;\
        }\
        .MPWcart a {\
            padding: 0;\
        }\
        .MPWcartCancel {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHdSURBVDjLpZNraxpBFIb3a0ggISmmNISWXmOboKihxpgUNGWNSpvaS6RpKL3Ry//Mh1wgf6PElaCyzq67O09nVjdVlJbSDy8Lw77PmfecMwZg/I/GDw3DCo8HCkZl/RlgGA0e3Yfv7+DbAfLrW+SXOvLTG+SHV/gPbuMZRnsyIDL/OASziMxkkKkUQTJJsLaGn8/iHz6nd+8mQv87Ahg2H9Th/BxZqxEkEgSrq/iVCvLsDK9awtvfxb2zjD2ARID+lVVlbabTgWYTv1rFL5fBUtHbbeTJCb3EQ3ovCnRC6xAgzJtOE+ztheYIEkqbFaS3vY2zuIj77AmtYYDusPy8/zuvunJkDKXM7tYWTiyGWFjAqeQnAD6+7ueNx/FLpRGAru7mcoj5ebqzszil7DggeF/DX1nBN82rzPqrzbRayIsLhJqMPT2N83Sdy2GApwFqRN7jFPL0tF+10cDd3MTZ2AjNUkGCoyO6y9cRxfQowFUbpufr1ct4ZoHg+Dg067zduTmEbq4yi/UkYidDe+kaTcP4ObJIajksPd/eyx3c+N2rvPbMDPbUFPZSLKzcGjKPrbJaDsu+dQO3msfZzeGY2TCvKGYQhdSYeeJjUt21dIcjXQ7U7Kv599f4j/oF55W4g/2e3b8AAAAASUVORK5CYII%3D);\
            z-index: 10002;\
            left: 125px;\
            top: -5px;\
            display: block;\
            width: 16px;\
            height: 16px;\
        }\
        .MPWremoveItem {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHdSURBVDjLpZNraxpBFIb3a0ggISmmNISWXmOboKihxpgUNGWNSpvaS6RpKL3Ry//Mh1wgf6PElaCyzq67O09nVjdVlJbSDy8Lw77PmfecMwZg/I/GDw3DCo8HCkZl/RlgGA0e3Yfv7+DbAfLrW+SXOvLTG+SHV/gPbuMZRnsyIDL/OASziMxkkKkUQTJJsLaGn8/iHz6nd+8mQv87Ahg2H9Th/BxZqxEkEgSrq/iVCvLsDK9awtvfxb2zjD2ARID+lVVlbabTgWYTv1rFL5fBUtHbbeTJCb3EQ3ovCnRC6xAgzJtOE+ztheYIEkqbFaS3vY2zuIj77AmtYYDusPy8/zuvunJkDKXM7tYWTiyGWFjAqeQnAD6+7ueNx/FLpRGAru7mcoj5ebqzszil7DggeF/DX1nBN82rzPqrzbRayIsLhJqMPT2N83Sdy2GApwFqRN7jFPL0tF+10cDd3MTZ2AjNUkGCoyO6y9cRxfQowFUbpufr1ct4ZoHg+Dg067zduTmEbq4yi/UkYidDe+kaTcP4ObJIajksPd/eyx3c+N2rvPbMDPbUFPZSLKzcGjKPrbJaDsu+dQO3msfZzeGY2TCvKGYQhdSYeeJjUt21dIcjXQ7U7Kv599f4j/oF55W4g/2e3b8AAAAASUVORK5CYII%3D);\
            display: inline;\
            cursor: pointer;\
            width: 16px;\
            height: 16px;\
        }\
        .MPWcart span, .MPWcart div, .MPWcart a, .MPWcart textarea {\
            position: absolute;\
        }\
        .MPWcartMessage {\
            display: none;\
            background-color: #D4E7FF;\
            border: 1px solid #7EB0CC;\
            color: gray;\
            display: none;\
            height: auto;\
            left: 8px;\
            padding: 5px;\
            text-align: center;\
            top: 229px;\
            width: 109px;\
            border-radius: 0 0 10px 10px;\
        }\
        .MPWcartDragDrop {\
            color: gray;\
            font-size: 9px;\
            left: 0;\
            top: 20px;\
            width: 135px;\
            text-align: center;\
            display: inline-block;\
        }\
        #MPWcartAlarmState {\
            font-size: x-small;\
            padding: 1px 2px;\
            font-weight: bold;\
            text-align: center;\
            width: 100px;\
            top: 22px;\
            left: 16px;\
            z-index: 10002;\
        }\
        .MPWcartAlarmStateALERT, .MPWcartAlarmStateALARM {\
            border: 1px solid red;\
            background-color: #ffbbbb;\
            color: red;\
        }\
        .MPWcartAlarmStateOK {\
            color: #669966;\
            border: 1px solid green;\
            background-color: #bbffbb;\
        }\
        .MPWcartAlarmStateSUPPRESSED, .MPWcartAlarmStateAUTO_SUPPRESSED {\
            border: 1px dashed red;\
            background-color: #ffbbbb;\
            color: red;\
        }\
        .MPWcartAlarmStateAT_RISK {\
            border: 1px dashed green;\
            color: #669966;\
            background-color: #bbffbb;\
        }\
        .MPWcartAlarmStateUNKNOWN, .MPWcartAlarmStateMIDWAY_ERROR, .MPWcartAlarmStateloading {\
            border: 1px solid black;\
            color: grey;\
            background-color: white;\
        }\
        .MPWcartEmpty:visited {\
            color: #32719D;\
        }\
        .MPWtopCartButton {\
            top: 10px;\
            left: 20px;\
            z-index: 10002;\
        }\
        .MPWcartButton {\
            top: 98px;\
            left: 20px;\
            z-index: 10002;\
        }\
        .MPWcartButton input, .MPWtopCartButton input {\
            width: 91px;\
            margin-bottom: 8px !important;\
        }\
        .MPWcartBigIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAwCAYAAABZq4foAAAMFGlDQ1BJQ0MgUHJvZmlsZQAASImVVwdUk8kWnr+kEBJaIAJSQm+C9Cq9FwHpYCMkAUIJkBBU7MiigmtBRQRFRVdAFFwLIGvFriyCvT9QUVlZFws2VN6kgK6vnXfPmX++3Ln3zncnd+bMAKBozcrNzUKVAMjm5wuiAn2YCYlJTFIfIANdQAVE4MxiC3O9IyPDAJSx/u/y7iZAxP01S3Gsfx3/r6LM4QrZACCREKdwhOxsiA8BgKuzcwX5ABA6od5gTn6uGA9BrCqABAEg4mKcJsXqYpwixZMkNjFRvhB7AUCmsliCNAAUxLyZBew0GEdBzNGaz+HxId4CsQc7ncWB+D7Ek7KzcyBWJENsmvJdnLS/xUwZj8lipY1jaS4SIfvxhLlZrHn/53L8b8nOEo3NoQ8bNV0QFCXOGa5bfWZOqBhTIT7KTwmPgFgF4gs8jsRejO+mi4JiZfaDbKEvXDPAAAAFHJZfKMRaEDNEmbHeMmzLEkh8oT0azssPjpHhFEFOlCw+WsDPCg+TxVmRzg0ewzVcoX/0mE0qLyAYYlhp6KHC9Jh4KU/0TAEvLhxiBYi7hZnRoTLfh4XpvuFjNgJRlJizIcRvUwUBUVIbTD1bOJYXZsVmSeaCtYB55afHBEl9sQSuMCFsjAOH6+cv5YBxuPxYGTcMVpdPlMy3JDcrUmaP1XCzAqOk64ztFxZEj/lezYcFJl0H7FEGKyRSNte73PzIGCk3HAVhwBf4ASYQwZYCckAG4HUNtg7CX9KRAMACApAGuMBSphnziJeM8OE3GhSCPyHiAuG4n49klAsKoP7LuFb6tQSpktECiUcmeApxNq6Je+BueBj8esFmizvjLmN+TMWxWYn+RD9iEDGAaDbOgw1ZZ8EmALx/owuFPRdmJ+bCH8vhWzzCU0IP4RHhBqGXcAfEgSeSKDKr2bwiwQ/MmWAq6IXRAmTZpXyfHW4MWTvgPrg75A+54wxcE1ji9jATb9wT5uYAtd8zFI1z+7aWP84nZv19PjK9grmCg4xFyvg/4ztu9WMU3+/WiAP70B8tsRXYQew8dgq7iB3FWgETO4G1YZ3YMTEer4QnkkoYmy1Kwi0TxuGN2Vg3Wg9Yf/5hbpZsfvF6CfO5c/PFm8E3J3eegJeWns/0hqcxlxnMZ1tNYtpa2zgBID7bpUfHG4bkzEYYl77p8k4C4FIKlWnfdCwDAI48BYD+7pvO4DUs97UAHOtmiwQFUp34OAYEQAGKcFdoAB1gAExhPrbAEbgBL+APQkAEiAGJYBZc8XSQDTnPAQvAUlACysBasBFUgW1gJ6gH+8AB0AqOglPgHLgMusENcA/WRT94AYbAOzCCIAgJoSF0RAPRRYwQC8QWcUY8EH8kDIlCEpFkJA3hIyJkAbIMKUPKkSpkB9KA/IocQU4hF5Ee5A7Shwwgr5FPKIZSUVVUGzVGJ6POqDcaisagM9E0NA8tRIvR1WglWovuRVvQU+hl9Abai75AhzGAyWMMTA+zxJwxXywCS8JSMQG2CCvFKrBarAlrh//zNawXG8Q+4kScjjNxS1ibQXgszsbz8EX4KrwKr8db8DP4NbwPH8K/EmgELYIFwZUQTEggpBHmEEoIFYTdhMOEs3Df9BPeEYlEBtGE6AT3ZSIxgzifuIq4ldhMPEnsIT4mDpNIJA2SBcmdFEFikfJJJaTNpL2kE6SrpH7SB7I8WZdsSw4gJ5H55CJyBXkP+Tj5KvkZeUROSc5IzlUuQo4jN09ujdwuuXa5K3L9ciMUZYoJxZ0SQ8mgLKVUUpooZyn3KW/k5eX15V3kp8nz5JfIV8rvl78g3yf/kapCNaf6UmdQRdTV1DrqSeod6hsajWZM86Il0fJpq2kNtNO0h7QPCnQFK4VgBY7CYoVqhRaFqwovFeUUjRS9FWcpFipWKB5UvKI4qCSnZKzkq8RSWqRUrXRE6ZbSsDJd2UY5QjlbeZXyHuWLys9VSCrGKv4qHJVilZ0qp1Ue0zG6Ad2XzqYvo++in6X3qxJVTVSDVTNUy1T3qXapDqmpqNmrxanNVatWO6bWy8AYxoxgRhZjDeMA4ybj0wTtCd4TuBNWTmiacHXCe/WJ6l7qXPVS9Wb1G+qfNJga/hqZGus0WjUeaOKa5prTNOdo1mie1RycqDrRbSJ7YunEAxPvaqFa5lpRWvO1dmp1ag1r62gHaudqb9Y+rT2ow9Dx0snQ2aBzXGdAl67rocvT3aB7QvcPphrTm5nFrGSeYQ7paekF6Yn0duh16Y3om+jH6hfpN+s/MKAYOBukGmww6DAYMtQ1nGq4wLDR8K6RnJGzUbrRJqPzRu+NTYzjjZcbtxo/N1E3CTYpNGk0uW9KM/U0zTOtNb1uRjRzNss022rWbY6aO5inm1ebX7FALRwteBZbLXomESa5TOJPqp10y5Jq6W1ZYNlo2WfFsAqzKrJqtXo52XBy0uR1k89P/mrtYJ1lvcv6no2KTYhNkU27zWtbc1u2bbXtdTuaXYDdYrs2u1f2FvZc+xr72w50h6kOyx06HL44OjkKHJscB5wMnZKdtjjdclZ1jnRe5XzBheDi47LY5ajLR1dH13zXA65/uVm6ZbrtcXs+xWQKd8quKY/d9d1Z7jvcez2YHske2z16PfU8WZ61no+8DLw4Xru9nnmbeWd47/V+6WPtI/A57PPe19V3oe9JP8wv0K/Ur8tfxT/Wv8r/YYB+QFpAY8BQoEPg/MCTQYSg0KB1QbeCtYPZwQ3BQyFOIQtDzoRSQ6NDq0IfhZmHCcLap6JTQ6aun3o/3CicH94aASKCI9ZHPIg0icyL/G0acVrktOppT6NsohZEnY+mR8+O3hP9LsYnZk3MvVjTWFFsR5xi3Iy4hrj38X7x5fG9CZMTFiZcTtRM5CW2JZGS4pJ2Jw1P95++cXr/DIcZJTNuzjSZOXfmxVmas7JmHZutOJs1+2AyITk+eU/yZ1YEq5Y1nBKcsiVliO3L3sR+wfHibOAMcN255dxnqe6p5anP09zT1qcNpHumV6QP8nx5VbxXGUEZ2zLeZ0Zk1mWOZsVnNWeTs5Ozj/BV+Jn8Mzk6OXNzenItcktye/Nc8zbmDQlCBbuFiHCmsC1fFV5zOkWmop9EfQUeBdUFH+bEzTk4V3kuf27nPPN5K+c9Kwwo/GU+Pp89v2OB3oKlC/oWei/csQhZlLKoY7HB4uLF/UsCl9QvpSzNXPp7kXVRedHbZfHL2ou1i5cUP/4p8KfGEoUSQcmt5W7Lt63AV/BWdK20W7l55ddSTumlMuuyirLPq9irLv1s83Plz6OrU1d3rXFcU7OWuJa/9uY6z3X15crlheWP109d37KBuaF0w9uNszderLCv2LaJskm0qbcyrLJts+HmtZs/V6VX3aj2qW7eorVl5Zb3Wzlbr9Z41TRt095Wtu3Tdt722zsCd7TUGtdW7CTuLNj5dFfcrvO/OP/SsFtzd9nuL3X8ut76qPozDU4NDXu09qxpRBtFjQN7Z+zt3ue3r63JsmlHM6O5bD/YL9r/x6/Jv948EHqg46DzwaZDRoe2HKYfLm1BWua1DLWmt/a2Jbb1HAk50tHu1n74N6vf6o7qHa0+pnZszXHK8eLjoycKTwyfzD05eCrt1OOO2R33Tiecvn5m2pmus6FnL5wLOHf6vPf5ExfcLxy96HrxyCXnS62XHS+3dDp0Hv7d4ffDXY5dLVecrrR1u3S390zpOX7V8+qpa37Xzl0Pvn75RviNnpuxN2/fmnGr9zbn9vM7WXde3S24O3JvyX3C/dIHSg8qHmo9rP2H2T+aex17j/X59XU+in507zH78Ysnwief+4uf0p5WPNN91vDc9vnRgYCB7j+m/9H/IvfFyGDJn8p/bnlp+vLQX15/dQ4lDPW/Erwafb3qjcaburf2bzuGI4cfvst+N/K+9IPGh/qPzh/Pf4r/9GxkzmfS58ovZl/av4Z+vT+aPTqayxKwJFcBDDY0NRWA13UA0BLh3aEbAIqC9O0lEUT6XpQg8J+w9H0mEUcA6rwAiF0CQBi8o9TAZgQxFfbiq3eMF0Dt7MabTISpdrbSWFT4giF8GB19ow0AqR2AL4LR0ZGto6NfdkGydwA4mSd984mFCO/3283EqKtTcS74Qf4JrF5srPmkm7gAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAIDaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA1LjQuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj44NDwvZXhpZjpQaXhlbFlEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOlBpeGVsWERpbWVuc2lvbj4xMzQ8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KQfBfzAAAC41JREFUaAXtWmlsXNUVfsu8WTweZxw7GyEJLs1qaAoJZGlobJoFtYoqgYJoEWr5USh/2h+thCqkMqnUiiIVtaAKRVWhBLHUJkIVSUoLyjhL0zRxnDjJ2I5X7PEynnmzv5n35q095848x3Y8tceecUzUq3nz7n7O/e6555x776Oo/4cZI0BPVdMwjCnzp6o7OY+maWNy3h2Z9ng8zFyAQlDm2n4hAzuFBBm0MQvZeLKRYhrbDhlvf/vgUjvrWGsklPbv16/nAT2aukOkDYDJLjlcPgNxab/LQu+yWxgdZpijGYqh8afrtEZRBFgGCrDQfJsxHSoKGYUNJzInrw4ErpZzi4QDW+/iF7KkFMybxzBw3NSp9sD94Yx8GcDDkIFHzT0avDUdArzJP8YhhWlSlqunwNvwR1MfH2xoYBvg8XoNS8EMLeAGzO6saFAypTwhq9TXJU03JEW1yqrGSgo+KpNRNEbRdFrWdFXVdBnjiq5TkGYUnYDN6gbF4jgrHdadnl17djRStSy1NGRfwGMvmDX6aNsXK/h0mlrlcD1aXWZbvbjCrthohraAvOFywwCrEeI6A3ZOgrhu0LoDywxVt8iGYWcYZm2Vy7G3nGMXKzpFB5LpX692O1/2+nyO+tpagXRyJ/y933yjusEXLJ/jWLiRuPgmrkkMCVE+fbS16+7Dh5s5r/HlW4qommAYtxq/965erTSBggpYqdCH6KWhmLAXlm4A2htpWUl2jEaexn4hSZanSWMhv4FXNHhEh+d4nwAYo8iOxaaSB4uoF/o0NWWHH8movWARY5iycZbycrt1T4Pf74D+UOAmEM22WFj/yCME/NM9Xl/5sTM3hcjklMlQ8QEPVDAzCn2H6ijilXX6h9ORtKKDi4FuhVFu5Xav1a0PYn9NTU0LWrpMoNCCXxnmH3/sK0veYKsXb3j+0iVLw7iVwTy/datSKEDj67cdOkTA+rDXCEdT6TMypOCn2a3Wmspyxw6oS7vq6sb8ufFtF1p82/4DT6+qWvTOKrfriTKWWXFXknUWnUdznbcOhdbzgngdHTAMEVE69s65KytfP3HCBskxXVB0BubQoSk53aPhnVFJ7Ue+eUGKXuoffY7yerN+Yk6NFGUAoJCQBr155ZIb4He9Cx6rivyzDLtz/fIVtdf9GgtLsSi05oDLLU2R5ydBp1Ien9VVVvYDt41dDf4ihlHQJeep+np0zBlzu1acAWT3fqQvIaO2q2hUgKqTYyuWux27WzOsxeWqW3BKvhH2s4hM249XrLNb6McwTtMUGqS/blm17DqCCVlZ+LCwWMEUZ2/3wH2BlNgDhMh+KCSkL5z6IlADdCaY5WLRnUM/Y/yMJNIvwsYFpchIZmTeNxx8BPv1mstwDkTyNR2TnB4+8WIqAxsiUF5pTU92hZMHsZFheIojyfk4KCAfcCG8tAZiNZF05oqpZ2FyLx1v612T5Xeini0m8waaXiSiaXoLTFMSRdrK0OVW2jhAebwWmvYgT2OgFjC2Ile9ubzcVuYpp437Giw2Fd0eUTXO//TzjkCOYPGXoDkSc7bOdQ3vH4ynoqDsiWhH01J3S//IJqwHdW67z2XyefLG4GY+LXWYUsWnRP/ZnuFdyKc58RgvSTCl5k/nry3rCMaP4zkPLEVFVFSpazTyAhClvX19t/UkwuRx2ZEjzs5w8gM8VwJ9IcMJijEcTf4KgYGsKfeGxVyGaEkIoR9tv380lEieTKRlMil2C2urKLPV/+yT5qrQxfSsdwuksyL9vbJhi6vSZlmJjhRscThJVdsHoumPsPtGkjUPdwnmzL3X0rtmOCmegjQJoqJ0XOob3I7MeG/jSQQwQwTEF4g9Cm5OPzKHUuWPCK8gb7nyKfVq0U8ycTMKgYV3v2+If80NytPBsW5QoOtcDsd3KOq5S3UUhboMqszD7GUBoNGnaoM7AgQEQ2WZda/dyq7GuE4Z/rgif4JxCAjU/El/bnbAT+mz88nUPxE99PSGEoLv02tdz3i83qzemkfL6AGJMn3Ba8P8xpiUuYJ8yaDdQ5Lc87eO3vWIFGTlNUBFlywkCBKDBoaBtzQQib9VpqgPOTiLu4zj1lVXODd6LiQ4qCbhNE8p79hJkYMnyxMBotrpqHdw3Ga4WFAzBm0ZiaR6hkJCMEdyTPqKzEL+7hAsLD3n96/kwdGDNJGuYEL8BeZDEgGbt2Dy86/uwNKoKHkhbWRUVRkUJNnbMfASMgJZOHd556+o1nCqkUcF2QmugwunC4lZLfTWT33+xe+fvVbe3NxMADMvd5HZEj1Imox1lbtsh52zbAOpgosZjQ3Fkkowle7K8Y5A3RbJIjN0+LPmRTdG+Y+JdwpIJDJKuG0wvJ06fJiDJFEDCFCO2ZK8zP7/0RpwRpLpDyENFlDLRIAp7w3/6T8ev7AcCZv1SsLEdJ0icXw+b+9Zx6ekjyBuwDWa5o/GfzmubUmBInRyk9EN7kJaUXmUKkFRjfbRaO/Rls49WAdYm3aVlZxRYALdCK0/FNuyrKK80WZla2JiZgguN/5D0yyIvM7A9VpRRf+m3b8Zg4EqHMtudFrZWgvLGimDsrQNBH7+8D0rfpcDCn2ZovIxTiBmFgVGULqIFQomUy/Bpa25FYPs2xOQgd5wwn+ipWs3jsJ0KaYb0bSiN10H05XnZovMWF8w3ajqegu2Aaf55rRP18kcytG/g3NIdNJBmCgebtQToBKOD0aTT0Vk6jJ2TU5LZ0CjJH7WZLoAmOl3dV4f4hudDuuDIPCjdivXjmV4lAM2SKNo+AIluyQRXAIw+tJwQQ7xbBL/cQIgEBVC4hqsoFwdMgMaZtAS/InQLgkXXHGapSNwlx5WNTk6KgjXvvnqscDb39uX1wGdPAZMl1xnjScKnrtlDbdsH2cxnoVD+v4ftvX/lrrcndjxyFYGN41qIKZnbH69c2Sd0bQpZOCOdizUtmXRGsvIE/H5aDhYQ7DySi4ev4hr1rhXL12aqq+pkfL0dEv2vILV0OCzKl+lVwwnk8wSe9mme6oq03dXOrr7YrHE3nvvjd/C3dwyaF8wuCwG5y/fWL4cP31C6cbx4oNgzgz8ufEw99bo7wTiwruSqg3AAeEVQVZOwlnST+Csy40DgoeFp9DPCMy9H9Mbju0Di/uWKCv/BoNyGq7k3mwfgetgCDnA5j6IUvZgMvn6iS4bn0z/AdITArgS6lAs8SrwQIwOFBYk9Wb9GwH+W6mMTC5MxhOIpsQ+n59/GMcI+QXpqlLiMmXfwCABYYBPfFdRtTgOBHxDuNUgW0YJ06Ks9vXx/IZCBwRNifML7eiokP499gUBvoYy8CAUH7KBiIuZlylP9hQU8gqaDOSp5K4DEhkfbBz9AOiLCshTwQqCw0p4wD2iwbF0ldNq35arX4hOgS5pwzccWQUW9j5sb1BkctDaj1l8oPVQzzO9rtnqq3kHi2UtaH3QUk2eWQAHDDxN26BsViH3pW/eJQaDNXS3u5BJmMDHfIJFwBFlvRXMUhS4QCUOq5A4p3jdD59c6pGUmLqY43AymBMYn5QgAGw6+9kgnCT4sAyAw5t47BcfEjSNal5b9YYwmyVo9jEvb5PB186dc4wkhCNoxyGYhxEG6DFpOCb8BpghIEFZIWCNbYTbQ9E6UPBdpPdxf3FR6rwyFHwABwvZeaVvXsCYCRHz/OpUj//x/pigJcWMCkcl3XDe1TSSTL1wNhRy5QZTEFAmbRPg3tHYvnhK/AtcklyErxAvRFOZP7cNhfdCPdMQmE0Kes+KqYIo5CrjQP7e3W29MDiorS2vWl1hK3vWZbeFljhtZ4KC6q9fn/1mHuvNVgGP58sLZ2XVwWBVKpWixP6acH09bS5HHPOs9dZ4GiWPm7M/mRDm5yubXPd/pXP93KKLi9H3vEnW5AEC8+aAyEyDNOXdy01uO5N0DhyTBn4r++WQpqkGV4yZnqrfUub9F9RdM1xrGrG0AAAAAElFTkSuQmCC);\
            position: absolute;\
            top: 43px;\
            left: 23px;\
            width: 75px;\
            height: 48px;\
            z-index: 10000;\
        }\
        .MPWcartNumItems {\
            color: white;\
            font-size: 25px;\
            font-weight: bold;\
            left: 0;\
            top: 44px;\
            width: 135px;\
            height: 35px;\
            display: inline-block;\
            text-align: center;\
            z-index: 10000;\
        }\
        .MPWcart textarea {\
            position: absolute;\
            color: white;\
            top: 0px;\
            left: 0px;\
            opacity: 0.1;\
            filter: alpha(opacity=10);\
            width: 135px;\
            height: 100%;\
            z-index: 10001;\
            cursor: default;\
            resize: none;\
        }\
        .MPWcart .MPWmoveCartToBottomIcon {\
            background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 448 512\'%3E%3Cpath fill=\'%23888888\' d=\'M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z\'/%3E%3C/svg%3E");\
            width: 18px;\
            height: 20px;\
            top: 212px;\
            left: 60px;\
            background-size: contain;\
            cursor: pointer;\
            z-index: 10002;\
        }\
        .MPWcart .MPWmoveCartToTopIcon {\
            background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 448 512\'%3E%3Cpath fill=\'%23888888\' d=\'M240.971 130.524l194.343 194.343c9.373 9.373 9.373 24.569 0 33.941l-22.667 22.667c-9.357 9.357-24.522 9.375-33.901.04L224 227.495 69.255 381.516c-9.379 9.335-24.544 9.317-33.901-.04l-22.667-22.667c-9.373-9.373-9.373-24.569 0-33.941L207.03 130.525c9.372-9.373 24.568-9.373 33.941-.001z\'/%3E%3C/svg%3E");\
            width: 18px;\
            height: 20px;\
            top: 0px;\
            left: 60px;\
            background-size: contain;\
            cursor: pointer;\
            z-index: 10002;\
            display: none;\
        }\
        .MPWmanageCartBox {\
            position: absolute;\
            background-color: #D4E7FF;\
            border: 1px solid #7EB0CC;\
            border-right: 0px;\
            color: gray;\
            width: 0px;\
            height: 210px;\
            left: 0px;\
            top: 10px;\
            text-align: center;\
            border-radius: 17px 0 0 17px;\
            overflow: hidden;\
        }\
        .MPWmanageCartBox .MPWmanageCartCloseIcon {\
            background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 512 512\'%3E%3Cpath fill=\'%23AAAAAA\' d=\'M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm113.9 231L234.4 103.5c-9.4-9.4-24.6-9.4-33.9 0l-17 17c-9.4 9.4-9.4 24.6 0 33.9L285.1 256 183.5 357.6c-9.4 9.4-9.4 24.6 0 33.9l17 17c9.4 9.4 24.6 9.4 33.9 0L369.9 273c9.4-9.4 9.4-24.6 0-34z\'/%3E%3C/svg%3E");\
            width: 20px;\
            height: 20px;\
            top: 85px;\
            left: 6px;\
            background-size: contain;\
            cursor: pointer;\
        }\
        .MPWmanageCartBox .MPWmanageCartOpenIcon {\
            background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 512 512\'%3E%3Cpath fill=\'%23AAAAAA\' d=\'M256 504C119 504 8 393 8 256S119 8 256 8s248 111 248 248-111 248-248 248zM142.1 273l135.5 135.5c9.4 9.4 24.6 9.4 33.9 0l17-17c9.4-9.4 9.4-24.6 0-33.9L226.9 256l101.6-101.6c9.4-9.4 9.4-24.6 0-33.9l-17-17c-9.4-9.4-24.6-9.4-33.9 0L142.1 239c-9.4 9.4-9.4 24.6 0 34z\'/%3E%3C/svg%3E");\
            width: 20px;\
            height: 20px;\
            top: 85px;\
            left: 6px;\
            background-size: contain;\
            cursor: pointer;\
            display: none;\
        }\
        .MPWmanageCartBox .MPWrefreshCartIcon {\
            background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAARCAYAAADQWvz5AAAACXZwQWcAAAASAAAAEQAIFT2JAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAArwAAAK8AFCrDSYAAACVklEQVQ4y2P4//8/AzUwgoEGtOf45dusjjvtuib9r/uytO9aEwN3qvf4eqOrw2uQwdrIqR5HC/+Fnmn9n3S5/X/G1Z7/Ex+s/u+8IvOL5pTAJKIM0lkcHKe/LPC5/qrwcr3lwf5AfqfX9rxvlTdm/J/ycO1/l6XZn9X7ojStF6Vvt1mccRS3QQuDJ5gdTpREtlV3Wax14I6KbyBXzXu89b9qi/f7tc+O/PdZWPSZYBihA42JIUUTbq76v+Lp3v+rn+39f+Dtmf/Wk1IuYzXI7GgGp9nROCZ0Q3QWJ4ooNwVUha+u+Lfp5eH/m18dBxuk3hC4EcMgrZmBoSl7G39k72v+Gbqv9LH7loxThssiNgDDyBAYW1M2vTzw/8T7S/9Pf7gKpC+D2Qrlgf0YBmlO8Zn4/Mfb/+c+3vl/+N0loK1H/k9/tOG/1ky/iZpTwgz1Z0XNc1yUdTxwVeWD2BXVP8KXVHxXbgkMwjDIcFbg5pufHv7f9vLE/00vgQG5Mvuv5rTQUmDMCaF71ezoZkal2hh2rNHvuSzj6qn31/5vfHH4/6qn+//Xnpn9X3tOWAGhSMAwKHhDybc5D7f815rq+27xk+3/++4v/++5Lv+HzsJoa9QUHyejOSWyCqdBdiszz9luyNgEDHRNxyVpX5tuz/9fc3P2f5fV2T+Aqblboz8iWLUrtEa9K+yFel9wFFFZRGdxjJPjsvTPRdcn/88BZo/UK+3/Q8+1/nfeU/wPGPATiM5rIKA5LVxVrdN7hfWCxE+WixJ/6fSHHVdt88smGEZUK0YoxQATSWyMvwe1dwAAAABJRU5ErkJggg%3D%3D) no-repeat scroll center;\
            width: 20px;\
            height: 20px;\
            top: 188px;\
            left: 6px;\
            background-size: contain;\
            cursor: pointer;\
        }\
        .MPWmanageCartBox .MPWrefreshCounter {\
            width: 24px;\
            height: 2px;\
            box-sizing: unset;\
            top: 182px;\
            border: 1px solid #AAAAAA;\
            left: 3px;\
        }\
        .MPWmanageCartBox .MPWrefreshCounterPercent {\
            height: 2px;\
            background-color: #AAAAAA;\
        }\
        .MPWmanageCartBox .MPWtimeSinceLastRefresh {\
            top: 171px;\
            left: 2px;\
            color: #888888;\
            font-size: 8px;\
        }\
        .MPWmanageCartBox .MPWmanageCartGraphContainer {\
            width: 95%;\
            overflow-x: auto;\
            top: 20px;\
            left: 35px;\
            margin-right: 10px;\
            padding-bottom: 10px;\
        }\
        .MPWmanageCartGraphContainer img {\
            max-width: 300px;\
        }\
        button.MPWbutton:active, a.button.MPWbutton:active, input.MPWbutton[type="submit"]:active, input.MPWbutton[type="reset"]:active {\
            -moz-box-shadow:none;\
            color:black !important;\
            text-decoration:none !important;\
            top:1px;\
        }\
        button.MPWbutton, input.MPWbutton[type="submit"], input.MPWbutton[type="reset"] {\
            height:19px;\
            cursor: pointer;\
        }\
        button.MPWbutton, a.button.MPWbutton, input.MPWbutton[type="submit"], input.MPWbutton[type="reset"] {\
            -moz-background-clip:border;\
            -moz-background-inline-policy:continuous;\
            -moz-background-origin:padding;\
            -moz-border-radius: 6px;\
            -moz-box-shadow:1px 1px 2px rgba(0, 0, 0, 0.15);\
            border-radius: 6px;\
            background:#D4D484 url(https://monitorportal.amazon.com/images/lib/dtux.amazon.com/secondary_action_button_bg.png) repeat-x scroll 0 0;\
            border-color:#959567 #898958 #7C7C4D;\
            border-style:solid;\
            border-width:1px;\
            color:black !important;\
            display:inline-block;\
            font-family:Lucida Sans Unicode,Lucida Grande,Verdana,Arial,sans-serif;\
            font-size:11px !important;\
            line-height:15px !important;\
            margin:0;\
            overflow:visible;\
            padding:0 6px;\
            position:relative;\
            text-decoration:none;\
            text-shadow:0 1px 0 rgba(255, 255, 255, 0.5);\
            vertical-align:middle;\
            margin: 3px;\
        }\
        input.MPWbutton.primary[type="submit"], input.MPWbutton.primary[type="reset"] {\
            background-color: #FFC435;\
            background-image: url("https://monitorportal.amazon.com/images/lib/dtux.amazon.com/primary_action_button_bg.png");\
        }\
        .igraphMessage {\
            border: #A9A9A9 2px solid;\
            margin-top: 5px;\
            padding: 3px;\
            background-color: yellow;\
            text-align: center;\
            width: 99%;\
        }\
        div.iGraphBackground {\
            background-color: #E8F3FA;\
            position: absolute;\
            z-index: 10010;\
            display: none;\
            opacity: 0.9;\
        }\
        div#iGraphBackgroundTop {\
            -moz-border-radius: 3px 3px 0px 0px;\
            border-top: 1px solid #333333;\
            border-right: 1px solid #333333;\
            border-left: 1px solid #333333;\
            height: 24px;\
        }\
        div#iGraphBackgroundLeft {\
            border-left: 1px solid #333333;\
            width: 5px;\
        }\
        div#iGraphBackgroundRight {\
            border-right: 1px solid #333333;\
            width: 5px;\
        }\
        div#iGraphBackgroundBottom {\
            -moz-border-radius: 0px 0px 3px 3px;\
            border-bottom: 1px solid #333333;\
            border-right: 1px solid #333333;\
            border-left: 1px solid #333333;\
            height: 24px;\
        }\
        div#iGraphBackgroundBottom div {\
            margin: 5px 10px 0px;\
        }\
        div#iGraphMaximizeIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNAay06AAAAAWdEVYdENyZWF0aW9uIFRpbWUAMDkvMzAvMTDV/ukiAAADCXByVld4nO2czW7aQBDH/67USyvueQcqQSJQydEmQKwAIYmSNtxCKrnFJKKB8HXKM/TUa6VWufURemhvfZDeqrxB3dkFIzDkkK7wNGJGstfjj/3N7K5nF9jl559vd2ijHQQBlHz+/cFaRfqx6lnPMS/WJH1xt7EybpgO3t/PXyU3TJWc4RWySMNFHjn08SRmfhI1vIM9TePmv0QKezgicg9VSuPm5+HgAqdUCwOMUJ/jxy1FdFj5LXRZ+dH2F7fsY4eVn6QowMm34bHy88z1f44tVr6HMiv/LRLM7S/Jyq9Rb8TJr9IbwMnvocLKz9FIiJN/xBx/KpHxT9ySQIO5/nn7vzRz/zdCgZXvMsefDvXAvPG3tdbjH24+d/wbMMefAXv7y611/LlmHv9sM8d/7vj3mizg/fw3ZOVfMscfh3n812Tuf8o0AuPkbzJ///iGvf2lmdufz8o/RImV3zZ6/60l8rAcMkbf/5jzS0b9rznfRZGVXzEafy3SHsrvG8Ufc34m8vtb3PwmWcDJNxt/m/N7hvHHlG82/jHnXxi+/6Z8s/GXOT8gEb7wHyvftP993HxzEb7whS984Qtf+MIXvvCFL3wO/s2vDTY7flj47nduY+cGERG+8IUvfOELX/jCXze+iIiIyP8in55aX75e3T4L14q72KF9brJ2fBDR+3o+UQceavq8p+c32hHdR1bfv03nGtiitIMT7KJFd9RxTJualXGJg3ueV3oCe3rtXIq0Ik5pX6f7HQzpqERHNp1T+rXWC7Qvaz2v9RztG7Q5ZEu4Eryi1wKPPcrodbGL6byns3qWLNqf5HSgfVI+FHFIV86JeEKb8nV23f1ijnk0iZSiYwdVymuX7LPpeY/09tSTOm02utpzV3ui7u9OrzfIE1+XkSotl44q2u/ouvtx6ug5mKGPypLhP9Wq0sM6GZfpIicx026W5zhr6aJlI2PLVJn509ZxRRapUj7WpabO9HQpZqal6s6UqqefCPUzfX1z7p8EbLKppj3oTTzpz1le0JapOVfLUmXxXzEMpJjgHgM1AAAASG1rQkb63sr+AAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAppDOhAAA5M21rVFN4nO1923PbxpI+NieOI9mW7WQr+7Avqtr91e/p5OBKgo8iKUpKKImHoGw5Ly4QJGJufDuSrMTLwv++092D23AAAhBFUTYkW0NicBl83fNNd08PcPxr+3r+YujM5m7wYng8m2tBb9hJFMN/nszmltdoWtOGHZz3O/5cDV5R8fKo6891NTg8GmE53Hf8eVMPhs7ZjFW3D9gZfPwJBv3+9bw9YH86e6PLufK9MlY85bXSVlzlUpkpXnB0csy2P2bb37Pth2z7hTJRdpU+q32vTINh93QMJ907wXPvsSYbUztod49mczNoH7O2T1mBd9J29nEnpwe30HYO8Vu7T8WvWHRO+An2e/h9OMJ9e2381hticUIbnQHb1wvaI6oc0dlHDl3kmM5HxdEetPIEWqUG3VMNmtM91eE03VMDix7bqLNCp8KAIiiAzdMFbIbKB+UT2zZRpsrkpghp9x+hUHschouvXN1EezTfrKw/2g3R0W5Xf2J0bqg/IkZlNOiOMXrMMdpj+FwwJNrs7yeG1huO1fccqxjDPHSg3Ql4Gibhg/VL8bHNFD5qCh9DTyM0uWEf0wkhnRAyCSGTEDIDZ/AbSdVx2AdvzDac0m04ziluKIPhI47hiGnXX0zfPrH6ZXpm6DJFywdSa3Eo9bFXAkrPJihx+62BqbeKgbnDwewwhXvLfmfK7wwuV/movFE+c0C3Ekr5jn3+oHzIBVPjvVYzCtO+pprybqvmdFtLJSSRDwBJ3y3cc3W7MJaGrROWhjYpjV1+h25OCDrbI+SmKzIo1LzhUq9IdsUgqwrQP1k/ncFeKYBMiwDSxoJu+RwilTDy8joqqMVy3UJCTOAEbAo4oVLdAlCLuhV11KoddMhqx9hB3+eqmdZarZ6tdlC9HT37jmP0ko0FV1J0moKKCUZHnl0Gh6bw0e8cH2fQJvZ32guk/yjC6w3a9B7TGIacoE0dHDeB8j8XonuOl6Z7UsQEwm965VXKbBBkLsfMmJiFx87qnZJdULdcAhKGmvJIDpD8rxiab0sh6ZsFRk4/HDnBnigIZMRtHEi0SVaPI8DnhNYIkBuZJeEHQJbskvDDsDTED9PORRl4ccxY6k6gOpfGd8otEzgYAG41Vg3wkOGqT6eEmTho5GNWxUCWk6Ju5RrInl6+j0fmsaUTdIRhMey0aWFqjBRP91PQbUXQwQjyGcfSKr5Z2jVDF6Fi7KNIR9ZtbqWgU1IQLUOXodUgtBqEVoO6MhEgfBj7QleGMWZ4WALHh5G14ip/LImR2IRii1BEEy2BonpTFE1CkVRMCqPlEo56Do6WysMALR4HaHEkueI1uOY1zCwwaUsCTGZ0llPKEevpTCWVP8r04kJaWcx6lqsldmYYqMcr5z8cYLAPh0AOkyMNjT3L1bOLnfkN8l86XJWoKdzppVGEDQhXaRXDVdkoPZOi1MXA3piZ4PndelNx0teE04j14xlzT+4rTsbKcdqKcPrALJKrNQaG83is5ZkVnTQ+JKgEjUrQqASNStCoBaHZkaoQn40prz5prlfXP/uSR0YWIWQRQtaNKPsQvdfrJd7rps4wcJTYiI0wWQSTRTC5BJNLMLlS278H7iZOt4yAayTKdMHMr13lmH+aKhdFTLEypoNmTYtMNqhSJ790l5MbDtyctQkqm4x/mmvIDozkY3eIAaY3PND0BtkqjR1YjRi2BA8IpammDFnymxYMWWlnRF0sGhF3bxW74lCFPbIfQZStaGL8zZP1SIhaZ9JW7KNXCCbdmp4l7fo4kgSWKkaS7GkJPB+mzPz3q51zLziRJQyNa+imEViAYxKs7zhYpzBlwCHajtxzsK0g3LbMunKrJieAN7MMJkNwLUNXKAy1oUIvOJZagXAGbEULi4Ol2+T7oKezhw4bKl+jQZ6PCSWGE5di+DyBIUSMINnDQTvV5VZZ/hjhSgNsBSCFSFbO1IznEqg6B9XThfjahMeIaOBe4mEy1SVYbY6rTcB6NgHrcWA9W/TX4cMw/JDq4FQVfQgDTIMh90mHwzDE6SyG62SiCIN0a4HfmBSCXwjRRejnzrtmxEpMbveZhD0zkBB7LA0sEWlCUYo0DuIAMCr6kBS/KLzbEbxXGFOBZJTLIvZPOKkdJlto7rQAvkXsH0tgjDSzAt86mCiXDW7DLAduCJzmRzESBFBfzhQ/ymPIPB2jGP82K/JvoWGKh/Z8V8gR4HCa4xT9mjL6DeEUecLifpzFHTlWppMuKAo1JECdIadm/h2A1nwpJYcezoBB+Z59WlRXTfk7q50xyJfOJaXnyStHn/N8vxI2QFpR7aqBg0Vk/kOGDFPDPbb1in3/O/sEhjp4hksnOVaL2WrtphViFg7zHTbIv2X/w66b3FPmzqDbkmliuuUDCyUMzOJDTCGgsJ8C/y2OLWB5Qo1DZTFIw+H6IEo8mMGAfTvpw15xM71UtplgfXL6cwlIl4C0Fwx1bnoms81SgCYBfMIBfIkWzZRPTaIOChMaxaI3Qt5e5FcXC+DAFGNJbYxsHjSZbjQtKUUymjOPJ9owVhF+GJ4mhm2VRhNBSYtjXGzSSLdlekoBoBUiHM4ZGeG8r1UcYLlPacjmjLBnZ/X9cjCWccp9bj36aevRdwuAWMTdvGkASK6iugxB8sqTXlA02SZmSIZ8OeQW9gflncCXMAS9V3xIyoLhWoahZpmEYSONoVsCwoZUD6VGDU39VrFqQi1ME6bO1RBLA0vqvQ3efYuDFiocTZLkuyuGrNMKaZLy0UUtbl0j3y5iNTaXT5pHvoowaQ4Ei3jRB4M+kH1tT7l9DR8GIYZO6PoNQ46koEcxTMO8wB64MDJEx2bKuQ61r4x3nTteI4ayZAS5/8cxNWSYerbcYWnx6FqLJ3W0GhQpQrcknCNvx25KOGcuRMezQYy96X8xGF00KPPV06pq+5QYUcjnS8TeSmRhMf9Qqp6wvce392h7BCWO1k0+WDdJQ0NIUUEPyTUs19lfIZ75o0t6hC6UN1jGluSaOZZOhgqetHR0yQpMZGXIpDMwuSqix5yxFuSMQfUeB+pPaICHZvkDDqKhdCuktzWLrKMp4tIYaRMnDSBTFUkooljYTLclseBDGqPL4LQd48T8wAM0c/7MR0w6wBRbehRCpi3XOU86wGhTGRlqa4XscWTBvMEkaQg7TBdS70XYGlXnHLTis4CRr2I0yicFhobgMq/vMDSdDxdN52XQPY/G3Le46qPsNIN8hvDmqof55Il5BldqTYfKVyQSK47EUuULLZphNFmwaMAU7cCnbPsVBryWLT9dRQe2igdgBQxbyweNMD1VMKdX1H1DHYTc/BnGCm9dBxcyKQ2pErbs9GSXLx015POHQoKvJ6dAmT0ohnHiaS5uxSTj2KSu7AabFg3LjXLa+iTynD+gK/OGAc+XSOTr7OoS4vLGaVu6RA7iIAnE9TIzMFlaS/aNs+gELkNwJ4HgXxjE2cVIRWkMMTBYYrFrhKO53JWuPD8AvnKBQQiDEF5TkpCOST64IfwQTr8MuDEJt0gTsgnrUpw5XCaFn7gUXuCMl4fZr5c4+QAMDDHi3ZhgytMJLaUqqthSNkkrtmBNYahtkUtKWaAGjxEZPLTOSuQSLp7k+DbgwkkFM1FaiakyOz1TBvZ+0Ot3r+e95JMGfBSLgwG5WSKJ1EdxnOCcxjsU1FlmDRdHjwDpETf0CIfePmpxb9jFXYZDqjuk4hyKoJf04qhB/LEP4LEJTUrWnGXWVGuSTk1ixUHUouesPV10HzHh2niVmPK5jLjY4zkfMPR5yh+MR8LZi97BCwb8SYdOfsQ+HwzgCSw9esSKij9BokoLq/jzV6DuFdSpNz+PVvEUYRX89JIJVz5fUzHD2O4nvH9RbkOO3qIqJWuqyc0guRm13MrIbYfLbciQ8djdQtzkd0F6O5GMZPucFdinmkRdkqhbS7SMRLejnghzAWDLJP0aPzFPENad5dRVk5xJkjNryVXpiySBK7R/LkK8hL4o3+eswD43YldNq0VaRqSxbeVi/ky80NDnIf5w+1nG9mriskhcVi2tKtIaoBHpJZ4j5fPoRrj9LGN7NWk1SVrNWlpVpNVDRCYRHqFU4u1nGdurScsmadm1tMpI6wmX1j5/psxH5LekcfKEy0e2x9nSParJskWybNWyLCPLh1yWbZxMvYymWP3oiQ4XUa8Tt1aTk0dy8mo5lZHTVuTcQV+hBdKiQx7XiA55XFNNZhOS2aSWWZVR7SXma04XRrV4+1nG9mrSmpK0prW0qjjbg3ieK7LxtyPrMFl3llNXTXI+Sc5PNexxpEZTZax0URRvcBounG8P1UasP1tSX62RGo/0QtnVEoj2unrqm5H6Zqa+jeCsQXCAAewqavosoaaf2F5DTNV/hdkGlKQRK6sh1ZCWqo71pIaoP1uxmuVpoIfqI2jybV1kBWpeCeDnAsAJaMNtWRD/HDdirOqum3X/E59Vpytb4pG5MK/4QncFdajL+5gtg/NomPpxgPmC7KgE0A1Z23TV8NJtU3/W7bBWG7ea2jhda0bgaFPTZ99StY2wsuFOPVVLVzat7BNrYotE8d2/5t+VUmxxpYAasN6AsGM1MGWtaTXNhiZ0AiPqBOOJ7QlA2VFtw9OnWkN6I1N/MvYmi6K8mybclTi+JrOoEkA7CX0dI4Vd4aJXcaSQMoCqGja0X84Aqqq33GYWA7ARtiEe28g7tJlzqCa2qBCBbXTz70ohnnKFIMssGsuWGQ+xSostS4zoqgr/M5stE9xtXeSu4YUUmw+YYnulnPIl+78vJyW9pbpWK4NMmtKx+wbnuWvWjrg65u9lAIWUmteqIgAVO89dAbTNAUo8iZnVLWFrNlY3Go0surNVWxUJLaa7RkOEI0F3cGDTz6I7unCWqrF/Bdl6o5t/14pAbL3I0Rm6nd0e7vkW7CNFznPXlriD72G4FixxqYq1jBZreJaKmTr8ZqnY2BobYy1DxRqNRd2NVWwyhV8pCKDWdlGHbKObf1dq8ChSg488Mwper/NuOVkumhh6snKBbOIG626OZSgaJ8yXSlJNpqcgH7vuWdtXEfzd73Wv5/u9xLzmFFXhCJOaIRDTZn+v8YkypAI/oHKACryLEvRpf2QF/njW/YFzPe929uHPr6hifN0YPlTJxf26/FFALmYbTINu5wXb898U1rTEkU+VfcXHReCgbkfsCEqonvFHCdNR33JVnKaOfRK3PkofuqBRnh/3jdJULOGYfdYFmPWIS/dxsSorcY49o4VP8Hkyv6P9Gb7H7D0edxkdYaSOeIzPO7xkDnTW/uIV4mclylH7m6Ip6gJyDmIOXfUYkxev+IOFZ8jf4bU04ShaJpSSfUwF/KiHyn8xlHy45sJ1d3AN+p/czQFtmSwcv8WOVxO/huILd3yIxmr+GfzEr3iGpxhKhPfdMFyVHhq806XtEO/lUUr7jvHBd0dKlx/9/5Q50x+obTD8QQK68nf2Ga4En2DbBJ8+ZLNtTVZD17Bwzyb7q7Ea+BakrrqVQH6kfAYJZmjGdmLPl7hajvXHSLe1hb1jPYp0NqFBhtAXthIaJLZDF3A6RMuAHAyZtiRkJRzp4CLJCeqM7Mgs2WzjkXDUKZPz/5CM+HEP2HUg/nIpMMIjhtcnnKMCNiAuuspEdytiLRFbcc//z3TtD9aKHqIwRXfrgqNxyq70lqFHD0R7x1D8gCx0wbYlteuM7X9Cy0X5VR4leHg3wcRI3CU4+yHn7B6tYKvZuWbnmp2/aHYWcarZefPZeYh5t7/X7Fyzc83OXzQ7WzU73xt23orY+RNeD6ReM3TN0DVDf8kM3agZ+t4xdCIiXTN0zdA1Q3/RDK3VDH1vGHqbM/RvKP3f2DV+V/Sao2uOrjn6i+Zos+boe8PRoRWd4OiaoWuGrhn6i2Zoo2boDWNoSb+tM+9qzq45+845W9sQzq4z79bB2XFfvAln15l3NTvX7Pw1sXOdeXf/2LnOvKvZuWbnr4Gd68y7+8POdeZdzdA1Q39tDF1n3t0/hq4z72qGrhn6a2HoOvPu/jB0nXlXc3TN0V8fR9eZd/eHo+vMu5qha4b+2hi6zrzbNIbusr1AVgk8o+cME0PHDz5/ndpLZOubcO7yHuMyzW8pJvudsPPZK+kx+Vok9nJXyEHaSR2dNS41JdoXHrMsPza5Lz2YNeZf0dZJ7rvYSw2GgLUW3Qv1aTelK2V1L5yj5iPdV6drDSEiXETXgLn1W9I2+x5r2w7XtuTILlqj33N9g7xixv51ztqNbVFduEJti67HFtVKs926bVFD4J1sW1TUojpj7X5Zoo9jPmUMndDmGzD0kF1hhrjUDF0z9H1k6M2PFoisWzP0l8rQT2I+VSa5HP00heIucgO9qvBtKmbgIL4zrEse8TP8LnD2fzJ9b7N2+3hXxAivWfsvUOOAQ/5k36+iewZO/t+o9Q9Q/3fhb8keNWb+ncpqW9gzptijTGSbsEeB1+eyX5/1otD/h71t9t1n/WrC9k/3qO+VSUG/7IHiCn3jG3Y2S9jHW8JGorbejoYsk2gVLXmcWht6dzEli7OljzwJbNpkvybbP9QCg30aox5MIo6wkYl91Bdg15vFlCxhXKtjSnIrUqYtVXRvO3W2sO7+2JINAfPldp5Z0faqbq/o2Gds1pcY82EfAtYEHq3er/JGSnMNWijXm7QGPma9ZMLshE+oJ7sJVEn3vkuuW9+YsXDCJGMx1EFWLbQkgQ0nTBqidWlHrAVsCTw5Yf/Bsm4J0rodGaTxK4f9Twzbi8g25X1E+YfYzzLslOfsXhaPfo2t+8Cu+T7qoSIf3JVUDSYfkMsYexaNaC0mNS3VB6F+ws6iohWkcg0A6Vso7UDgDk9AqwgCt6ML5eRZTle2mBcTMuPlWi3XZ2w/QPMC/bvXnPFes7sMXwgux/i5cNwbjszikX/D3m7lXjU+eqzQ6wCzjy3CLyrTxSnbB/SQrCyNndmS8ItekF92MnC6YO0eZ47MWXeZPEp2j4+xj5C+F7nSk8T+xa+SfU/TzLhQ3j3FRxW/p+wrZd1T/lV2JFdZpstPpVcqosciGuEV01qcd2fFjtiRtnB5X9liewKHvWN/RQ3ScvdMykUcCZJ7LmIrZn4k9xbvUlsDb8u4tRw7P2L1nzC+sps8V83QK2JoLWJos2bomqFrhv7KGDqLX8va0B2U8zXKYbOiv2nfaBr5RsYNfKPHsWTxHj4oM/RDLoODAQPtYDC6np/3O/Cy2ldUBPE23bJoK3wIBH1ALVz5OSHev8pzPgp1daVnvS0bZFE3y2n3c+UQ7/UfioPzO5/wyqCp4H1mxRAuJfsW8aCfYfz9vsYeJlH/0m/Uv96gxfg6nhcRWiufj9tmx5FW3lWkooiulNO+7XgLq6XWvl3p3MmDzBlWWUT4IUPnI85+A1afo/F1MV+giC06wWikyy1LmIXTMR8zHTsGfXJTc904P48Zm1PJXHc4xw86MMm0G24rdiyTV1rmD9j54dmm04SUe8iiNC9L+SLr8nKWy8nHbAOVyQFQB//Ax/nReO5MRZ8BpFHUZ7gt9GU4LkP/GY8khk+Z3eUW0R5rxUeYZ9oYSegoAx37jYsc67HSxBnspPdm4fxKseyQ25HEckzTUvk2mqEkmezg/YfMuRvWrtW6/HdkkHj0HvM2vM6Z/RcjAVlnWMwKaJXmT4vpgo1ybbAzN7Bf+nw2x0Rp+8ipGuY/WJgHAblFYLnauIe7wJ+3ow350szXhMfKbwo8e+PdHWnBM7YPXT8tP9HC+IZJQ5S+7Mh/sdJV3qbGz2+AN0tKv8XXLIC8G5GVpaOPA+sZxih90I8GjrFjlLyPo66OYyuwwjqkny3BfMnH3zeFf2H083A8nGL/oehZ6FdWi57dDuYxdst4doj21wx18m562A94T2EbyvayHzOPXlVPm6DUDcyCMXHU1fGKNvY0mGe1kGdBtj4y7QTHaRP1wEe5e2vi2Txp5mvCVrT3LqJwIcm73ox+p29wv5OhmI/7M+WAneETevoztAvuytr5XWhHsi+FfexTlG30A0P3Z/QKsn/FZ52Vm51Qo9kJY+PkvFxqaak/5BlrF5j//D7KoT3DVRNhzW6U4bVOyf+EDBu34jVGpC9xFfBVwVULP+acYxW6k3d+2ShhlWb5NMeYG8wxy7SmiOY9Tm/dQM6H/EAd/1s8V62F9m5zQR5hZuFdySMbyyKSELduCv4eajnEeSDHk6I+tOpkMerTvFP8RQTFeM8JzlFAtDjU/T30gnbjmgy+fYa6BbMn76M9i/HNj9IjP/FSzPfPimjfleynKEUVM3THGOfzUL4GWrweH5Hhr4UrfcKcX/Aop+iXgiW8nr6XJUux79G6w3SGePjsgUNE/8ONcsPT6+ZvPzdcnDdfvs5QE45Yts4QfKWyGeji6sd6pWG90pCklc7cr99fcldrDdexguLbjFUTchYOnw93gucHu35xhvP+rNLZDCZeXIlYc3HNxTUXbxYXr2NNZRYXf8dweot+zISxRrhqLbltUzxRH+OBJvfyPT6/1UrkLNMKbpX1hqIruG9r1VoSv/RdelHNov8HGhrGvQzh6R5byPKfc46CFrGygHyfI/PTHVwgJwLL7G6k1Cc4l9lExmuh1Bs4p9JKSX2Mc9qtlNThv4/7rmd2uwiqd6sLP2A+zGfeKlot/Zl9NjlukP27z3UkafNATJvGvs3K6gXZayh5m69z9HFN8TgVm2pgHoyBM7Xwl76bqE/r0o08NKvL6KmQTzHC1kC7vyw5UX7gemLq+YhWl9UWWuoX5G18cfKBbeuZV11EMS2THzG3bKZQBN5hbZjxT+CtgIWWlMr3cX7gvZRJk0miifkITcxLgL8NHCsttI7WIZNFDNMSeYTYTzFXGOzoMBs2XKU/QMv7CjnxjULP9gTf4hr7VfLai1bJTbz6b3G89hI+vOjjLJcSzAtO0ePw0feC2akpHhFKyUWbtIn9ROXPU9C5BdtiNZC1tQ4plcMZfo4dJsLgN/w72Btdz9ud/mzu+yr+BD36Rj9BexDJewvnCl6z65ENNItk/R+sBiI8oM0Dtv0vPh7uYURlxrZS33Uxfj8Jzvg8jbh/+IzgYfd0PFeD9t7JDAtnNjemdtDuHs3mWtA+PmYNZAXb7AZtZx93cnpY5xxi0e7jxvavWHRO+An2e/h9OMKdem0qhrjxhDY6g9m81QjaozZuHdHZRw5d5JjOR8XR3pgdcQKtUoPuqTab26zQ4TTdUwOLHtuos0KnwoAi6MWYfo+zbq/jJzNFo4q/EDM7y6zhePWozT26yx40Vmff8L56wy7uMhxS3SEV51AEo/P29Zwu/IC5kzQ0vmeK8uv1/OWA7WOrwSEvR85v7HxMT0ZH7C5GR93ZvOlPTF8F1Rqd91ZzomD/fHA97x2P4BY6/SEUgz7eyWAPFbePujGAKjjJYMS/n4JM9gZ9Khy46b29Dn7b62LhsNNM2Z5dOOAATqoGvwz+OZtbUDr09ZSKARx/0DuC4hcH9nFZuU9fR3C6X5w2AtsfIKIn0LgDpw/b+s4ZFF0q+g5KoOMcw2H7HQdu5uSVA9/6Dn47HKFiHY6IXrs4GEFn/xNLTLYOznu47/kxtn80xNOxI6E476JK7vfO2QmU4OTYvJ6zP7N5I8DCp0KjQhUKVvZgf6Y+VoAFG9z2TzpQjvawR40GL6E4h4ZqQad9htfptFGrOu093Nrdw2/d4+t5vzfy5+rPVjA6HdCH4RHf0j7lH4LOOUIYHJ+wyx+fdPGcwdExgj846lMBm/8b04V8dAIh8XmKQ6WF4TJK1rPRbQT6tjCAMGUD5xQdRkjqg2lMTKZmiLPWBUd9EtQrJrX+3itGhb8ewIazIepPn/e4l+wUY2RVF63Ci6DfRziOHdzvuIOn6R6hMDt96N77cMrOr7B9vw/XCoIXR+z+XtBOQbBwPZVf72F8HXZNLXUtla6l5V/r6Pgg2nB+2sO1elSkV+5hl9RM6pKsxC5pp3ukMW1AMG60h7cg3kRwMOxezw9Oz+F0B6evsHDYN6PByldU0oDSwB92RJcN9QddvJmD7q808uBYc9A9hM7TfQGXOnWQzE4dVKZg0O2wyw6R8l8Mj4nSOoli+E9GAJbXaFrThi3e51HXn+usY4HusXK47/jzph4MnTMk8oNOOOIxWmC33k4SNA16bRy8mFkRJRmMo6nlC5yg7qNBOs0dvEwavKY5g5daYvBSZYOX4RUevNTU4OUWGrwKYPN0AZshT6iY4PB/Q4TKDO8bilCoPeHkzg20R/PNyvojNX5KoKPdrv7E6NxQf0SMbmwgrg+jxxyjPYYPvQTmAtOM3kSOLmEVY5iHDrQ7AU/DJHywfik+tpnCR03hY+hphCY37GM6IaQTQiYhZBJCZuAMfiOpOjBieWO24ZRuw3FOcUMZDB9xDMH1+kuhZb3L9MzQZYqWD6TW4lDqY68ElJ5NUOL2WwNTbxUDc4eD2UGfn1azg50Pq/4+R95LrJQ0v/oh36fjvVYzCtO+pprybqvmdFtLJSSRDwBJ3y3cc3W7MJaGrROWhjYpjV1+h25OCDrbI+SmKzIo1LzhUq9IdsUgqwrQP1k/pYBTEiDTIoC0saBbYcBAJYy8vI4KarFct5AQEzgBmwJOqFS3ANSibkUdtWoHHWJADTro+1w101qr1bPVDqq3o2ffcYzA+buSotMUVEwwOvLsMjg0hY9+5/g4gzaxv9NeIP1HEV6UiO1hyPStoE2dKF7xuRDdc7w03ZMiJhB+0yuvUiYP5LkcM2NiFh47q3dKdkHdcglIGGrKIzmgJDQIi5ZC0jcLjJx+OHKCPVEQyIjbOJBok6weR4DPCa0RIDcyS8IPgCzZJeGHYWmIH6adizLw4pix1J1AdS6N75RbJnAwAIwh6JUCPGS46tMpYSYOGvmYVTGQ5aSoW7kGsqeX7+OReWzpBB1hWAw7bVqYGiPF0/1ANi3SwRHkM46lVXyztGuGLkLF2EeRjqzb3EpBp6QgWoYuQ6tBaDUIrQZ1ZSJA+DD2ha4MY8zwsASODyNrxVX+WBIjsQnFFqGIJloCRfWmKJqEIqmYFEbLJRz1HBwtlYcBWjwO0OJIcsVrcM1rmFlg0pYEmMzoLKeUI3yaoqf8UaYXF9LKYtazXC2xM8NAPV45/+EAg304BHKYHGlo7Fmunl3szG+Q/9LhqkRN4U4vjSJsQLhKqxiuykbpmRSlLgb2aE7/PuKkrwmnEWYKfLy3OBkrx2krwukD5mqvLzCcx2Mtz6zopPEhQSVoVIJGJWhUgkYtCM2OVIX4bEx59Ulzvbr+2Zc8MrIIIYsQsm5E2Yd8lj3fe93UGQaOEhuxESaLYLIIJpdgcgkmV2r79zAL5wqzIxnXSJTpgplfuzxT7w+cBy9gipUxHTRrWmSyQZU6+aW7nNxw4OasTVDZZPzTXEN2YCQfu0O+oiZ+9quIHViNGLYEDwilqaYMWfKbFgxZaWdEXSwaEXdvFbviUIU9Ml58lK1oYvzNk/VIiFpn0lbso1cIJt2aniXt+jiSBJYqRpLsaQk8H6bM/PernXMvOJGlriaprkQ3jcACHJNgfcfBOk1kLW5H7vkFXy+5zLpyqyYngDezDCZDcC1DVygMtaFCLziWWoFwBmxFC4uDpdvk+6Cns4cOGypfo0GejwklhhOXYvg8geEHzJdNZmQv8lw+op5dGFKIZOVMzXgugapzUD1diK9NeIyIBu4lHiZTXYLV5rjaBKxnE7AeB9azRX8dPgzDD6kOTlXRhzDANBhynxQSNSnE6SyG62SiCIN0a4HfmBSCXwjRRejnzrtmxEpMbveZhD0zkBB7LA0sEWlCUYo0DuIAMCr6kBS/KLzbEby0Rvw9rvsqYP+Ek9phsoXmTgvgW8T+sQTGSDMr8K2DiXLZ4DbMcuCGwGl+FCNBAPXlTPGjPIbM0zGK8W+zIv8WGqZ4aM93hRwBDqc5TtGvKaPfEE6RJyzux1nckWNlOumColBDAtQZcmrm3wFozZdScnZKfqiuqRT7dSbWS32/EjZAWlGLJdbfymKFL3wxQiHMwmE+fvg9dd3knjJ3Bt2WTBPTLR9YKGFgFh9iCgGF/RT4b3FsAcsTahwqi0EaDtcHUeIBrgS6nfRhr7iZXirbTLA+Of25BKRLQNoLhjo3PZPZZilAkwA+4QC+pIcw8KnJ5Cs0vo+c7CLRGyFvL/KriwVwYIqxpDZGNg+aTDealpQiGc2ZxxNtGKsIPwxPE8O2SqOJoKTFMS42aaTbMj2lANAKEQ7njIxw3tcqDrDcpzRkc0bYs7P6fjkYyzjlPrce/bT16LsFQCzibt40ACRXUV2GIHnlSS8ommwTMyRDvhxyC/uD8k7gS3pOE6xoBAdnJsNQs0zCsJHG0C0BYUOqh1KjhqZ+q1g1oRamCVPnaoilgSX13gbvvsVBCxWOJkny3RVD1mmFNEn56KIWt66RbxexGpvLJ80jX0WYNAeCRbzog0EfyL62p9y+hg+DEEMndP2GIUdS0KMYpmFeYA8f8i1BdGymnOtQ+8p417njNWIoS0aQ+38cU0OGqWfLHZYWj661eFJHq0GRInRLwjnyduymhHPmQnQ8G8TYm6an+ONz1HLV06pq+5QYUcjnS8TeSmRhMf9Qqp6wvce392h7BCWO1k0+WDdJQ0NIUUEPyTUs19lfIZ75o0t6hC6UN1jGluSaOZZOhgqetHR0yQpMZGXIpDMwuSqix5yxFgQesf1eiV/iFprlDziIhtKtkN7WLLKOpohLY6RNnDSATFUkoYhiYTPdlsSCD2mMLoPTdowT8wPDR5DlIiYdYIotPQoh05brnCcdYLSpjAy1tUL2OLJg3tATHPApEGLqvQhbo+qcg1Z8FjDyVYxG+aTA0BBc5vUdhqbz4aLpvAy659GY+xZXfZSdZpDPEN5c9TCfPDHP4Eqt6VD5ikRixZFYqnyhRTOMJgsWDZiiHZie5Pm2wPLTVXRgq3gAVsCwtXzQCNNTBXN6Rd031MEBPdQCZ1xvWQcXMikNqRK27PRkly8dNeTzh0KCryenQJk9KIZx4mkubsUk49ikruwGmxYNy41y2vok8pw/oCvzBt9Serk0YqatLiEub5y2pUvkIA6SQFwvMwOTpbVk3ziLTuAyBHcSCP6FQZxdjFSUxhADgyUWu0Y4mstd6crzA+ArFxiEMAjhNSUJ6ZjkgxvCD+H0y4Abk3CLNCGbsC7FmcNlUviJS4GeZuVh9uslf29m+GyziGDK0wktpSqq2FI2SSu2YE1hqG2RS0pZoAaPERk8tM5K5BIunuT4NuDCSQUzUVqJqTI7PVMG9n7Q63ev5xv3mKVe0oujBvHHPoDHJjQpWXOWWVOtSTo1iRUHUYues/Z40XzEhGvjVWLK5zLiYo/nfMDQ5yl/MB4JZy96By8Y8PDIIDj5Eft8AM/9YZ87iUeMJaq0sIo/fwXqXkGdevPzaBVPEVbBTy+ZcOXzNRUzjO1+wvsX5ZZ4Q58gt2RNNbkZJDejllsZue1wuQ35U/Do3bxp6e1EMpLtc1Zgn2oSdUmibi3RMhLdjnoizAWALZP0a/zEPEFYd5ZTV01yJknOrCVXpS+Gb9v4gPYRx0voi/J9zgrscyN21bRapGVEGttWLubPxAsNfR7iD7efZWyvJi6LxGXV0qoirQEakV7iOVI+j26E288ytleTVpOk1aylVUVaPUQkftFDKJV4+1nG9mrSskladi2tMtJ6wqW1z58p8xH5LWmcPOHyke1xtnSParJskSxbtSzLyPIhl2UbJ1MvoylWP3qiw0XU68St1eTkkZy8Wk5l5LQVOXfQV2iBtOiQxzWiQx7XVJPZhGQ2qWVWZVR7qdAzrcVRLd5+lrG9mrSmJK1pLa0qzvYgnueKbPztyDpM1p3l1FWTnE+S81MNexypETydu4uieIPTcOF8e6g2Yv3ZkvpqjdR4pBfKrpZ8o0JXT30zUt/M1LcRPgk9OMAAdhU1fZZQ009sryGm6r/CbANK0oiV1ZBqSEtVx3pSQ+Ah7ZGa5Wmgh+ojaPJtXWQFal4J4OcCwAlow21ZEP8cN2Ks6q6bdf8Tn1WnK1vikbkwr/hCdwV1qMv7mC2D82iY+nGA+YLwLvgY6IasbbpqeOm2qT/rdlirjVtNbZyuNSNwtKnps2+p2kZY2XCnnqqlK5tW9ok1sUWi+O5f8+9KKba4UnTwVTcfkbBjNTBlrWk1zYYmdAIj6gTjie0JQNlRbcPTp1pDeiNTfzL2JouivJsm3JU4viazqBJAOwl9HSOFXeGiV3GkkDKAqho2tF/OAKqqt9xmFgOwEbYhHtvIO7SZc6gmtqgQgW108+9KIZ5yhSDLLBrLlhkPsUqLLUuM6PAmlZxmywR3Wxe5a3ghxeYDptheKad8yf7vy0lJb6mu1cogk6Z07L7Bee6atSOujvl7GUAhpea1qghAxc5zVwBtc4AST2JmdUvYml5ylEV3tmqrIqHFdNdoiHAk6A4ObPpZdEcXzlI19q8gW2908+9aEYitFzk6Q7ez28M934J9pMh57toSd/A9DNeCJS5VsZbRYg3PUjFTh98sFRtbY2OsZahY+HYxuYpNpvArBQHU2i7qkG108+9KDR5FavCRZ0bB63XeLSfLRRNDT1YukE3cYN3NsQxF44T5UkmqyfQU5GPXPWv7KoK/+73u9Tzxot8nKNbXyhEmNUMgJnrpeTQvNo3W57jK1cLrfJ+HK8Tw8UkwS3aFAddLnkbnRa+z/TfhVb03eRFw8uXsYaLQBY3n0auBm4olHBO+9BgW6eOyVHyp7ltlktHCJ/jkmN/R0gzfWPYej7uMjjBSRzzGJxteMlc5a3/xCvFTEeWo/Q1fKS0i5yDm0CmPMU3xij9CeIZMHV5LE46iBUEpKcednh/1UPkvfDUyvQ49fd0dXG3+J3doQC8mC8dvsePVxK+h+MIdH6JZmn8GP/ErnuEpBg3H+FLkS6aXYNpOl7ZDvJflL4puYm0DXwoNL4CG16nDlfToRdEavo/Uw5d30zUs3LPJ/mqsBr4FqatuJZAfKZ9BghmasZ3Y8yWui7tS3mS+9no7oUeRziY0yBD6wlZCg/Lb8Qjl9Za7EjJtSchKONLB5ZAT1BnZkVmy2cYj4ahTJuf/IRlFr2f3MdJyKTDCI4bXJ5yNAjYgLrrKvKutiLVEbMU9b+fV3o8SjLub4Nwg9Rr25ey8xdn5N5T+b+wav9cMXTN0zdBfNEMbNUPfG4beXmRoRa85uubomqO/aI42a46+NxwdxjiGuBKitqBrdq7Z+ctmZ6tm53vDzmGMY8juHa4HUq8ZumbomqG/ZIZu1Ax9bxj6B87QDjt3+BAv2h8zBxR6hWPN2TVn15z9JXO2XnP2veHs0KpOcHbN0DVD1wz9RTO0VjP0hjG0pN/WmXc1O9fsvEZ21jaEnevMu3Wwc9wXb8LOdeZdzdA1Q39tDF1n3t0fhq4z72qOrjn66+PoOvPu/nB0nXlXs3PNzl8TO9eZd/eHnevMu5qha4b+2hi6zry7PwxdZ97VnF1zds3Zdebd/eHsOvOuZuiaob82hq4z7zaNobtsL5BVAs/oOcPE0PGDz1+n9hLZ+iacu7zHuEzzW4rJfifsfPZKeky+Fom93BXsi53U0VnjUlOifeExy/Jjk/vSg1lj/hXnd5L7LvZSgyFgrUX3Qn3aTelKWd0LZ0T4SPfV6VpDiD8U0TVgbv2WtM2+x9q2w7UtObKL1uj3XN8gZsDYv84zvrEtqgtXqG3R9diiWmm2W7ctagi8k22LilpUZxnfL0v0ccynjKET2nwDhh6yK8wQl5qha4a+jwy9+dECkXVrhv5SGfpJzKfKJJejn6ZQ3EVuoFcVvk34bdupVX9h3f1h6oagn8tZ1KzIbNXZQMe3rNmsbzN/j/Uo6Pk6+1UjNoBtsA9IK7yKjfzho08LnCCyQbYemmvQQ7neVNHAx6kz3V28yuJM7CMHA1M32a/J9q8upbLxKksYM+t4ldxClWlLFd17iizxFntQ6mzKz/C7oIH/yTSnzVrt4z0Ra7xmrb9A5gAL6k/2/Sq6Y9DN/43a/gA1aRf+ltTNsdJi+uGxv2AXTNGeMNHWCnUTYl6gmT7yCmkT7A1MAxo9YfundfN7ZVIwKvVAcQV5f8POZgn7eEtsMZE3b0c/lkk0rSWPmSZPmJ3wCXHYTfTQ8EVCezg6fGB1/Wh0uFyTXjxj+32APom242vO96+ZJMKXDcv79XPhuDfcwls88m9MOyxBkuJV46PHCr1qLPvY5ZoMLGmyeh+tXw1ZVmNnNhcsY5trsotsDDw8Yf/BK2gJmryTgdMFa/c40y7JusvkUbJ7fMzaMUV9KXalJ4n9i18l+56mmT5n3j3FRxW/p+wrZd1T/lV2JFdZpstPpVcqosciGuEV01qcd2fFjtiRtnB5X9liewJzvWN/RQ3ScvdMykUcSZJ7LmIrzion9xbvUlsDW2fxazmW/olx70XkxXJ7X/mH6DNkjOnP2V0tHv0a2wn68z7yNkTJ35U1YDA2BBYco/1J9mmLaZiWslShHjRTRYsBOLSF0YgJWgVidOEpjt9JtIogcDtaUU6e5XRlO/G6wF3e7rcr9TQeZMY6ZN7jQ4bTR4xDAWqfE5GX8n7mBGVrosXjoXfpYkSpJXgwoCtuKuqEkTKcO51Kok5htA20YZLJg7flZ8rkVU7mW2wLjAPXqEmbZdmn+/I06svGDfry45j58R4+KDPsN5fBwYCBdjAYXc/P+x14DeMrKoJ4m25ZtBU+BMJ4gaPUys8JkaxVnvNROJat9Ky3o98y3Syn3c+VQ7zXfzBvByKXn/DKoKnAlllj3qVk3yKM/wx9q/s6Vk6i/qXfqH+9wTjy69jnFVorjzRvs+NIK+9qZC2iK+W077vkqo2NYdUJ2tsmxltb3MsEaTYkXmYYLVnmZd6ORNL4lR3XEjbzWse1Lz8yoUeRCauOTNSRiToy8ZVFJmTcmmbnB+zssG5xGvHxM+6hhmsYd3lkY4+d4yNEojdmfIRR0WB/wb5xkes8Vpo4i5DkOgtnt4rlJ9yOHJZjukwq29ii93y2nLJ41hXBXy4JH3NAVJSHj6j7OG8TzzqqKAnwzIuOOrflictwTKP/bTSLSNjH3zcHb43V+ci8ZjT/EHre1Ub528E7xi4f463wO8PjGM++mGm3GWjrG4y2DMV83J8pB+wMn9ADnuEM6W50jnXa4v+OY2WyHeGIeYFjsovzvJ+iDJgfGLo/I+Nk/4rPUihnO6uR7WxsnJyXSy1f6jt4/6HHfFcSf5doQ1La2TP6oh+WdYbFmf5W6Ti0xaRpo53QYGdu4Jjmc+/bxP7vY2xaw5wGC3MbIFsSLEIb93AVMQ59O9qQL81lmjDkfQtiPXejCT9E/RvakJajGGH6hkklLckfM4/+Fytd5W1qTuIb6LmleQH438DsIOJ/Ha9ooybAjJWFmgC930ddmKAlZCJT+MgM3po0IU+a+ZrwWPlNgRXx7+5IC56xfej6ZTXgufTIVUm/xdfjQc9vRHFWHUd/WKs3Rh4ApmjgrNUYOcDHeSwdI7Pgb6xD+tkSTEv+Ic8ousD85/fR2sf01k2xvjwca8GbgAxU8i0o43zRt2je6agsIlgE9cfprRto/WqYjedjhIWi0C3sD80FqyjMKL0r/LOxLCKJp+yM73FFDNXsRjnY62TBn5Dr4la8xujRJa6Cvyq4aufHnHOswpLOO7+Mr63SnJv2uMwN9riWaY0Y1znBmVyYUwv7/x6OFLtxTYa+PUPJwRzz+2jPYnj/KD3yEy/FjNeseb+74p8pShUy2mGs9TDKp6K19XesGfN8EIPdt4Y2O61KgFF3imM3WGXr4Z8sWaa14Dulg4h/YvteRjOQyW2bwv0++sIm53WPWzytRJ4rZWyrDOuiGdu3NQOZxC99l15Us6jtkNUUspwhrGXcwn78OecoH+OcrQLyfY4rH+gOLnB0Am7b3UipT9C6baKN1UKpN9CbaaWkPkZ/t5WSOvz3cd/1eL5FUL1bXfgB48yfeato/cZn9tnkuEHG6D7XkeRKMbDgaX3nZmV6gew1lLzNczV9XD00TlnjDZxzMTAKAn/pu4n6tC7dyEOzuoy2cHy/oAzKL0w2E9y2njj1IorVZfJUiH+NsBXQ3i9NPtaaRtNliKZl9SPOY864z+Ww9sz4J1iR7+J8Zyyt7+N5t3spnyaTShMjgU2MCMLfBo6VFlpH65DPIoZpiTxC7KeYjw22fJhxHK40GKAHeYWcCJ8+ooRmyJa7qWsvWiU3ySr/FsdrL+GriDH95VICL3CKHo2P8/cQj5jiEaGUXLRJm9hnVJ4bp3MLtsVqII63DimVw1mMUdCzSdIrPcOnl55gG8DrXsz6vz+r3Is8j0QTjlj2PBKI8JZbS7+4UrR+Jkn9TJJQWun14/Xbae/qqSTrWJX/bcYTIORcHD4r8hDv/MONeNheMw+LOZmbwMOijGsWrlm4ZuHNYuF1PJMnxcLBYG90PW93+rO576v4E/ToG/0E7UHE01s4P/CaWd0UCZxFHs9/sBrgatDKAdv+F48K7SE/zthW8mBdjNlPgjM+NyPuHz4XeNg9Hc/VoL13MsPCmc2NqR20u0ezuRa0j49ZA1nBNrtB29nHnZwe1jmHWLT7uLH9KxadE36C/R5+H45wp16biiFuPKGNzmA2bzWC9qiNW0d09pFDFzmm81FxtDdmR5xAq9Sge6rN5jYrdDhN99TAosc26qzQqTCgCHoxpt/jLNzr+HkkkSfiL3giZ5k1HK8etblHd9mDxursG95Xb9jFXYZDqjuk4hyKYHTevp7ThR8w9aBgxPvg2Pn1ev5ywPax1eCQlyPnN3Y+piejI3YXo6PubN70J6avgjqNznurOVGwfz64nveOR3ALnf4QikEf72Swx3ZnX1A3BlAFJxmM+PdTkMneoE+FAze9t9fBb3tdLBx2minbswsHHMBJ1eCXwT9ncwtKh76eUjGA4w96R1D84sA+Liv36esITveL00Zg+wNE9AQad+D0YVvfOYOiS0XfQQl0nGM4bL/jwM2cvHLgW9/Bb4cjVKzDEQUZumgsQOf9E0tMbw/Oe7jv+TG2fzTE07EjoTjvokru987ZCZTg5Ni8nrM/s3kjwMKnQqNCFQpW9mB/pj5WgAUbxvdPOlCO9rBHjQYvoTiHhmpBp32G1+m0Uas67T3c2t3Db93j63m/N/Ln6s9WMDod0IfhEd/SPuUfgs45Qhgcn7DLH5908ZzB4ODkEiZ7BoqLxtMuMyqOjlEgg6M+FbDrf7NhDx6bNsbAAwWRDBwAbT6h1sDghYtBCw/Ty8aYaqHjI2Vc/NUZ+fYd1uKg/4qJsL/3ivHirwdwmbMhSZObpX2292eFHi3FJNdHXI5J4scd1LvuEUq104d+vg+n6/wK1ft9doGj44Now/lpD5cYU5FecIz9RTOpv7AS+4ud7i7GtAEj32iPtRt+XhwxBF/Q1YNg4SY0fhNbbCSZspvfjW8mdSMa3YiafyML1wsOusxGP+geQhfovoA9Th2kpFMHVSL4P0scv+djnmRRAAAAvm1rQlN4nF1Oyw6CMBDszd/wEwCD4BHKw4atGqgRvIGxCVdNmpjN/rstIAfnMpOZnc3IKjVY1HxEn1rgGj3qZrqJTGMQ7ukolEY/CqjOG42Om+toD9LStvQCgg4MQtIZTKtysPG1Bkdwkm9kGwasZx/2ZC+2ZT7JZgo52BLPXZNXzshBGhSyXI32XEybZvpbeGntbM+joxP9g1RzHzH2SAn7UYlsxEgfgtinRYfR0P90H+z2qw7jkChTiUFa8AWnpl9ZIO0EWAAAANlta0JU+s7K/gB/Pm8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7dmxDQAxDAMx77+0v8sCnyY4CuAEV2pnZi+a3eUdN9vr/x792/RvO+3+Tv8n6d+mf5v+bfq36d+mf5v+bfq36d+mf5v+bfq36d/m/23THwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuO0DROnLo9UOpq8AAAq1bWtCVPrOyv4Af1e6AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4nO2djZHbOAxGU0gaSSEpJI2kkBSSRlJIbpCbd/PuC0jJWa8d23gzntXqh6QIEqIAkPr5cxiGYRiGYRiGYRiGYXhJvn///tvvx48f/x27J1WOe5fh2fnw4cNvv69fv/6q99q+Z/1XOaoMw/uBvM/i9vCW/rm7to7Vbyd/rkdXDXs+fvzY1tVK/u7/bH/69OnX32/fvv388uXLf/qi9he1r/IpKi/O5RjnkU79XK7az7Hab/mTdp1baVpf1bFhz0rOnf4vOvl//vz51zb1T/8tuZQMkDkyYj/nVP7IFJnX/mwX9GvOJT+3E9oC5Rv27ORfMvL4r+jkzzHkQn+1DJFztRX3WeTHNeA+vjqGPgDKYz0x7NnJ/6z+T/l37wzoeeRef6stINfatiz9zFjJ33oA6PuVnnXD0HNN+SPXklVd6z5IX/eYwHn4WZLHdroh24n1jOVfbcRpDP9SdeL+c7QfXc1YnG0fp19n+ylZWd4pD/pt5l3XeSyXsqxt2iB6hjHJ6pphGIZhGIZheEUYx9+TR7DXp//zby/vWfLd+h5c6mu6NvWueITL6O1qB8/mZ0id8Jb2vruW9/Od/M/Y8Y98hnme93W+xC69lfz/hv7zFlz+9LNhz8Omjk0m/Xfp28MX5GvpI53PkPokP85d+QNN52+kjFyP/ci+LNsv7d/apZfytx/iUdtAyt9+Nh9zPyl9ic4suSAbbL7s55z0C9hnWCAj7HYF51HntA+T9me3HdoM90KemRby7uzZmV7K33X0qOOBrv8DdWi94L5tP459e12M0C5+yH3Qdl/3/0o763jnb8xnSvbr9Fldkt6z639AtukDLuyrKZnhb3F/Q5b8v5M/fd8+QMf7WJ/Azt+Y8ict/ADk08n/KL1XkT/P9vqbsrG8i/TF2xfn+t7pBvSJ2wm6xboYdv7GlL/P6+RPnMqZ9FL+nNf5w/527FtLP1tBfaU/Lf139u3ltdRt0dWR/X08R8hj5UuElb8xfYi8p3Xl8XjmTHreph4eVf7DMAzDMAzDUGNb7Jv8PD6/Z1w99oAZY78ftn3xs02+iwu9FX/D/MNnZ2fT6vzg1gnoDseE59zA9C1CXuvza19nP8zyoK9GP5yjs6sg/5Xd13YwfHzYjtAb2H89x6dIv1DG7ttn53Pst+Mvx2gf2JHxSQ3HdP3cfhfXe5Hy5/puXqd9gbbvWub4D7p5RJ7rl/PP7LfzNeiI6f/nWMl/pf9XdvD0padPHRsp7SL7sWMwzhzLdlngk9jFCwz/51ry73x+4LlfJS/PBSzO9H9wXIDLybl5zrDnWvIv0MnpOy94hhfW4c5z9fxf6Qa3OT//HatQzNyvNd27XO1bveN5fN7ZAhjD5/XEjTid1M/d+J9nAOT7v8vKsUx75D8MwzAMwzAM5xhf4GszvsDnhj60kuP4Ap8b29zGF/h65BqryfgCX4Od/McX+PxcU/7jC3w8rin/YnyBj8XK5ze+wGEYhmEYhmF4bi61lXTrhhxhfxI/bMT3XkPjld8RdmutrNi9I67g/dx+ZfuQ7in/tDM8M17XB9sbtrnCa/CsZGz5Y3/BJrdqSyubnOVvfyJl8vo8LuPKnmCbwepeKDN6zPLP9uh1Cp/BpmzbKza7+t92tO6bPJmG1xDDr4cNvms3Xf8vbNNjG1tg/U/a9vnQbn291+fymoSr7wuRR8rf646xBprXxHp0kBG4Xnbf5DIpfz87V23GcvU1nfwdb+Rj9h+zn/5Jeuw/+r6Yj5FP7vd6ePeMe7km2Mch+4VluXou/qn8u/2d/NMX1MUi0a/R7aR/9A253TH8FNbz5MHxR2fX/+17K9KPA7eSf9cebPt3PAH9PX1H3b3s2kbGqJBe+ikf9Z2Btux6SR1w5Ee/lfwLr+NL7ACs1pzOe8172cnfZcjvC/uaR5V/kTEy6cfbra/Pca+nmWl1bWYXl5M+vy6/1f7dfayuzevynK5+nmHsPwzDMAzDMAywmlt1tL+bK/A3+FN2cazD7+zm1q32ec6F5wodvT/egpF/j30YtqHlnBpY+ed37cW2kdp2zD/f5bDfqfD3RPD/gY/5WtuT8C1xL5Y/37PxPb/qPBHLzH62jJuHI/3f2eat/9nmuz6209lGa/+M2yJx/vh6sAFyrb9R6G8JOcbEcqYs+IjuraduzVlbOxztp2/mOgEpf0APuC1g16ct2DeL/Ch7zhux36+bU9Ltp936u0CvwrXl3/WfS+TvOR/o7vzWoL/JuJN/Pg86n27BM+kV5wpfW/9fKn/rbXSwY23sw0M+5HGk/1P+tI1Mk/gQxwg8sj/nEjxuoo/Rr24h/8I+Pffn3TzyvDbHfzv548er9HP89+j+3GEYhmEYhmEYhnvgeMuMmVzFf96K3fvqcB1457Y/MNeLvBcj/zWe3+D4eubH0Y+Zg2O/XaazsqF4Dl766myH8ryglQ/QxygT12b5sf86fh+fpsvT2aNeAWygaQ/Fbuc1Gjmvs6kXnlfHz363XDsU2z92/m6Ol+279ueSNmXMcqXf0f2/81ViU352+af+o16591UMTzdPKOl8Oyv5U8/pR/T8NHw/2GbtH7T/0Pe2Kj/Hco6X91d+zzLPb8VO/pbZn8p/pf9T/jn/135kjmGr55jn8u7Wh9zJ320USIs29uxtwFj/W//dSv6F/ZB+znMu4xLaA3mc0f+QbYM02bZP3O3vFXxCHv+tZPye8vf4L+f42QeY/sFiNf7byb/Ief7d+O9V5D8MwzAMwzAMwzAMwzAMwzAMwzAMwzC8LsRQFpd+DwQf/irWzjFAR1zin7/k3EvK8N4Q33JLWP+YtXMyf+KxKN+l8ue6jkrr7LcWujiUjownPuKSWEDilrwOzlGs+1H9GmKj4Npx9I6d8nd4iQvsYvcpk7/r7rhfykt8lY+Rds4XIN7cMeeO1U28NhBrCGWfZS0yx5vv+jX5nzmX8x0/S16ORbqkfok58s+xUe+xrlmu10a5OJbrfxEPTj/lfjs6PUo8l+/b3/6hLex0APG6xJJ5TkHeG8fpZ7v+Q/6OCVzh+0794ljKS+qXcykn6V5L/2dcfuLnMn2bNu191LO/t+HvKbke3G5dT7v7ct4dXhvM97Nqh36GIrfuex9w5rni+TI5d4A2lBzVL9AuHJ96LXbtOvsr/cf/o/OyTXveV5ce/Y/7Slm5r1r3rcrqtaJgJbeMDe3SpGw5j4W8EueV7Z62mRzVr88jT89VeivowVX/Pzvu/RP5c47n3GSafh528eBOt5uHRJ3nNyouWeerGyt2OtN5ZTv0+DjLfaZ+6f/dfIW3sivDkd6FTv45f6Pg3cB9lXtCxp4jdAav6ZjXeO6Q49Wtc49Yyb9rr4xTrB9W7Zv8L9Xnu3VKPW/qDEf9v/A8i9W7TCf/o7LzTKzyOg/kRF2yNtxqrGadmfJnTJjrBHqdL68r2L1be46Z3x26cvDdQ/RNrlnXcaZ+4ehbuxx7j3mLvKOu8s15GgljBch6Qb+n3vS79JHeO9Pud++Eq7GAxzmXrBN6yXN6V7+U+0iunPPs81aHYXgz/wCggvog4L8lowAADtdta0JU+s7K/gB/koEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7Z2NkRwpDIUdiBNxIA7EiTgQB+JEHMhe6eo+17tnSUDPz/5Yr2pqZ7tpEBII0IOel5fBYDAYDAaDwWAwGAwGg8HgP/z69evl58+ff3ziOveq5+JzpawAZfj3wf9R6fmK/jN8//795dOnT3984jr3Mnz58uXfzy6+ffv2O++wN2UE9PtHRtT7tJ6Vnk/1vwI20f6u9l/1Ufp2laaT1+3f+Z1dVPKs5ARdGr1epcuuZ+28ez5wauereuvsH+Vr33W5tG97HpoPeQWq/q95ZfWO+58/f/73e+gt0v348eP3vXiGuqgvC0Q6vR7pM0T+nibyiLy5F2WrXkgX1/V56qBpIy9PRx30evyNz6r/x9+vX7/+fu4KOvtzTWXR8iNNlM8zWZ8jPfcy+7sMUZ7bCJvH39CZponvjFtccz1FGp3zOLR9RT6kRxfIqelU7vigC9qyyh3XVB+qZy2f8X3X/vrMFaz8f1Zm1v/pf528gcz+6m+oU1Z37Bx6Vn3RLuKDL9A+qH6BPFZydrpAPsohP/cVVZ39+ZDPy98Z/+8xF7jF/ug8+iP17uSl/pX9fR3iwLbYPf5GWyB//vd+hqz0UdqLQvOhTpku8LcuK+2RuV5lf2TU5738TG8rW1zFLfanHWu77+QNZPZXf4fvzfoofd39j+o27nHd/SS+I7M/etA2lulC06nNaRfI7/bHP/JM/OUZzTeuIeMz7E9fUX3QnwF19e/qbxnfHJoemelb+j2epQ90a6XIi/v4TcD/kcbvISd9LwP1xodkutByMvnJX8dD+of/77Ko/DqXqfTpuh0MBoPBYDAYDDo495fdf83yb8E9uIQrOC3zNH3F257CY+XEpVjPZHGBe2JV/urZFZ/WcZiPwqnOrui44m3vIavGtqtnKs6q8h9VXHq3/Fv5tEdB5dY9E16nK3J18fx7tetMVuXV/P4J51WlPyn/Vj6t0pPzhs4p+h4F53iQhXycA1nprNKBxhW7Zx5pf/TjnFzFeWncXmPmVfrT8m/h0yo9EaMLwLPC8yHzyv7E7VQWlbPTWaUDtT9yZvJn/v/KHpoT+1ecl3PWyr1WHNlu+dT1Kp9W2R/uWPkj5RQ9/8xGyNz9f6oDz6uSf5crW6Eaq+BG9H7FeQVIq1xMl363/Fv5tM5P0oejjGgP9DWe3bW/jhme9lQHp/a/Fepv4BqUd698U2YXrvvcwdOflH8rn9bpKbO3zjsZF7TszEYB5RaztDs6eA3769jJx/fiKS+IT1POC3my61X6k/Jv4dMy3s5lA8opVmUzJ3eulOeRZ0dnmY4970r+rl6DwWAwGAwGg8EKxL6I+ZyCdSBrmFUsqksTc9sd/uce2JE1gG4eWeauLPcG52JYd3sMfwXiH6y/d9Ym3fr1mfsZM65R15SB+E6s8FFldtcfCY9dB6ivxre69q9nY0iv+sue5xnuab2d94p77pf0zEGmM57p9El/8ziGx2iz8nfyymTM0nXXd8vI9LiDVRxJ9+RX53GUg/A4re7V1+dJoz4HnSuXo/FA5eyUD3CZ9BxRxZ/h88hHY/5al6r8nfJcxqrM6vqOvMQbVcYTrOzfnbcEXczS+S/4Ou3/6MrPM2TnO8mrOmdCOchSnY3I9O98R1d+lZfu13cZqzKr6zvyZno8QcePkd+KZ+zsX+l/52wR+fqnyxd50P2Oz9L+nsXis/I9r52zhFWZ1fUdeTM9niAb/5Vb9DZf7fu52v8zXVX9X8vu7O8c9Kr/a95d/6/mf13/17KrMqvrO/Leav+Aji0+huGfdHzp+CuXaTX+q9xu/4Ce4avOn2e6Ws1ZfDz1MU55xax8RTf+a/qqzOr6jrz3sD/1rtb/ei9rm9zXPuQ8ms//PY3OkX1On83luxiBzoX5ngEZ/D7ldeVXea1krMqsrq/SZHocDAaDwWAwGAwq6NxcP1c4wEejksvXHx8Bz+ICWbv7HszVOoL90s9EFWer9mO+ZzyLC8z2MiuyuIDu2dX9/yfrV7UVsTa9nnFu2J97ngdy6HXnIne4PNJUa/TOLpke9FygcqSVvm7lG0/g++/VPlXsj5gTfmOHI1Q/o/Erruueefbve7xR+cIsjyxenXFGHS9Yxft2OLou1qlnE+HXM33tyLjiAk9Q+X/sjwx+biXjaFUH3kc0Dqfn+Chf+4VzbnxXfVRnJnheY+v0kyxG7f2Ftsf5FbDD0a24DvKr9LUr44oLPMHK/yMrfS/jVXc4Qs5SaF/Pyu/k0Xy7MzMhD22Wclw3VTmMberfKHvF0Z1wnZm+dmXc5QJ30Olb+6z6eK/rDkeo77XM+r+O313/37E/Zzv1LOdu39K9A9pvdzi6Xa6z0teV/q/P32J/9//I7uM/+sdPVum8Pfm4Wtlf887G/x37oyO/dmX8P+HodrnOTl9Xxv+ds44VqvW/ct5ZTIDr2m87jhD5sJ/OMbNnsjlwVl6VR7V+PplbX+HodrhOT7dT9x0ZnxUzGAwGg8FgMBi8f8Dn6NrvUbiSt75b4x7vvtfYwAl2ZX9PXBRrXjgA1pSPqAN2PAHrWmJ6uq+y2wdcAY7hFBpP7HCljq8FYha+biR+FvB9rL4Ox2/oepUzGPHRmA1tS+ML6KvjdlXGzv5dXrtptE66D97luFcdQfa7I7T3eI7rlKvpApHmat/KdMT17BwLcQuNszoHo7/PRT3QDXol1oXfcfkpQ2Px1VkBtUXF0e2kcZm0rsp5Ukf9LaErdQwoD0tcD/torFDTESel3Cpe2KGyv16v7K/xcdo9bRI9eXxL8/L4dsWrZfyJ21z9mHLIip00AbWfxx89jpvxe1fquPrdMdL7+wSdOz3dt+XyeBza6xNw+ztvQD76m5TImOkGVFzUjv0rHkOxkwY9Ku+Zyat8mL9H8EodT7hDyuUDV135lhV4jjEus5nvtaAPOV9Fn9CxqeINvf1W/XHH/gH1f8rjKXbSKOeo46DKkX3P7L9bR+UE8fkdd6icn+7HugId2/Tjey3ig2/0vRzcUx1k15Vfy57vzteDyv74MuXUHTtpVCafdyrfznf6h7eZkzoG1Aa6p8fHZ9ettpNT/k+h4wdzzOzeao/d6rrvJVqNW35fy69k6daut6TxsiudnNbx9LnMd13Z/zcYDAaDwWAw+Lug6xhdz9xrHtntSYx1kL4rZadMXasS787Wgu8Bb0Fej+ew7js9R1Khsz+cAOl27K+xFtY7PPcW9HmCtyBvFo8kTu4xG+e0iD0636VQ7lbjFQGedZ+jPLTHIDwmq/y/6jNLq3kTQ6m4GC8X+TSWoxxyxylpPbX+Ki98zo5ekF3LUblO0J0xcY5HuQiNpXc+w7l75ZXhCzxGqvXz843OwVb+n3KyMr1u2d5sb//Yjdinx3yxbbZvm7YCJ+JxYuyt7aLTi8vucp1gZX/s6mVmsf8Vj+g2CjAHqGx6kp9zQd5fsryrGLDuD9J4N7HW7LejKu5VfY3urVKuJfMZK724v0OuE6z8v9tf5wm32p9+SVz9UfbXfrFrf/wGeanPI1+3/2pvB35EeVXlD8CuXqr6nmA1/6OecIy6B+UW+2u57odvtT86pBzVy679yUPHDrW57nfZyQd/rvyfy+s+P9NLds/lOkG2/vN9RTq3yM5fq24cK3vR/nX/wz3sr/O/6txyoLOb93HNk77Ms10+Pv/LZNF9GCu9+PzP5Rp8TLyF9eLg9TD2/7sx/P5gMBgM7oVs/beKZYC39K75jmc6ha7XuvG2ip2eYFfX9ywzy0/jP6u9kQFdl74FXDn7UIH41+5+zVuwo2tP/wj7V/lp7EdjFX7GKeMIHcQtPJ4Od6a8Lv2PM3HMfZUP455/J3aqdfB3JFaxkqxuGpPRduHyKLJysrrC/7iuNY7vMqm9iFM7V7iLyv9rjF/PS9HPlPOtOEIvB93BnWj56EXP1aAflyeLOep3P39LO9J4OvJ4G/C6BTyW7HxAtg/bY7PEz72uFYen+Vb64HnixhUHu2N/9/9A25aOUx53zThCBxyV8nGuw+7/XfujFz2P6TIH9GyPQtNlNlZ9Zfb3uYieravyUv0ot9jpw8vh3glW/t9lyvZaVByh64Q03fsf72F/ZKKtZTIH3pL9K27xWfbP5n/4QvWXuo8Cn1RxhK5T/H/X/wO7/g7flOk8m8Pv+H+tWybPPfx/Zv+OW3yG//cP9fdzsHruUOcpGUfo5ejZwap9e1rXhc4zq7OZbjfFav4XcPtX87/Od2bldPbvuEW/d8/531vHvdc7g/eFsf9gbD8YDAaDwWAwGAwGg8FgMBgMBoPBYPD34RF70dn79JHBfhP/rPa9s8fS32kRYG9M9nmEPnVvqcPfaVxxiexL83x9/wjvANIP+zeeyVN2dTnNR/ft8ansr79jwr4j9tnpPrcsz2pv8K3yd3v11Yb6HhCH1hvdsodM+wT5PattV+jq8sgydV+k9o2s/zjYr5bl6Z9qb54/u9obsmt/3stE+vjf37Gh9n9tvIb9/XcH1D70ww7sI66gfanbyxbX9bdFOqzsT9uhTzs8/6z/c538eZeb7qHUfZsB2pu+a4l9fvqM7rHVfLVNkobvJzgZQ1QX/q6hrG8rqFtXnvqCzPaMvfiGVZnkqe/vUZn1/XIn9ve97lznf60n55J0nFRZuM939IrMei5E86U9qNxXfNPJfnE9X6G+AHmqvk273PHn2dkBzcf3lq/kx49r/gF0p+9iUz0y5vt8pdKxz3m0TtpffU+v7mXX+ZTmkb3bj/bg/fB0TOCcUzafcWBD/+3Mahxm/bQzliPL6dywsz961TEL/+ntSO2v/l33mpPnif31XCLtV8vM3l3l86zK/vxPO74yJ0C+7ONAfnRHG878Orqr/Krne+XddYHK/uo3AW0xixXomVFd31BXnR9W5xsy+1OujuV6Xc+lep/Scx+d/ZHJ29cz0MVdducWke6q3N14d9Ke9N062pc+2nmKwWDwofEPiCRqout3vRYAAAR5bWtCVPrOyv4Af6I2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4nO2aiW3rMBAFXUgaSSEpJI2kkBSSRlKIPzb4YzxsSNmxZPiaBwx0kOKxy0Mitd8rpZRSSimllFJK/df39/f+6+trSoXfg7Iel0z7EulfU1Wf3W435fPzc//6+vpzfst1px5V1i1Vvn95eTnYY+v0r630//v7+y9Kdax6P6P/afvP4P+ZPj4+ftoAcwFto64rjHbBdYXVkfgVzr1ZmnXMOLO0+rN1ThnSP6RXUD7KMUpzpIpXaVb/5/yR/V91S/BFH/+Jz7iIL3KczPmjwohf4ppnS5VXXdexnpnNRVke8mNsyvMsW6afVJxZG0i7VL7P4P8Otpv5/+3t7fCOiH14pvfHTCN9QZsgvNLinPZH/J5WHcs3vJeRXvd9PpNp0p66si3nHPjo/p9p5v/sO32eTEr4sOxY7SbHVMpQ9zP9VN4jr/TfqB1n/67wSh8f1vlsDiAeZeT9J+89itb4P4XNmG/p5/lugO2xYfbr7Jv0vXw3GI0V+T6a/T/HkPRVliXLO6vvEo+irfyPL/Ft9rWeTn8v6ONJjrXZ92bzUdaD/Hp7yPE802TM6TbpZJlu+Tvor9rK/6WyUb4Dlm37e3v3Ne0k/cD7BGnRpnjmFP9nPMYk8iLNXr4lPer8r5RSSimlnlOX2ufNdO9lL/nWlOsgl7BhfRvNvmv699RftfZ5tT+sOdSayWzNeo3S/31tI7/zR9/8S2shrJv082soyznqR/zjMbu/lN7oepbXLK1RvybubM1pVua/iv2y3PsjX9Y88pz2wjO5zp5tJPdeOWcNl3s5JrB3sya82zrLmeuJdY/1Ztaa+rpShfc61r1MK21Xx/QZkFdeox6nxHol90mXve6lMp+j7pdsb6P+z1obtmY/vms09le83Mct6COs860JP1Yv7JdjXv+3IfchEHsZdcy1yrRVptnzGtm3/xNBnNH9kf9HZT5Hff4/xf8Zf/b+kHbinL0Zjvgz/8lYE35qvfqcl3sC+HpUp/RBt09ez/LKsNE+E/ezP3OdeY/KfK628H/fRymfUKY8LzHWMX4yltGe14afUi/CGDf4jwAb074Qc233fx9zco/ymP/5fyLzKPX73f+zMp+rY/7PuR079H6SdS318Sl9g7+Iyzy2Vfgxu2cYtuT9OudhxnDiYue0NXud+DP3KI+Vg39r8SFtJ23KntnI/6Myn/MuyH5b1il9R9/OumKP0VhF3Eyv59f92fvBmnDCluqVYdSDuaT7N+fy0TcYz/fnRnn1MNpA34tMGxM/856Vufe1S2hpvUA9vvS/UkoppZRSSimllFJKXU07EREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREZE75B+Hl45q2TuOnAAAAVNta0JU+s7K/gB/pYUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7dbhaYNgFIZRB3ERB3EQF3EQB3ERB7G8gQu3piH/ignngUObT/vrTWzOU5IkSZIkSZIkSZIkSZIkSZIkSR/RcRznvu9P5znLtXf3v7pP929d13Mcx3OapsfP7Bj9LPfUvXUWy7I8XscwDH++h3TvsmOVfbNhdq3N+z21f9U3v/6N7l+263tWOeuf5XqdffvG2b+6XtP9y3O+71//1+d5fto/1+z/fWXbeu7X79u2/frM9+e//b+v+h7X96v3QK7Vd/ucRdWfHddrkiRJkiRJkiRJ+vcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4QD8K+ay4UtoqZgAAKhdta0JU+s7K/gB/1PAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7X0ruOwo1vaSSCwSicQikUgkFhmJxCIjkVgkEhmJjYyMjI0smX9R+5zunp7p+dT/1Ihac+k+VXvXCbAu77suVObnfTaeANqzkS3G10Zgh6PDAnBdxQVrAN+FfsPzYh3ggQoQAbYKG9CeJMF33ZPZsYTB8c18c/zxQ28AlZvdQSvVcTO2vmxPFRTgeJ1A4SjpMPBhua8rP/cJEqDcVCykX40DrzeBuHNcndvez5heQmwxKfxDEfOV0g8PK9Rr2yjuRnlOIjj1lmRQQ8xfORbI0j5PBjAmbKs0uI9JbSv+7utukHfu20cXj3LFsPiNmeABPFGqg3EJD9EUCSuvl7KFSJN9DPqhrsFlobcdf3GPua5+foJbKS6jNWODiTYs1vq4xcDBgm0Onh0EdU+g+O+oOXBc+NP9PC8bDy8/vPy3uE7EOhKek03CmwVwKbYVIBX2xJwtHNUeMnDAJw+HdUtxYAK+tM1ft+Da5sAf1S+4mfs2/DQdPH4AhQu0Hjc3U+obgcfhTt3VQlHX4dbt8+unqJR1TeD3e4+O+zXIJS5Cpk7JigsYazoYCWubTsC8bYE52A/85wIqp3WBVcV8MqiG2SU70e8RgZurHbhdRuFh15IpzwuqUkUlSFdjME1nA8Y+u/gpL3RpaJNmmPXVCdG4WIY+ysocqBLLRcvF8uMpFZbUPA8s6Tb2czTF4cB/1jWbeuBi8D+kokof8OD2XBs8GU8cTSVPIyg35DbgOqcWPQmdqur904sHWUGj98KDSA22qwiQTKBzNpvOA02DWOrI+UJjWJ0mx5hKvRN0BGW7Lsr2EvyozwkzLhhqZSiUzz/UPD+dLTHpJHCdTwE9AP1/eBQaEowL/9r9CR9dPEp0wqG3VmebmmB8SSw85LiVfeBG8w5Ral3QbyVbUGHR/QGINv0YWBJZv8084ReqPxCoWW9oAIBGnhf8MDY34YGtHzZKRvGXR1vwhQV3dimazzc/LBzkQHeOCo0Gbk3gx6bdE23MBcprPj/16MlM2mrvD7MVPYDdD9old4NaiGl6RlR4BoEQ9IQkEYGva1D2OJtFt5Bt8vgJakFPmfHU1/regKueHD5+/pKG5dzg2IaRugbpQjn6teIJhgvWpAI4Va2rSxwOQ8N2tGpi6w9MC+jl50O8Au+Aea8FoQvnHo07pG0XagtQLtQFIJf44+9Ea/EVwup3/qFV/0XCwoAz9NyowZSRlZI4eOtVwIVKyvy5cxKPoxKJnlyEswgO6Mmfjis7Bn0HBHOtGEYQ4x1RKB5LSa3u96ZY3ZuExqgKuTELy/r+K0uP+qjoZFiMH107SsSjju9jCIh4JJ2nRNHXt94PEJ6iE1hgadceIOyo69EQQGzMj/tybrBtJIGoxl7XOc6E73pCR8+eoFE9FcZuZhDka4RE6vasZTsKPKj9+BZh0/w+LLXiop6basbva4cwQp9bcCj14iS/HQC6h8egkdv2zHD9NAxuyxnLcWCUWMaT+Qn6ds+19ugY2S549UhujPuNb3KfSr6AzzWs8cHg/0jgHHWpifHq64eXjwtm4KcWDO3X12HsGJWGiVtaFxk6PjzHTUBKoznzAv0CrOIk03FdFQGhAH09SIUWDGsE0P4zxsoYuuOv+emyunS/UZM9f4IBLAk3xscGtd+7/ezq53MNxD6Q46Iz+Lbv3tw2W6bRZ5WolwxSTI3Yjaqo+RGtPxe3KAyNJnfdLjdDI35CewiCXa/TCtfil1XUVwKyDDeZ0jF/amt+gmWUY0e7v3IWy8f5H9DjRNguGxI99MtLtNzu6wjFQN1X3cexTRID+zDlgJAD4/vt6OS8MM5cBtryeH+Q8652z3HfTlqiCz4jBMYNg4SM4EJFlwmZpSmVgromedhBfXTlP0L76gtZ7G0owldJcOGBybHygPELuHy9Mpcr6P3gXDK39iDt3imQbNw4t9Z0bBgFHMFAWi5CvYCj7xgElWXxhYuNg1JT3/SBxoNtPmSYSYHp/mz+9PInTg1hhmTEokczuSWNhrwjqyk/6LzPJAUBcx8c3wkDXzU9E7LtWRzHQlIjLWsicUdQLdBlEv4i52atwQjC4SXWqS3PkzMeN+rQ5MzIONRNOZkZgc+KGYosG6zo5F8qbjtIgsH6xkUWQsaxhh3WY2y/fvjO7rHnDcudW4OOL3Nhn2e4SRUXRQgy5Sx6A9Ix2hd0gRs6kmtMxtPnzsEGoc3tHMiZCA/lo4tHKeYc1HsSN8pv8MvFbmSo+KTot/DhlXtAcvVQmD4QxmvCd4xr172+oQsjuA9rWBdmeZES1kXH95rIQanNQsI5wnVNELDb3jRQPblfBNNskpDGZ1ePrtiH3U6VFNUjll9umYdH76RwA3ALLFqFHhL/VXWbNsiT98NWppvTsLjlMEVLkTcqfLf9GF2ve538NzVGXOnUtrv6elHYFaB6IeGCxwcJdRVIgD7u//OmdXCastr29VTZo7tvM1ApiPi0W+Be1Tbj1trz42AgLZpkJhLhKj22JcTAymZZkjy/XpKD2LdgXzadqN/IfGgduMzrBTPYoT6AhDIgGVC6EPpx/9c3BxXPjrML/dUO/CxOc75qu0aZPUK1ivxgC6jtgbOVQ6fy9gRpjlWSKQFS6ZCPQEzF3wbSroSL/4kdArfHp21iPDITRkiTUnGwshzDuUa9HuXj+PdYHLppjeSOsvVPbaxHQf3dELf00n06tioavssTdQzEZgXYOh1AyqtSSJkuA/LZ74qwNsLxvLHDNo5qkOUBp2PmR09wTy0NEPqtNh1IF9L9+tzKf0udyUrm21XAzuwWOrpKx4O+nYr9yXY8Z3qO44zoBPEg8f8IMUYqcW2ZLTuTDUnyjRQANw0/A94e4k/sKFlyDdlkZccKz8lGBsoXDeWZCdL60aX/lnLF2EiWEB/LwWHsx8fboeilPhjGEAAsoZW4rzP/ixtE7FoIi7lF8crGrgHScXHw7Ng3cBuBP7iDyIzeS6wGkPfFJQ7IpySBOw/ivD8e/VGschiNNrNwUAM3YLxhmYa46V49hAeE/clS57ZfF4b1mbMpbaOExz7ARDMjHsKjDLxfJw3nSf7CHcmtdQ/Ni0PByi1SjW4QZeOvhLOyz/Mfc3OVwO5Mz8w8yK0vE7XgG1IpfEx0XzG76fLBPHX1fUUKRMh6bMLxJBRI0xEOK+9OCB1fFTLsv3MHYwHbry3yckiRVi6gGbOliPQa/87U1o8ngJHvjJmFKH0L4G8Jsu06Xeisp9s2p0ZobHexhrxAjNJ6xns2ulBfmT8MAbYNResb0t0Y0GizovbfuaODw3ai5kurDC/7QukiTdL+smg7wNfx8foX5wTQsaFvv+spZ1ICbSDDJKw1vywglEWDePwoP6o6E7ZnwFXrtYUXRrw0npnqwCAJ6OAWCPO137nDRTSMgQYhlrNxPxBs5JgHkPVBrvUOiJ8WWXa07nM6bVIeqihHB/+wWt952kdxhCt3MBEpTnr79ufhdYhZ9C3FJpWnj+jAIqJZEAk9J0mG/c4dgzjwt+gYe7uZbYgbTC9+hLmPGYPCIf6Px/v/LuNC767g2NHMQT2onvjnvLFZmcsMfHoE9PA6ZokbI8Ksf29ouTJYaoH4x7xJfDHW2GkzE0EofPmndhBmMcUDE6XWDU5LgIiaTMDNqxraLp/r0+s/0nLZXcNxQlOgXiNvFvL+LmyAJQR6AuLigYsNr8T3WdLjfmmI5JSDUK4AiHEQHut1JjcohAUc+VU7QgKhkmwgekbreNeOBrOBootNm/fL8gssfFBmDFb11qD2a4KRJ5tOuvRizJQvoSRFTpW5qgpIA0HXad77UQs9gnUtHy9U5lFBRDmTo6jSZ9XsV+3w4CVZWu+uXICf2mHUpaTjNZBPrWpyqA/L0fGp+HUiOePWQth6cIPMrNZ2bKWtbD0LgxCPHhXJuFns6Md5nxXcvjV0A/2FptIRC9dtRYOBep4r/Kod700bsb6LPqhMv2vHPYtycgw0jQP57Oqn/BQvZ/0PmkXAchL+wH5QhhimbkLfW6CuXGdbFXuhq4eSZxqj41nbA3ZSn1cnG4aHCntGZbBtMe/eAYx7CwLdd74HA0z/1TuQHTeoJiSR5/54+mPa+MPQMJ8LgY6ebt32ifPtJhH62nXFQDVzQ+gUQ9WxbZzxHzhIGIPjZWbx77nGdAySzjxQSlr/9I6wQIOP75D5yNz/6B2huxY0nUt8ro8jYA4XfRdhn2sRUk7i/6Anl35JVSHCa/JXAYCBTIybWtf1RJgETkuVwaUF98yhVeMGDKOcz8T3/d07tJpnzBLvTH5hKF3lr94hQmp26CjRZvLH9R+jv7n0XLfzQuUFfZJBdUj3UqGkoBEGzgIA1Wfr95juGk0f7guoPDeHDE+LtzrI7cpb9202de129o7dxzszjua1Pcj87ncd6ad3jG4e6Puv//j6j5cEpKQzcEv+zk2ipLalg6ire/MuAHQLriKhA/NudJoaPxPg641kafGwYsxDNrPzPbDKRQmzGaAerR7VDoUsgKUb0a5PyAqynPUwuWj+dofLRxePkjsePbrv9U1WJaUT9vebyqqIcvynAMDkwjSdSBgNHThy5NnUBkvsjYDJeLrtQRz0OsoyDdoRZcAuqawB192fME48Z53r5IP4mSeIpsruzTaj6YclwcNHzDHW1rdtfe6hXmqubu3SvdNT/TAMQ3oBi8ftTFiGM/2cyFWD9oRNO14F4v5eFX5YY7C9joABYQEa6HYDR0gFdSLh5w0xivNrTtdL/VSCPyyI2edygz3u3I6GWH02Q0IQVzbbuwCQRt8XqFzuM5ZtezQhXTn/4but19xKNG7pFNgTNUrTc4R3gtxeDKpEn/doqA+CjfSMevaCu7aj3/04/5XgHFDrlF2Xep0X8PO6MbYbeKXifhcA/LVKOCNjviWBz74TrrdjRntk85cb3d8DHbq9bx33iEB3xTCJUXNQr+O5EppfFcyBziA/CDN5QjLEkHt8vv8FNbOnuId9yz54e3EoYb+y29GCYaE/BYCO0P5RkyXyp8xswaz2NPSCpM+CeG1XSdeGgEftr6ZD6BrS9OwxEuoSkgjbEmvXUdb9jDNpSmgb3CzH/4D64/qJGku6mlKI98XE8KIVxMLI9shPAWD6yOeFyrK7ho88IfONWxCeuE532fS2YcTc+LaiWoCOwHiJXFJ0dpoB0l5aSu3dYVwoAcoeyFqZUEWWj+v/7iAxipreowWhaI7g953seQYw91MAkEwhyHkOzVEDUA/MnhDtI1JA07EmNK9hnzkQAicyyQGexIvgtkkVrEXHOFjJ+Ely1cQKNKgTlip5nv1iH89/i8u80xovI4kNeLDd0dw7xjJSfhcAqosB9eIZ1uFPN8/tomjvk9WYVY7zXginawT0DbuapeOnKOS+oCyliJ8yGIf81ynPQwf3OijZkDuXHFEzPr3+NOEp+iWI+dRiNu4XQjgB/VygFB+zAHC19ZrJ7KtlPOq67VPpuRCQgtjs2ivTanPwxHCMhLgI3yU8Jhl0ezM/jKMIrHxOBilwNxFimdQCf+7j6T/UYaRp5EQTtVdsCH+SFgGhvfCIWJefAsBa2j47dfidKaRrbwMpI1fhyM1Tmm6uY1K9ePSUe1vAc1h2MaSsOTWJEV+sGqwwS+kY9cEYihG21Zk32j6eAFRwoTWHi7jZtKRsGjOlU/wi2J3qTO69iFiQ6oXnnatb4TVt9qH4Dgy6v1EAPSJ1ffaRxnDPmCp4jWL21Ym67uOX4yNpTSuz+UC7WiGQCf63z65+auDSWZTdrBUYkaG00iQePzWKlaBtBnTqdYhdIIcljkCO992FOg40aDjbg7iYobt0dewXM8A7+grOkU+kMUEvcou/BL6ZBQobxhHPUio1wMf7/8vsadwmaiMEWR4yOrokWggoYa1k5kDfPid6Cp4UBoTXTBCsr7Os2wIX64e2qb02WpDRwDh8YBvGNt0iAuWMWAEx31+AD3oFJxAN7kYtqfe70Y/7P7D6WF4C8gtBOj8xCKIHO9jMaC9LGJ5WQif1Bwz8dk9uEh8ZzwRGU/KCvMkM9QbGpOqw78zeUXs9a2g3mcAXTeWvwHdYUflw/Fx2782Tzk8v/7Yuxfba8bkK9I1OM7fNSEtS8MlsikuWIptxHQ/ylB6JXlfcBLNogbwxd3T5HuOgC2hABwKnrNEz8GUSHzb+TnyWkhe2wamLSTt57o/zPx8DOHRbBoNb6SGRC/qltSQsH86uTK23ZZYijwV6puUlSd6GQepr3MwXEVLkbCEzdfo44NqBeRPf6z8TX55Xxem9KYNBYkPS9en1T/khcnq/hGGipDVTsc1u1pejs4gRI8IUPP00M3mP3DYiqhWg0lL96tH034NDgYJRBOW/Jj64W4+8IwpCAEjNx73fe3ahZeAF12tPw9dUyWxxKI9VSAPwzbVojw8Mu92UOBC6LEB0sLX2yMPVgkzbe3AItBmV/B+JL9gqy0wijRRkX3kMH+9/n2ssNO4LR8yW/dFiRD4swc8ub2sSIv1EO4Z8N5ZbLhUctUTWQ+0XQZyfEeQjiWnH5uls//yvic+foUnWrNAW8gji894fRL9xvV0r3hhlRQmV8pZfqy0toJmDpgvasGOpHJuz6OeAXvi/pUz0EphxsTF+EesQQ5DfQ5P/lPieQ5M5oY4IZ06NEeTz/f/7GpP1SMgEOEIWa2jq56tKwY4jWqQtYPpWgW+nmU3LYSA5chgRFyQAE+7VuhQDWi28aPNraPIfCh8/Q5Mktwn7XpbxdMSP9785ZCiROBZQ3YVd2raao9d3WxKiAXdsGOnPO7WMZJXUbpfXhvRvzkur6I1k+QxIGqbehChE+q+Fr5+hSW78ScwgTe/j/F8oAPmBvA4Z8Bqckhju8DUpNhJIL/b1zFnNMYe4ILFRUuaMax8sbsvW+1hIva0GyonwDpGDyss/FD7/GJpkZpMEAecmNrN//Py9XkV/FUqWbYsSFKrpdN7Ie6VDl7WbvcxDrAJjYL3u2TDKhXYeNR3Dwng85IPzXDlZArfd/2Ph+9fQ5H0x2jA2Ite0IdaP85/rOepkbDonlgz7MUgiwTxITrYCJl0LxDXP9o82tjnHIRZJ7TE7IpDJHvjuWXhBz9dLLZd59X9tfGh/H5oMZBwNoiJd8M/X/9vruQhVuS5ha6tnYmJ3MjSsjab9mIPAai25IFEOqszCAE9kli3WBNbBOk6KFAlkR6eXy6VN2f6l8eX496FJCVb4Rz2zV/h/IQFyNumbd9FIM/OxGLsW+9JwIvEd19uLFwwBuaGCoyNnNip4pTkf8K6E72t7SJCuPFeQqPYI7dxCFlHfjU/nvw9NVgQR+YV7S2j1n148zEZ/FYlXDR085LVMwIbH/Tp3JHywb1mAnC1RXTwTyqvN2iHhIeWeufvwRs8ecUAQfTNmoVL4JR27mI1vFcS/D02Oo9AGcq9E9fLx/g8ry0587FnNWfyZjjb9ahuXcgMx0TEVazT4+mknWMkZ/GaDXDrcZa7evPcg3H65UDma5dIx7d+Nj7MK9h+GJjeOOFGhYXBl9cfx74bo9og1IDlvc6ZN2nmXCfVLBC3R23WKpHUWOebcB0JkeDdIh1aZvtbYJqZfD6ivnSFD8qNsARhnTA4g/zA0ibF/t3lT9wKlfXz+cdmz3mvQ8OwB2frMYq5zOgFmuicv0PyCwA4d47yzQCH+XSW5g9x6I9c9xEqkc8dgM5d/VyBlejyNUElH8g9Dk4Ku+zCoQOg07cf7vwsD1d4e+zW4AjVntZV4/2OO7VS/R/Tc+1UZ9COvUtQbQ0PGP3RkeMcc9Ib4TGCMxoE4p/Xr6WRnc1TiPw9NNn0sDAJfnZqTIB+WXIJr2awE3viebHTOhGyvc6CLOm0iMtfjNbdiAWVcXQhc8gzLm9zke3hh30xvuYtR039sUHdLN43s6T8PTe6liQBeYSzVH1/+bGIo1MAxhz/xv+uDBu3zDs8zkx2E3YxeN6Lb9jrwEIXL3oPDw166dXOsz5pxQrk4KsGN6GiAR3iMH7BZ/g9Dk201AoNNfu17Ux9nwDlu6JFSWJYdQ31b+auLF59oB0/OdEOblzEjVzPoByqa+zo7vSZfGIdHFNvbgrQmnEh8id3Q4MHoNYJMkYn/PDTJg+/yXGIFpvvH+7+GEZdEP11mTXtWNiqCU+Q8h5vZ22WZjTAsoCGr2A1BtMvYvrzn9oXkofaMS7gIn22knG2dwcbfjcNyi529T/dvQ5OtpJr8vDKJCggf93/W4SODw3AnJLRGkMu/QCHSezCeF1aEEaZZV6nYwm9lrSypiieqi0gnur/3YOdy/THO4troFYMjms2/D01SU5Ya3RATWbqP33+SWkId0GjEfJZ4srdI80ANNttZemlXH2yEd1ETwQwRHOF9gnlxDxdz4K3ssyFgq7Mffnkjoi1PGN0L1ZGq9rehSaJYlfeQbdbLERR/vP4H8ajMec/xgdH1n3zv/Cowb0CigRtd25OJXihgUA8RynHtq8KDdratZWa3AenPdu4nmk9BPUKA+x6Mg92CcOTvQ5NKIwq8qBAM1p6ej6f/cZXmNbENUtHD7he6gOuBd1Ym7YUpDNSpg9luQHBv743nsl3dzHszrHa2Ogv6DhjH+rWG3sNZkejNZiphV+/SX4cmJwpKazBupYmir0S4eOiP+38LlFwvSJPczMlEDOF1A85xD1qWXNqMRyvllbVYC3/sWqVUPnonETf5UYeBcRGbhLmOvrnJjO0CI0viUi7yL0OTuwdW1txnx1HXyKyo5enj8x9cC+IQ7GC4tz9k3NsXMXmzlOV1Tds2xrU4WlhdOMP4XnCFqndR6xZFvucNJgjvjIetMRZmchNSmgPBS2n78efQJBBHpBbOE9Pw1N2cnY/bxwHQlRgejK/waDMngcCuwviUt5MGx3u8HBQBsZoeHjs71n5GoPZL7jM30GuaFJbMdTwIcPa1ZMqO5eiIK0OofxmapAiZDI1S4Q+R9016ucaP5783GyluANKACKnmBPbUIGxFAw5HHRt5zWy9hzoSzJH/SY3e7ZJvH7FC7DxBXI6Mmlw2j2Tw6P1GpuBxH+DPocmFUYlb4rUxPGuo7t1Owz7e/5dTJXzrgs7Qle9zAVR1xmxlwfWSYppBfUG46+btFp7NtP4x4/0bMMBBex/JS/mTypgbFNO6vHRq0Qfyx9BkFkxJPXKeCREPolBSZ/P7x/NfTGK4UrOj6Q3FnusQbD+r4pCUnikhsNZbq4lGwuYIb9bnC3dpJgJrXpRDVih0QHD8VzLT97IO83to0niBSJdHUm6yBM2JjGURBENi+ngF1ImwgarpNkfBs6n3HZGsjVGF1mQyN1zM2KtknFORG8k9XLtGAqdmKrww6ZEdA9ujANwOT1ADkPrHNShyhFrfmRN4UZEQWhY+CKV+R6BBZR5OLfXj+f9qWfTcN5fSvm47+m4/07kiULeveNJ9Foe3lRoWEB0v4E7k9hgA3lc63YomtJfXvobZOngiDOqtpdGDEDuGxFLnFO2OlLkXDIGuY+SbhdGZ9bHx3BX9/P0XRWxtR8KnYT2PCxdoCPIWwqhCR1/mdYWz11luWuyrrUZZcyD0Vem1IhV6TRsmyzrL3UduuAHPde0u9URYiRqDyTVYbhQcmsGh9gKbO959ttSrJVhPP71+Mib53dgc7rgHRnJqaqIRGKIdhTiImwt5QcrG5BcqsVcQCRGhsxOJgKnSEEmQ0hGY9wSTOS+5p3WCYin1gVqzbBg66wxz4bwOuSA4sgg1wMBK9Zo+fv9ptIGcgZDQ85hJPJBrne0OwrYNiNmk416iU9d4mluL6Aey1nMOgK1HRBe44RbA4yiGACuJlyJFo7mzSG7WhkFfm+FcRrALWvm92Rkl0swbi5LE0j/e/zRgtQSsrHed1x5fe9k3oRwcErkQIvTdMKtZ7QbxrkCTZn2YpbbJ/+fFUEVqr23I2nY671HIHh2IvwTv0t5yTr6vW3fM9J164Cr2sYo1HAiLYz+iah+f/+UYlKyUZp03tbWXP0tf0RpQndEnLCBzWihvVA18kerDk1wtJerolJL7aISS7HmDwfjF88pcCWNLLxcJy6dZR9S72pD+ho0S0XomYyIMKscoLN/Rf9z/t3ntRZ9xKJp5B5hb9byyHHFg5WGgN1jEvN3gfhD/wf6kvlKupdAv5sl7aJJohfHMIqZn+MMaET13CJiO992g+9WXiIqEP/rT6f/MtpF1Ek4daHvcZxcP8/o/dHGqnoht7SzlonWiW/dZwvPab3T/BqEr9IAUIatoZtrnLjJd7N25P4cmlZx3QeFSiLS+RsPEvuu2vhFVZa2Cqwcl/Z1kz8tsAhuzafiBi9r+cf6XTXMm5zaZWJt3Fi0mzh4WWe2+hTMopa2ZRzmRrHtj14HM1qzHvw9N5t07o6Kt6Rx23vD6gG6BIpfOCAHtYrUduSkEvTyD177N3PGHZV/wMbYVHfyccOjo9+d996sxMfTdRiOR31lYg4FwFaRxFBpdl9xzjn8fmixbwiUqJhyhBrFAgx1EvGbzw9K5QYfZmWZzlAy9yyyog94+v/4zWc8c1JUXCDvnOiNoRUys151bAVJPZIvKEV5H6ZpBjcupZt9+WSH9y9DkReXqGPEIbhe3DvT8MK9+xeAvq0EO3fKBCpZL5W33ggGxED5e/91XWaJxhiK1ARITpeI8GAjRhkaKss7rKmMHub06Gnjbd4R8pM2ed62XJf1laFJnsOXY+gHm3OZkvznntPzMlarLw3aeM8B2DURnmY1o5z4+P//yM+mJaJ9ZRGuQZ0PjKAPKuRDCg6rUlY3011PJAbeGrNScfOgNETJRwfw5NKko8b0/T0cUlVEzNIUNZutjY7O2UG9wA1SAWWGDllcooz4fx/9ArXTjWDSIYPBMR6bZnnCVCIvJhONh7+OaxbBsHlykWzmCY/syNvPiVQ5/DE02Ziy6ivK8ywAnmxekEYUGnkPQ1vE0+Gk8RPduBLLvoSP4ePyX0LMNSHo1574PW6oKsl+pz8G36Bu0UXScwW2Jdk7LQ1/M8WCgh3jo0fzifg1NYggNcwAW1xRQRXi7hsfYhzviwPdjV8EXjCpuXAKY1j+Z/4/Xv3aDOk8I9bEzQGa+H4PC0lLPJsZl2/L18x0V78dtBZZbbdmcQweEh+o1Zhco/AxN1uTW2U5pA7+OWVjQeNCoE6Xm1T2nNAp5xEgYT5E85J4wfJqP538cEzP0pcwQCMxb//ZCCTp/ZDGRIlrZTyQrS3j3acySPe9zmOVKuP6A1GemiMgMBX7faVtSeieGGLyaB8ZHFZ4jr3aRl33aPqU/V35wH69zz6A/nv9rs95B99dLw3LFtcTFzmtAlknwfD5eePBzuD/9XNXwYCxEG+jk9cySAamMsI77Na8H6Z1XAxeP2/zJXqMT6PjndwuARNMZtU0HiOEW+FhmXzg8JXweABM4X+yZiXASUPMxhoXj7oRX/sBsbd+DmJOKZj80nv28uzq98syBD5Nfo9SUdiD7jx37TeA7a546cM3Wf7IfDuIcjV/W+eFzatiOcXddJEaHo30c/6IVu3mrDdfX+yxiGCfV6LBOh87+PdRvufbW9NQwLAr1qMf/urvifpbGTYseg8T7ClmVUrSJpTTiNishj5R9QH51h2qwY3SdQ9T64PVQLsVZKP14/9eOj6C913q1PzcSMMZXWEbco75vGwOMG723r4szeg6LgYqAMAh/sBauEMFjOKhSo+pHsaJnH5sw4PYTDAKmVJdV6xr48oS9uwSLnXetIi80s97Wj4/3v77uQ75RYFsFe0+zkwS6Y8hur12VA7YrlXvbe63nvN7VzgtOESGBM5WBPK7ex1btgux5eOksIUMK5plisi6g6ghsZtbX5cH4Jw6E0sFcINefzs/t4+tndSwQzry3uJp3LS8W9N8z26X5uvHtTrDt4lgom2MNg47T4m/1TRFE8JFzyhmiYbcj/CMwe2MNwcjA8CW1dURXQ0IBE6VagEHpzVo2uyzYj+f7eP0LKFolh7G12Od3gNHA4YpIYgZoVGIy+f48JPfGKmPAvOYIbmv3s5Rf99eQlfCr0Pe/I3tEK0IQPJkh4sf8Uy+8Z/8Dw49g+DmUrS5eB12fj8OfmcZD7cwrPpnsM++DK5UF/TXG612kBnGdh4TEcKZqJwpyrzm1vEZEyKwpfjoM4+gTup+XOUdt3OyTeDKSpfktP3MGlnJhRyJ5dlWzgXBhO1IPDwKr5+P498SDnBcgzEGfXCYX+rmTCv8/jSPEB+xuCdvtMNplZY29tJNkfm+SceW2ra8hACHHslBeSCk+vm+168iRLq7EvAiR1LY9SHm7GTe0U7QtTQK9CuE/3v/0OHmjY7bOEZnfp3EThHzcIwjeNSL5MtCRC4dstW0jl/1VidHKDrvs/WX8zqTOVobOyGIXTZAUg6TNmAX3akHMYzcGvlofCuRdPgs0vWdi9grEFf3x9XMJMldScxVLZwPtNt4I5ucNJ3M4cR8bevFUVFuUUptbd8QAzSlJi5c5+DV4pY7cV2r92g0jlCFuTit6UJLE2pQT4gnBSxBn4rLB3lRFjCwHwgHB+cfrP7Ole+leUn+oRN2lPbQEUqV1XnrDrmOvkqezzAelJkQOvASJJ2k3NPhTFctKvRzflI/tJkil5lWpG0fguxxbEfuC4WNyCMPNpoGKPPqSi6Ee179+Hv6JNH3ahRie7WiisM47r/zybHBBWvC0JZJY1FoWO3SuUT+EE7H39x0OnvN5me9rMSvGs3U2wh1bq6nM1uiGDOFE9ZljNL/GnNrz0N0qZISVQiMhfd7/ZT7Hc2FtaKG5/+pHM2Ne5x7mlzh1OfO8tZUb4riI34LPVel5h4dCO2YLIlmQaT3WRKcLPcriHILBNJHtiiahjpLe13y+Q/2T0jO7xPeaZ13Yfvz+m1dnagZoU0lYVQ6TkSIxQTVGHn9yNAbXEnv84dzrQeSX6Wxqn3e4VPDO4ZbddDY8He8vTsGgII1c+6T186tSpXTH+w6YYXwMxmmozM0+iVQumldvPj7/eIyVz6+8WbzmyHvnt7cAbSwHSrJ7Z2d9yXZ+KepdDxfR5nMhP3f46PdYm4mB5uiYHkeXRrClbCE3joZVnNZ8Q27hFmbvs4U6LkBtcSWuweiHlLF/3P/TUgYXdT8HLpaPOq/oYULrvNa6zMwPRSNHHINnJ3lYq0Tl/3WHU1e65JnHikQpjJgyMdfRtRmJVrWIYWdXrOBQjrOycY2956vPyJLPCwPNFnOUHz9/wraVQOVnIimq7arnqXNc1lTy4vR73gHqq2YzZ/eJbwLR/s8dXhB3Ol7rvCIAld17uRiqZCOzFRghz4Z04H2pLG7GeVdGS3YIj8KEWJQSNJaDfDz7jUIrBKDorsI4iGk9jy07tAizWAk1HGw9L3hs6vOOd5WW5fcdbrNd7CAKGeArU9vTvCx71Z4Ary/QlOJWAKH7uys8PA3YzAikrsBvIB6f4t7n6NSHZU5w+V5P//4WvNn5jk92C3FStiCjE3dIAUYz+92B3z1v/Y87/GB+a5JSzwN3Q9/P7bKUdcKm4xlroWpFmBN8+4lxz6mO1BQEgktWLM8L4M8qP97//nhr4dx9UZB4wVW56RMGnC9N2/zeA8TC4YE9nQuk1bBw/b7K5j3nipAIHs5eePpCFsuP9xfe2kt4q6fTQPBbkPLOSZm+1FlCXRZUqqbinpAHmY/n//rRS3EFyS4C4b2AUNbbdxv/vMPTQUdc9JpXws+LgdjiOfnjDs8yUx6zl+VBXOiTWVyc33k9x6jwR2r3vszpx/XVosJN7kAa4ox01IK2hHYDRH++/IMOes4rstnMQg7Euly3n6z8vMPVrIX32es2y9trmTZM/rjKptpS319y/W6dbHxVQc+vEDwRCqK5y3ymsiGCuDu6EsE4mV8x3Gfpc96N+cZDn4f/v+QgCz7qVkKJfuYstrmuGaDLmF//JmaZ5NVqcPEvV9nUjcp3YQD5TyC8mrBIDBIzydv7/r4BSWCYyPJ12PkVu/W4MerNpMn7twjIz/f/f+UrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yFYD/B92aGZl3Kab3AAAyEGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNC4yLjItYzA2MyA1My4zNTE3MzUsIDIwMDgvMDcvMjItMTg6MTE6MTIgICAgICAgICI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyI+CiAgICAgICAgIDx4bXA6Q3JlYXRvclRvb2w+QWRvYmUgRmlyZXdvcmtzIENTNDwveG1wOkNyZWF0b3JUb29sPgogICAgICAgICA8eG1wOkNyZWF0ZURhdGU+MjAxMC0wOS0zMFQyMToxMzoxNFo8L3htcDpDcmVhdGVEYXRlPgogICAgICAgICA8eG1wOk1vZGlmeURhdGU+MjAxMC0wOS0zMFQyMToxNjo1Mlo8L3htcDpNb2RpZnlEYXRlPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9wbmc8L2RjOmZvcm1hdD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgCjw/eHBhY2tldCBlbmQ9InciPz5DnFz1AAAANklEQVQ4jWNkYGD4z0BFwERNw4aGgSwwxv//lAUlIyMjAwPDUPDyqIGjBo4aOCAGMjIM9hIbAIf+BSc7FnzSAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div.iGraphHelperZoom {\
            float: right;\
            font-family: verdana;\
            font-size: 10px;\
            color: black;\
        }\
        div.iGraphHelperZoom a {\
            color: #002BB8;\
        }\
        div.iGraphHelperBottomIcons {\
            float: left;\
        }\
        div.iGraphHelperTopIcons {\
            float: right;\
        }\
        div.iGraphHelperIcons {\
            width: 18px;\
            height: 18px;\
            cursor: pointer;\
            margin: 3px 5px 3px 1px;\
            opacity: 1;\
        }\
        div#iGraphIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAACZ0lEQVR42q2UW0iUURDH/5+7YhFFRiCFkC9SiJZYFhsFgl2oEPJCRkT0IoUmkUlGN8PWLmwiSg8mRT1oipQVqClJbeuqmQ+JYvlQtoZ8uSu6uuzFXff7/j24nty2INJ5mTNzzvxmzgyMBIBYAtECALk4liRJCJs3kou60fPV+d+wsIWGze7C3VZr0ANP7RNM55+Fo/ACfCbTP4BIxEavRnO/G95ZFQDgKroEf+MLaCMiILmc8FTegyPnFNQx6x9hJMlthWb6FZWJJRbm1Y7RW1VNZ0oq/f0DnBdFljmdkcXJw0dY894u/ACoXUCDdcKBzKRVkJ+b4B+sQXh6GjQJ8SJjRX8EGrYYoA0DtMYpVBun8K4oJriipPMmkWE8TseR5ANcKGce27ixcJgX62xURkbo3rqdHx62iop+gQqMJEn/6Vx6ozcwNbOdBTUT9CsqM8p+MCpnmIaXkwLsO3GSnh07Q0GJ595QHhqmsjKSyvUSXq6fJLIt1By1UJNtYUOnk7+LN3ZTaI+gEuuGBoCoKKD4KvQA9NmRuNNox4r1j9Bp/wRTi4LMuGNIidkLANDodKHjJ1Wos7Og2Sgue793oc91HL3fTFgTvhbLsBxl5hto+9I0F3y7NHT8m/PbKJt7RNnlbTd5qHw3S5uu0O11Cf/9jgoerNoV9MWgHiXkveL4tI23nhYzTb+H+67p+Ky7PqQvM74Zplfup6FV/xdQbgvf9rWza7CD5o899Hg9JMlR2SYCRmUrSdI2Nca61/V0zTgFSAqAEJ/bDJAgAgnUOR1IJXSgG+L8+UEWJEmCAC12jUhLtdh+AkEUAe++FhGGAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div#iGraphZoomerIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAB4ElEQVR42q2UvWuTURTGf/d93ySmJsZWmiIWP+ikgyIFRVzESf8CBxdXQf+Hzg7uIri7OgkuuihGpQpWE7TQEluSNI2aj9f3657jkCZSbJqKfZbDhXt/PJzz3GMAZR/kAaj+H8sY0wcNpKp8aQr1jsUPLYkVXCMUcw7nj09gjBkN679XVJX3axZVYXLC4DkKCkGiVJsBYZRw7dzUjjBjDM7gUNkQRC3FnCGILc2upd61+JFwcjqLAi+WWiMdDUH1dsxU1tAJLX6kJKJYq/QipfXLcuxIlspaezyoG1hcB/xIsaJYoQ8TpRcK6ZRLqx3uPjWAKE4QTZGIIgJW/1QVsNq/M9aRixDEgueYLScMa8oz+EFMxpXxoGLeZaXuk884pF2D3XKW8QyHsy4fl5sc+r5Ib/Pb7qCLc3mCMGZp9QcpF4p5j2LBI+0opU81ups1rsys8/LhHTobq6NzNAjksw8NKtU2rU5IElsOpB2mo6/MO6+YPX2B9cobVj6XuHr3EYWZU8McbQONkiQx7x4vEHcanDhziWr5NcvlEjfvL/4dyN3keCnmbyyQeAcpv31KcXaOTqu2c4/2Art86x6SKfD8yQPOXr89ukd7kYjF/9kgN3l021/7Z9CoNWL2a7H9BsVQBplwQpyqAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div#iGraphCSVIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAIAAADZrBkAAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAB90lEQVR4nJ2SzUtUURiH589w4cJC0TTNYcI0E2FQBh1BZ3LCm6aSU4yJ4zd+4MfVJpGuX8SgTFiBqUjZ5MYS3cyijSCCC12JrhJKSAhExUU9cI5nrrrz8GxmuM95z/t7X4vl2mfkew8EvrZCz2wdtL17Wh987BstfWa4nwQKNT3f0213deSAs+leVPuyNRfe/AizayF4/+PN28hocHVo/NsADIY79flm4Maoxr9o/87PydmJ4Pj0WPDn6FBwQeNt1LmkXXUO/v7m8QUNGVLT5/2fNj4g+MO14Jvxlk9owtH0R4r9w59ojnqb1ChNP1QomMjntd0r7Z3LTZ7hYj5tXvQ+nHbbXqdbnlvQ6kJlebVWqXEHGYi3YU5vTLUsvqhZqHL22c3OZY2syU0l8cDICq2HfDMajr3Rppy9g13fpDvXe1tqzIesVQZ8bR1IMyKvKiYdzqnC7OokugW0mmARP6XGTMeW+kVoOKKfW13xgUivMo0FfefXDlpWZaLUqgadjE44d1wpioSOG+1LfmWiVYzZ75bdlBq7IzQmIxDNvPysm29B00ZyrKVxUmPfWByzIAIws72/DR4jM7UkVmosKKMzO0LjeoFwwDVkjWrulvtq8QXMh6wJAOiHt1EH0JKLYqTGdirYHQYKzAfIDYiBloBS0WrXOP8BX5G9lz7LzIkAAAAASUVORK5CYII%3D) no-repeat scroll center;\
        }\
        div#iGraphDataTableIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAIAAADZrBkAAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAA7EAAAOxAGVKw4bAAACOUlEQVR4nGNgIBv0bq8Fopb1JUBUuzQbiErnJuVOicroC0ntDopt8YpscA2tcQqssAUi70JzhLaJC7bN2/lo/oG3c/e9nrXn9bRdLydvfz5h67OeTU861j9qWfOgYeXd2qV3qmcfR2hrW1c5b/fTL99/E0Ql868gtAHdNm//G6Do0qtzFl6eMffClBnnJkw+3d13sr3zWFPL4bqGg1U1+8qACvJnX/HMN4Nqa1iRN3vva6Dof7wAqCBr+kX3XGOoNmAYzNj1Eii67PBLPAioIGXyOZdMQ6g2YLhN2f4cog1o6sojL+A2rDmOYL/++D2+/zRCGzCs+7c8/fTt16pjL9cA0fFXa4+/XHfy5YaTQPYLILnhxIutZ17ce/4psuuEfYoOVBswfno2Pv747de6k6+Apm4Ak5i23X76MbTtmHWCBlQbME7b1z388OXXptOvNp9BoO3nXgG1gSw88WLdiRc3Hn0IaTtiGacO1Rbf5t206v77zz+B6oCm7r7wGm7DrvOvPn2DhjBQW3zvCZMIJag2YNqpW3EXqG3Xhde7kdDei6+3nn0FR0BtMV3HDEMUoNqA6a1qyc13n3/uuwSyZ/9lhG1rjyP8CbKt55hugAxUGzCBli68/vbTj1cfvj97++3Rqy/3nn++/eQjUB0aiu08gtAWVGxVOv1Q3vTzGdMuJk86F9d3OrrrZFj78aCWw2gotHKFlo8EVBswdcIRMO0AIxSIgPEDRMBwAyJgMAC9BERAqxC2kQEA0b0fsDpUmdQAAAAASUVORK5CYII%3D) no-repeat scroll center;\
        }\
        div#iGraphRefreshIcon {\
            background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAARCAYAAADQWvz5AAAACXZwQWcAAAASAAAAEQAIFT2JAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAArwAAAK8AFCrDSYAAACVklEQVQ4y2P4//8/AzUwgoEGtOf45dusjjvtuib9r/uytO9aEwN3qvf4eqOrw2uQwdrIqR5HC/+Fnmn9n3S5/X/G1Z7/Ex+s/u+8IvOL5pTAJKIM0lkcHKe/LPC5/qrwcr3lwf5AfqfX9rxvlTdm/J/ycO1/l6XZn9X7ojStF6Vvt1mccRS3QQuDJ5gdTpREtlV3Wax14I6KbyBXzXu89b9qi/f7tc+O/PdZWPSZYBihA42JIUUTbq76v+Lp3v+rn+39f+Dtmf/Wk1IuYzXI7GgGp9nROCZ0Q3QWJ4ooNwVUha+u+Lfp5eH/m18dBxuk3hC4EcMgrZmBoSl7G39k72v+Gbqv9LH7loxThssiNgDDyBAYW1M2vTzw/8T7S/9Pf7gKpC+D2Qrlgf0YBmlO8Zn4/Mfb/+c+3vl/+N0loK1H/k9/tOG/1ky/iZpTwgz1Z0XNc1yUdTxwVeWD2BXVP8KXVHxXbgkMwjDIcFbg5pufHv7f9vLE/00vgQG5Mvuv5rTQUmDMCaF71ezoZkal2hh2rNHvuSzj6qn31/5vfHH4/6qn+//Xnpn9X3tOWAGhSMAwKHhDybc5D7f815rq+27xk+3/++4v/++5Lv+HzsJoa9QUHyejOSWyCqdBdiszz9luyNgEDHRNxyVpX5tuz/9fc3P2f5fV2T+Aqblboz8iWLUrtEa9K+yFel9wFFFZRGdxjJPjsvTPRdcn/88BZo/UK+3/Q8+1/nfeU/wPGPATiM5rIKA5LVxVrdN7hfWCxE+WixJ/6fSHHVdt88smGEZUK0YoxQATSWyMvwe1dwAAAABJRU5ErkJggg%3D%3D) no-repeat scroll center;\
        }\
        div#iGraphCartIcon.addToCartIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAAMFGlDQ1BJQ0MgUHJvZmlsZQAASImVVwdUk8kWnr+kEBJaIAJSQm+C9Cq9FwHpYCMkAUIJkBBU7MiigmtBRQRFRVdAFFwLIGvFriyCvT9QUVlZFws2VN6kgK6vnXfPmX++3Ln3zncnd+bMAKBozcrNzUKVAMjm5wuiAn2YCYlJTFIfIANdQAVE4MxiC3O9IyPDAJSx/u/y7iZAxP01S3Gsfx3/r6LM4QrZACCREKdwhOxsiA8BgKuzcwX5ABA6od5gTn6uGA9BrCqABAEg4mKcJsXqYpwixZMkNjFRvhB7AUCmsliCNAAUxLyZBew0GEdBzNGaz+HxId4CsQc7ncWB+D7Ek7KzcyBWJENsmvJdnLS/xUwZj8lipY1jaS4SIfvxhLlZrHn/53L8b8nOEo3NoQ8bNV0QFCXOGa5bfWZOqBhTIT7KTwmPgFgF4gs8jsRejO+mi4JiZfaDbKEvXDPAAAAFHJZfKMRaEDNEmbHeMmzLEkh8oT0azssPjpHhFEFOlCw+WsDPCg+TxVmRzg0ewzVcoX/0mE0qLyAYYlhp6KHC9Jh4KU/0TAEvLhxiBYi7hZnRoTLfh4XpvuFjNgJRlJizIcRvUwUBUVIbTD1bOJYXZsVmSeaCtYB55afHBEl9sQSuMCFsjAOH6+cv5YBxuPxYGTcMVpdPlMy3JDcrUmaP1XCzAqOk64ztFxZEj/lezYcFJl0H7FEGKyRSNte73PzIGCk3HAVhwBf4ASYQwZYCckAG4HUNtg7CX9KRAMACApAGuMBSphnziJeM8OE3GhSCPyHiAuG4n49klAsKoP7LuFb6tQSpktECiUcmeApxNq6Je+BueBj8esFmizvjLmN+TMWxWYn+RD9iEDGAaDbOgw1ZZ8EmALx/owuFPRdmJ+bCH8vhWzzCU0IP4RHhBqGXcAfEgSeSKDKr2bwiwQ/MmWAq6IXRAmTZpXyfHW4MWTvgPrg75A+54wxcE1ji9jATb9wT5uYAtd8zFI1z+7aWP84nZv19PjK9grmCg4xFyvg/4ztu9WMU3+/WiAP70B8tsRXYQew8dgq7iB3FWgETO4G1YZ3YMTEer4QnkkoYmy1Kwi0TxuGN2Vg3Wg9Yf/5hbpZsfvF6CfO5c/PFm8E3J3eegJeWns/0hqcxlxnMZ1tNYtpa2zgBID7bpUfHG4bkzEYYl77p8k4C4FIKlWnfdCwDAI48BYD+7pvO4DUs97UAHOtmiwQFUp34OAYEQAGKcFdoAB1gAExhPrbAEbgBL+APQkAEiAGJYBZc8XSQDTnPAQvAUlACysBasBFUgW1gJ6gH+8AB0AqOglPgHLgMusENcA/WRT94AYbAOzCCIAgJoSF0RAPRRYwQC8QWcUY8EH8kDIlCEpFkJA3hIyJkAbIMKUPKkSpkB9KA/IocQU4hF5Ee5A7Shwwgr5FPKIZSUVVUGzVGJ6POqDcaisagM9E0NA8tRIvR1WglWovuRVvQU+hl9Abai75AhzGAyWMMTA+zxJwxXywCS8JSMQG2CCvFKrBarAlrh//zNawXG8Q+4kScjjNxS1ibQXgszsbz8EX4KrwKr8db8DP4NbwPH8K/EmgELYIFwZUQTEggpBHmEEoIFYTdhMOEs3Df9BPeEYlEBtGE6AT3ZSIxgzifuIq4ldhMPEnsIT4mDpNIJA2SBcmdFEFikfJJJaTNpL2kE6SrpH7SB7I8WZdsSw4gJ5H55CJyBXkP+Tj5KvkZeUROSc5IzlUuQo4jN09ujdwuuXa5K3L9ciMUZYoJxZ0SQ8mgLKVUUpooZyn3KW/k5eX15V3kp8nz5JfIV8rvl78g3yf/kapCNaf6UmdQRdTV1DrqSeod6hsajWZM86Il0fJpq2kNtNO0h7QPCnQFK4VgBY7CYoVqhRaFqwovFeUUjRS9FWcpFipWKB5UvKI4qCSnZKzkq8RSWqRUrXRE6ZbSsDJd2UY5QjlbeZXyHuWLys9VSCrGKv4qHJVilZ0qp1Ue0zG6Ad2XzqYvo++in6X3qxJVTVSDVTNUy1T3qXapDqmpqNmrxanNVatWO6bWy8AYxoxgRhZjDeMA4ybj0wTtCd4TuBNWTmiacHXCe/WJ6l7qXPVS9Wb1G+qfNJga/hqZGus0WjUeaOKa5prTNOdo1mie1RycqDrRbSJ7YunEAxPvaqFa5lpRWvO1dmp1ag1r62gHaudqb9Y+rT2ow9Dx0snQ2aBzXGdAl67rocvT3aB7QvcPphrTm5nFrGSeYQ7paekF6Yn0duh16Y3om+jH6hfpN+s/MKAYOBukGmww6DAYMtQ1nGq4wLDR8K6RnJGzUbrRJqPzRu+NTYzjjZcbtxo/N1E3CTYpNGk0uW9KM/U0zTOtNb1uRjRzNss022rWbY6aO5inm1ebX7FALRwteBZbLXomESa5TOJPqp10y5Jq6W1ZYNlo2WfFsAqzKrJqtXo52XBy0uR1k89P/mrtYJ1lvcv6no2KTYhNkU27zWtbc1u2bbXtdTuaXYDdYrs2u1f2FvZc+xr72w50h6kOyx06HL44OjkKHJscB5wMnZKdtjjdclZ1jnRe5XzBheDi47LY5ajLR1dH13zXA65/uVm6ZbrtcXs+xWQKd8quKY/d9d1Z7jvcez2YHske2z16PfU8WZ61no+8DLw4Xru9nnmbeWd47/V+6WPtI/A57PPe19V3oe9JP8wv0K/Ur8tfxT/Wv8r/YYB+QFpAY8BQoEPg/MCTQYSg0KB1QbeCtYPZwQ3BQyFOIQtDzoRSQ6NDq0IfhZmHCcLap6JTQ6aun3o/3CicH94aASKCI9ZHPIg0icyL/G0acVrktOppT6NsohZEnY+mR8+O3hP9LsYnZk3MvVjTWFFsR5xi3Iy4hrj38X7x5fG9CZMTFiZcTtRM5CW2JZGS4pJ2Jw1P95++cXr/DIcZJTNuzjSZOXfmxVmas7JmHZutOJs1+2AyITk+eU/yZ1YEq5Y1nBKcsiVliO3L3sR+wfHibOAMcN255dxnqe6p5anP09zT1qcNpHumV6QP8nx5VbxXGUEZ2zLeZ0Zk1mWOZsVnNWeTs5Ozj/BV+Jn8Mzk6OXNzenItcktye/Nc8zbmDQlCBbuFiHCmsC1fFV5zOkWmop9EfQUeBdUFH+bEzTk4V3kuf27nPPN5K+c9Kwwo/GU+Pp89v2OB3oKlC/oWei/csQhZlLKoY7HB4uLF/UsCl9QvpSzNXPp7kXVRedHbZfHL2ou1i5cUP/4p8KfGEoUSQcmt5W7Lt63AV/BWdK20W7l55ddSTumlMuuyirLPq9irLv1s83Plz6OrU1d3rXFcU7OWuJa/9uY6z3X15crlheWP109d37KBuaF0w9uNszderLCv2LaJskm0qbcyrLJts+HmtZs/V6VX3aj2qW7eorVl5Zb3Wzlbr9Z41TRt095Wtu3Tdt722zsCd7TUGtdW7CTuLNj5dFfcrvO/OP/SsFtzd9nuL3X8ut76qPozDU4NDXu09qxpRBtFjQN7Z+zt3ue3r63JsmlHM6O5bD/YL9r/x6/Jv948EHqg46DzwaZDRoe2HKYfLm1BWua1DLWmt/a2Jbb1HAk50tHu1n74N6vf6o7qHa0+pnZszXHK8eLjoycKTwyfzD05eCrt1OOO2R33Tiecvn5m2pmus6FnL5wLOHf6vPf5ExfcLxy96HrxyCXnS62XHS+3dDp0Hv7d4ffDXY5dLVecrrR1u3S390zpOX7V8+qpa37Xzl0Pvn75RviNnpuxN2/fmnGr9zbn9vM7WXde3S24O3JvyX3C/dIHSg8qHmo9rP2H2T+aex17j/X59XU+in507zH78Ysnwief+4uf0p5WPNN91vDc9vnRgYCB7j+m/9H/IvfFyGDJn8p/bnlp+vLQX15/dQ4lDPW/Erwafb3qjcaburf2bzuGI4cfvst+N/K+9IPGh/qPzh/Pf4r/9GxkzmfS58ovZl/av4Z+vT+aPTqayxKwJFcBDDY0NRWA13UA0BLh3aEbAIqC9O0lEUT6XpQg8J+w9H0mEUcA6rwAiF0CQBi8o9TAZgQxFfbiq3eMF0Dt7MabTISpdrbSWFT4giF8GB19ow0AqR2AL4LR0ZGto6NfdkGydwA4mSd984mFCO/3283EqKtTcS74Qf4JrF5srPmkm7gAAAAJcEhZcwAALiMAAC4jAXilP3YAAAIEaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA1LjQuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj4yNjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MjY0PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CpnH5CIAAAPJSURBVDgRVVRRTFtlFP56e4tSwFI62yXLQrWbEqtspECR6UIgkRgm8YmHPfDAg+FBjZEXMPiwiBoeJBqMJiQmsOAixpgsIYKwEmtIlulkIytOMLAxGSFdGy4rbW97b/t7zj9awrm59/7/Pef/zne+8//XksvlLgkhziuKkgBgtVgs9Dq0u7H7uLq5iPXUI7zuqsGb3mY8a3cgJwQH5yjSQRjfWQgkTJPzh0sPR3f2NvDZ3Z/wot2DgPM0rjxchM/uRt/LXXAq9mKgaZpfKNvb249jsRg2Nzf1RCJhklfea/EHZu21j8wf1r4260uqzbdONpu2/Yz56e1PzA8WvjTTRobj9AO0lNLT02OtqamB1+tVp6amVHLIe+HedfUUytS+6j7VWepQ8wLqOddL6ocn31Uvx66rq482CrEgWRTE4/FfqDwxOztrtLW18VDae3ND4mrkWmEqzBypcmDvzFwSs2u/88w4+DSkVlVVSXaBQAA7OzsIhUI488oZCC2Ln1MhZLI6/MdfQI3Hh9DqIqLJOMZ2buBCVRD/3XuATD4LbVeDQopLoMrKStTV1WHhtwVkM1kEHX5M3P8cXdMX8Hd0g+njq9s/4uLC20AyhRNPu6E91tDb24uGhgYoVqtVAqmqisbGRtz88yaMnIHj6jF8e3YSKPfhr4cRhP/9A3eIzaueHnzvfx8KSZ3S01j9ZxWjo6NQJMrBw+/3Y+7XOQjaSsecVXij+hy+Of0xrtwKoeXyRQTTLgw814XXvAHYniqBYRhwOp1ob2+XHSpi+Xw+Od7TNAi6Ent7aH0+iOYTZ6GoClRFBe0ZaAkNVquKra0ttLa2gtcdYeR2u9HS0oJkMgnqBkEB+3oSOgnOltJT0A0dgvZCnrTVKGF9fb3U7whQaWkpgsEgIpGIpFxRXg5npfPJuKICDocDjmcc4E6z+Nzh2tpamYQ3lTRmwOesqakJg4ODYFC73U7MgGw2I+esCZfGHV5eXsbMzAzGx8fl+iLQEziABV9ZWcHw8DCi0ShsNhvKysqQyWRQUlIiy2Fm6+vr6O7ulj5eWwQqnHo6Ktjd3SUWWUmfmebzecmWx7xNeM7GCdjydB3RiGkzAxZxbGwM4XAYLpcLHo8H3Ah+s01OTmJ6elqCyw+MS1nkWSMQg3a5SKfToqOjgxsm7/n5eQoRgvyC/QMDA0XfxMSEPGuk3VCREcUWS9nf35eJ+MElshVKp0Ryzg9dL/xFaEKZJCMCMqh2Ti6WlpZEZ2enGBkZEQQqvzEbNhJZ0K9H9Pf3C/qPSUbkG/ofgQYPGkB9aTMAAAAASUVORK5CYII=) no-repeat scroll center;\
        }\
        div#iGraphCartIcon.removeFromCartIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAAMFGlDQ1BJQ0MgUHJvZmlsZQAASImVVwdUk8kWnr+kEBJaIAJSQm+C9Cq9FwHpYCMkAUIJkBBU7MiigmtBRQRFRVdAFFwLIGvFriyCvT9QUVlZFws2VN6kgK6vnXfPmX++3Ln3zncnd+bMAKBozcrNzUKVAMjm5wuiAn2YCYlJTFIfIANdQAVE4MxiC3O9IyPDAJSx/u/y7iZAxP01S3Gsfx3/r6LM4QrZACCREKdwhOxsiA8BgKuzcwX5ABA6od5gTn6uGA9BrCqABAEg4mKcJsXqYpwixZMkNjFRvhB7AUCmsliCNAAUxLyZBew0GEdBzNGaz+HxId4CsQc7ncWB+D7Ek7KzcyBWJENsmvJdnLS/xUwZj8lipY1jaS4SIfvxhLlZrHn/53L8b8nOEo3NoQ8bNV0QFCXOGa5bfWZOqBhTIT7KTwmPgFgF4gs8jsRejO+mi4JiZfaDbKEvXDPAAAAFHJZfKMRaEDNEmbHeMmzLEkh8oT0azssPjpHhFEFOlCw+WsDPCg+TxVmRzg0ewzVcoX/0mE0qLyAYYlhp6KHC9Jh4KU/0TAEvLhxiBYi7hZnRoTLfh4XpvuFjNgJRlJizIcRvUwUBUVIbTD1bOJYXZsVmSeaCtYB55afHBEl9sQSuMCFsjAOH6+cv5YBxuPxYGTcMVpdPlMy3JDcrUmaP1XCzAqOk64ztFxZEj/lezYcFJl0H7FEGKyRSNte73PzIGCk3HAVhwBf4ASYQwZYCckAG4HUNtg7CX9KRAMACApAGuMBSphnziJeM8OE3GhSCPyHiAuG4n49klAsKoP7LuFb6tQSpktECiUcmeApxNq6Je+BueBj8esFmizvjLmN+TMWxWYn+RD9iEDGAaDbOgw1ZZ8EmALx/owuFPRdmJ+bCH8vhWzzCU0IP4RHhBqGXcAfEgSeSKDKr2bwiwQ/MmWAq6IXRAmTZpXyfHW4MWTvgPrg75A+54wxcE1ji9jATb9wT5uYAtd8zFI1z+7aWP84nZv19PjK9grmCg4xFyvg/4ztu9WMU3+/WiAP70B8tsRXYQew8dgq7iB3FWgETO4G1YZ3YMTEer4QnkkoYmy1Kwi0TxuGN2Vg3Wg9Yf/5hbpZsfvF6CfO5c/PFm8E3J3eegJeWns/0hqcxlxnMZ1tNYtpa2zgBID7bpUfHG4bkzEYYl77p8k4C4FIKlWnfdCwDAI48BYD+7pvO4DUs97UAHOtmiwQFUp34OAYEQAGKcFdoAB1gAExhPrbAEbgBL+APQkAEiAGJYBZc8XSQDTnPAQvAUlACysBasBFUgW1gJ6gH+8AB0AqOglPgHLgMusENcA/WRT94AYbAOzCCIAgJoSF0RAPRRYwQC8QWcUY8EH8kDIlCEpFkJA3hIyJkAbIMKUPKkSpkB9KA/IocQU4hF5Ee5A7Shwwgr5FPKIZSUVVUGzVGJ6POqDcaisagM9E0NA8tRIvR1WglWovuRVvQU+hl9Abai75AhzGAyWMMTA+zxJwxXywCS8JSMQG2CCvFKrBarAlrh//zNawXG8Q+4kScjjNxS1ibQXgszsbz8EX4KrwKr8db8DP4NbwPH8K/EmgELYIFwZUQTEggpBHmEEoIFYTdhMOEs3Df9BPeEYlEBtGE6AT3ZSIxgzifuIq4ldhMPEnsIT4mDpNIJA2SBcmdFEFikfJJJaTNpL2kE6SrpH7SB7I8WZdsSw4gJ5H55CJyBXkP+Tj5KvkZeUROSc5IzlUuQo4jN09ujdwuuXa5K3L9ciMUZYoJxZ0SQ8mgLKVUUpooZyn3KW/k5eX15V3kp8nz5JfIV8rvl78g3yf/kapCNaf6UmdQRdTV1DrqSeod6hsajWZM86Il0fJpq2kNtNO0h7QPCnQFK4VgBY7CYoVqhRaFqwovFeUUjRS9FWcpFipWKB5UvKI4qCSnZKzkq8RSWqRUrXRE6ZbSsDJd2UY5QjlbeZXyHuWLys9VSCrGKv4qHJVilZ0qp1Ue0zG6Ad2XzqYvo++in6X3qxJVTVSDVTNUy1T3qXapDqmpqNmrxanNVatWO6bWy8AYxoxgRhZjDeMA4ybj0wTtCd4TuBNWTmiacHXCe/WJ6l7qXPVS9Wb1G+qfNJga/hqZGus0WjUeaOKa5prTNOdo1mie1RycqDrRbSJ7YunEAxPvaqFa5lpRWvO1dmp1ag1r62gHaudqb9Y+rT2ow9Dx0snQ2aBzXGdAl67rocvT3aB7QvcPphrTm5nFrGSeYQ7paekF6Yn0duh16Y3om+jH6hfpN+s/MKAYOBukGmww6DAYMtQ1nGq4wLDR8K6RnJGzUbrRJqPzRu+NTYzjjZcbtxo/N1E3CTYpNGk0uW9KM/U0zTOtNb1uRjRzNss022rWbY6aO5inm1ebX7FALRwteBZbLXomESa5TOJPqp10y5Jq6W1ZYNlo2WfFsAqzKrJqtXo52XBy0uR1k89P/mrtYJ1lvcv6no2KTYhNkU27zWtbc1u2bbXtdTuaXYDdYrs2u1f2FvZc+xr72w50h6kOyx06HL44OjkKHJscB5wMnZKdtjjdclZ1jnRe5XzBheDi47LY5ajLR1dH13zXA65/uVm6ZbrtcXs+xWQKd8quKY/d9d1Z7jvcez2YHske2z16PfU8WZ61no+8DLw4Xru9nnmbeWd47/V+6WPtI/A57PPe19V3oe9JP8wv0K/Ur8tfxT/Wv8r/YYB+QFpAY8BQoEPg/MCTQYSg0KB1QbeCtYPZwQ3BQyFOIQtDzoRSQ6NDq0IfhZmHCcLap6JTQ6aun3o/3CicH94aASKCI9ZHPIg0icyL/G0acVrktOppT6NsohZEnY+mR8+O3hP9LsYnZk3MvVjTWFFsR5xi3Iy4hrj38X7x5fG9CZMTFiZcTtRM5CW2JZGS4pJ2Jw1P95++cXr/DIcZJTNuzjSZOXfmxVmas7JmHZutOJs1+2AyITk+eU/yZ1YEq5Y1nBKcsiVliO3L3sR+wfHibOAMcN255dxnqe6p5anP09zT1qcNpHumV6QP8nx5VbxXGUEZ2zLeZ0Zk1mWOZsVnNWeTs5Ozj/BV+Jn8Mzk6OXNzenItcktye/Nc8zbmDQlCBbuFiHCmsC1fFV5zOkWmop9EfQUeBdUFH+bEzTk4V3kuf27nPPN5K+c9Kwwo/GU+Pp89v2OB3oKlC/oWei/csQhZlLKoY7HB4uLF/UsCl9QvpSzNXPp7kXVRedHbZfHL2ou1i5cUP/4p8KfGEoUSQcmt5W7Lt63AV/BWdK20W7l55ddSTumlMuuyirLPq9irLv1s83Plz6OrU1d3rXFcU7OWuJa/9uY6z3X15crlheWP109d37KBuaF0w9uNszderLCv2LaJskm0qbcyrLJts+HmtZs/V6VX3aj2qW7eorVl5Zb3Wzlbr9Z41TRt095Wtu3Tdt722zsCd7TUGtdW7CTuLNj5dFfcrvO/OP/SsFtzd9nuL3X8ut76qPozDU4NDXu09qxpRBtFjQN7Z+zt3ue3r63JsmlHM6O5bD/YL9r/x6/Jv948EHqg46DzwaZDRoe2HKYfLm1BWua1DLWmt/a2Jbb1HAk50tHu1n74N6vf6o7qHa0+pnZszXHK8eLjoycKTwyfzD05eCrt1OOO2R33Tiecvn5m2pmus6FnL5wLOHf6vPf5ExfcLxy96HrxyCXnS62XHS+3dDp0Hv7d4ffDXY5dLVecrrR1u3S390zpOX7V8+qpa37Xzl0Pvn75RviNnpuxN2/fmnGr9zbn9vM7WXde3S24O3JvyX3C/dIHSg8qHmo9rP2H2T+aex17j/X59XU+in507zH78Ysnwief+4uf0p5WPNN91vDc9vnRgYCB7j+m/9H/IvfFyGDJn8p/bnlp+vLQX15/dQ4lDPW/Erwafb3qjcaburf2bzuGI4cfvst+N/K+9IPGh/qPzh/Pf4r/9GxkzmfS58ovZl/av4Z+vT+aPTqayxKwJFcBDDY0NRWA13UA0BLh3aEbAIqC9O0lEUT6XpQg8J+w9H0mEUcA6rwAiF0CQBi8o9TAZgQxFfbiq3eMF0Dt7MabTISpdrbSWFT4giF8GB19ow0AqR2AL4LR0ZGto6NfdkGydwA4mSd984mFCO/3283EqKtTcS74Qf4JrF5srPmkm7gAAAAJcEhZcwAALiMAAC4jAXilP3YAAAIEaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA1LjQuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj4yODA8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MjY0PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cj1tM28AAANXSURBVDgRZVNLT1NREP7u7S19y0MIGF4SFkYWbuThg24IkeiKDVEhQYLoQhP1H2g0YcHCyBYXLjTSQHCpUQMLIgZcovERqUSsBNBgbaGWtvdevznYq42TTM65M3O+mW9mrmbbdr9lWYcApHQKT0dyvOWi72A9nYSV3oa+txL6qbPwVuxzYvIXjSCzmqaF84aCc+UT8HAM+PFt16xpQHUDMHAZCJUUhBoE+fnHkuZp2KYJzeVCKvYZO+FGYIXWUuo2tZgqmC9fIXj3AdzBEGDbABMYkUjEtbW1hWQyaYTDYaP58GFYjDVnX8De3w73zfPkR5LqgQ7LtmBeuIjclTcwjh79C+Ri9mAwiPn5eczNzWFiYgI6M5gfPkK/dBmh02cI+1ekb4mVGHJfYtCIgz9tNXp6elRUR0cHmpqa8DUWQ3VdHVLV1TBv3EJ2bQNazmTMLgWpKH3rJgIzM0izSi2dhquoCIbJnkhVxcXFONHVhbtjY+gdGMDqnhDq37+Fee0qpAq2WaDgoSbgwxeegdevcf/ePRw5dgy6gIh4PB5If6LLy/C73QgeOIBUJII1+rIIQSaRocao5pNH8FdUwGMYuH3njnqrcY8e03eSmpuenjY6OzuxtLSEn/E4/KWl2FldRXB9Hb82NhCorUO8fC+85eXIpVLYyWTQ0tKCaDQKgwCONDY2qrtMUUaaSSaBkhJ8DwTgazqIH+wVF0+BCM04k5WVlaGykovqoPBSVVWFtrY2bG9zizkNTSbC0btNCzpB9GxWAYld/Jubm+g/148AExUAeb1edLHhi4uL8Pv9irvX54PH54WcXtqK2EuJE6CFhQW0H29XtTjU2Cuy0dDa2oqRkRFVnUwyx4qyrESAM+yJTDkUCmGZQ3n2/BmGhoZ2SUmzqTb/uaycbJzQL1AurE0gm8DKzp6os7m52U4kEvLMdiqSakTq6+uxzimluWhSPhOoKsTPeLi5GiJy95Gu9EfEAZIPccpeSflTU1OoqalBd3e381hiZKLj4+MqTv4KSSDx8lhR46mosR92b2+vQ21ycpIuOmkXGR4ednyjo6PKJr6CqUlGEdnyvOQ3X2iK5L/l/q/tP2oG1/76jeuora1Fw/4GtQ7yKC+Dg4MKTOL6+vryZvwGSWqFaQfeFMUAAAAASUVORK5CYII=) no-repeat scroll center;\
        }\
        div#iGraphColorBlindFriendlyIcon{\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAAEbSURBVDhPrVQxDsIwDHS6dEMVLEiwVDDxBt7CQ3hO39C3MCF1YWAgbcWOSs5xQhJRQMBJp9jx+eQ0bRURDYY/g42Gq02+hZoQZRJTu1lL9DnSHkzE1Mu1j0HUUj7TSu1RdALXNEZouq57beSEXKzOEZVSvlaWJethiNw/IwAPDZidjmQabBLgslhxDWiahvpbR0VRcA5414hmgvCYHJu9PM8jnTuFvf5hIDO2CQNUZ170fssrTyJ7tJvb1QB96Oej9X1PdV1zYRRPTIC2bSWS8UCtdTS2Ow7o46Dubk7yhxGYZRkX0MixGHmzxGTUCAwbHHH1WFFL9aKJN1OhiJhvNOOCVwy18Ig+2unBvmyfANrwo/3bb+RPPzaiO3OWgslMWGyFAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div#iGraphSnapshotIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsEAAA7BAbiRa+0AAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAAEVSURBVDhPpZOxDcIwEEUviBIqOliBJRALMAKhYwaHikSICegII7AAYgkKMkDomAH8D184B6cIeZJ1Z/v738lOIiJ62dEZNrJ8Zn8SRRH1XN6Zxo42SeIyn22auuwLOgIw8kiMcdkvoT14eB1JF6GqmrrO60hXQh6qXF/f73Yc4eFdNpwTW204GHC1VRx7QzpAR9Dei4LnoO9iRZZlaJEPjicTOj/ndDvMuAAOYw/RGEOPsnSn6Pf5IRBgAqbrK6Xq3qBBQU1lVFr3kECAmQCNLgi8jrQgP51oMbpwDnTeVJBvPl4uX1bALyBrkofWoMUZtfY1EoHEOnoPsdGoLdrI+7Lx5G045jlHfA6NP20bKqPPtAtEbw8iYxB46Q0cAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div#iGraphCloudWatchServiceLogsIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAAEMUlEQVRIDbVVXWgcVRQ+d+bub3bT3W6TbGL+1zTZDaS0EUp8aDYP+iBUUNkFlYrQ0ELF0kXwBx8yDypEoS/SBxUpiCI0UMQHQRS61BDUtj4l/hRXacMmMTU/y+7M7mR+rufOZpKd7aYB0cOcufece+Y7555z7lyA/5nIfvipFIgAKevhtjPpGRMHtt93/3pdkiRBupakjMG+wXEnextxAALsxOODfT2jgefbY02LxHB/MX3224IdnSQlqSRldVtuNDZ0kEwmaTab1Z++MNpeWq3Mtsf8/Q8dDoBWMf5EkKuEsCvvTn73YyPAel1DB2jE9ezkqZE+zTQWwh0e2hUPmtQleESRQEXWdUJgDvnS9OnrV+pBa2WhVsC55fD48YeDT06OTEXjvg+ohzDMN7ejmmroHBytaCDsOWEyeNP+XpIsG1vcGR0OMDXYMQCBTrEXQSS3T3xMoMQPjHE7vkY5OI5bZVnDAYrIe2WBrzf2KpqCiWGva6pZYSa2JC+3kwRBwA6o6h/Yso4dODHAhbAuzPOeXU+qrVrv3AHzIAeAANXobCcNYsUzYaV1aqrx4WvoYMsRQ1XA1kQEHQxTA9PUwWQGlsbQpYnqOUjPpBpi8YLtUEtL1orR7/cTQrCI25vnbcTr7HMdAhd1A6aNiFQAXTBa3v78uRdluXDznfTMPNrhdxhJDTm83htOWpBffXZL03UNUQkIAgVKKazlVVi+rWL0gLvQxbJaZhVNHgDvxmXFWHmKYyK4A4/rHIqsVN3B9MevBtxuL61o60KhuASaUWFbFQ3y+UUoyEtQUu9BsbxMikqeyUoBopHBZg6GZFSH3bdVIBTtTmCnX3/ijbbWlvcSQ8OeruigWzQPCExQiYyg62vLrLWnCZiwRbw0DO2RONGLTWTlNz0xPjF2LjHWGvxpNnd9G97CrK0BV7D8Uq5nU853Hwx0Qm93TEkMxZk/eNSlKIor15ojkYNeOBSKMr8noCmyqv8wN0vdnXdCEAmG7txa7+fg/E9rtTfO7ci53nKQyoz5ShuFZ0vK6isGrCXCgSHoaj+sxvpiWrSjjbq8BDZLa/qmuuj6PfeLZ/7GzzBx8tFfO/rCr708fvVLDoRkYdkTS7P92lm4eDHjm7v9/Qul8sZ5zSwkyuW/oSUSV2NHD4DgLXqo6AFVFm9+88kfq/NzKyH8/mvkj5CXkXlt+cXk2AGXgf+0stkkcrW/M5mU727l7im1XDnvDprDA8dCeADpvGmI76cn+y8/Qj7kP6Ujza3iWaVodutl9gzKKvKOE5zfT9zRmTOjrt2VXm/6wrGXMpfGz+Hp9W7rxZGRtqZdG5jDed+2XFvfGpO6KXfEL6A6tSV2xpsHcPIp8lvIM8jTyDbxdN+fInu1fuSOFhZShN//nPDyt3v+CIpx5L+QryFz2qllVfxv31bkNuQ/6QmDzBSaM80AAAAASUVORK5CYII=) no-repeat scroll center;\
        }\
        div#iGraphCloudWatchApplicationLogsIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAAEP0lEQVRIDbVVXWhcRRQ+M3f27k/uJtmmm2Zr/re2+cFKm4faB8u2oA9CCxZ2IYoitDaIoi2CtPiQ+1CFqFQQigSVPoVKYsUi9UnsYkoppRVLawqFEEmyCeZ/u393c3/GM3f3prtxk6DgsLNnzpkz33dmzpk7AP9zI1vhR6MgAUTtn/AdiY1YKPhW6/7zvKqqVL0eYZzDlsEJko2dBAABfujFPW0tPcqroXDVFDHlHwb6fk460alqhKlq3HD0SrIiQSQSYfF43Dh+uieUntNuhMK+9qd2K6Br5gSCfE8IH/7k5OjtSoDrbRUJ0EnY+dHX9rbplvlHYKebNXX6LeaibkkioGUMgxC4if3iwIlfh9eDluq0VMGxTXjgwC7/sZN7+xs6vYPMTTiet/Bjet40BDh6MSXgPmRx+NBZr6q2j6OuyTICPBqsGAClUWpFEFX2Si9QRnzAufATc0yAo1zNZXQUkMK+0SmI+cqskkUtDHtJz1sat7AkRbrLG6UUK6Bg37Rky3ZQjgEuhHXhOW9Y9aRQquvJy2A2IwAEKETnkFSIFe+Efaz9/ZUvX0WC1bIYCgqWJiIYYFo6WJYBFjcxNaahHi7cg9hItCKWSNhaCwbjdow+n48Qgkksbl6Ukciz17UdXEwGPDYiMQoGNYMfXX7ljUwmeefj2MgD9MN1GElJK2Od747YkD8N3dUNQ0dUApQyYIzBYiIPs4/yGD3gLgwpl89xTc8+Dd6VS1lz7mWBSWKkDE/YygxxtbCDgW8+UGTZwzR9iSZTM6CbGl/VdEgkpiCZmYF0fh5SuVmSyk7zx6kFCNXt8gswGAHTliV/doJQdyqBnzj70rkd9cFPuzq63U0Ne2TJqqGc5kkGQZcWZ3l9SxWGpRNZqoXG7d1EW/KRqftad9/Z4289d6zB98uVsdEino1ZmgNh4ImZ8ZaVTKJ5m9IIrc3hbFdHJ/f597my2axrvH6c1G1zQzAQ4m5WpQPlxsS93+WvP7taq7T/Vev1e5pF8JiyQsSI6EQu7DZB9MxBb3o52ZvOzr1vwmJXQOmAptDufLgtrDfs3MFcHgIr6UVjMTspzy9PyL/deGAFapq1mT+Xrt2+9kUvITEsL8TCe+iACuk0m0QoFy6c8d58dOv1dG75Xd1KduVyCxCs68yH99UA9abcFGSYn9RXR7+bHnr2SMP5K5/f78dlb2IXVS5yKx4m+/si5ForfLQi0uDgt6tjd6bvHj1y+FKewqRMA+0uHw8FmzyMWsrD6uravqtfjk2P31vY//DWHHcrtLe2no3mHlsJBBNHbxOsAa8fCKJTp3pcT+ytntjp/W+/d/H5d65z1cndj1V19Jy/nh1Ev8vYzxf9neJ5snyjkSASD9D6+faewDOeajpUYhckX5XoZVegxF55KIii0agUHY5KxffYjZ7eoreIWORPwf7vgIsAm4nSSvyH399InITuoxR4MwAAAABJRU5ErkJggg==) no-repeat scroll center;\
        }\
        div#iGraphCartIcon.iGraphHelperTopIcons {\
            float: left;\
            position: absolute;\
            left: 4px;\
        }\
        \
        .imgareaselect-border1, .imgareaselect-border2,\
        .imgareaselect-border3, .imgareaselect-border4 {\
            opacity: 0.5;\
            filter: alpha(opacity=50);\
        }\
        \
        .imgareaselect-handle {\
            background-color: #fff;\
            border: solid 1px #000;\
            opacity: 0.5;\
            filter: alpha(opacity=50);\
        }\
        \
        .imgareaselect-outer {\
            background-color: #000;\
            opacity: 0.5;\
            filter: alpha(opacity=50);\
        }\
        \
        .imgareaselect-selection {  \
            opacity: 0.5;\
            color: red;\
        }\
        #iGHmodalClose {\
            cursor: pointer;\
        }\
        #iGHmodalPage {\
            display: none;\
            position: fixed;\
            width: 100%;\
            height: 100%;\
            top: 0px; left: 0px;\
            font-family: Verdana, Arial, Helvetica, sans-serif;\
            color: #000000;\
            text-align: left;\
            z-index: 10; \
        }\
        .iGHmodalHeader a, .iGHmodalHeader a:visited, .iGHmodalHeader a:hover  {\
            color: #32719D;\
            background-color: transparent;\
            font-family: arial;\
            font-weight: normal;\
        }\
        #iGHmodalPage select {\
            vertical-align: top;\
            border-color: none;\
        }\
        .iGHmodalBackground {\
            filter: Alpha(Opacity=60); -moz-opacity:0.6; opacity: 0.6;\
            width: 100%; height: 100%; background-color: #999999;\
            position: absolute;\
            z-index: 500;\
            top: 0px; left: 0px;\
        }\
        .iGHmodalContainer {\
            position: absolute;\
            width: 760px;\
            left: 50%;\
            top: 50%;\
            z-index: 750;\
            font-size: 10px;\
        }\
        .iGHmodalHeader {\
            background-color: #EEE;\
        }\
        .iGHmodal {\
            background-color: white;\
            border: solid 1px black; position: relative;\
            top: -230px;\
            left: -380px;\
            width: 760px;\
            height: 460px;\
            z-index: 10000;\
            padding: 0px;\
        }\
        .iGHzooms {\
            float: right;\
        }\
        .iGHmodalTop {\
            width: 752px;\
            background:#5A7EAA url(https://monitorportal.amazon.com/images/header_background.png) repeat-x scroll 0 0;\
            padding: 4px;\
            color: #ffffff;\
            text-align: right;\
        }\
        .iGHperiod {\
            font-size: 9px;\
            margin-top: 4px;\
        }\
        .iGHmodalLeft {\
            float: left; \
        } \
        .iGHinstructions {\
            position:absolute;\
        }\
        .iGHmodalRight {\
            float: right; \
        } \
        .iGHmodalTop a, .iGHmodalTop a:visited, .iGHmodalTop a:hover  {\
            font-size: 10px;\
            color: #ffffff;\
            background-color: transparent;\
        }\
        .iGHmodalBody {\
            width: 760px;\
            height: 426px;\
        }\
        #iGHaddToMyGraphs {\
            display: inline; \
            margin: 8px 5px 0px 10px;\
        }\
        #iGHaddToMyGraphs span {\
            width: 100px;\
        }\
        .iGHwikiView {\
            cursor: pointer;\
        }\
        #iGHsnapshotWiki {\
            margin-left: 63px;\
        }\
        #iGHsnapshotS3-button, #iGHsnapshotWiki-button, #iGHsnapshotNewWiki-button, #iGHsnapshotTT-button, #iGHsnapshotSIM-button, #iGHsnapshotJIRA-button, #iGHsnapshotMCM-button {\
            margin-left: auto;\
            margin-right: auto;\
            text-align: center;\
        }\
        #iGHsnapshotS3, #iGHsnapshotWiki, #iGHsnapshotNewWiki, #iGHsnapshotTT, #iGHsnapshotSIM, #iGHsnapshotJIRA, #iGHsnapshotMCM,\
        #iGHsnapshotS3 .first-child, #iGHsnapshotWiki .first-child, #iGHsnapshotNewWiki .first-child, #iGHsnapshotTT .first-child, #iGHsnapshotSIM .first-child, #iGHsnapshotJIRA .first-child, iGHsnapshotMCM .first-child {\
            width: 150px;\
        }\
        #iGHsnapshotS3, #iGHsnapshotWiki, #iGHsnapshotNewWiki, #iGHsnapshotTT, #iGHsnapshotSIM, #iGHsnapshotJIRA, #iGHsnapshotMCM {\
            margin-top: 5px;\
        }\
        .iGHlabel {\
            cursor: pointer;\
        }\
        button.iGHbutton:active, a.button.iGHbutton:active, input.iGHbutton[type="submit"]:active, input.iGHbutton[type="reset"]:active {\
            -moz-box-shadow:none;\
            color:black !important;\
            text-decoration:none !important;\
            top:1px;\
        }\
        button.iGHbutton, input.iGHbutton[type="submit"], input.iGHbutton[type="reset"] {\
            height:19px;\
            cursor: pointer;\
        }\
        button.iGHbutton, a.button.iGHbutton, input.iGHbutton[type="submit"], input.iGHbutton[type="reset"] {\
            -moz-background-clip:border;\
            -moz-background-inline-policy:continuous;\
            -moz-background-origin:padding;\
            -moz-border-radius-bottomleft:6px;\
            -moz-border-radius-bottomright:6px;\
            -moz-border-radius-topleft:6px;\
            -moz-border-radius-topright:6px;\
            -moz-box-shadow:1px 1px 2px rgba(0, 0, 0, 0.15);\
            background:#D4D484 url(https://monitorportal.amazon.com/images/lib/dtux.amazon.com/secondary_action_button_bg.png) repeat-x scroll 0 0;\
            border-color:#959567 #898958 #7C7C4D;\
            border-style:solid;\
            border-width:1px;\
            color:black !important;\
            display:inline-block;\
            font-family:Lucida Sans Unicode,Lucida Grande,Verdana,Arial,sans-serif;\
            font-size:11px !important;\
            line-height:15px !important;\
            margin:0;\
            overflow:visible;\
            padding:0 6px;\
            position:relative;\
            text-decoration:none;\
            text-shadow:0 1px 0 rgba(255, 255, 255, 0.5);\
            vertical-align:middle;\
            margin: 3px;\
        }\
        span.iGHrefreshAll {\
            top: -2px;\
            position: relative;\
        }\
         .iGHwidget {\
         }\
        .iGHmenuArea {\
            -moz-background-clip: border;\
            -moz-background-inline-policy: continuous;\
            -moz-background-origin: padding;\
            -moz-border-radius-bottomleft:8px;\
            -moz-border-radius-bottomright:8px;\
            -moz-border-radius-topleft:8px;\
            -moz-border-radius-topright:8px;\
            background-color: #EAF3FE;\
            border: 1px solid #CCCCCC;\
            padding: 5px 0px;\
            margin-top: 5px;\
         }\
        .iGHmenuArea select {\
            vertical-align: inherit;\
         }\
         .iGHmenuTitle {\
            padding-left: 10px;\
         }\
         .iGHmenuLink {\
            font-size: 9px;\
            padding-left: 10px;\
         }\
         .iGHradio {\
            -moz-background-clip: border;\
            -moz-background-inline-policy: continuous;\
            -moz-background-origin: padding;\
            -moz-border-radius-bottomleft:4px;\
            -moz-border-radius-bottomright:4px;\
            -moz-border-radius-topleft:4px;\
            -moz-border-radius-topright:4px;\
            background-color: white;\
            font-size: 10px;\
            border: 1px solid #CCCCCC;\
            display: inline-block;\
            padding: 4px 6px 0px 2px;\
            height: 18px;\
         }\
         .iGHradio input {\
            margin-top: 0px;\
         }\
         .iGHradio label {\
            top: -3px;\
            position: relative;\
            cursor: pointer;\
         }\
         .iGHcopyPasteTimeRanges {\
             text-align: right;\
             position: absolute;\
             right: 20px;\
         }\
         .iGHextraOptionsWide {\
            position: relative;\
            left: -500px;\
            width: 850px;\
            max-width: 850px;\
        }\
        .iGHicon {\
             cursor: pointer;\
             margin: 1px 3px 0 3px;\
             font-size: 1.2em;\
         }\
         .timeRangesResetIcon.iGHicon {\
             margin: 1px 1px 0 1px;\
         }\
         .metricMathEnlargeIcon, .metricMathReduceIcon {\
            font-size: 1.5em;\
         }\
        ';

    var isIgraph = false;
    var ICON_WIDTH = 18;
    var LOADER_IMAGE = "data:image/gif;base64,R0lGODlhyAA8APMAAAAAAH9/fzMzM7+/v4+Pj09PTw8PD8zMzK+vrz8/P9/f329vbx8fH5+fn19fX////yH5BAEHAA8ALAAAAADIADwAAAT+8MlJq7046827/2AojmRpnmiqrmzrvnAsz3Rt33iu73zv/8CgcEgsGo/IpHLJbDqf0Kh0Sq1ar9isdsvter/gsPimGAwUyYOZoh6MfQEAIJBMyCl2wLsXn9fvE3l7PH10SIITDQGGgzmFf3qNQI+HgJJwcoweBwSLCGgZZYsBBG6higEHEogSbWxrDwqophiyi6oPrpcVlB0IDHLBBpoTCg7ByAYEFsbIAAkKrA/Sgn3BDLgUzcgCB9K7D70bx87B0GwG5cjLxQLqAu6Rq5bTcuTOBqASCvH4wPLgwmXyFSwAGlnpACzAI6eAKQUI4hmgUECOAAQSGvyjRy3YRQn+CBI6oLBADgOMD34hCzhBXIaEDSocSAjqgJwEzILhsglAgL5YCQF27PmTJ4NiJn8q2MhSgssLCOxdaCBn4YMBCxLQYgjAVEkAKClQ5UgWQMwK/yYQkHOWQlR64J5a6BNWm0UO/OSY+rYvGFeuP+fJ4yshYVOBfjbkCTwh3gUzARzk0SvhJgbHgcpeYAVMAAbCkuRWAF0P4ICK6ig/sLxZc2aAryewtkB6kOi/ny2NTZaAQDxTs0e7FtxaXnDcLG9PQM1YArCJV4M5aLA1j6l0Ry9gJh6btiV30C1sD6jcKdsLCliTqzvhnynmOYeXLj6BHOP0cHeVz3XcPAB2hA3+EIwpayUmll/dcSecPG+NxAuCyQ3EQTwOJhIMKKhtdVVQDyW01UwQzpcgcg/8w05GKzXVRwKjtDhKTeZQh8A9jIxlwAJmNHDPeSjaY8YC6Rg2ImHSCGjRIv3Q400CbbWSAJMyPdlkFNakptoDDQTljFWNpdabhBJ85Yxk8hEJ127IJDCekcSwWYGbVFRp5VbbBOMQM0ByE5MC6XhGwQD9DCOigoOSuI8D/wgQU5FgSgDnBI9KYoaGF7TRHHqw6GBHeIdJskABxEyQDk6dXkLOlIidWOogNhJQEzn5rGqqlWDJqp+WN2Vj6yUDjNLApbsGK+ywxBZr7LHIJqvssswQNuvss9BGK+201FZrbRYRAAA7";
    var graphsFound = false;
    var stylesInitialized = false;
    var modalCreated = false;
    var iconsCreated = false;
    var ticketGraphCache = {
        currentGraph: null,
        graphParams: {}
    };

    function initialize() {
        IGH.WikiHtml.initialize();
        IGH.WikiEditor.initialize();
        IGH.MetricSchemas.initialize();
        IGH.PortalGraphZoomer.initialize();
        IGH.PortalGraphSelector.initialize();
        IGH.loadingImage = new Image();
        IGH.loadingImage.src = LOADER_IMAGE;
        decorateGraphs();
        createIGraphLinks();
        IGH.IGraphUpdates.initialize();
        IGH.WikiCart.initialize();
        IGH.TT.initialize();
        OCLSettingsManager.setOCLConfigInitialValue();
        document.addEventListener("keydown", checkKeyPress, false);
        iGraphHelper = { initialize, decorateGraphs, IGH };
    }

    function setStyles() {
        if (!stylesInitialized) {
            // Setup styles for the links
            stylesInitialized = true;
            IGH.WikiWidgets.initialize();
            addStyle(STYLES);
        }
    }

    function checkKeyPress(e) {
        // Check for Ctrl-Alt-G
        if (e.ctrlKey && e.altKey && ((e.which == 103) || (e.which == 71))) {
            decorateGraphs();
        }
    }

    function goToCloudWatchConsole(logType) {
        if (IGH.hoveredImage) {
            return OCLLinksManager.goToCloudWatchConsole(logType, getFullGraphUrl());
        }
        return false;
    }

    function iconClicked(baseUrl) {
        if (IGH.hoveredImage) {
            window.open(getFullGraphUrl(baseUrl));
        }
        return false;
    }

    function getFullGraphUrl(baseUrl) {
        var graphArgs = getGraphArgs(IGH.hoveredImage, false);
        return baseUrl + graphArgs;
    }

    function maximizeClicked(graphParams) {
        var img = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&";
        img += removeQueryParams(graphParams, ["WidthInPixels", "HeightInPixels", "Action", "Version", "ShowLegend", "ShowXAxisLabel"]);
        revealModal(img);
    }
    function removeQueryParams(url, paramList) {
        var newUrl = url;
        for (var i = 0; i < paramList.length; i++) {
            var re = new RegExp(paramList[i] + "(=|%3D)[^&]*", "gi");
            newUrl = newUrl.replace(re, "");
        }
        return newUrl;
    }
    function extractQueryValue(url, param) {
        var re = new RegExp(param + "=([^&]*)");
        if (null !== url.match(re)) {
            return RegExp.$1;
        }
        return null;
    }

    function createModal() {
        if (modalCreated) {
            return;
        }
        var modalContainer = document.createElement("div");
        modalContainer.innerHTML = '\
                <div id="iGHmodalPage" style="display: none;">\
                    <div class="iGHmodalBackground">\
                    </div>\
                    <div class="iGHmodalContainer">\
                        <div class="iGHmodal">\
                            <div class="iGHmodalTop">\
                                <div class="iGHmodalLeft"><a href="https://w.amazon.com/?IGraphHelper" target="_blank">iGraph Helper</a> - Magnifier (click and drag to zoom in)</div>\
                                <div class="iGHmodalRight"><a id="iGHmodalClose" href="">Esc or [X]</a></div>\
                                <div style="clear: both;"></div>\
                            </div>\
                            <div class="iGHmodalHeader">\
                                <input type="submit" value="View in iGraph" class="iGHbutton" id="iGHviewInIGraph">\
                                <input type="submit" value="View in Zoomer" class="iGHbutton" id="iGHviewInZoomer">\
                                <input type="submit" value="Snapshot" class="iGHbutton" id="iGHSnapshot">\
                                <span class="iGHzooms">\
                                    <input type="submit" value="Apply Selection to All Graphs" class="iGHbutton" id="iGHapplyToAll">\
                                    &nbsp;&nbsp;Period: \
                                        <select class="iGHperiod" name="iGHperiod">\
                                            <option value="">Select...</option>\
                                            <option value="OneMinute">1 Minute</option>\
                                            <option value="FiveMinute">5 Minutes</option>\
                                            <option value="OneHour">1 Hour</option>\
                                            <option value="OneDay">1 Day</option>\
                                            <option value="OneWeek">1 Week</option>\
                                        </select>\
                                    &nbsp;Zoom: <a>1h</a> | <a>3h</a> | <a>8h</a> | <a>1d</a> | <a>1w</a> | <a>2w</a> | <a>30d</a> | <a>3m</a> | <a>1y</a>&nbsp;\
                                    <input type="submit" value="Refresh" class="iGHbutton" id="iGHrefresh">\
                                </span>\
                            </div>\
                            <div class="iGHmodalBody">\
                                <img id="iGHimage" title="When the graph loads, select and drag to zoom in to a time range. Use the _Apply Selection to All Graphs_ button to apply your time range and period selection to all graphs on the underlying page">\
                            </div>\
                        </div>\
                    </div>\
                </div>';
        document.body.insertBefore(modalContainer, document.body.firstChild);
        jQuery('#iGHmodalPage').on('click', hideModal);
        jQuery(document).on('keydown', function(e) {
            if (e.keyCode == 27) {
                hideModal();
            }});
        jQuery('.iGHmodalContainer').on('click', function() {return false;});
        jQuery('#iGHmodalClose').on('click', hideModal);
        jQuery('#iGHapplyToAll').on('click', applyToAll);
        jQuery('#iGHrefresh').on('click', refresh);
        jQuery('#iGHviewInIGraph').on('click', function() {viewGraphInOtherPage(IGRAPH_LINK.url);});
        jQuery('#iGHviewInZoomer').on('click', function() {viewGraphInOtherPage(IGRAPH_ZOOMER_LINK.url);});
        jQuery('#iGHSnapshot').on('click', function() {
            var graphArgs = window.MPW.getGraphArgs(window.MPW.getImageUrlWithSelectedPeriod(jQuery('#iGHimage')[0]));
            WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, graphArgs);
        });
        jQuery('#iGHmodalPage select[name="iGHperiod"]').on('change', setPeriodAcrossImage);
        jQuery('a', '.iGHzooms').attr('href', '#').on('click', function() {setTime.call(this, jQuery("#iGHimage")[0]); return false;});
        modalCreated = true;
    }

    function getModalImage() {
        var modalImage =  jQuery("#iGHimage");
        if (modalImage.length === 1) {
            return modalImage[0];
        }
        return undefined;
    }

    function loadingImg(img) {
        const width = extractQueryValue(img.src, 'WidthInPixels') || img.clientWidth;
        const height = extractQueryValue(img.src, 'HeightInPixels') || img.clientHeight;
        img.src = LOADER_IMAGE;
        if (width && height) {
            img.width = width;
            img.height = height;
            img.style.width  = `${width}px`;
            img.style.height = `${height}px`;
        }
    }

    function setTimeRangeForGraph(url, start, end) {
        let newImgUrl;

        if (IGH.util.isCloudWatchGraph(url)) {
            const metricWidget = IGH.util.getMetricWidgetFromUrl(url);
            metricWidget.start = start;
            metricWidget.end = end;
            const metricWidgetStr = IGH.util.metricWidgetToJsonUrlParam(metricWidget);
            newImgUrl = removeQueryParams(url, ['metricWidget', 'start', 'end']);
            newImgUrl += `&metricWidget=${metricWidgetStr}`;
        } else {
            newImgUrl = removeQueryParams(url, ["StartTime1", "EndTime1"]);
            newImgUrl += `&StartTime1=${start}&EndTime1=${end}`;
        }

        return newImgUrl;
    }

    function setTime(img) {
        const TIMES = { '1h': '-PT1H', '3h': '-PT3H', '8h': '-PT8H', '1d': '-P1D', '1w': '-P7D', '2w': '-P14D', '30d': '-P30D', '3M': '-P90D', '1y': '-P365D' };
        const newStart = TIMES[jQuery(this).text()];
        const newImgUrl = setTimeRangeForGraph(img.src, newStart, 'P0D');
        loadingImg(img);
        img.src = cleanImgUrl(newImgUrl);
    }

    function viewGraphInOtherPage(baseUrl) {
        var imgUrl = getModalImage().src;
        window.open(baseUrl + imgUrl.replace(/.*[?]/, ""), "_blank");
    }

    function setPeriodAcrossImage() {
        var img = getModalImage();
        var newImg = getImageUrlWithSelectedPeriod(img.src);
        loadingImg(img);
        img.src = cleanImgUrl(newImg);
    }

    function getImageUrlWithSelectedPeriod(imgUrl) {
        var period = getSelectedPeriod();
        if (period !== null && period.length > 0) {
            return imgUrl.replace(/(\bPeriod\d*=)[^&]*/g, "$1" + period);
        }
        return imgUrl;
    }

    function getSelectedPeriod() {
        return jQuery('select[name="iGHperiod"] option:selected', '#iGHmodalPage').val();
    }
    function setSelectedPeriod(period) {
        jQuery('select[name="iGHperiod"] option[value="' + period + '"]', '#iGHmodalPage').prop("selected", "selected");
    }

    function refresh() {
        _refreshImg(getModalImage());
    }

    function _refreshImg(img) {
        var newImgUrl = removeQueryParams(img.src, ['iGHrefresh']);
        newImgUrl += /[?]/.test(newImgUrl) ? '' : '?';
        newImgUrl += '&iGHrefresh=' + new Date().valueOf();
        loadingImg(img);
        img.src = cleanImgUrl(newImgUrl);
    }

    function refreshAll() {
        if (isIgraph) {
            MP.GraphSection.displayGraph();
        }
        else {
            for (i = 0; i < document.images.length; i++) {
                var image = document.images[i];
                var searchString = getGraphArgs(image, true);
                if (searchString != null) {
                    loadingImg(image);
                    var newUrl = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&";
                    newUrl += removeQueryParams(searchString, ["Action", "Version", "iGHrefresh"]);
                    newUrl += "&iGHrefresh=" + new Date().valueOf();
                    image.src = cleanImgUrl(newUrl);
                }
            }
        }
    }

    function applyToAll() {
        hideModal();
        var timeRange = getImageTimeRange();
        if (isIgraph) {
            var model = MP.graph.model();
            model.timeRanges().clear();
            var rangeType = IGH.TimeRangeUtils.isDuration(timeRange.startTime) ? MP.MWS.TimeRangeType.RELATIVE : MP.MWS.TimeRangeType.FIXED;
            model.timeRanges().add(model.createTimeRange(rangeType, timeRange.startTime, timeRange.endTime));
            MP.GraphSection.displayGraph();
        }
        else {
            for (i = 0; i < document.images.length; i++) {
                var image = document.images[i];
                var searchString = getGraphArgs(image, true);
                if (searchString != null) {
                    loadingImg(image);
                    var newUrl = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&";
                    newUrl += removeQueryParams(searchString, ["Action", "Version", "StartTime1", "EndTime1"]);
                    newUrl += "&StartTime1=" + timeRange.startTime + "&EndTime1=" + timeRange.endTime;
                    newUrl = getImageUrlWithSelectedPeriod(newUrl);
                    image.src = cleanImgUrl(newUrl);
                }
            }
            decorateGraphs(true);
        }
    }

    function getImageTimeRange() {
        var imgUrl = getModalImage().src;
        return {startTime: extractQueryValue(imgUrl, "StartTime1"),
            endTime: extractQueryValue(imgUrl, "EndTime1")};
    }

    function revealModal(img) {
        createModal();
        var modalSize = sizeModal();
        var imgWidth  = modalSize.width - 2;
        var imgHeight = modalSize.height - 46;
        img += "&WidthInPixels=" + imgWidth + "&HeightInPixels=" + imgHeight;
        var period = extractQueryValue(img, "Period1");
        if (period) {
            setSelectedPeriod(period);
        }
        jQuery('#iGHmodalPage').show();
        getModalImage().width = imgWidth;
        getModalImage().height = imgHeight;
        loadingImg(getModalImage());
        jQuery('#iGHimage').attr("src", cleanImgUrl(img));
        iGraphResizer(getModalImage(), zoomGraph, imgHeight);
    }

    function zoomGraph(x, width, zoomLevel) {
        var imageTimeRange = getImageTimeRange();
        var now = new Date();
        var minutesRange = IGH.TimeRangeUtils.getTimeRangeInMinutes(now, imageTimeRange);

        var startDuration, endDuration;

        var centerSpot = minutesRange.startTime - Math.floor((minutesRange.startTime - minutesRange.endTime) * x / width);
        var halfDuration = Math.floor((minutesRange.startTime - minutesRange.endTime) * zoomLevel / 2);
        var newStartMinutes = centerSpot + halfDuration;
        var newEndMinutes = centerSpot - halfDuration;

        if (newEndMinutes >= newStartMinutes) {
            newEndMinutes = newStartMinutes - 1;
        }

        var newStartDuration = IGH.TimeRangeUtils.getDurationFromControl(
          IGH.TimeRangeUtils.UNITS.MINUTE, newStartMinutes);
        var newEndDuration   = IGH.TimeRangeUtils.getDurationFromControl(
          IGH.TimeRangeUtils.UNITS.MINUTE, newEndMinutes);
        var newStart = IGH.TimeRangeUtils.getXMLCalendarFromDuration(new Date(), newStartDuration);
        var newEnd   = IGH.TimeRangeUtils.getXMLCalendarFromDuration(new Date(), newEndDuration);

        var img = getModalImage();
        var imgUrl = img.src;
        var newImg = removeQueryParams(imgUrl, ["StartTime1", "EndTime1"]);
        newImg += "&StartTime1=" + newStart + "&EndTime1=" + newEnd;
        loadingImg(img);
        img.src = cleanImgUrl(newImg);
    }

    function cleanImgUrl(imgUrl) {
        var newImg = removeQueryParams(imgUrl, ["actionSource", "actionSource1", "NoRedirect"]);
        newImg += "&actionSource=iGraphHelper&NoRedirect=1";
        return newImg.replace(/[&]+/g, "&");     // Replace contiguous &'s with single &
    }

    function hideModal() {
        jQuery('#iGHmodalPage').hide();
    }

    function sizeModal() {
        var TOP_BOTTOM_MARGIN = 50;
        var SIDE_MARGIN = 100;
        var MODAL_TOP_MARGIN = 8;
        var MODAL_BODY_MARGIN = 46;

        var windowSize  = IGH.getWindowSize();
        var modalWidth  = windowSize.width - (2 * SIDE_MARGIN);
        var modalHeight = windowSize.height - (2 * TOP_BOTTOM_MARGIN);
        jQuery(".iGHmodalContainer").width(modalWidth);
        jQuery(".iGHmodal").css("top", -(modalHeight/2)).css("left", -(modalWidth/2)).width(modalWidth).height(modalHeight);
        jQuery(".iGHmodalTop").width(modalWidth - MODAL_TOP_MARGIN);
        jQuery(".iGHmodalBody").width(modalWidth).height(modalHeight - MODAL_BODY_MARGIN);

        return {width: modalWidth, height: modalHeight};
    }

    function createIcons() {
        if (iconsCreated) {
            return;
        }
        var iconContainer = document.createElement("div");
        iconContainer.innerHTML = '\
          <div id="iGraphBackgroundTop" class="iGraphBackground">\
            <div id="iGraphMaximizeIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="Maximize - Display this graph maximized (iGraphHelper)"></div> \
            <div id="iGraphIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraph - Display this graph in iGraph (iGraphHelper)"></div> \
            <div id="iGraphZoomerIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraph Zoomer - Display this graph in iGraph Zoomer tool (iGraphHelper)"></div> \
            <div id="iGraphDataTableIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraph Data Table - See the data for this graph (iGraphHelper)"></div> \
            <div id="iGraphCSVIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="CSV - Download the CSV data for the graph (iGraphHelper)"></div> \
            <div id="iGraphColorBlindFriendlyIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="Color Blind Friendly - Convert graph to color blind friendly colors (iGraphHelper)"></div> \
            <div id="iGraphSnapshotIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="Snapshot - Take a snapshot of graph image (iGraphHelper)"></div> \
            <div id="iGraphCloudWatchApplicationLogsIcon" class="iGraphHelperIcons iGraphHelperTopIcons OCLIcons" title="CloudWatch - Go to Cloudwatch application logs for this graph"></div> \
            <div id="iGraphCloudWatchServiceLogsIcon" class="iGraphHelperIcons iGraphHelperTopIcons OCLIcons" title="CloudWatch - Go to Cloudwatch service logs for this graph"></div> \
            <div id="iGraphCartIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="Buy Now - Add to iGraph Shopping Cart, for merging with other graphs in cart (iGraphHelper)"></div> \
          </div>\
          <div id="iGraphBackgroundLeft" class="iGraphBackground"></div>\
          <div id="iGraphBackgroundRight" class="iGraphBackground"></div>\
          <div id="iGraphBackgroundBottom" class="iGraphBackground">\
            <div id="iGraphRefreshIcon" class="iGraphHelperIcons iGraphHelperBottomIcons" title="Refresh - Refresh this graph (iGraphHelper)"></div> \
            <div class="iGraphHelperZoom"><a>1h</a>|<a>3h</a>|<a>8h</a>|<a>1d</a>|<a>1w</a>|<a>2w</a>|<a>30d</a>|<a>3m</a>|<a>1y</a></div>\
          </div>\
        ';
        document.body.insertBefore(iconContainer, document.body.firstChild);

        jQuery('#iGraphIcon')[0].addEventListener('click', () =>
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false,(imgUrl) => {
                if (IGH.util.isCloudWatchGraph(imgUrl)) {
                    window.open(IGH.util.getConsoleUrl(imgUrl));
                } else {
                    return iconClicked(IGRAPH_LINK.url);
                }
            }),
          false);

        jQuery('#iGraphZoomerIcon')[0].addEventListener('click', () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false,(imgUrl) => {
              if (IGH.util.isCloudWatchGraph(imgUrl)) {
                  window.open(IGH.util.getConsoleUrl(imgUrl));
              } else {
                  return iconClicked(IGRAPH_ZOOMER_LINK.url);
              }
          }), false);

        jQuery('#iGraphDataTableIcon')[0].addEventListener('click', () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false, (imgUrl) => {
              if (IGH.util.isCloudWatchGraph(imgUrl)) {
                  alert('Display as Data Table is not supported for CloudWatch graphs')
              } else {
                  return iconClicked(IGRAPH_DATA_TABLE_LINK.url);
              }
          }), false);

        jQuery('#iGraphCSVIcon')[0].addEventListener('click', () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false,(imgUrl) => {
              if (IGH.util.isCloudWatchGraph(imgUrl)) {
                  alert('Export as CSV data is not supported for CloudWatch graphs')
              } else {
                  return iconClicked(IGRAPH_CSV_LINK.url);
              }
          }), false);

        jQuery('#iGraphColorBlindFriendlyIcon')[0].addEventListener('click',  () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false, () => {
              if (IGH.hoveredImage) {
                  var graphUrl = isIgraph ? getGraphUrl() : getGraphArgs(IGH.hoveredImage, false);
                  WikiSnapshot.displayColorBlindFriendly(IGH.hoveredImage, graphUrl);
              }
              return false;
          }),
        false);

        jQuery('#iGraphSnapshotIcon')[0].addEventListener('click',  () =>
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false, () => {
                if (IGH.hoveredImage) {
                    var graphUrl = isIgraph ? getGraphUrl() : getGraphArgs(IGH.hoveredImage, false);
                    WikiSnapshot.snapshotDisplayInPopup(IGH.util.lightbox, graphUrl, getSnapshotSizeMessage());
                }
                return false;
            }),
          false);

        jQuery('#iGraphCloudWatchApplicationLogsIcon')[0].addEventListener('click', function() { return goToCloudWatchConsole(OCLLinksManager.APPLICATION_LOG_KEY); }, false);
        jQuery('#iGraphCloudWatchServiceLogsIcon')[0].addEventListener('click', function() { return goToCloudWatchConsole(OCLLinksManager.SERVICE_LOG_KEY); }, false);

        jQuery('#iGraphMaximizeIcon')[0].addEventListener('click', () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false,(imgUrl) => {
              if (IGH.util.isCloudWatchGraph(imgUrl)) {
                  alert('Maximize is not supported for CloudWatch graphs')
              } else {
                  maximizeClicked(getGraphArgs(IGH.hoveredImage, false));
              }
          }), false);

        jQuery('#iGraphCartIcon')[0].addEventListener('click', function() {
            const self = this;
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false,() => {
                var graphUrl = isIgraph ? getGraphUrl() : getGraphArgs(IGH.hoveredImage, false);
                return jQuery(self).hasClass('addToCartIcon') ? IGH.WikiCart.addGraphToCart(graphUrl) : IGH.WikiCart.removeGraphFromCart(graphUrl);
            });
        });

        jQuery('#iGraphBackgroundTop')[0].addEventListener('mouseout', mouseOutTop, false);
        jQuery('#iGraphBackgroundBottom')[0].addEventListener('mouseout', mouseOutBottom, false);

        jQuery('a', '#iGraphBackgroundBottom').attr('href', '#').on('click', function() {
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false, () => {
                setTime.call(this, IGH.hoveredImage);
            });
            return false;
        });

        jQuery('#iGraphRefreshIcon')[0].addEventListener('click', () => {
            return expandUrlForSnapshotGraphs(IGH.hoveredImage, true, () => _refreshImg(IGH.hoveredImage));
        }, false);

        iconsCreated = true;
    }

    function decorateGraphs(noEvents){
        var iGHimage = getModalImage();
        // Go through all images in doc and look for GetGraph or chart.cgi images
        for (let i = 0; i < document.images.length; i++) {
            var image = document.images[i];
            var searchString = getGraphArgs(image, true);
            if (searchString != null && image != iGHimage) {
                if (IGH.WikiEditor.onWiki()) {
                    jQuery(image).parent().attr("title", "");
                }
                jQuery(image).attr("origimgurl", searchString);
                if (!noEvents) {
                    image.addEventListener("mouseover", function(e){ mouseOverGraph(e, searchString);}, false);
                    image.addEventListener("mouseout",  function(e){ mouseOutGraph(e, searchString);}, false);
                    jQuery(image).iGHSingleDoubleClick(
                      function() { maximizeClicked(jQuery(this).attr("origimgurl"));},
                      function() { IGH.WikiCart.graphDoubleClicked(jQuery(this));});
                }
                var period = extractQueryValue(searchString, 'Period1');
                var startTime = extractQueryValue(searchString, 'StartTime1');
                IGH.WikiWidgets.setDefaultPeriod(period);
                IGH.WikiWidgets.setDefaultStartTime(startTime);

                graphsFound = true;
            }
        }

        doDecorateIGraph(noEvents);
        graphsFound = graphsFound || doDecorateTicketing();
        setStyles();
        if (graphsFound) {
            createIcons();
        }
    }

    function doDecorateIGraph(noEvents) {
        // Check for iGraph page
        if (noEvents) {
            return;
        }
        jQuery('.iGraphHelperContainer').hide();
        var igraphImg = document.getElementById("graphImg");
        if (/igraph/.test(window.location.href) && igraphImg) {
            igraphImg.addEventListener("mouseover", function(e){ mouseOverGraph(e, igraphImg);}, false);
            igraphImg.addEventListener("mouseout",  function(e){ mouseOutGraph(e, igraphImg);}, false);
            iGraphResizer(igraphImg, function(x, width, zoomLevel) {
                MP.GraphSection._zoom(x, width, zoomLevel);
                MP.GraphSection.displayGraph();
            });
            addIGraphZoom();
            addIGraphReset();
            addSnapshotButton();
            addTTSearch();
            isIgraph = true;
            graphsFound = true;
        }
    }

    function getDurationBetweenStartEnd(start, end) {
        const now = new Date();
        const startInMin = IGH.TimeRangeUtils._getTimeInMinutes(now, start);
        const endInMin = IGH.TimeRangeUtils._getTimeInMinutes(now, end);
        const duration = Math.round(startInMin - endInMin);
        const minDuration = Math.max(duration, 30);     // Don't go below 30 minutes
        return `-PT${minDuration}M`;
    }

    function graphDeepLinkToImageUrl(deepLink, convertTimeRangeToNow) {
        let graphUrl = null;

        // Check for CloudWatch Console deep link
        if (/metricsV2:graph=/.test(deepLink)) {
            const metricWidgetUrlBit = deepLink.replace(/.*metricsV2:graph=/, '');
            let metricWidgetStr = decodeURIComponent(metricWidgetUrlBit.replace(/\+/g, '%20'));

            if (convertTimeRangeToNow) {
                try {
                    const metricWidget = JSON.parse(metricWidgetStr);
                    const newStart = getDurationBetweenStartEnd(metricWidget.start, metricWidget.end);
                    metricWidget.start = newStart;
                    metricWidget.end = 'P0D';
                    metricWidgetStr = IGH.util.metricWidgetToJsonUrlParam(metricWidget);
                } catch (e) {
                    // Ignore and carry on
                }
            }

            graphUrl = IGH.util.graphArgsToCloudWatchGraphUrl(`metricWidget=${metricWidgetStr}`);
        }
        // Check for iGraph deep link
        else  if (/.amazon.com\/igraph[?]/.test(deepLink)) {
            graphUrl = deepLink.replace(/igraph[?]/, 'mws?Action=GetGraph&Version=2007-07-07&');

            if (convertTimeRangeToNow) {
                const startTime = extractQueryValue(deepLink, 'StartTime1');
                const endTime = extractQueryValue(deepLink, 'EndTime1');
                try {
                    const newStart = getDurationBetweenStartEnd(startTime, endTime);
                    graphUrl = IGH.util.replaceQueryParam(graphUrl, 'StartTime1', newStart);
                    graphUrl = IGH.util.replaceQueryParam(graphUrl, 'EndTime1', 'P0D');
                } catch (e) {
                    // Ignore and carry on
                }
            }
        }

        return graphUrl;
    }

    async function expandUrlForSnapshotGraphs(img, convertTimeRangeToNow, then) {
        if (!img) {
            return false;
        }
        const origSrc = img.src;
        const sourceUrl = jQuery(img).data('sourceUrl');
        if (sourceUrl) {
            loadingImg(img);
            const expandedUrl = await expandTinyUrl(sourceUrl);
            let graphUrl = graphDeepLinkToImageUrl(expandedUrl, convertTimeRangeToNow);

            jQuery(img).data('sourceUrl', null);

            if (graphUrl) {
                graphUrl = graphUrl.replace(/#TT-EMBED/, '');
                img.src = graphUrl;
            } else {
                img.src = origSrc;
            }
        }

        then(img.src);
        return false;
    }

    function expandTinyUrl(sourceUrl) {
        const MATCH_TINY_SITE = /^https:..tiny.amazon.com/;
        if (MATCH_TINY_SITE.test(sourceUrl)) {
            return new Promise(resolve => GMUtils.gmXmlHttpRequest({
                method: 'GET',
                url: sourceUrl,
                dataType: 'json',
                onload: function(response) {
                    if (response && response.finalUrl) {
                        if (MATCH_TINY_SITE.test(response.finalUrl)) {
                            const expandedLink = response.response.split('\n').join('')
                              .replace(/.*; URL=/m, '')
                              .replace(/" \/\>\<\/head\>$/m, '');
                            resolve(expandedLink);
                        } else {
                            resolve(response.finalUrl);
                        }
                    }
                }
            }));
        }

        return sourceUrl;
    }

    function grabTicketingMouseOvers(event) {
        const target = event.target;
        if (target.tagName === 'IMG') {
            // Check for rolling over a graph we've already expanded
            if (jQuery(target).data('sourceUrl')) {
                return mouseOverGraph(event);
            }
            // Check for rolling over a snapshot graph
            else if (/.amazon.com\/snap\/load/.test(target.src)) {
                ticketGraphCache.currentGraph = target;

                // Try to find source URL for graph (usually tiny link) in link closeby image
                const sourceUrl = jQuery(target).parent().siblings('a').attr('href') ||
                  jQuery(target).parent().parent().nextAll('a:first').attr('href');

                if (sourceUrl) {
                    // Tag image with sourceUrl, for handy access if someone clicks controls on hover border
                    jQuery(target).data('sourceUrl', sourceUrl);
                    return mouseOverGraph(event);
                }
            }
            // Check for rolling over live portal graph (probably converted from a snapshot)
            else if (/https:..monitorportal.amazon.com/.test(target.src)) {
                return mouseOverGraph(event);
            }
        }

        mouseOutGraph(event);
        ticketGraphCache.currentGraph = null;
    }

    // Do special snapshot expansion only for ticketing sites, for the moment
    function isOnTicketingSite() {
        const ALL_TICKETING_SITES = {
            'issues.amazon.com': 1, 'i.amazon.com': 1, 'issues-pdx.amazon.com': 1,
            'issues-dub.amazon.com': 1, 'issues-iad.amazon.com': 1, 'sim.amazon.com': 1,
            'issues-integ.amazon.com': 1, 't.corp.amazon.com': 1, 't-integ.amazon.com': 1,
            'tt.amazon.com': 1, 'halp-beta.amazon.com': 1, 'halp.amazon.com': 1
        };
        const domain = window.location.hostname;
        return !!ALL_TICKETING_SITES[domain];
    }

    function doDecorateTicketing() {
        if (isOnTicketingSite()) {
            // Grab all mouse over events in page on ticketing sites, to help discover hovering over snapshot images
            document.addEventListener('mouseover', grabTicketingMouseOvers);
            return true;
        }
        return false;
    }

    function iGraphResizer(igraphImg, zoomFn, height) {
        var MIN_ZOOM = 5;
        var minHeight = height || jQuery(igraphImg).height();
        var imgAreaSelect = jQuery(igraphImg).imgAreaSelect({
            onSelectEnd: function(img, select) {
                if (zoomFn && (select.x2 - select.x1 >= MIN_ZOOM)) {
                    zoomFn((select.x1 + select.x2) / 2,
                      jQuery(igraphImg).width(), (select.width * 1.0 / jQuery(igraphImg).width()));
                }
            },
            onSelectStart: function() {imgAreaSelect.setOptions({
                minHeight: jQuery(igraphImg).height(),
                maxHeight: jQuery(igraphImg).height()
            });
                imgAreaSelect.doResize();},
            instance: true,
            autoHide: true,
            minHeight: minHeight,
            maxHeight: minHeight,
            selectionColor: "#CFFCFF"
        });
    }

    function addSnapshotButton() {
        var id = "iGHsnapshotS3";
        var button = jQuery('<input type="button" id="' + id + '" name="iGHsnapshotButton" class="wikiButtonClass" value="Snapshot..." title="Snapshot graph as fixed bitmap and get code for pasting it elsewhere (added by iGraph Helper)"/>');
        jQuery(button).insertAfter(jQuery('#wikiButton'));
        button.on('click', function() {
            snapshotTo(getSnapshotSizeMessage());
        });
    }

    function getGraphUrl() {
        const obeyFit = GMUtils.getValue('iGraphHelper.snapshotObeyFit') != "false";

       if (obeyFit && ($('#graphImg').attr('src'))) {
            // Return the parameters from the currently plotted iGraph, size of which obeys the 'Fit' flag
            return $('#graphImg').attr('src').replace(/.*[?]/, '');
        }

        if (typeof MP.GraphSection.getGraphUrlWithoutInvisibleMetrics === 'function') {
            return MP.GraphSection.getGraphUrlWithoutInvisibleMetrics(MP.graph.model());
        }
        return MP.GraphSection.getDataModelQueryString();
    }

    function addTTSearch() {
        var search = jQuery(
          '<iframe name="emptyFrame" src="/images/state_ok.png" style="display: none;"></iframe>' +
          '<form id="ttForm" target="emptyFrame" action="/images/state_ok.png">' +
          '<input type="text" name="ttSearch" placeholder="Search TT (embedding current graph)" id="ttSearch" style="width: 235px; margin: 5px 0 0 10px;">' +
          '</form>');
        jQuery(search).appendTo(jQuery('#wikiButton').parent());
        jQuery('#ttSearch').on('keyup', function(e) {
            if (e.which == 13) {
                var search = jQuery('#ttSearch').val();
                var graphArgs = getGraphUrl();
                graphArgs = IGH.util.removeQueryParams(graphArgs, ["WidthInPixels", "HeightInPixels"]) + "&WidthInPixels=1024&HeightInPixels=300";
                window.open('https://tt.amazon.com/search?phrase_search_text=' + search + '&search=Search!&' + graphArgs, "_blank");
            }
        });
    }

    function getSnapshotSizeMessage() {
        let width;
        let height;
        if (isIgraph) {
            const iGraphUrl = getGraphUrl();
            width = extractQueryValue(iGraphUrl, 'WidthInPixels');
            height = extractQueryValue(iGraphUrl, 'HeightInPixels');
        } else {
            width = IGH.hoveredImage.width;
            height = IGH.hoveredImage.height;
        }
        return `The snapshot image size will be ${width} x ${height} pixels`;
    }

    function snapshotTo(message) {
        var queryString = getGraphUrl();
        WikiSnapshot.snapshotDisplayInPopup(IGH.util.lightbox, queryString, message);
    }

    // Includes a Javascript a file, given by 'url', in the current document
    function includeScript(url) {
        if (document.body || document.head) {
            var script = document.createElement('script');
            script.setAttribute('language', 'javascript');
            script.setAttribute('type', 'text/javascript');
            script.setAttribute('src', url);
            (document.body || document.head).appendChild(script);
        }
    }

    function getWikiPage() {
        return "https://w.amazon.com/index.php/" + jQuery('input[name="iGraphHelper.wikiGraphPage"]').val();
    }

    function saveGraph(user) {
        var queryString = getGraphUrl();
        if (queryString && queryString.length) {
            var model = MP.graph.model();
            var wikiText = "{{IGraph/graph|graph=" + queryString.replace(/=/g, "%3D").replace(/:/g, "%3A").replace(/[&]/g, "%26") +
              "|width=" + model.options().widthInPixels() + "|height=" + model.options().heightInPixels()  + "}}";
            saveTextToWiki(user, wikiText);
        }
        else {
            alert("Please display a graph first.\n\nYou can then save it to Wiki (" + getWikiPage() + ")");
        }
    }

    function saveTextToWiki(user, text) {
        var wikiEdit = getWikiPage() + "?action=edit&autoadd=" + encodeURI(text);
        window.open(wikiEdit, "_blank");
    }

    function getIgraphUser() {
        return jQuery('.hidden.username').text();
    }

    function addIGraphZoom() {
        var zoomRow = '<tr><td>Zoom:</td><td><a>1h</a> | <a>3h</a> | <a>8h</a> | <a>1d</a> | <a>1w</a> | <a>2w</a> | <a>30d</a></td></tr>';
        var fixedZoom = jQuery(zoomRow);
        var relZoom   = jQuery(zoomRow);
        var naturalZoom   = jQuery(zoomRow);
        var TIMES = { "1h": "-PT1H", "3h": "-PT3H", "8h": "-PT8H", "1d": "-P1D", "1w": "-P7D", "2w": "-P14D", "30d": "-P30D" };
        function setTime() {
            var model = MP.graph.model();
            model.timeRanges().clear();
            model.timeRanges().add(model.createTimeRange(MP.MWS.TimeRangeType.RELATIVE, TIMES[jQuery(this).text()], "-PT0M"));
            MP.GraphSection.displayGraph();
            return false;
        }

        jQuery('a', fixedZoom).attr('href', '#').on('click', setTime);
        jQuery('a', relZoom).attr('href', '#').on('click', setTime);
        jQuery('a', naturalZoom).attr('href', '#').on('click', setTime);
        jQuery('#relative-time tbody').prepend(relZoom);
        jQuery('#fixed-time tbody').prepend(fixedZoom);
        jQuery('#natural-time tbody').prepend(naturalZoom);
    }

    function addIGraphReset() {
        var reset = jQuery('<li><a href="#" title="Reset visibility of controls and height of graph (iGraphHelper)">Factory Settings</a></li>');
        reset.on('click', function() {
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'timeRanges', true);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'generalOptions', false);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'yAxisOptions', false);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'extraOptions', false);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'dashboarding', false);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'searchControls', false);
            jQuery(".graphImgResize").height(200);
            MP.GraphSection.resizeAll();
            MP.GraphSection._refreshGraph();
            MP.IgraphConfig.setAndStore("graphHeight", jQuery("#graphImgContainer").height());
        });

        jQuery('.globalFeatures').prepend(reset);
    }

    function createIGraphLinks(){
        if (document.getElementById('metrics') && document.getElementById('monitor-amazon-com')) {
            addStyle("\
                div#graph-control div.control-container { \
                    overflow: visible; \
                }\n \
                div#main div.detailpanel {\
                    overflow: visible;\
                }\
                ");
        }
    }

    function mouseOverGraph(event, data) {
        // Get position of graph
        IGH.hoveredImage = event.target;
        if (! document.getElementById("iGraphBackgroundTop")) {
            decorateGraphs();
            return;
        }
        var MARGIN = 5;
        var TOP_HEIGHT = 24;
        var imgWidth = event.target.width;
        var imgHeight = event.target.height;
        var offset = $(event.target).offset();
        var pos = { x: Math.floor(offset.left),
            y: Math.floor(offset.top) + 1};
        var args = jQuery(event.target).attr("origimgurl");
        var widthOffset = ICON_WIDTH + 5;
        var nextIcon = 3;
        var width = 96;
        if (isIgraph && data) {
            args = data.src.replace(/.*[?]/, "");
            jQuery('#iGraphIcon').hide();
            width = 72;
        }
        else {
            jQuery('#iGraphIcon').show();
        }
        IGH.WikiCart.updateCartIcon();
        jQuery("#iGraphBackgroundTop").
        width(imgWidth + 2 * MARGIN - 1).
        css("left", pos.x - MARGIN).
        css("top", pos.y - TOP_HEIGHT - 1).
        fadeIn();
        jQuery("#iGraphBackgroundLeft").
        height(imgHeight).
        css("left", pos.x - MARGIN).
        css("top", pos.y).
        fadeIn();
        jQuery("#iGraphBackgroundRight").
        height(imgHeight).
        css("left", pos.x + imgWidth).
        css("top", pos.y).
        fadeIn();
        jQuery("#iGraphBackgroundBottom").
        width(imgWidth + 2 * MARGIN - 1).
        css("left", pos.x - MARGIN).
        css("top", pos.y + imgHeight - 1).
        fadeIn();

        if (IGH.hoveredImage) {
            OCLLinksManager.setOCLIconsVisibility(getFullGraphUrl());
        }
    }

    function mouseOutGraph(event) {
        // Ignore if hover border is invisible
        if (jQuery('#iGraphBackgroundTop').length === 0) {
            return;
        }

        // Get mouse and current element positions
        var mousePos = IGH.getMouseCoords(event);
        var posTop = IGH.getElementPosition(jQuery("#iGraphBackgroundTop")[0]);
        var posBottom = IGH.getElementPosition(jQuery("#iGraphBackgroundBottom")[0]);

        // If mouse is outside both elements hide the icons
        if (isMouseOutside(mousePos, posTop, jQuery("#iGraphBackgroundTop").width(), jQuery("#iGraphBackgroundTop").height() + 2)
          && isMouseOutside(mousePos, posBottom, jQuery("#iGraphBackgroundBottom").width(), jQuery("#iGraphBackgroundBottom").height())) {
            hideGraphBorder();
        }
        return false;
    }
    function mouseOutTop(event) {
        var mousePos = IGH.getMouseCoords(event);
        var igraphBackgroundPos = IGH.getElementPosition(jQuery("#iGraphBackgroundTop")[0]);
        if (isMouseNotBelow(mousePos, igraphBackgroundPos, jQuery("#iGraphBackgroundTop").width(), jQuery("#iGraphBackgroundTop").height())) {
            hideGraphBorder();
        }
        return false;
    }
    function mouseOutBottom(event) {
        var mousePos = IGH.getMouseCoords(event);
        var igraphBackgroundPos = IGH.getElementPosition(jQuery("#iGraphBackgroundBottom")[0]);
        if (isMouseNotAbove(mousePos, igraphBackgroundPos, jQuery("#iGraphBackgroundBottom").width(), jQuery("#iGraphBackgroundBottom").height())) {
            hideGraphBorder();
        }
        return false;
    }
    function hideGraphBorder() {
        jQuery("#iGraphBackgroundTop").hide();
        jQuery("#iGraphBackgroundBottom").hide();
        jQuery("#iGraphBackgroundLeft").hide();
        jQuery("#iGraphBackgroundRight").hide();
    }

    function isMouseOutside(mousePos, pos, width, height) {
        if (!mousePos || mousePos.x < pos.x || mousePos.x > pos.x + width ||
          mousePos.y < pos.y || mousePos.y > pos.y + height) {
            return true;
        }
        return false;
    }
    function isMouseNotBelow(mousePos, pos, width, height) {
        if (!mousePos || mousePos.x < pos.x || mousePos.x > pos.x + width ||
          mousePos.y < pos.y) {
            return true;
        }
        return false;
    }
    function isMouseNotAbove(mousePos, pos, width, height) {
        if (!mousePos || mousePos.x < pos.x || mousePos.x > pos.x + width ||
          mousePos.y > pos.y + height) {
            return true;
        }
        return false;
    }

    function getGraphArgs(image, includeQPlot) {
        // Look for graph image in http://performance*.amazon.com/chart.cgi
        if (/var\/performance\/cache\/png/.test(image.src) &&
          /amazon.com\/chart.cgi/.test(window.location.href) && includeQPlot) {
            return getSearchFromChartCgi();
        }
        else if (/Action=GetGraph/.test(image.src)) {
            return convertMWSParamsToIGraph(image.src.replace(/.*[?]/, ""));
        }
        else if (/Action=GetGraph/.test(image.alt)) {
            return convertMWSParamsToIGraph(image.alt.replace(/.*[?]/, ""));
        }
        else if (/SchemaName[0-9]*=/.test(image.title)) {
            return convertMWSParamsToIGraph(image.title.replace(/^MWS:/, ""));
        }
        else if (/amazon.com\/dashboard-PMETGraphs.cgi/.test(image.src) && includeQPlot) {
            return getSearchFromQplotUrl(image.src);
        } else if (/cw\/getMetricWidgetImage/.test(image.src)) {
            // CloudWatch bitmap graph
            return image.src.replace(/.*[?]/, "");
        }
        else if (image.tagName === "DIV") {
            return jQuery(image).parents(".MPWgraphInteractiveContainer").children(".MPWgraphInteractiveParams").text();
        }

        return null;
    }

    // Gets graph args from a deep link to igraph
    // ** Would be good to expand later with deep links from CloudWatch Console, just requires understanding of jsUrl
    function getGraphArgsFromPageDeepLink(url) {
        if (/\bSchemaName/i.test(url)) {
            return convertMWSParamsToIGraph(url.replace(/.*[?]/, ''));
        }
        return null;
    }

    function convertMWSParamsToIGraph(url) {
        var SEARCH_REPLACEMENTS = {
            "StartTime=": "StartTime1=",
            "EndTime=": "EndTime1=",
            "MetricSchema&": "&",
            "Period1=1": "Period1=One",
            "Period1=5": "Period1=Five",
            "StatOptions=": "StatOptions1=",
            "HorizontalLineLeft=": "HorizontalLineLeft1=",
            "HorizontalLineRight=": "HorizontalLineRight1=",
            "ValueUnit=": "ValueUnit1=",
            "SecurityToken": "",
            "X-Amz-Algorithm": "",
            "X-Amz-Credential": "",
            "X-Amz-Date": "",
            "X-Amz-Expires": "",
            "X-Amz-Signature": ""
        };
        var NON_SEARCH_REPLACEMENTS = {
            "SchemaName=": "SchemaName1=",
            "Period=": "Period1=",
            "Stat=": "Stat1=",
            "=Oneminute": "=OneMinute",
            "=Fiveminute": "=FiveMinute",
            "=Onehour": "=OneHour",
            "=Oneday": "=OneDay",
            "=Oneweek": "=OneWeek"
        };

        var graph = url.replace(/%3D/g, "=");

        var replacementList = [ SEARCH_REPLACEMENTS ];
        if (! /SchemaName[0-9]*=Search/.test(graph)) {  // If graph doesn't contain a search string do more conversions
            replacementList.push(NON_SEARCH_REPLACEMENTS);
            var schemaDefs = IGH.MetricSchemas.schemaDefs;
            for (var schemaName in schemaDefs) {
                var dims = schemaDefs[schemaName];
                for (var i = 0; i < dims.length; i++) {
                    graph = graph.replace(new RegExp(dims[i] + "=", "i"), dims[i] + "1=");
                }
            }
        }

        for (var r = 0; r < replacementList.length; r++) {
            var replacements = replacementList[r];
            for (var reStr in replacements) {
                var re = new RegExp(reStr, "g");
                graph = graph.replace(re, replacements[reStr]);
            }
        }
        return graph;
    }

    function getSearchFromMWSGetGraph(getGraphUrl) {
        var regexp = new RegExp("^(.*)[0-9]+$");
        var metricSearch = new IGH.MetricSearch();
        var paramValues = getGraphUrl.split("&");
        for (var i = 0; i < paramValues.length; i++) {
            var paramValue = paramValues[i].split("=");
            if (paramValue.length = 2) {
                var param = paramValue[0];
                var match = regexp.exec(param);
                var field = match ? match[1] : param;
                if (IGH.MetricSchemas.getUniqueDimensions()[field]) {
                    metricSearch.add(field, paramValue[1]);
                }
            }
        }

        return metricSearch.getSearchString();
    }

    function getSearchFromChartCgi() {
        var regexp = new RegExp("^Metric pmet[0-9] (.*): got ");
        var textNode, text = document.evaluate("//span[@id='Output Messages']/font/text()",document,null,6,null);
        var haveMatch = false;

        var metricSearch = new IGH.MetricSearch();
        for (var i = text.snapshotLength - 1; i >= 0; i--) {
            var textContent = text.snapshotItem(i).textContent;
            var match = regexp.exec(textContent);
            if (match) {
                var metricFields = match[1].split(",");
                metricSearch.addMetric(new IGH.Metric(metricFields));
            }
        }
        var searchString = metricSearch.getSearchString();
        if (searchString) {
            var graphTable = document.evaluate("/html/body/table[3]",document,null,6,null).snapshotItem(0);
            var div = document.createElement('div');
            div.className = "igraphMessage";
            div.innerHTML = '<a target="_blank" href="' + IGRAPH_LINK.url + "search=" + searchString + '">Click here to search for the metrics below in iGraph</a>'
            graphTable.parentNode.insertBefore(div, graphTable);
            graphsFound = true;
        }


        return null;
    }

    function getSearchFromQplotUrl(qplot) {
        return null;
    }

    IGH.WikiHtml = {
        initialize: function() {
            // Go check if we're on Wiki. Then
            if (IGH.WikiEditor.onWiki()) {
                var htmlContainer = jQuery('pre.html');
                var html = htmlContainer.text();
                try {
                    htmlContainer.replaceWith(html);
                }
                catch (e) {
                    log(e);
                }
            }
        }

    };

    IGH.WikiWidgets = {
        DEFAULT_WIDGETS: {
            period: "menu|Period|,1 Minute;OneMinute,5 Minute;FiveMinute,1 Hour;OneHour,1 Day;OneDay,1 Week;OneWeek|",
            time: "radio|Zoom;StartTime&EndTime|1h;-PT1H&P0D,3h;-PT3H&P0D,8h;-PT8H&P0D,1d;-P1D&P0D,3d;-P3D&P0D,1w;-P7D&P0D,2w;-P14D&P0D|",
            refresh: "refresh"
        },

        defaultPeriod: '',
        defaultTime: '',

        initialize: function() {
            if (! IGH.WikiEditor.onWiki()) {
                return;
            }

            this.displayWidgets();
        },

        displayWidgets: function() {
            var self = this;
            var widgetElements = jQuery('.IGraphWidget');

            var widgetDefs = [];
            var insertAfter = null;
            if (widgetElements.length == 0) {
                insertAfter = jQuery("#toc")[0] || jQuery("#contentSub")[0];

            }
            else {
                insertAfter = jQuery('.IGraphWidget:first');
                widgetElements.each(function() {
                    widgetDefs.push(jQuery(this).text());
                });
            }
            if (jQuery('.IGraphNoDefaultWidgets').length === 0) {
                widgetDefs.push(this.DEFAULT_WIDGETS.period + this.defaultPeriod);
                widgetDefs.push(this.DEFAULT_WIDGETS.time + this.defaultTime);
                widgetDefs.push(this.DEFAULT_WIDGETS.refresh);
            }
            this.displayWidgetsFromDefs(widgetDefs, insertAfter);
        },

        displayWidgetsFromDefs: function(widgetDefs, insertAfter) {
            if (widgetDefs.length == 0) {
                return;
            }
            var div = jQuery('<div>').addClass('iGHmenuArea');
            for (var i = 0; i < widgetDefs.length; i++) {
                var def = widgetDefs[i];
                var fields = def.split("|");
                if (fields.length > 0) {
                    var menuType = jQuery.trim(fields[0]);
                    if (menuType === 'menu' && fields.length == 4) {
                        this.doMenu(div, fields[1], fields[2], fields[3]);
                    }
                    else if (menuType === 'radio' && fields.length == 4) {
                        this.doRadio(div, i, fields[1], fields[2], fields[3]);
                    }
                    else if (menuType === 'html' && fields.length == 2) {
                        this.doHtml(div, fields[1]);
                    }
                    else if (menuType === 'refresh') {
                        this.doRefresh(div);
                    }
                    else {
                        log("Error, expected '[menu|radio]|<name>|<options>|<default>' but got this: " + def);
                    }
                }
                else {
                    log("Error, expected '[menu|radio|input]|<field>[|<fields>]...' but got this: " + def);
                }
            };
            div.append('<a href="http://w.amazon.com/index.php/IGraphHelper#Adding_Custom_Wiki_Controls" target="_blank" class="iGHmenuLink">Customize...</a>');
            div.insertAfter(insertAfter);
        },

        doMenu: function(div, nameField, optionsField, defaultOptionField) {
            var self = this;
            var menuName = this.parseMenuEntry(jQuery.trim(nameField));
            var options = jQuery.trim(optionsField).split(",");
            var defaultOption = jQuery.trim(defaultOptionField);
            var container = jQuery('<span>').addClass('iGHwidget').appendTo(div);
            jQuery('<span>').addClass('iGHmenuTitle').text(menuName.text + ": ").appendTo(container);
            var optionsHtml = "";
            for (var j = 0; j < options.length; j++) {
                var option = this.parseMenuEntry(options[j]);
                var selected = option.value == defaultOption ? "selected" : "";
                optionsHtml += '<option value="' + option.value + '" ' + selected + '>' + option.text + '</option>';
            }
            jQuery('<select>' + optionsHtml + '</select>').appendTo(container).on('change', function() {
                self.updateFields(menuName.value, jQuery(this).val());
            });
        },

        doRadio: function(div, index, nameField, optionsField, defaultOptionField) {
            var self = this;
            var radioName = this.parseMenuEntry(jQuery.trim(nameField));
            var options = jQuery.trim(optionsField).split(",");
            var defaultOption = jQuery.trim(defaultOptionField);
            var container = jQuery('<span>').addClass('iGHwidget').appendTo(div);
            jQuery('<span>').addClass('iGHmenuTitle').text(radioName.text + ": ").appendTo(container);
            var radioContainer = jQuery('<span class="iGHradio"></span>').appendTo(container);
            for (var j = 0; j < options.length; j++) {
                var option = this.parseMenuEntry(options[j]);
                if (option.value.length > 0) {
                    var selected = option.value == defaultOption ? ' checked="checked"' : '';
                    var inputName = 'iGraphRadio' + index;
                    var inputId = inputName + '_' + j;
                    var radio = jQuery('<input type="radio" name="' + inputName + '" id="' + inputId + '" value="' + option.value + '"' + selected + '>' +
                      '<label for="' + inputId + '" title="' + option.text + '">' + option.text + '</label>');
                    radio.appendTo(radioContainer);
                    var radioValue = new String(option.value)
                    radio.on('change', function() {
                        self.updateFields(radioName.value, jQuery(this).val());
                    });
                }
            }
        },

        doHtml: function(div, html) {
            jQuery(div).append(html);
        },

        doRefresh: function(div) {
            jQuery(div).append(' <span class="iGHrefreshAll"><input type="submit" value="Refresh" class="iGHbutton"></span>');
            jQuery('.iGHrefreshAll input', div).on('click', refreshAll);
        },

        parseMenuEntry: function(menuEntry) {
            var fields = menuEntry.split(';');
            var value = fields.length == 2 ? fields[1] : fields[0];
            return {text: jQuery.trim(fields[0]), value: jQuery.trim(value)};
        },

        keys: function(object)  {
            var keys = [];
            var key;
            for (key in object) {
                if (object.hasOwnProperty(key)) {
                    keys.push(key);
                }
            }
            return keys;
        },

        updateFields: function(fields, values) {
            var fieldEntries = fields.split("&");
            var valueEntries = values.split("&");
            if (fieldEntries.length != valueEntries.length) {
                log('Error: different number of entries in "' + fields + '" versus "' + values + '"');
                return;
            }
            for (i = 0; i < document.images.length; i++) {
                var image = document.images[i];
                var searchString = getGraphArgs(image, true);
                if (searchString != null) {
                    var modified = false;
                    for (var f = 0; f < fieldEntries.length; f++) {
                        var fieldEntry = fieldEntries[f];
                        var valueEntry = valueEntries[f];
                        var replaced = this._doFieldReplace(searchString, fieldEntry, valueEntry);
                        if (replaced) {
                            modified = true;
                            searchString = replaced;
                        }
                    }
                    if (modified) {
                        loadingImg(image);
                        var newUrl = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&" + searchString;
                        image.src = cleanImgUrl(newUrl);
                    }
                }
            }
            decorateGraphs(true);
        },

        _doFieldReplace: function(string, field, value) {
            var fieldSplit = field.split("#");
            if (fieldSplit.length == 2) {
                var reStr = "(\\b" + fieldSplit[0] + "\\d*=)([^&]*)(" + fieldSplit[1].replace(/%3D/g, "=") +")([^&]*)";
                var valueRe = new RegExp(reStr, "g");
                if (valueRe.test(string)) {
                    return string.replace(valueRe, "$1$2" + value.replace(/%3D/g, "=") + "$4");
                }
            }
            else {
                var re = new RegExp("(\\b" + field + "\\d*=)([^&]*)", "g");
                if (re.test(string)) {
                    return string.replace(re, "$1" + value);
                }
            }
            return null;
        },

        setDefaultPeriod: function(period) {
            if (this.defaultPeriod.length === 0) {
                this.defaultPeriod = period;
            }
        },

        setDefaultStartTime: function(startTime) {
            if (this.defaultTime.length === 0) {
                this.defaultTime = startTime.replace(/T0H$/, '') + '&P0D';
            }
        }
    };

    IGH.WikiEditor = {
        initialize: function() {
            // Check if we're on a Wiki page with parameters
            if (this.onWiki(true)) {
                // We're on Wiki. Check for edit
                var queryParams = window.location.href.replace(/.*[?]/, '');
                var action = extractQueryValue(queryParams, 'action');
                if (action == 'edit') {
                    // We're on an edit page. Check for autoadd
                    var autoadd = extractQueryValue(queryParams, 'autoadd');
                    if (autoadd && autoadd.length > 0) {
                        if ((jQuery('#wpTextbox1').val().length === 0) && /MyGraphs\//.test(window.location.href)) {
                            autoadd = "[[Category:MyGraphs]]\n" + autoadd;
                        }
                        // We've got autoadd, let's add it to the page contents and save
                        this.addAndSaveText(decodeURI(autoadd).replace(/[%]26/g, "&"));
                    }
                }
            }
        },

        addAndSaveText: function(text) {
            var textBox = jQuery('#wpTextbox1');

            // Add text to edit box
            textBox.val(textBox.val() + '\n' + text);

            // Set summary for edit
            jQuery('#wpSummary').val('Autoadded by iGraph Helper, https://w.amazon.com/?IGraphHelper');

            // Click 'Save Page'
            jQuery('#wpSave').trigger('click');
        },

        onWiki: function(withArgs) {
            // Check if we're on a Wiki page with parameters
            if (! /^w[.].*amazon[.]com/.test(window.location.host)) {
                return false;
            }
            if (withArgs && ! /[?]/.test(window.location.href)) {
                return false;
            }
            return true;
        }
    };

    IGH.Metric = function(dimValues) {
        this._schemaName = dimValues[0];
        dimValues.splice(0, 1);
        this._dimValues = dimValues.slice();
    }
    IGH.Metric.prototype = {
        getSchemaName: function() {
            return this._schemaName;
        },

        getDimensions: function() {
            return IGH.MetricSchemas.getDimensions(this._schemaName);
        },

        getDimensionValues: function() {
            return this._dimValues;
        }
    }

    IGH.MetricSearch = function() {
        this._uniqueValues = new Array();
    }
    IGH.MetricSearch.prototype = {
        add: function(field, value) {
            if (!this._uniqueValues[field]) {
                this._uniqueValues[field] = new Array();
            }
            if (field == IGH.SCHEMA_NAME_FIELD) {
                value = value.replace(/MetricSchema/, "");
            }
            this._uniqueValues[field][value] = true;
        },

        addMetric: function(metric) {
            this.add(IGH.SCHEMA_NAME_FIELD, metric.getSchemaName());
            var dimensions = metric.getDimensions();
            var dimValues  = metric.getDimensionValues();
            for (var i = 0; i < dimensions.length; i++) {
                if (dimValues[i]) {
                    this.add(dimensions[i], dimValues[i]);
                }
            }
        },

        getSearchString: function() {
            var clauses = [];
            for (var field in this._uniqueValues) {
                var values = [];
                for (var value in this._uniqueValues[field]) {
                    if (field == IGH.SCHEMA_NAME_FIELD) {
                        values.push(value);
                    }
                    else {
                        values.push("$" + value + "$");
                    }
                }

                var clause = field.toLowerCase() + "=";
                clause += (values.length == 1) ? values[0] : "(" + values.join(" OR ") + ")";
                clauses.push(clause);
            }

            return clauses.length ? clauses.join(" ") : null;
        }
    }

    IGH.SCHEMA_NAME_FIELD = "SchemaName";

    IGH.MetricSchemas = {
        initialize: function() {
            for (var schemaName in this.schemaDefs) {
                this._schemas.push(schemaName);
                var dims = this.getDimensions(schemaName);
                for (var i = 0; i < dims.length; i++) {
                    this._uniqueDimensions[dims[i]] = true;
                }
                this._uniqueDimensions[IGH.SCHEMA_NAME_FIELD] = true;
            }
        },

        getDimensions: function(schemaName) {
            return this.schemaDefs[schemaName];
        },

        getSchemas: function () {
            return this._schemas;
        },

        getUniqueDimensions: function() {
            return this._uniqueDimensions;
        },

        schemaDefs: {
            "Apollo": ["Environment","Host","Stage","Step","Metric"],
            "ArizonaAccess": ["Family","Host","Page","User","Metric"],
            "CatalogRTP": ["Family","Instance","Metric"],
            "Community": ["Marketplace","ActionName","URLType","DisplayGroup","Metric"],
            "COSS": ["Family","Host","Program","OperationName","CustType","Metric"],
            "ErrorLog": ["Family","Host","Program","Severity","SignatureName","URLType","Source","Function"],
            "GKM": ["Family","Filter1","Filter2","Filter3","Filter4","Filter5","Filter6","Filter7","Filter8","Metric"],
            "Marmoset": ["Family","Host","Metric"],
            "Network": ["DataSet","AlternateName","SourceName","SourceType","DestinationName","Instance","Grouping","Metric"],
            "OnlineQueryLog": ["Family","Host","URLType","CustType","Metric"],
            "OrdersCreated": ["Family","Merchant","ProductGroup","Event"],
            "PAQ": ["ModuleName","Host","Domain","Realm","ServiceName","Queue","Metric"],
            "Search": ["Pattern"],
            "SearchSDA": ["Component","Marketplace","Host","Metric"],
            "SellerCentral": ["Family","Host","Merchant","ServiceName","Status","Tool","Metric"],
            "Service": ["DataSet","Marketplace","HostGroup","Host","ServiceName","MethodName","Client","MetricClass","Instance","Metric"],
            "Snitch": ["DataSet","HostGroup","Host","Class","Object","Metric"],
            "Spools": ["SpoolName","Type","Host","Metric"],
            "SubscriptionServices": ["DataSet","Marketplace","PlanGroup","Plan","Category","OperationName","Metric"],
            "TimingLog": ["Family","Host","Function","ServiceName","Metric"],
            "WebLabData": ["Family","WebLab","Metric"],
            "XDQ": ["XDQ","XDQVersion","Machine","Metric"] },
        _schemas: [],
        _uniqueDimensions: {}
    };

    /*
     * Browser constants
     */
    IGH.BrowserConstants = {};
    IGH.BrowserConstants._isIE = navigator.appVersion.match(/MSIE/);
    IGH.BrowserConstants._userAgent = navigator.userAgent;
    IGH.BrowserConstants._isFireFox = IGH.BrowserConstants._userAgent.match(/firefox/i);
    IGH.BrowserConstants._isFireFoxOld = IGH.BrowserConstants._isFireFox &&
      (IGH.BrowserConstants._userAgent.match(/firefox\/2./i)
        || IGH.BrowserConstants._userAgent.match(/firefox\/1./i));
    IGH.BrowserConstants._isFireFoxNew = IGH.BrowserConstants._isFireFox && !IGH.BrowserConstants._isFireFoxOld;
    IGH.BrowserConstants._isSafari = /^((?!chrome|android|crios|fxios).)*safari/i.test(IGH.BrowserConstants._userAgent);
    IGH.BrowserConstants._isOpera = IGH.BrowserConstants._userAgent.indexOf(' OPR/') >= 0;

    /*
     * Get the absolute position of any HTML element
     */
    IGH.getElementPosition = function(element) {
        var offset = $(element).offset();
        var pos = { x: Math.floor(offset.left),
            y: Math.floor(offset.top) };
        return pos;
    };

    IGH._parseBorderWidth = function(width) {
        var res = 0;
        if (typeof(width) == "string" && width != null
          && width != "" ) {
            var p = width.indexOf("px");
            if (p >= 0) {
                res = parseInt(width.substring(0, p));
            }
            else {
                //do not know how to calculate other
                //values (such as 0.5em or 0.1cm) correctly now
                //so just set the width to 1 pixel
                res = 1;
            }
        }
        return res;
    }

    //returns border width for some element
    IGH._getBorderWidth = function(element) {
        var res = new Object();
        res.left = 0; res.top = 0; res.right = 0; res.bottom = 0;
        if (window.getComputedStyle) {
            //for Firefox
            var elStyle = window.getComputedStyle(element, null);
            res.left = parseInt(elStyle.borderLeftWidth.slice(0, -2));
            res.top = parseInt(elStyle.borderTopWidth.slice(0, -2));
            res.right = parseInt(elStyle.borderRightWidth.slice(0, -2));
            res.bottom = parseInt(elStyle.borderBottomWidth.slice(0, -2));
        }
        else {
            //for other browsers
            res.left = IGH.BrowserConstants._parseBorderWidth(element.style.borderLeftWidth);
            res.top = IGH.BrowserConstants._parseBorderWidth(element.style.borderTopWidth);
            res.right = IGH.BrowserConstants._parseBorderWidth(element.style.borderRightWidth);
            res.bottom = IGH.BrowserConstants._parseBorderWidth(element.style.borderBottomWidth);
        }

        return res;
    }

    /*
    * Utility function for getting size of window
    */
    IGH.getWindowSize = function() {
        var myWidth = 0, myHeight = 0;
        if (typeof( window.innerWidth ) == 'number' ) {
            //Non-IE
            myWidth = window.innerWidth;
            myHeight = window.innerHeight;
        } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
            //IE 6+ in 'standards compliant mode'
            myWidth = document.documentElement.clientWidth;
            myHeight = document.documentElement.clientHeight;
        } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
            //IE 4 compatible
            myWidth = document.body.clientWidth;
            myHeight = document.body.clientHeight;
        }
        return { width: myWidth, height: myHeight};
    };

    /*
     *  Given an event returns the absolute position of the mouse pointer
     */
    IGH.getMouseCoords = function(ev) {
        try {
            ev = ev || window.event;
            if (ev.pageX || ev.pageY) {
                return {
                    x: ev.pageX,
                    y: ev.pageY
                };
            }
            var windowOffset = IGH.getWindowOffset();
            return {
                x: ev.clientX + windowOffset.x - document.body.clientLeft,
                y: ev.clientY + windowOffset.y - document.body.clientTop
            };
        }
        catch (e) {
            // The event object was not obtainable or did not contain location information
            return null;
        }
    };

    IGH.getWindowOffset = function() {
        return {
            x: IGH.filterAreaResults(window.pageXOffset ? window.pageXOffset : 0,
              document.documentElement ? document.documentElement.scrollLeft : 0,
              document.body ? document.body.scrollLeft : 0),
            y: IGH.filterAreaResults(window.pageYOffset ? window.pageYOffset : 0,
              document.documentElement ? document.documentElement.scrollTop : 0,
              document.body ? document.body.scrollTop : 0)
        }
    };

    /*
    * Utility function for getting the correct number in the DOM for x and y positions.
    * It is given numbers that come from the window, document and documeny body and
    * the algorithm figures out the correct one to use.
    */
    IGH.filterAreaResults = function(n_win, n_docel, n_body) {
        var n_result = n_win ? n_win : 0;
        if (n_docel && (!n_result || (n_result > n_docel))) {
            n_result = n_docel;
        }
        return n_body && (!n_result || (n_result > n_body)) ? n_body : n_result;
    };

    IGH.PortalGraphZoomer = {
        initialize: function() {
            monitorPortal = document.getElementById("masthead");
            if (monitorPortal) {
                if (!(/[<]h1[>]Infrastructure[<].h1[>]/.exec(monitorPortal.innerHTML) &&
                  /[<]h2[>]Powered By Monitoring[<].h2[>]/.exec(monitorPortal.innerHTML) && window.jQuery)) {
                    return;
                }

                // Register click event on all graphs
                jQuery("#graph_results .img img").on('click', IGH.PortalGraphZoomer._graphClickEvent);
                jQuery("#graph_results .img img").css("cursor", "pointer");
                jQuery("#graph_results .img img").attr("title", "Click to zoom");
            }
        },

        /*
         * Graph was left-clicked:
         * - left-click on its own zooms in by 2, and recenters around clicked-on spot
         * - shift-left-click recenters graph on around clicked-on spot (no zoom)
         * - ctrl-left-click jumps to latest data (no zoom)
         */
        _graphClickEvent: function(e) {
            var event = window.event || e;
            var graphPos = jQuery(this).offset();
            var width = jQuery(this).width();
            var xClick = event.clientX - graphPos.left;

            IGH.PortalGraphZoomer._zoom(xClick, width, event.shiftKey ? 1.0 : 0.5);
            return false;
        },

        _getTimeRange: function() {
            var endTime = jQuery('#end_time').val();
            var endTimeMillis = Date.parse(endTime);
            var isFixedTime = jQuery('div#time-control .switch-time a').attr('id') != 'fixed-time';
            if (isFixedTime) {
                var startTime = jQuery('#start_time').val();
                var startTimeMillis = Date.parse(startTime);
            }
            else {
                var relTime = jQuery('#relative_time_value').val();
                var period = jQuery('#relative_time_value').next().val();
                var minMultiplier = 1;
                if (period == "hour") {
                    minMultiplier = 60;
                }
                else if (period == "day") {
                    minMultiplier = 24 * 60;
                }
                else if (period == "week") {
                    minMultiplier = 7 * 24 * 60;
                }
                var relMinutes = relTime * minMultiplier;
                var startTimeMillis = endTimeMillis - 60000 * relMinutes;
            }
            return {startTime: startTimeMillis, endTime: endTimeMillis};
        },

        _zoom: function(x, width, zoomLevel) {
            var timeRange = this._getTimeRange();
            var startDuration, endDuration;

            var centerSpot = timeRange.startTime - Math.floor((timeRange.startTime - timeRange.endTime) / 1.0 / width * x);
            var halfDuration = Math.floor((timeRange.startTime - timeRange.endTime) * zoomLevel / 2);
            var newStartMillis = centerSpot + halfDuration;
            var newEndMillis = centerSpot - halfDuration;

            this._setTimeRange(newStartMillis, newEndMillis);
            jQuery('#graph-metrics').submit();
        },

        _setTimeRange: function(startTimeMillis, endTimeMillis) {
            this._displayFixedTime();
            var startTime = new Date(startTimeMillis);
            var endTime = new Date(endTimeMillis);
            jQuery('#start_time').val(this._formatTime(startTime));
            jQuery('#end_time').val(this._formatTime(endTime));
        },

        _formatTime: function(time) {
            var y = time.getYear() + 1900;
            var m = time.getMonth() + 1;
            var d = time.getDate();
            var h = time.getHours();
            var min = time.getMinutes();

            return (y + "/" + this._zeroPad(m) + "/" + this._zeroPad(d) + " " + this._zeroPad(h) + ":" + this._zeroPad(min));
        },

        _displayFixedTime: function() {
            var timecontrol = jQuery('div#time-control');
            var fixedTime = 'div#hidden-fixed-time-control';
            timecontrol.empty().append(jQuery(fixedTime).html());
        },

        _zeroPad: function(x) {
            return(x<0||x>9?"":"0")+x;
        }

    };

    IGH.PortalGraphSelector = {
        initialize: function() {
            if (unsafeWindow.GraphData && unsafeWindow.GraphData.initDataTable && ! (/monitorportal.amazon.com[/]mws[/]data/.test(window.location.href))) {
                this._origInitDataTable = unsafeWindow.GraphData.initDataTable;
                unsafeWindow.GraphData.initDataTable = this._myInitDataTable;
                graphsFound = true;
            }
        },

        _myInitDataTable: function(index) {
            IGH.PortalGraphSelector._origInitDataTable(index);
            var divId = "#graph_data_" + index;
            jQuery(divId + " table.tablesorter tr td").on("click", function() {
                var cb = jQuery("input", jQuery(this).parent());
                cb.prop("checked", ! cb.prop("checked"));
            });
            jQuery(divId).prepend("<a id='iGraphPreview" + index + "' style='cursor: pointer;' title='Preview metrics in popup (iGraphHelper)'>Preview</a>");
            jQuery(divId).prepend("<a id='iGraphView" + index + "' style='cursor: pointer;' title='View metrics in iGraph (iGraphHelper)'>View in iGraph</a>&nbsp|&nbsp;");
            jQuery("#iGraphPreview" + index).on('click', function() {IGH.PortalGraphSelector._previewGraphs(index);});
            jQuery("#iGraphView" + index).on('click', function() {IGH.PortalGraphSelector._viewGraphs(index);});
            jQuery(divId + " table tr:first").prepend("<th><input type=checkbox checked title='Toggle all metrics (iGraphHelper)'></th>");
            jQuery(divId + " table tr:first input").on('change', function() { IGH.PortalGraphSelector._checkAllChanged(this, index);});
            jQuery(divId + " table tr:gt(0)").prepend("<td><input type=checkbox checked title='Toggle this metric (iGraphHelper)'></td>");


        },

        _checkAllChanged: function(cb, index) {
            jQuery("#graph_data_" + index + " table tr:gt(0) input").prop("checked", jQuery(cb).prop("checked"));
            return false;
        },

        _viewGraphs: function(index) {
            var igraph = "/igraph?";
            var args = IGH.PortalGraphSelector._getGraphs(index);
            if (args.length == 0) {
                alert("Please tick metrics below to view in iGraph");
            }
            else {
                window.open(igraph + args);
            }
            return false;
        },

        _previewGraphs: function(index) {
            var img = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&WidthInPixels=760&HeightInPixels=460&";
            var args = IGH.PortalGraphSelector._getGraphs(index);
            if (args.length == 0) {
                alert("Please tick metrics below to preview");
            }
            else {
                maximizeClicked(args);
//            jQuery.blockUI(IGH.PortalGraphSelector._getPreviewModalHtml(img + args), window.modal_normal);
            }
            return false;

        },

        _getGraphs: function(index) {
            var LIMIT = 50;
            var args = "";
            jQuery("#graph_data_" + index + " table tr:gt(0) input:checked").each(function(i) {
                var td = jQuery(this).parent().next();
                var link = jQuery("a", td).attr("href");
                if (!link) {
                    link = IGH.PortalGraphSelector._getLinkFromMetricString(jQuery.trim(td.text()), index);
                }

                link = link.replace(/^.igraph[?]/, "").replace(/\d+=/g, (i + 1) + "=");
                if (i > 0) {
                    link = link.replace(/[&]StartTime.*/, "");
                }
                if (i < LIMIT) {
                    args += "&"+ link;
                }
                else if (i == LIMIT) {
                    alert("Warning: limited to displaying " + LIMIT + " metrics in iGraph");
                }
            });

            return args;
        },

        _getPreviewModalHtml: function(img) {
            return  '\
                    <div id="lightbox">\
                        <div id="header"><h2>Preview Metrics (iGraphHelper)</h2>\
                             <a href="#" class="close" onclick="jQuery.unblockUI(); return false;">close</a><br/>\
                        </div>\
                        <div style="background:url(\'/images/spinner-l-lime.gif\') no-repeat scroll center center #FFFFFF; width: 760px; height: 460px;">\
                            <center>\
                                <img src="' + img + '" onclick="jQuery.unblockUI(); return false;" title="Click to close" style="cursor: pointer;">\
                            </center>\
                        </div>\
                    </div>';

        },

        _getLinkFromMetricString: function(label, index) {
            var metricString = jQuery(".title", jQuery("#graph_data_" + index).parents("tr").children(":first-child")).text();
            var METRIC_EXTRACTOR_REGEXP =  new RegExp('^([^ ]*) ([^ ]*) ([^ ]*)');
            var metricParts = METRIC_EXTRACTOR_REGEXP.exec(metricString);
            if (metricParts && metricParts.length == 4) {
                return "&SchemaName1=Snitch&Stat1=avg&Period1=OneMinute&DataSet1=prod" +  this._getHostOrHostclass(label) +
                  "&DecoratePoints=true" + this._getCurrentTimeRange() +
                  "&Class1=" + metricParts[1] +
                  "&Object1=" + metricParts[2] +
                  "&Metric1=" + metricParts[3];
            }
        },

        _getHostOrHostclass: function(label) {
            return location.pathname.indexOf('/hostclasses/') === 0 ?
              ("&HostGroup1=" + encodeURIComponent(label) + "&Host1=ALL") :
              ("&HostGroup1=NONE&Host1=" + encodeURIComponent(label));
        },

        _getCurrentTimeRange: function() {
            var time = IGH.PortalGraphZoomer._getTimeRange();
            var startTime = new Date(time.startTime);
            var endTime = new Date(time.endTime);
            return "&StartTime1=-PT" + parseInt((endTime.getTime() - startTime.getTime()) / 3600000) + "H&EndTime1=-P0D";

        },

        _getTimeInHours: function(time) {
            var now = new Date();
            return (now.getTime() - time.getTime()) / 1000 / 60 / 60;
        }
    };

    IGH.IGraphUpdates = {
        initialize: function() {
            if ((typeof MP !== 'undefined') && MP.graph && MP.graph.model &&
              MP.graph.PARAMS.MODEL_CHANGED_EVENT && MP.graph.model() &&
              jQuery) {
                MP.graph.model().register(MP.graph.PARAMS.MODEL_CHANGED_EVENT, IGH.IGraphUpdates.setTitle);
                IGH.IGraphUpdates.setTitle();
                jQuery('#linkToThisGraphTiny').on('click', IGH.IGraphUpdates.tinyClicked);
            }
        },

        setTitle: function() {
            var title = MP.graph.model().options().graphTitle();
            if (title != null && title != "") {
                window.document.title = title;
            }

        },

        tinyClicked: function() {
            var title = MP.graph.model().options().graphTitle();
            var tinyLink = jQuery('#linkToThisGraphTiny').attr("href", tinyLink);
            tinyLink = tinyLink.replace(/comment=iGraph/, "comment=" + escape(title));
            jQuery('#linkToThisGraphTiny').attr("href", tinyLink);
            return true;
        }
    };


    IGH.TimeRangeUtils = {

        TZ_PDT: "PST8PDT",
        XML_DATE: new RegExp('(\\d{4})-(\\d{2})-(\\d{2})'),
        XML_TIME: new RegExp('T(\\d{2}):(\\d{2}):(\\d{2})'),
        XML_TZ: new RegExp('([-+]\\d{2}):00$'),
        DECIMAL: 10,
        MILLISECONDS_IN_MINUTE: 60 * 1000,
        DURATION: new RegExp('^-?P'),

        PATTERN: {
            DAY: new RegExp('(\\d*)D'),
            HOUR: new RegExp('(\\d*)H'),
            MINUTE: new RegExp('(\\d*)M')
        },

        DURATIONS: {
            DAY: "D",
            HOUR: "H",
            MINUTE: "M"
        },

        MINUTES: {
            DAY: 24 * 60,
            HOUR: 60,
            MINUTE: 1
        },

        UNITS: {
            MINUTE: "MINUTE",
            HOUR: "HOUR",
            DAY: "DAY"
        },

        ORDERED_UNITS: ["MINUTE", "HOUR", "DAY"],

        // get units and corresponding value form a control
        getControlFromDuration: function(duration){
            var minutes = this.getMinutes(duration);
            var unit = this.getUnits(duration);
            var value = minutes / this.MINUTES[unit];
            var result = {};
            result[unit] = value;
            return result;
        },

        // get number of minutes corresponding to a duration
        getMinutes: function(duration){
            // sign is inverted sign widget is ago
            var sign = duration.match("-P") ? 1 : -1;
            var minutes = 0;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    minutes += this.MINUTES[index] * parseInt(results[1], this.DECIMAL);
                }
            }
            return sign * minutes;
        },

        // get most significant Unit present in a duration
        getUnits: function(duration){
            var unit = this.UNITS.MINUTE;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    unit = index;
                }
            }
            return unit;
        },

        // create a duration form the screen widget
        getDurationFromControl: function(unit, value){
            // sign is inverted sign widget is ago
            var sign = value < 0 ? "" : "-";
            var minutes = Math.floor(this.MINUTES[unit] * Math.abs(value));
            var duration = sign + "P";
            if (minutes >= this.MINUTES.DAY || unit === this.UNITS.DAY) {
                var days = Math.floor(minutes / this.MINUTES.DAY);
                duration += days + this.DURATIONS.DAY;
                minutes = minutes % this.MINUTES.DAY;
            }
            duration += "T";
            if (minutes >= this.MINUTES.HOUR || unit === this.UNITS.HOUR) {
                var hours = Math.floor(minutes / this.MINUTES.HOUR);
                duration += hours + this.DURATIONS.HOUR;
                minutes = minutes % this.MINUTES.HOUR;
            }
            if (minutes >= this.MINUTES.MINUTE || unit === this.UNITS.MINUTE) {
                var mins = Math.floor(minutes / this.MINUTES.MINUTE);
                duration += mins + this.DURATIONS.MINUTE;
            }
            if( duration.charAt(duration.length-1) === "T") {
                duration= duration.slice(0,-1);
            }
            return duration;
        },

        // get a calendar string in UTC from the int values of a javascript date
        getXMLCalendarFromControl: function(year, month, dayOfMonth, hours, minutes){
            var date = new fleegix.date.Date(year, month, dayOfMonth, hours, minutes, this.TZ_PDT, false);
            return this.getXMLCalendarFromDate(date);
        },

        // get a calendar string in UTC from a date
        getXMLCalendarFromDate: function(date){
            return date.getUTCFullYear() + "-" + this.pad(date.getUTCMonth() + 1) + "-" + this.pad(date.getUTCDate()) + "T" + this.pad(date.getUTCHours()) + ":" + this.pad(date.getUTCMinutes()) + ":00Z";
        },

        // get a date in PDT from an xml calendar in UTC
        getDateFromXMLCalendar: function(xmlCalendar){
            var hour = 0;
            var minute = 0;
            var second = 0;
            var tz = 0;
            var results = this.XML_TZ.exec(xmlCalendar);
            if (results) {
                tz = parseInt(results[1], this.DECIMAL);
            }
            results = this.XML_TIME.exec(xmlCalendar);
            if (results) {
                hour = parseInt(results[1], this.DECIMAL);
                minute = parseInt(results[2], this.DECIMAL);
                second = parseInt(results[3], this.DECIMAL);
            }
            results = this.XML_DATE.exec(xmlCalendar);
            if (results) {
                var year = parseInt(results[1], this.DECIMAL);
                var month = parseInt(results[2], this.DECIMAL) - 1;
                var dayInMonth = parseInt(results[3], this.DECIMAL);
                var utc = new Date(Date.UTC(year, month, dayInMonth, hour, minute, second) - (tz * (60 * 60 * 1000)));
                return utc;
            }
            return null;
        },

        // get an xml calendar in UTC from a date and an xml duration
        getXMLCalendarFromDuration: function(now, duration){
            var minutes = this.getMinutes(duration);
            now.setMinutes(now.getMinutes() - minutes);
            return this.getXMLCalendarFromDate(now);
        },

        // get an xml calendar in UTC from a date and an xml duration
        getDurationFromXMLCalendar: function(now, calendar){
            calendar = unescape(calendar);
            var then = this.getDateFromXMLCalendar(calendar);
            var minutes = (now.getTime() - then.getTime()) / this.MILLISECONDS_IN_MINUTE;
            return this.getDurationFromControl(this.UNITS.MINUTE, minutes);
        },

        // Convert a time range into minute durations
        getTimeRangeInMinutes: function(now, timeRange) {
            var minuteRange = new Object();
            minuteRange.startTime = this._getTimeInMinutes(now, timeRange.startTime);
            minuteRange.endTime   = this._getTimeInMinutes(now, timeRange.endTime);
            return minuteRange;
        },

        // Convert a time (duration or fixed) into number of minutes, compared to now
        _getTimeInMinutes: function(now, time) {
            var duration;
            if (! this.isDuration(time)) {
                duration = this.getDurationFromXMLCalendar(now, time);
            }
            else {
                duration = time;
            }
            return this.getMinutes(duration);
        },

        // Return true if time is a duration
        isDuration: function(time) {
            return this.DURATION.test(time);
        },

        pad: function(number){
            if (number < 10) {
                return "0" + number;
            }
            return number;
        }
    };

    // Only load jQuery if not already loaded
    if ((typeof($) === 'undefined') && (typeof(jQuery) === 'undefined')) {
        /*! jQuery v1.9.1 | (c) 2005, 2012 jQuery Foundation, Inc. | jquery.org/license
        //@ sourceMappingURL=jquery.min.map */
        (function(e,t){var n,r,i=typeof t,o=e.document,a=e.location,s=e.jQuery,u=e.$,l={},c=[],p="1.9.1",f=c.concat,d=c.push,h=c.slice,g=c.indexOf,m=l.toString,y=l.hasOwnProperty,v=p.trim,b=function(e,t){return new b.fn.init(e,t,r)},x=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,w=/\S+/g,T=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,N=/^(?:(<[\w\W]+>)[^>]*|#([\w-]*))$/,C=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,k=/^[\],:{}\s]*$/,E=/(?:^|:|,)(?:\s*\[)+/g,S=/\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,A=/"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g,j=/^-ms-/,D=/-([\da-z])/gi,L=function(e,t){return t.toUpperCase()},H=function(e){(o.addEventListener||"load"===e.type||"complete"===o.readyState)&&(q(),b.ready())},q=function(){o.addEventListener?(o.removeEventListener("DOMContentLoaded",H,!1),e.removeEventListener("load",H,!1)):(o.detachEvent("onreadystatechange",H),e.detachEvent("onload",H))};b.fn=b.prototype={jquery:p,constructor:b,init:function(e,n,r){var i,a;if(!e)return this;if("string"==typeof e){if(i="<"===e.charAt(0)&&">"===e.charAt(e.length-1)&&e.length>=3?[null,e,null]:N.exec(e),!i||!i[1]&&n)return!n||n.jquery?(n||r).find(e):this.constructor(n).find(e);if(i[1]){if(n=n instanceof b?n[0]:n,b.merge(this,b.parseHTML(i[1],n&&n.nodeType?n.ownerDocument||n:o,!0)),C.test(i[1])&&b.isPlainObject(n))for(i in n)b.isFunction(this[i])?this[i](n[i]):this.attr(i,n[i]);return this}if(a=o.getElementById(i[2]),a&&a.parentNode){if(a.id!==i[2])return r.find(e);this.length=1,this[0]=a}return this.context=o,this.selector=e,this}return e.nodeType?(this.context=this[0]=e,this.length=1,this):b.isFunction(e)?r.ready(e):(e.selector!==t&&(this.selector=e.selector,this.context=e.context),b.makeArray(e,this))},selector:"",length:0,size:function(){return this.length},toArray:function(){return h.call(this)},get:function(e){return null==e?this.toArray():0>e?this[this.length+e]:this[e]},pushStack:function(e){var t=b.merge(this.constructor(),e);return t.prevObject=this,t.context=this.context,t},each:function(e,t){return b.each(this,e,t)},ready:function(e){return b.ready.promise().done(e),this},slice:function(){return this.pushStack(h.apply(this,arguments))},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},eq:function(e){var t=this.length,n=+e+(0>e?t:0);return this.pushStack(n>=0&&t>n?[this[n]]:[])},map:function(e){return this.pushStack(b.map(this,function(t,n){return e.call(t,n,t)}))},end:function(){return this.prevObject||this.constructor(null)},push:d,sort:[].sort,splice:[].splice},b.fn.init.prototype=b.fn,b.extend=b.fn.extend=function(){var e,n,r,i,o,a,s=arguments[0]||{},u=1,l=arguments.length,c=!1;for("boolean"==typeof s&&(c=s,s=arguments[1]||{},u=2),"object"==typeof s||b.isFunction(s)||(s={}),l===u&&(s=this,--u);l>u;u++)if(null!=(o=arguments[u]))for(i in o)e=s[i],r=o[i],s!==r&&(c&&r&&(b.isPlainObject(r)||(n=b.isArray(r)))?(n?(n=!1,a=e&&b.isArray(e)?e:[]):a=e&&b.isPlainObject(e)?e:{},s[i]=b.extend(c,a,r)):r!==t&&(s[i]=r));return s},b.extend({noConflict:function(t){return e.$===b&&(e.$=u),t&&e.jQuery===b&&(e.jQuery=s),b},isReady:!1,readyWait:1,holdReady:function(e){e?b.readyWait++:b.ready(!0)},ready:function(e){if(e===!0?!--b.readyWait:!b.isReady){if(!o.body)return setTimeout(b.ready);b.isReady=!0,e!==!0&&--b.readyWait>0||(n.resolveWith(o,[b]),b.fn.trigger&&b(o).trigger("ready").off("ready"))}},isFunction:function(e){return"function"===b.type(e)},isArray:Array.isArray||function(e){return"array"===b.type(e)},isWindow:function(e){return null!=e&&e==e.window},isNumeric:function(e){return!isNaN(parseFloat(e))&&isFinite(e)},type:function(e){return null==e?e+"":"object"==typeof e||"function"==typeof e?l[m.call(e)]||"object":typeof e},isPlainObject:function(e){if(!e||"object"!==b.type(e)||e.nodeType||b.isWindow(e))return!1;try{if(e.constructor&&!y.call(e,"constructor")&&!y.call(e.constructor.prototype,"isPrototypeOf"))return!1}catch(n){return!1}var r;for(r in e);return r===t||y.call(e,r)},isEmptyObject:function(e){var t;for(t in e)return!1;return!0},error:function(e){throw Error(e)},parseHTML:function(e,t,n){if(!e||"string"!=typeof e)return null;"boolean"==typeof t&&(n=t,t=!1),t=t||o;var r=C.exec(e),i=!n&&[];return r?[t.createElement(r[1])]:(r=b.buildFragment([e],t,i),i&&b(i).remove(),b.merge([],r.childNodes))},parseJSON:function(n){return e.JSON&&e.JSON.parse?e.JSON.parse(n):null===n?n:"string"==typeof n&&(n=b.trim(n),n&&k.test(n.replace(S,"@").replace(A,"]").replace(E,"")))?Function("return "+n)():(b.error("Invalid JSON: "+n),t)},parseXML:function(n){var r,i;if(!n||"string"!=typeof n)return null;try{e.DOMParser?(i=new DOMParser,r=i.parseFromString(n,"text/xml")):(r=new ActiveXObject("Microsoft.XMLDOM"),r.async="false",r.loadXML(n))}catch(o){r=t}return r&&r.documentElement&&!r.getElementsByTagName("parsererror").length||b.error("Invalid XML: "+n),r},noop:function(){},globalEval:function(t){t&&b.trim(t)&&(e.execScript||function(t){e.eval.call(e,t)})(t)},camelCase:function(e){return e.replace(j,"ms-").replace(D,L)},nodeName:function(e,t){return e.nodeName&&e.nodeName.toLowerCase()===t.toLowerCase()},each:function(e,t,n){var r,i=0,o=e.length,a=M(e);if(n){if(a){for(;o>i;i++)if(r=t.apply(e[i],n),r===!1)break}else for(i in e)if(r=t.apply(e[i],n),r===!1)break}else if(a){for(;o>i;i++)if(r=t.call(e[i],i,e[i]),r===!1)break}else for(i in e)if(r=t.call(e[i],i,e[i]),r===!1)break;return e},trim:v&&!v.call("\ufeff\u00a0")?function(e){return null==e?"":v.call(e)}:function(e){return null==e?"":(e+"").replace(T,"")},makeArray:function(e,t){var n=t||[];return null!=e&&(M(Object(e))?b.merge(n,"string"==typeof e?[e]:e):d.call(n,e)),n},inArray:function(e,t,n){var r;if(t){if(g)return g.call(t,e,n);for(r=t.length,n=n?0>n?Math.max(0,r+n):n:0;r>n;n++)if(n in t&&t[n]===e)return n}return-1},merge:function(e,n){var r=n.length,i=e.length,o=0;if("number"==typeof r)for(;r>o;o++)e[i++]=n[o];else while(n[o]!==t)e[i++]=n[o++];return e.length=i,e},grep:function(e,t,n){var r,i=[],o=0,a=e.length;for(n=!!n;a>o;o++)r=!!t(e[o],o),n!==r&&i.push(e[o]);return i},map:function(e,t,n){var r,i=0,o=e.length,a=M(e),s=[];if(a)for(;o>i;i++)r=t(e[i],i,n),null!=r&&(s[s.length]=r);else for(i in e)r=t(e[i],i,n),null!=r&&(s[s.length]=r);return f.apply([],s)},guid:1,proxy:function(e,n){var r,i,o;return"string"==typeof n&&(o=e[n],n=e,e=o),b.isFunction(e)?(r=h.call(arguments,2),i=function(){return e.apply(n||this,r.concat(h.call(arguments)))},i.guid=e.guid=e.guid||b.guid++,i):t},access:function(e,n,r,i,o,a,s){var u=0,l=e.length,c=null==r;if("object"===b.type(r)){o=!0;for(u in r)b.access(e,n,u,r[u],!0,a,s)}else if(i!==t&&(o=!0,b.isFunction(i)||(s=!0),c&&(s?(n.call(e,i),n=null):(c=n,n=function(e,t,n){return c.call(b(e),n)})),n))for(;l>u;u++)n(e[u],r,s?i:i.call(e[u],u,n(e[u],r)));return o?e:c?n.call(e):l?n(e[0],r):a},now:function(){return(new Date).getTime()}}),b.ready.promise=function(t){if(!n)if(n=b.Deferred(),"complete"===o.readyState)setTimeout(b.ready);else if(o.addEventListener)o.addEventListener("DOMContentLoaded",H,!1),e.addEventListener("load",H,!1);else{o.attachEvent("onreadystatechange",H),e.attachEvent("onload",H);var r=!1;try{r=null==e.frameElement&&o.documentElement}catch(i){}r&&r.doScroll&&function a(){if(!b.isReady){try{r.doScroll("left")}catch(e){return setTimeout(a,50)}q(),b.ready()}}()}return n.promise(t)},b.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),function(e,t){l["[object "+t+"]"]=t.toLowerCase()});function M(e){var t=e.length,n=b.type(e);return b.isWindow(e)?!1:1===e.nodeType&&t?!0:"array"===n||"function"!==n&&(0===t||"number"==typeof t&&t>0&&t-1 in e)}r=b(o);var _={};function F(e){var t=_[e]={};return b.each(e.match(w)||[],function(e,n){t[n]=!0}),t}b.Callbacks=function(e){e="string"==typeof e?_[e]||F(e):b.extend({},e);var n,r,i,o,a,s,u=[],l=!e.once&&[],c=function(t){for(r=e.memory&&t,i=!0,a=s||0,s=0,o=u.length,n=!0;u&&o>a;a++)if(u[a].apply(t[0],t[1])===!1&&e.stopOnFalse){r=!1;break}n=!1,u&&(l?l.length&&c(l.shift()):r?u=[]:p.disable())},p={add:function(){if(u){var t=u.length;(function i(t){b.each(t,function(t,n){var r=b.type(n);"function"===r?e.unique&&p.has(n)||u.push(n):n&&n.length&&"string"!==r&&i(n)})})(arguments),n?o=u.length:r&&(s=t,c(r))}return this},remove:function(){return u&&b.each(arguments,function(e,t){var r;while((r=b.inArray(t,u,r))>-1)u.splice(r,1),n&&(o>=r&&o--,a>=r&&a--)}),this},has:function(e){return e?b.inArray(e,u)>-1:!(!u||!u.length)},empty:function(){return u=[],this},disable:function(){return u=l=r=t,this},disabled:function(){return!u},lock:function(){return l=t,r||p.disable(),this},locked:function(){return!l},fireWith:function(e,t){return t=t||[],t=[e,t.slice?t.slice():t],!u||i&&!l||(n?l.push(t):c(t)),this},fire:function(){return p.fireWith(this,arguments),this},fired:function(){return!!i}};return p},b.extend({Deferred:function(e){var t=[["resolve","done",b.Callbacks("once memory"),"resolved"],["reject","fail",b.Callbacks("once memory"),"rejected"],["notify","progress",b.Callbacks("memory")]],n="pending",r={state:function(){return n},always:function(){return i.done(arguments).fail(arguments),this},then:function(){var e=arguments;return b.Deferred(function(n){b.each(t,function(t,o){var a=o[0],s=b.isFunction(e[t])&&e[t];i[o[1]](function(){var e=s&&s.apply(this,arguments);e&&b.isFunction(e.promise)?e.promise().done(n.resolve).fail(n.reject).progress(n.notify):n[a+"With"](this===r?n.promise():this,s?[e]:arguments)})}),e=null}).promise()},promise:function(e){return null!=e?b.extend(e,r):r}},i={};return r.pipe=r.then,b.each(t,function(e,o){var a=o[2],s=o[3];r[o[1]]=a.add,s&&a.add(function(){n=s},t[1^e][2].disable,t[2][2].lock),i[o[0]]=function(){return i[o[0]+"With"](this===i?r:this,arguments),this},i[o[0]+"With"]=a.fireWith}),r.promise(i),e&&e.call(i,i),i},when:function(e){var t=0,n=h.call(arguments),r=n.length,i=1!==r||e&&b.isFunction(e.promise)?r:0,o=1===i?e:b.Deferred(),a=function(e,t,n){return function(r){t[e]=this,n[e]=arguments.length>1?h.call(arguments):r,n===s?o.notifyWith(t,n):--i||o.resolveWith(t,n)}},s,u,l;if(r>1)for(s=Array(r),u=Array(r),l=Array(r);r>t;t++)n[t]&&b.isFunction(n[t].promise)?n[t].promise().done(a(t,l,n)).fail(o.reject).progress(a(t,u,s)):--i;return i||o.resolveWith(l,n),o.promise()}}),b.support=function(){var t,n,r,a,s,u,l,c,p,f,d=o.createElement("div");if(d.setAttribute("className","t"),d.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",n=d.getElementsByTagName("*"),r=d.getElementsByTagName("a")[0],!n||!r||!n.length)return{};s=o.createElement("select"),l=s.appendChild(o.createElement("option")),a=d.getElementsByTagName("input")[0],r.style.cssText="top:1px;float:left;opacity:.5",t={getSetAttribute:"t"!==d.className,leadingWhitespace:3===d.firstChild.nodeType,tbody:!d.getElementsByTagName("tbody").length,htmlSerialize:!!d.getElementsByTagName("link").length,style:/top/.test(r.getAttribute("style")),hrefNormalized:"/a"===r.getAttribute("href"),opacity:/^0.5/.test(r.style.opacity),cssFloat:!!r.style.cssFloat,checkOn:!!a.value,optSelected:l.selected,enctype:!!o.createElement("form").enctype,html5Clone:"<:nav></:nav>"!==o.createElement("nav").cloneNode(!0).outerHTML,boxModel:"CSS1Compat"===o.compatMode,deleteExpando:!0,noCloneEvent:!0,inlineBlockNeedsLayout:!1,shrinkWrapBlocks:!1,reliableMarginRight:!0,boxSizingReliable:!0,pixelPosition:!1},a.checked=!0,t.noCloneChecked=a.cloneNode(!0).checked,s.disabled=!0,t.optDisabled=!l.disabled;try{delete d.test}catch(h){t.deleteExpando=!1}a=o.createElement("input"),a.setAttribute("value",""),t.input=""===a.getAttribute("value"),a.value="t",a.setAttribute("type","radio"),t.radioValue="t"===a.value,a.setAttribute("checked","t"),a.setAttribute("name","t"),u=o.createDocumentFragment(),u.appendChild(a),t.appendChecked=a.checked,t.checkClone=u.cloneNode(!0).cloneNode(!0).lastChild.checked,d.attachEvent&&(d.attachEvent("onclick",function(){t.noCloneEvent=!1}),d.cloneNode(!0).click());for(f in{submit:!0,change:!0,focusin:!0})d.setAttribute(c="on"+f,"t"),t[f+"Bubbles"]=c in e||d.attributes[c].expando===!1;return d.style.backgroundClip="content-box",d.cloneNode(!0).style.backgroundClip="",t.clearCloneStyle="content-box"===d.style.backgroundClip,b(function(){var n,r,a,s="padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;",u=o.getElementsByTagName("body")[0];u&&(n=o.createElement("div"),n.style.cssText="border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px",u.appendChild(n).appendChild(d),d.innerHTML="<table><tr><td></td><td>t</td></tr></table>",a=d.getElementsByTagName("td"),a[0].style.cssText="padding:0;margin:0;border:0;display:none",p=0===a[0].offsetHeight,a[0].style.display="",a[1].style.display="none",t.reliableHiddenOffsets=p&&0===a[0].offsetHeight,d.innerHTML="",d.style.cssText="box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;",t.boxSizing=4===d.offsetWidth,t.doesNotIncludeMarginInBodyOffset=1!==u.offsetTop,e.getComputedStyle&&(t.pixelPosition="1%"!==(e.getComputedStyle(d,null)||{}).top,t.boxSizingReliable="4px"===(e.getComputedStyle(d,null)||{width:"4px"}).width,r=d.appendChild(o.createElement("div")),r.style.cssText=d.style.cssText=s,r.style.marginRight=r.style.width="0",d.style.width="1px",t.reliableMarginRight=!parseFloat((e.getComputedStyle(r,null)||{}).marginRight)),typeof d.style.zoom!==i&&(d.innerHTML="",d.style.cssText=s+"width:1px;padding:1px;display:inline;zoom:1",t.inlineBlockNeedsLayout=3===d.offsetWidth,d.style.display="block",d.innerHTML="<div></div>",d.firstChild.style.width="5px",t.shrinkWrapBlocks=3!==d.offsetWidth,t.inlineBlockNeedsLayout&&(u.style.zoom=1)),u.removeChild(n),n=d=a=r=null)}),n=s=u=l=r=a=null,t}();var O=/(?:\{[\s\S]*\}|\[[\s\S]*\])$/,B=/([A-Z])/g;function P(e,n,r,i){if(b.acceptData(e)){var o,a,s=b.expando,u="string"==typeof n,l=e.nodeType,p=l?b.cache:e,f=l?e[s]:e[s]&&s;if(f&&p[f]&&(i||p[f].data)||!u||r!==t)return f||(l?e[s]=f=c.pop()||b.guid++:f=s),p[f]||(p[f]={},l||(p[f].toJSON=b.noop)),("object"==typeof n||"function"==typeof n)&&(i?p[f]=b.extend(p[f],n):p[f].data=b.extend(p[f].data,n)),o=p[f],i||(o.data||(o.data={}),o=o.data),r!==t&&(o[b.camelCase(n)]=r),u?(a=o[n],null==a&&(a=o[b.camelCase(n)])):a=o,a}}function R(e,t,n){if(b.acceptData(e)){var r,i,o,a=e.nodeType,s=a?b.cache:e,u=a?e[b.expando]:b.expando;if(s[u]){if(t&&(o=n?s[u]:s[u].data)){b.isArray(t)?t=t.concat(b.map(t,b.camelCase)):t in o?t=[t]:(t=b.camelCase(t),t=t in o?[t]:t.split(" "));for(r=0,i=t.length;i>r;r++)delete o[t[r]];if(!(n?$:b.isEmptyObject)(o))return}(n||(delete s[u].data,$(s[u])))&&(a?b.cleanData([e],!0):b.support.deleteExpando||s!=s.window?delete s[u]:s[u]=null)}}}b.extend({cache:{},expando:"jQuery"+(p+Math.random()).replace(/\D/g,""),noData:{embed:!0,object:"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",applet:!0},hasData:function(e){return e=e.nodeType?b.cache[e[b.expando]]:e[b.expando],!!e&&!$(e)},data:function(e,t,n){return P(e,t,n)},removeData:function(e,t){return R(e,t)},_data:function(e,t,n){return P(e,t,n,!0)},_removeData:function(e,t){return R(e,t,!0)},acceptData:function(e){if(e.nodeType&&1!==e.nodeType&&9!==e.nodeType)return!1;var t=e.nodeName&&b.noData[e.nodeName.toLowerCase()];return!t||t!==!0&&e.getAttribute("classid")===t}}),b.fn.extend({data:function(e,n){var r,i,o=this[0],a=0,s=null;if(e===t){if(this.length&&(s=b.data(o),1===o.nodeType&&!b._data(o,"parsedAttrs"))){for(r=o.attributes;r.length>a;a++)i=r[a].name,i.indexOf("data-")||(i=b.camelCase(i.slice(5)),W(o,i,s[i]));b._data(o,"parsedAttrs",!0)}return s}return"object"==typeof e?this.each(function(){b.data(this,e)}):b.access(this,function(n){return n===t?o?W(o,e,b.data(o,e)):null:(this.each(function(){b.data(this,e,n)}),t)},null,n,arguments.length>1,null,!0)},removeData:function(e){return this.each(function(){b.removeData(this,e)})}});function W(e,n,r){if(r===t&&1===e.nodeType){var i="data-"+n.replace(B,"-$1").toLowerCase();if(r=e.getAttribute(i),"string"==typeof r){try{r="true"===r?!0:"false"===r?!1:"null"===r?null:+r+""===r?+r:O.test(r)?b.parseJSON(r):r}catch(o){}b.data(e,n,r)}else r=t}return r}function $(e){var t;for(t in e)if(("data"!==t||!b.isEmptyObject(e[t]))&&"toJSON"!==t)return!1;return!0}b.extend({queue:function(e,n,r){var i;return e?(n=(n||"fx")+"queue",i=b._data(e,n),r&&(!i||b.isArray(r)?i=b._data(e,n,b.makeArray(r)):i.push(r)),i||[]):t},dequeue:function(e,t){t=t||"fx";var n=b.queue(e,t),r=n.length,i=n.shift(),o=b._queueHooks(e,t),a=function(){b.dequeue(e,t)};"inprogress"===i&&(i=n.shift(),r--),o.cur=i,i&&("fx"===t&&n.unshift("inprogress"),delete o.stop,i.call(e,a,o)),!r&&o&&o.empty.fire()},_queueHooks:function(e,t){var n=t+"queueHooks";return b._data(e,n)||b._data(e,n,{empty:b.Callbacks("once memory").add(function(){b._removeData(e,t+"queue"),b._removeData(e,n)})})}}),b.fn.extend({queue:function(e,n){var r=2;return"string"!=typeof e&&(n=e,e="fx",r--),r>arguments.length?b.queue(this[0],e):n===t?this:this.each(function(){var t=b.queue(this,e,n);b._queueHooks(this,e),"fx"===e&&"inprogress"!==t[0]&&b.dequeue(this,e)})},dequeue:function(e){return this.each(function(){b.dequeue(this,e)})},delay:function(e,t){return e=b.fx?b.fx.speeds[e]||e:e,t=t||"fx",this.queue(t,function(t,n){var r=setTimeout(t,e);n.stop=function(){clearTimeout(r)}})},clearQueue:function(e){return this.queue(e||"fx",[])},promise:function(e,n){var r,i=1,o=b.Deferred(),a=this,s=this.length,u=function(){--i||o.resolveWith(a,[a])};"string"!=typeof e&&(n=e,e=t),e=e||"fx";while(s--)r=b._data(a[s],e+"queueHooks"),r&&r.empty&&(i++,r.empty.add(u));return u(),o.promise(n)}});var I,z,X=/[\t\r\n]/g,U=/\r/g,V=/^(?:input|select|textarea|button|object)$/i,Y=/^(?:a|area)$/i,J=/^(?:checked|selected|autofocus|autoplay|async|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped)$/i,G=/^(?:checked|selected)$/i,Q=b.support.getSetAttribute,K=b.support.input;b.fn.extend({attr:function(e,t){return b.access(this,b.attr,e,t,arguments.length>1)},removeAttr:function(e){return this.each(function(){b.removeAttr(this,e)})},prop:function(e,t){return b.access(this,b.prop,e,t,arguments.length>1)},removeProp:function(e){return e=b.propFix[e]||e,this.each(function(){try{this[e]=t,delete this[e]}catch(n){}})},addClass:function(e){var t,n,r,i,o,a=0,s=this.length,u="string"==typeof e&&e;if(b.isFunction(e))return this.each(function(t){b(this).addClass(e.call(this,t,this.className))});if(u)for(t=(e||"").match(w)||[];s>a;a++)if(n=this[a],r=1===n.nodeType&&(n.className?(" "+n.className+" ").replace(X," "):" ")){o=0;while(i=t[o++])0>r.indexOf(" "+i+" ")&&(r+=i+" ");n.className=b.trim(r)}return this},removeClass:function(e){var t,n,r,i,o,a=0,s=this.length,u=0===arguments.length||"string"==typeof e&&e;if(b.isFunction(e))return this.each(function(t){b(this).removeClass(e.call(this,t,this.className))});if(u)for(t=(e||"").match(w)||[];s>a;a++)if(n=this[a],r=1===n.nodeType&&(n.className?(" "+n.className+" ").replace(X," "):"")){o=0;while(i=t[o++])while(r.indexOf(" "+i+" ")>=0)r=r.replace(" "+i+" "," ");n.className=e?b.trim(r):""}return this},toggleClass:function(e,t){var n=typeof e,r="boolean"==typeof t;return b.isFunction(e)?this.each(function(n){b(this).toggleClass(e.call(this,n,this.className,t),t)}):this.each(function(){if("string"===n){var o,a=0,s=b(this),u=t,l=e.match(w)||[];while(o=l[a++])u=r?u:!s.hasClass(o),s[u?"addClass":"removeClass"](o)}else(n===i||"boolean"===n)&&(this.className&&b._data(this,"__className__",this.className),this.className=this.className||e===!1?"":b._data(this,"__className__")||"")})},hasClass:function(e){var t=" "+e+" ",n=0,r=this.length;for(;r>n;n++)if(1===this[n].nodeType&&(" "+this[n].className+" ").replace(X," ").indexOf(t)>=0)return!0;return!1},val:function(e){var n,r,i,o=this[0];{if(arguments.length)return i=b.isFunction(e),this.each(function(n){var o,a=b(this);1===this.nodeType&&(o=i?e.call(this,n,a.val()):e,null==o?o="":"number"==typeof o?o+="":b.isArray(o)&&(o=b.map(o,function(e){return null==e?"":e+""})),r=b.valHooks[this.type]||b.valHooks[this.nodeName.toLowerCase()],r&&"set"in r&&r.set(this,o,"value")!==t||(this.value=o))});if(o)return r=b.valHooks[o.type]||b.valHooks[o.nodeName.toLowerCase()],r&&"get"in r&&(n=r.get(o,"value"))!==t?n:(n=o.value,"string"==typeof n?n.replace(U,""):null==n?"":n)}}}),b.extend({valHooks:{option:{get:function(e){var t=e.attributes.value;return!t||t.specified?e.value:e.text}},select:{get:function(e){var t,n,r=e.options,i=e.selectedIndex,o="select-one"===e.type||0>i,a=o?null:[],s=o?i+1:r.length,u=0>i?s:o?i:0;for(;s>u;u++)if(n=r[u],!(!n.selected&&u!==i||(b.support.optDisabled?n.disabled:null!==n.getAttribute("disabled"))||n.parentNode.disabled&&b.nodeName(n.parentNode,"optgroup"))){if(t=b(n).val(),o)return t;a.push(t)}return a},set:function(e,t){var n=b.makeArray(t);return b(e).find("option").each(function(){this.selected=b.inArray(b(this).val(),n)>=0}),n.length||(e.selectedIndex=-1),n}}},attr:function(e,n,r){var o,a,s,u=e.nodeType;if(e&&3!==u&&8!==u&&2!==u)return typeof e.getAttribute===i?b.prop(e,n,r):(a=1!==u||!b.isXMLDoc(e),a&&(n=n.toLowerCase(),o=b.attrHooks[n]||(J.test(n)?z:I)),r===t?o&&a&&"get"in o&&null!==(s=o.get(e,n))?s:(typeof e.getAttribute!==i&&(s=e.getAttribute(n)),null==s?t:s):null!==r?o&&a&&"set"in o&&(s=o.set(e,r,n))!==t?s:(e.setAttribute(n,r+""),r):(b.removeAttr(e,n),t))},removeAttr:function(e,t){var n,r,i=0,o=t&&t.match(w);if(o&&1===e.nodeType)while(n=o[i++])r=b.propFix[n]||n,J.test(n)?!Q&&G.test(n)?e[b.camelCase("default-"+n)]=e[r]=!1:e[r]=!1:b.attr(e,n,""),e.removeAttribute(Q?n:r)},attrHooks:{type:{set:function(e,t){if(!b.support.radioValue&&"radio"===t&&b.nodeName(e,"input")){var n=e.value;return e.setAttribute("type",t),n&&(e.value=n),t}}}},propFix:{tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},prop:function(e,n,r){var i,o,a,s=e.nodeType;if(e&&3!==s&&8!==s&&2!==s)return a=1!==s||!b.isXMLDoc(e),a&&(n=b.propFix[n]||n,o=b.propHooks[n]),r!==t?o&&"set"in o&&(i=o.set(e,r,n))!==t?i:e[n]=r:o&&"get"in o&&null!==(i=o.get(e,n))?i:e[n]},propHooks:{tabIndex:{get:function(e){var n=e.getAttributeNode("tabindex");return n&&n.specified?parseInt(n.value,10):V.test(e.nodeName)||Y.test(e.nodeName)&&e.href?0:t}}}}),z={get:function(e,n){var r=b.prop(e,n),i="boolean"==typeof r&&e.getAttribute(n),o="boolean"==typeof r?K&&Q?null!=i:G.test(n)?e[b.camelCase("default-"+n)]:!!i:e.getAttributeNode(n);return o&&o.value!==!1?n.toLowerCase():t},set:function(e,t,n){return t===!1?b.removeAttr(e,n):K&&Q||!G.test(n)?e.setAttribute(!Q&&b.propFix[n]||n,n):e[b.camelCase("default-"+n)]=e[n]=!0,n}},K&&Q||(b.attrHooks.value={get:function(e,n){var r=e.getAttributeNode(n);return b.nodeName(e,"input")?e.defaultValue:r&&r.specified?r.value:t},set:function(e,n,r){return b.nodeName(e,"input")?(e.defaultValue=n,t):I&&I.set(e,n,r)}}),Q||(I=b.valHooks.button={get:function(e,n){var r=e.getAttributeNode(n);return r&&("id"===n||"name"===n||"coords"===n?""!==r.value:r.specified)?r.value:t},set:function(e,n,r){var i=e.getAttributeNode(r);return i||e.setAttributeNode(i=e.ownerDocument.createAttribute(r)),i.value=n+="","value"===r||n===e.getAttribute(r)?n:t}},b.attrHooks.contenteditable={get:I.get,set:function(e,t,n){I.set(e,""===t?!1:t,n)}},b.each(["width","height"],function(e,n){b.attrHooks[n]=b.extend(b.attrHooks[n],{set:function(e,r){return""===r?(e.setAttribute(n,"auto"),r):t}})})),b.support.hrefNormalized||(b.each(["href","src","width","height"],function(e,n){b.attrHooks[n]=b.extend(b.attrHooks[n],{get:function(e){var r=e.getAttribute(n,2);return null==r?t:r}})}),b.each(["href","src"],function(e,t){b.propHooks[t]={get:function(e){return e.getAttribute(t,4)}}})),b.support.style||(b.attrHooks.style={get:function(e){return e.style.cssText||t},set:function(e,t){return e.style.cssText=t+""}}),b.support.optSelected||(b.propHooks.selected=b.extend(b.propHooks.selected,{get:function(e){var t=e.parentNode;return t&&(t.selectedIndex,t.parentNode&&t.parentNode.selectedIndex),null}})),b.support.enctype||(b.propFix.enctype="encoding"),b.support.checkOn||b.each(["radio","checkbox"],function(){b.valHooks[this]={get:function(e){return null===e.getAttribute("value")?"on":e.value}}}),b.each(["radio","checkbox"],function(){b.valHooks[this]=b.extend(b.valHooks[this],{set:function(e,n){return b.isArray(n)?e.checked=b.inArray(b(e).val(),n)>=0:t}})});var Z=/^(?:input|select|textarea)$/i,et=/^key/,tt=/^(?:mouse|contextmenu)|click/,nt=/^(?:focusinfocus|focusoutblur)$/,rt=/^([^.]*)(?:\.(.+)|)$/;function it(){return!0}function ot(){return!1}b.event={global:{},add:function(e,n,r,o,a){var s,u,l,c,p,f,d,h,g,m,y,v=b._data(e);if(v){r.handler&&(c=r,r=c.handler,a=c.selector),r.guid||(r.guid=b.guid++),(u=v.events)||(u=v.events={}),(f=v.handle)||(f=v.handle=function(e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)},f.elem=e),n=(n||"").match(w)||[""],l=n.length;while(l--)s=rt.exec(n[l])||[],g=y=s[1],m=(s[2]||"").split(".").sort(),p=b.event.special[g]||{},g=(a?p.delegateType:p.bindType)||g,p=b.event.special[g]||{},d=b.extend({type:g,origType:y,data:o,handler:r,guid:r.guid,selector:a,needsContext:a&&b.expr.match.needsContext.test(a),namespace:m.join(".")},c),(h=u[g])||(h=u[g]=[],h.delegateCount=0,p.setup&&p.setup.call(e,o,m,f)!==!1||(e.addEventListener?e.addEventListener(g,f,!1):e.attachEvent&&e.attachEvent("on"+g,f))),p.add&&(p.add.call(e,d),d.handler.guid||(d.handler.guid=r.guid)),a?h.splice(h.delegateCount++,0,d):h.push(d),b.event.global[g]=!0;e=null}},remove:function(e,t,n,r,i){var o,a,s,u,l,c,p,f,d,h,g,m=b.hasData(e)&&b._data(e);if(m&&(c=m.events)){t=(t||"").match(w)||[""],l=t.length;while(l--)if(s=rt.exec(t[l])||[],d=g=s[1],h=(s[2]||"").split(".").sort(),d){p=b.event.special[d]||{},d=(r?p.delegateType:p.bindType)||d,f=c[d]||[],s=s[2]&&RegExp("(^|\\.)"+h.join("\\.(?:.*\\.|)")+"(\\.|$)"),u=o=f.length;while(o--)a=f[o],!i&&g!==a.origType||n&&n.guid!==a.guid||s&&!s.test(a.namespace)||r&&r!==a.selector&&("**"!==r||!a.selector)||(f.splice(o,1),a.selector&&f.delegateCount--,p.remove&&p.remove.call(e,a));u&&!f.length&&(p.teardown&&p.teardown.call(e,h,m.handle)!==!1||b.removeEvent(e,d,m.handle),delete c[d])}else for(d in c)b.event.remove(e,d+t[l],n,r,!0);b.isEmptyObject(c)&&(delete m.handle,b._removeData(e,"events"))}},trigger:function(n,r,i,a){var s,u,l,c,p,f,d,h=[i||o],g=y.call(n,"type")?n.type:n,m=y.call(n,"namespace")?n.namespace.split("."):[];if(l=f=i=i||o,3!==i.nodeType&&8!==i.nodeType&&!nt.test(g+b.event.triggered)&&(g.indexOf(".")>=0&&(m=g.split("."),g=m.shift(),m.sort()),u=0>g.indexOf(":")&&"on"+g,n=n[b.expando]?n:new b.Event(g,"object"==typeof n&&n),n.isTrigger=!0,n.namespace=m.join("."),n.namespace_re=n.namespace?RegExp("(^|\\.)"+m.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,n.result=t,n.target||(n.target=i),r=null==r?[n]:b.makeArray(r,[n]),p=b.event.special[g]||{},a||!p.trigger||p.trigger.apply(i,r)!==!1)){if(!a&&!p.noBubble&&!b.isWindow(i)){for(c=p.delegateType||g,nt.test(c+g)||(l=l.parentNode);l;l=l.parentNode)h.push(l),f=l;f===(i.ownerDocument||o)&&h.push(f.defaultView||f.parentWindow||e)}d=0;while((l=h[d++])&&!n.isPropagationStopped())n.type=d>1?c:p.bindType||g,s=(b._data(l,"events")||{})[n.type]&&b._data(l,"handle"),s&&s.apply(l,r),s=u&&l[u],s&&b.acceptData(l)&&s.apply&&s.apply(l,r)===!1&&n.preventDefault();if(n.type=g,!(a||n.isDefaultPrevented()||p._default&&p._default.apply(i.ownerDocument,r)!==!1||"click"===g&&b.nodeName(i,"a")||!b.acceptData(i)||!u||!i[g]||b.isWindow(i))){f=i[u],f&&(i[u]=null),b.event.triggered=g;try{i[g]()}catch(v){}b.event.triggered=t,f&&(i[u]=f)}return n.result}},dispatch:function(e){e=b.event.fix(e);var n,r,i,o,a,s=[],u=h.call(arguments),l=(b._data(this,"events")||{})[e.type]||[],c=b.event.special[e.type]||{};if(u[0]=e,e.delegateTarget=this,!c.preDispatch||c.preDispatch.call(this,e)!==!1){s=b.event.handlers.call(this,e,l),n=0;while((o=s[n++])&&!e.isPropagationStopped()){e.currentTarget=o.elem,a=0;while((i=o.handlers[a++])&&!e.isImmediatePropagationStopped())(!e.namespace_re||e.namespace_re.test(i.namespace))&&(e.handleObj=i,e.data=i.data,r=((b.event.special[i.origType]||{}).handle||i.handler).apply(o.elem,u),r!==t&&(e.result=r)===!1&&(e.preventDefault(),e.stopPropagation()))}return c.postDispatch&&c.postDispatch.call(this,e),e.result}},handlers:function(e,n){var r,i,o,a,s=[],u=n.delegateCount,l=e.target;if(u&&l.nodeType&&(!e.button||"click"!==e.type))for(;l!=this;l=l.parentNode||this)if(1===l.nodeType&&(l.disabled!==!0||"click"!==e.type)){for(o=[],a=0;u>a;a++)i=n[a],r=i.selector+" ",o[r]===t&&(o[r]=i.needsContext?b(r,this).index(l)>=0:b.find(r,this,null,[l]).length),o[r]&&o.push(i);o.length&&s.push({elem:l,handlers:o})}return n.length>u&&s.push({elem:this,handlers:n.slice(u)}),s},fix:function(e){if(e[b.expando])return e;var t,n,r,i=e.type,a=e,s=this.fixHooks[i];s||(this.fixHooks[i]=s=tt.test(i)?this.mouseHooks:et.test(i)?this.keyHooks:{}),r=s.props?this.props.concat(s.props):this.props,e=new b.Event(a),t=r.length;while(t--)n=r[t],e[n]=a[n];return e.target||(e.target=a.srcElement||o),3===e.target.nodeType&&(e.target=e.target.parentNode),e.metaKey=!!e.metaKey,s.filter?s.filter(e,a):e},props:"altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(e,t){return null==e.which&&(e.which=null!=t.charCode?t.charCode:t.keyCode),e}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(e,n){var r,i,a,s=n.button,u=n.fromElement;return null==e.pageX&&null!=n.clientX&&(i=e.target.ownerDocument||o,a=i.documentElement,r=i.body,e.pageX=n.clientX+(a&&a.scrollLeft||r&&r.scrollLeft||0)-(a&&a.clientLeft||r&&r.clientLeft||0),e.pageY=n.clientY+(a&&a.scrollTop||r&&r.scrollTop||0)-(a&&a.clientTop||r&&r.clientTop||0)),!e.relatedTarget&&u&&(e.relatedTarget=u===e.target?n.toElement:u),e.which||s===t||(e.which=1&s?1:2&s?3:4&s?2:0),e}},special:{load:{noBubble:!0},click:{trigger:function(){return b.nodeName(this,"input")&&"checkbox"===this.type&&this.click?(this.click(),!1):t}},focus:{trigger:function(){if(this!==o.activeElement&&this.focus)try{return this.focus(),!1}catch(e){}},delegateType:"focusin"},blur:{trigger:function(){return this===o.activeElement&&this.blur?(this.blur(),!1):t},delegateType:"focusout"},beforeunload:{postDispatch:function(e){e.result!==t&&(e.originalEvent.returnValue=e.result)}}},simulate:function(e,t,n,r){var i=b.extend(new b.Event,n,{type:e,isSimulated:!0,originalEvent:{}});r?b.event.trigger(i,null,t):b.event.dispatch.call(t,i),i.isDefaultPrevented()&&n.preventDefault()}},b.removeEvent=o.removeEventListener?function(e,t,n){e.removeEventListener&&e.removeEventListener(t,n,!1)}:function(e,t,n){var r="on"+t;e.detachEvent&&(typeof e[r]===i&&(e[r]=null),e.detachEvent(r,n))},b.Event=function(e,n){return this instanceof b.Event?(e&&e.type?(this.originalEvent=e,this.type=e.type,this.isDefaultPrevented=e.defaultPrevented||e.returnValue===!1||e.getPreventDefault&&e.getPreventDefault()?it:ot):this.type=e,n&&b.extend(this,n),this.timeStamp=e&&e.timeStamp||b.now(),this[b.expando]=!0,t):new b.Event(e,n)},b.Event.prototype={isDefaultPrevented:ot,isPropagationStopped:ot,isImmediatePropagationStopped:ot,preventDefault:function(){var e=this.originalEvent;this.isDefaultPrevented=it,e&&(e.preventDefault?e.preventDefault():e.returnValue=!1)},stopPropagation:function(){var e=this.originalEvent;this.isPropagationStopped=it,e&&(e.stopPropagation&&e.stopPropagation(),e.cancelBubble=!0)},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=it,this.stopPropagation()}},b.each({mouseenter:"mouseover",mouseleave:"mouseout"},function(e,t){b.event.special[e]={delegateType:t,bindType:t,handle:function(e){var n,r=this,i=e.relatedTarget,o=e.handleObj;
                return(!i||i!==r&&!b.contains(r,i))&&(e.type=o.origType,n=o.handler.apply(this,arguments),e.type=t),n}}}),b.support.submitBubbles||(b.event.special.submit={setup:function(){return b.nodeName(this,"form")?!1:(b.event.add(this,"click._submit keypress._submit",function(e){var n=e.target,r=b.nodeName(n,"input")||b.nodeName(n,"button")?n.form:t;r&&!b._data(r,"submitBubbles")&&(b.event.add(r,"submit._submit",function(e){e._submit_bubble=!0}),b._data(r,"submitBubbles",!0))}),t)},postDispatch:function(e){e._submit_bubble&&(delete e._submit_bubble,this.parentNode&&!e.isTrigger&&b.event.simulate("submit",this.parentNode,e,!0))},teardown:function(){return b.nodeName(this,"form")?!1:(b.event.remove(this,"._submit"),t)}}),b.support.changeBubbles||(b.event.special.change={setup:function(){return Z.test(this.nodeName)?(("checkbox"===this.type||"radio"===this.type)&&(b.event.add(this,"propertychange._change",function(e){"checked"===e.originalEvent.propertyName&&(this._just_changed=!0)}),b.event.add(this,"click._change",function(e){this._just_changed&&!e.isTrigger&&(this._just_changed=!1),b.event.simulate("change",this,e,!0)})),!1):(b.event.add(this,"beforeactivate._change",function(e){var t=e.target;Z.test(t.nodeName)&&!b._data(t,"changeBubbles")&&(b.event.add(t,"change._change",function(e){!this.parentNode||e.isSimulated||e.isTrigger||b.event.simulate("change",this.parentNode,e,!0)}),b._data(t,"changeBubbles",!0))}),t)},handle:function(e){var n=e.target;return this!==n||e.isSimulated||e.isTrigger||"radio"!==n.type&&"checkbox"!==n.type?e.handleObj.handler.apply(this,arguments):t},teardown:function(){return b.event.remove(this,"._change"),!Z.test(this.nodeName)}}),b.support.focusinBubbles||b.each({focus:"focusin",blur:"focusout"},function(e,t){var n=0,r=function(e){b.event.simulate(t,e.target,b.event.fix(e),!0)};b.event.special[t]={setup:function(){0===n++&&o.addEventListener(e,r,!0)},teardown:function(){0===--n&&o.removeEventListener(e,r,!0)}}}),b.fn.extend({on:function(e,n,r,i,o){var a,s;if("object"==typeof e){"string"!=typeof n&&(r=r||n,n=t);for(a in e)this.on(a,n,r,e[a],o);return this}if(null==r&&null==i?(i=n,r=n=t):null==i&&("string"==typeof n?(i=r,r=t):(i=r,r=n,n=t)),i===!1)i=ot;else if(!i)return this;return 1===o&&(s=i,i=function(e){return b().off(e),s.apply(this,arguments)},i.guid=s.guid||(s.guid=b.guid++)),this.each(function(){b.event.add(this,e,i,r,n)})},one:function(e,t,n,r){return this.on(e,t,n,r,1)},off:function(e,n,r){var i,o;if(e&&e.preventDefault&&e.handleObj)return i=e.handleObj,b(e.delegateTarget).off(i.namespace?i.origType+"."+i.namespace:i.origType,i.selector,i.handler),this;if("object"==typeof e){for(o in e)this.off(o,n,e[o]);return this}return(n===!1||"function"==typeof n)&&(r=n,n=t),r===!1&&(r=ot),this.each(function(){b.event.remove(this,e,r,n)})},bind:function(e,t,n){return this.on(e,null,t,n)},unbind:function(e,t){return this.off(e,null,t)},delegate:function(e,t,n,r){return this.on(t,e,n,r)},undelegate:function(e,t,n){return 1===arguments.length?this.off(e,"**"):this.off(t,e||"**",n)},trigger:function(e,t){return this.each(function(){b.event.trigger(e,t,this)})},triggerHandler:function(e,n){var r=this[0];return r?b.event.trigger(e,n,r,!0):t}}),function(e,t){var n,r,i,o,a,s,u,l,c,p,f,d,h,g,m,y,v,x="sizzle"+-new Date,w=e.document,T={},N=0,C=0,k=it(),E=it(),S=it(),A=typeof t,j=1<<31,D=[],L=D.pop,H=D.push,q=D.slice,M=D.indexOf||function(e){var t=0,n=this.length;for(;n>t;t++)if(this[t]===e)return t;return-1},_="[\\x20\\t\\r\\n\\f]",F="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",O=F.replace("w","w#"),B="([*^$|!~]?=)",P="\\["+_+"*("+F+")"+_+"*(?:"+B+_+"*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|("+O+")|)|)"+_+"*\\]",R=":("+F+")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|"+P.replace(3,8)+")*)|.*)\\)|)",W=RegExp("^"+_+"+|((?:^|[^\\\\])(?:\\\\.)*)"+_+"+$","g"),$=RegExp("^"+_+"*,"+_+"*"),I=RegExp("^"+_+"*([\\x20\\t\\r\\n\\f>+~])"+_+"*"),z=RegExp(R),X=RegExp("^"+O+"$"),U={ID:RegExp("^#("+F+")"),CLASS:RegExp("^\\.("+F+")"),NAME:RegExp("^\\[name=['\"]?("+F+")['\"]?\\]"),TAG:RegExp("^("+F.replace("w","w*")+")"),ATTR:RegExp("^"+P),PSEUDO:RegExp("^"+R),CHILD:RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+_+"*(even|odd|(([+-]|)(\\d*)n|)"+_+"*(?:([+-]|)"+_+"*(\\d+)|))"+_+"*\\)|)","i"),needsContext:RegExp("^"+_+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+_+"*((?:-\\d)?\\d*)"+_+"*\\)|)(?=[^-]|$)","i")},V=/[\x20\t\r\n\f]*[+~]/,Y=/^[^{]+\{\s*\[native code/,J=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,G=/^(?:input|select|textarea|button)$/i,Q=/^h\d$/i,K=/'|\\/g,Z=/\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,et=/\\([\da-fA-F]{1,6}[\x20\t\r\n\f]?|.)/g,tt=function(e,t){var n="0x"+t-65536;return n!==n?t:0>n?String.fromCharCode(n+65536):String.fromCharCode(55296|n>>10,56320|1023&n)};try{q.call(w.documentElement.childNodes,0)[0].nodeType}catch(nt){q=function(e){var t,n=[];while(t=this[e++])n.push(t);return n}}function rt(e){return Y.test(e+"")}function it(){var e,t=[];return e=function(n,r){return t.push(n+=" ")>i.cacheLength&&delete e[t.shift()],e[n]=r}}function ot(e){return e[x]=!0,e}function at(e){var t=p.createElement("div");try{return e(t)}catch(n){return!1}finally{t=null}}function st(e,t,n,r){var i,o,a,s,u,l,f,g,m,v;if((t?t.ownerDocument||t:w)!==p&&c(t),t=t||p,n=n||[],!e||"string"!=typeof e)return n;if(1!==(s=t.nodeType)&&9!==s)return[];if(!d&&!r){if(i=J.exec(e))if(a=i[1]){if(9===s){if(o=t.getElementById(a),!o||!o.parentNode)return n;if(o.id===a)return n.push(o),n}else if(t.ownerDocument&&(o=t.ownerDocument.getElementById(a))&&y(t,o)&&o.id===a)return n.push(o),n}else{if(i[2])return H.apply(n,q.call(t.getElementsByTagName(e),0)),n;if((a=i[3])&&T.getByClassName&&t.getElementsByClassName)return H.apply(n,q.call(t.getElementsByClassName(a),0)),n}if(T.qsa&&!h.test(e)){if(f=!0,g=x,m=t,v=9===s&&e,1===s&&"object"!==t.nodeName.toLowerCase()){l=ft(e),(f=t.getAttribute("id"))?g=f.replace(K,"\\$&"):t.setAttribute("id",g),g="[id='"+g+"'] ",u=l.length;while(u--)l[u]=g+dt(l[u]);m=V.test(e)&&t.parentNode||t,v=l.join(",")}if(v)try{return H.apply(n,q.call(m.querySelectorAll(v),0)),n}catch(b){}finally{f||t.removeAttribute("id")}}}return wt(e.replace(W,"$1"),t,n,r)}a=st.isXML=function(e){var t=e&&(e.ownerDocument||e).documentElement;return t?"HTML"!==t.nodeName:!1},c=st.setDocument=function(e){var n=e?e.ownerDocument||e:w;return n!==p&&9===n.nodeType&&n.documentElement?(p=n,f=n.documentElement,d=a(n),T.tagNameNoComments=at(function(e){return e.appendChild(n.createComment("")),!e.getElementsByTagName("*").length}),T.attributes=at(function(e){e.innerHTML="<select></select>";var t=typeof e.lastChild.getAttribute("multiple");return"boolean"!==t&&"string"!==t}),T.getByClassName=at(function(e){return e.innerHTML="<div class='hidden e'></div><div class='hidden'></div>",e.getElementsByClassName&&e.getElementsByClassName("e").length?(e.lastChild.className="e",2===e.getElementsByClassName("e").length):!1}),T.getByName=at(function(e){e.id=x+0,e.innerHTML="<a name='"+x+"'></a><div name='"+x+"'></div>",f.insertBefore(e,f.firstChild);var t=n.getElementsByName&&n.getElementsByName(x).length===2+n.getElementsByName(x+0).length;return T.getIdNotName=!n.getElementById(x),f.removeChild(e),t}),i.attrHandle=at(function(e){return e.innerHTML="<a href='#'></a>",e.firstChild&&typeof e.firstChild.getAttribute!==A&&"#"===e.firstChild.getAttribute("href")})?{}:{href:function(e){return e.getAttribute("href",2)},type:function(e){return e.getAttribute("type")}},T.getIdNotName?(i.find.ID=function(e,t){if(typeof t.getElementById!==A&&!d){var n=t.getElementById(e);return n&&n.parentNode?[n]:[]}},i.filter.ID=function(e){var t=e.replace(et,tt);return function(e){return e.getAttribute("id")===t}}):(i.find.ID=function(e,n){if(typeof n.getElementById!==A&&!d){var r=n.getElementById(e);return r?r.id===e||typeof r.getAttributeNode!==A&&r.getAttributeNode("id").value===e?[r]:t:[]}},i.filter.ID=function(e){var t=e.replace(et,tt);return function(e){var n=typeof e.getAttributeNode!==A&&e.getAttributeNode("id");return n&&n.value===t}}),i.find.TAG=T.tagNameNoComments?function(e,n){return typeof n.getElementsByTagName!==A?n.getElementsByTagName(e):t}:function(e,t){var n,r=[],i=0,o=t.getElementsByTagName(e);if("*"===e){while(n=o[i++])1===n.nodeType&&r.push(n);return r}return o},i.find.NAME=T.getByName&&function(e,n){return typeof n.getElementsByName!==A?n.getElementsByName(name):t},i.find.CLASS=T.getByClassName&&function(e,n){return typeof n.getElementsByClassName===A||d?t:n.getElementsByClassName(e)},g=[],h=[":focus"],(T.qsa=rt(n.querySelectorAll))&&(at(function(e){e.innerHTML="<select><option selected=''></option></select>",e.querySelectorAll("[selected]").length||h.push("\\["+_+"*(?:checked|disabled|ismap|multiple|readonly|selected|value)"),e.querySelectorAll(":checked").length||h.push(":checked")}),at(function(e){e.innerHTML="<input type='hidden' i=''/>",e.querySelectorAll("[i^='']").length&&h.push("[*^$]="+_+"*(?:\"\"|'')"),e.querySelectorAll(":enabled").length||h.push(":enabled",":disabled"),e.querySelectorAll("*,:x"),h.push(",.*:")})),(T.matchesSelector=rt(m=f.matchesSelector||f.mozMatchesSelector||f.webkitMatchesSelector||f.oMatchesSelector||f.msMatchesSelector))&&at(function(e){T.disconnectedMatch=m.call(e,"div"),m.call(e,"[s!='']:x"),g.push("!=",R)}),h=RegExp(h.join("|")),g=RegExp(g.join("|")),y=rt(f.contains)||f.compareDocumentPosition?function(e,t){var n=9===e.nodeType?e.documentElement:e,r=t&&t.parentNode;return e===r||!(!r||1!==r.nodeType||!(n.contains?n.contains(r):e.compareDocumentPosition&&16&e.compareDocumentPosition(r)))}:function(e,t){if(t)while(t=t.parentNode)if(t===e)return!0;return!1},v=f.compareDocumentPosition?function(e,t){var r;return e===t?(u=!0,0):(r=t.compareDocumentPosition&&e.compareDocumentPosition&&e.compareDocumentPosition(t))?1&r||e.parentNode&&11===e.parentNode.nodeType?e===n||y(w,e)?-1:t===n||y(w,t)?1:0:4&r?-1:1:e.compareDocumentPosition?-1:1}:function(e,t){var r,i=0,o=e.parentNode,a=t.parentNode,s=[e],l=[t];if(e===t)return u=!0,0;if(!o||!a)return e===n?-1:t===n?1:o?-1:a?1:0;if(o===a)return ut(e,t);r=e;while(r=r.parentNode)s.unshift(r);r=t;while(r=r.parentNode)l.unshift(r);while(s[i]===l[i])i++;return i?ut(s[i],l[i]):s[i]===w?-1:l[i]===w?1:0},u=!1,[0,0].sort(v),T.detectDuplicates=u,p):p},st.matches=function(e,t){return st(e,null,null,t)},st.matchesSelector=function(e,t){if((e.ownerDocument||e)!==p&&c(e),t=t.replace(Z,"='$1']"),!(!T.matchesSelector||d||g&&g.test(t)||h.test(t)))try{var n=m.call(e,t);if(n||T.disconnectedMatch||e.document&&11!==e.document.nodeType)return n}catch(r){}return st(t,p,null,[e]).length>0},st.contains=function(e,t){return(e.ownerDocument||e)!==p&&c(e),y(e,t)},st.attr=function(e,t){var n;return(e.ownerDocument||e)!==p&&c(e),d||(t=t.toLowerCase()),(n=i.attrHandle[t])?n(e):d||T.attributes?e.getAttribute(t):((n=e.getAttributeNode(t))||e.getAttribute(t))&&e[t]===!0?t:n&&n.specified?n.value:null},st.error=function(e){throw Error("Syntax error, unrecognized expression: "+e)},st.uniqueSort=function(e){var t,n=[],r=1,i=0;if(u=!T.detectDuplicates,e.sort(v),u){for(;t=e[r];r++)t===e[r-1]&&(i=n.push(r));while(i--)e.splice(n[i],1)}return e};function ut(e,t){var n=t&&e,r=n&&(~t.sourceIndex||j)-(~e.sourceIndex||j);if(r)return r;if(n)while(n=n.nextSibling)if(n===t)return-1;return e?1:-1}function lt(e){return function(t){var n=t.nodeName.toLowerCase();return"input"===n&&t.type===e}}function ct(e){return function(t){var n=t.nodeName.toLowerCase();return("input"===n||"button"===n)&&t.type===e}}function pt(e){return ot(function(t){return t=+t,ot(function(n,r){var i,o=e([],n.length,t),a=o.length;while(a--)n[i=o[a]]&&(n[i]=!(r[i]=n[i]))})})}o=st.getText=function(e){var t,n="",r=0,i=e.nodeType;if(i){if(1===i||9===i||11===i){if("string"==typeof e.textContent)return e.textContent;for(e=e.firstChild;e;e=e.nextSibling)n+=o(e)}else if(3===i||4===i)return e.nodeValue}else for(;t=e[r];r++)n+=o(t);return n},i=st.selectors={cacheLength:50,createPseudo:ot,match:U,find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(e){return e[1]=e[1].replace(et,tt),e[3]=(e[4]||e[5]||"").replace(et,tt),"~="===e[2]&&(e[3]=" "+e[3]+" "),e.slice(0,4)},CHILD:function(e){return e[1]=e[1].toLowerCase(),"nth"===e[1].slice(0,3)?(e[3]||st.error(e[0]),e[4]=+(e[4]?e[5]+(e[6]||1):2*("even"===e[3]||"odd"===e[3])),e[5]=+(e[7]+e[8]||"odd"===e[3])):e[3]&&st.error(e[0]),e},PSEUDO:function(e){var t,n=!e[5]&&e[2];return U.CHILD.test(e[0])?null:(e[4]?e[2]=e[4]:n&&z.test(n)&&(t=ft(n,!0))&&(t=n.indexOf(")",n.length-t)-n.length)&&(e[0]=e[0].slice(0,t),e[2]=n.slice(0,t)),e.slice(0,3))}},filter:{TAG:function(e){return"*"===e?function(){return!0}:(e=e.replace(et,tt).toLowerCase(),function(t){return t.nodeName&&t.nodeName.toLowerCase()===e})},CLASS:function(e){var t=k[e+" "];return t||(t=RegExp("(^|"+_+")"+e+"("+_+"|$)"))&&k(e,function(e){return t.test(e.className||typeof e.getAttribute!==A&&e.getAttribute("class")||"")})},ATTR:function(e,t,n){return function(r){var i=st.attr(r,e);return null==i?"!="===t:t?(i+="","="===t?i===n:"!="===t?i!==n:"^="===t?n&&0===i.indexOf(n):"*="===t?n&&i.indexOf(n)>-1:"$="===t?n&&i.slice(-n.length)===n:"~="===t?(" "+i+" ").indexOf(n)>-1:"|="===t?i===n||i.slice(0,n.length+1)===n+"-":!1):!0}},CHILD:function(e,t,n,r,i){var o="nth"!==e.slice(0,3),a="last"!==e.slice(-4),s="of-type"===t;return 1===r&&0===i?function(e){return!!e.parentNode}:function(t,n,u){var l,c,p,f,d,h,g=o!==a?"nextSibling":"previousSibling",m=t.parentNode,y=s&&t.nodeName.toLowerCase(),v=!u&&!s;if(m){if(o){while(g){p=t;while(p=p[g])if(s?p.nodeName.toLowerCase()===y:1===p.nodeType)return!1;h=g="only"===e&&!h&&"nextSibling"}return!0}if(h=[a?m.firstChild:m.lastChild],a&&v){c=m[x]||(m[x]={}),l=c[e]||[],d=l[0]===N&&l[1],f=l[0]===N&&l[2],p=d&&m.childNodes[d];while(p=++d&&p&&p[g]||(f=d=0)||h.pop())if(1===p.nodeType&&++f&&p===t){c[e]=[N,d,f];break}}else if(v&&(l=(t[x]||(t[x]={}))[e])&&l[0]===N)f=l[1];else while(p=++d&&p&&p[g]||(f=d=0)||h.pop())if((s?p.nodeName.toLowerCase()===y:1===p.nodeType)&&++f&&(v&&((p[x]||(p[x]={}))[e]=[N,f]),p===t))break;return f-=i,f===r||0===f%r&&f/r>=0}}},PSEUDO:function(e,t){var n,r=i.pseudos[e]||i.setFilters[e.toLowerCase()]||st.error("unsupported pseudo: "+e);return r[x]?r(t):r.length>1?(n=[e,e,"",t],i.setFilters.hasOwnProperty(e.toLowerCase())?ot(function(e,n){var i,o=r(e,t),a=o.length;while(a--)i=M.call(e,o[a]),e[i]=!(n[i]=o[a])}):function(e){return r(e,0,n)}):r}},pseudos:{not:ot(function(e){var t=[],n=[],r=s(e.replace(W,"$1"));return r[x]?ot(function(e,t,n,i){var o,a=r(e,null,i,[]),s=e.length;while(s--)(o=a[s])&&(e[s]=!(t[s]=o))}):function(e,i,o){return t[0]=e,r(t,null,o,n),!n.pop()}}),has:ot(function(e){return function(t){return st(e,t).length>0}}),contains:ot(function(e){return function(t){return(t.textContent||t.innerText||o(t)).indexOf(e)>-1}}),lang:ot(function(e){return X.test(e||"")||st.error("unsupported lang: "+e),e=e.replace(et,tt).toLowerCase(),function(t){var n;do if(n=d?t.getAttribute("xml:lang")||t.getAttribute("lang"):t.lang)return n=n.toLowerCase(),n===e||0===n.indexOf(e+"-");while((t=t.parentNode)&&1===t.nodeType);return!1}}),target:function(t){var n=e.location&&e.location.hash;return n&&n.slice(1)===t.id},root:function(e){return e===f},focus:function(e){return e===p.activeElement&&(!p.hasFocus||p.hasFocus())&&!!(e.type||e.href||~e.tabIndex)},enabled:function(e){return e.disabled===!1},disabled:function(e){return e.disabled===!0},checked:function(e){var t=e.nodeName.toLowerCase();return"input"===t&&!!e.checked||"option"===t&&!!e.selected},selected:function(e){return e.parentNode&&e.parentNode.selectedIndex,e.selected===!0},empty:function(e){for(e=e.firstChild;e;e=e.nextSibling)if(e.nodeName>"@"||3===e.nodeType||4===e.nodeType)return!1;return!0},parent:function(e){return!i.pseudos.empty(e)},header:function(e){return Q.test(e.nodeName)},input:function(e){return G.test(e.nodeName)},button:function(e){var t=e.nodeName.toLowerCase();return"input"===t&&"button"===e.type||"button"===t},text:function(e){var t;return"input"===e.nodeName.toLowerCase()&&"text"===e.type&&(null==(t=e.getAttribute("type"))||t.toLowerCase()===e.type)},first:pt(function(){return[0]}),last:pt(function(e,t){return[t-1]}),eq:pt(function(e,t,n){return[0>n?n+t:n]}),even:pt(function(e,t){var n=0;for(;t>n;n+=2)e.push(n);return e}),odd:pt(function(e,t){var n=1;for(;t>n;n+=2)e.push(n);return e}),lt:pt(function(e,t,n){var r=0>n?n+t:n;for(;--r>=0;)e.push(r);return e}),gt:pt(function(e,t,n){var r=0>n?n+t:n;for(;t>++r;)e.push(r);return e})}};for(n in{radio:!0,checkbox:!0,file:!0,password:!0,image:!0})i.pseudos[n]=lt(n);for(n in{submit:!0,reset:!0})i.pseudos[n]=ct(n);function ft(e,t){var n,r,o,a,s,u,l,c=E[e+" "];if(c)return t?0:c.slice(0);s=e,u=[],l=i.preFilter;while(s){(!n||(r=$.exec(s)))&&(r&&(s=s.slice(r[0].length)||s),u.push(o=[])),n=!1,(r=I.exec(s))&&(n=r.shift(),o.push({value:n,type:r[0].replace(W," ")}),s=s.slice(n.length));for(a in i.filter)!(r=U[a].exec(s))||l[a]&&!(r=l[a](r))||(n=r.shift(),o.push({value:n,type:a,matches:r}),s=s.slice(n.length));if(!n)break}return t?s.length:s?st.error(e):E(e,u).slice(0)}function dt(e){var t=0,n=e.length,r="";for(;n>t;t++)r+=e[t].value;return r}function ht(e,t,n){var i=t.dir,o=n&&"parentNode"===i,a=C++;return t.first?function(t,n,r){while(t=t[i])if(1===t.nodeType||o)return e(t,n,r)}:function(t,n,s){var u,l,c,p=N+" "+a;if(s){while(t=t[i])if((1===t.nodeType||o)&&e(t,n,s))return!0}else while(t=t[i])if(1===t.nodeType||o)if(c=t[x]||(t[x]={}),(l=c[i])&&l[0]===p){if((u=l[1])===!0||u===r)return u===!0}else if(l=c[i]=[p],l[1]=e(t,n,s)||r,l[1]===!0)return!0}}function gt(e){return e.length>1?function(t,n,r){var i=e.length;while(i--)if(!e[i](t,n,r))return!1;return!0}:e[0]}function mt(e,t,n,r,i){var o,a=[],s=0,u=e.length,l=null!=t;for(;u>s;s++)(o=e[s])&&(!n||n(o,r,i))&&(a.push(o),l&&t.push(s));return a}function yt(e,t,n,r,i,o){return r&&!r[x]&&(r=yt(r)),i&&!i[x]&&(i=yt(i,o)),ot(function(o,a,s,u){var l,c,p,f=[],d=[],h=a.length,g=o||xt(t||"*",s.nodeType?[s]:s,[]),m=!e||!o&&t?g:mt(g,f,e,s,u),y=n?i||(o?e:h||r)?[]:a:m;if(n&&n(m,y,s,u),r){l=mt(y,d),r(l,[],s,u),c=l.length;while(c--)(p=l[c])&&(y[d[c]]=!(m[d[c]]=p))}if(o){if(i||e){if(i){l=[],c=y.length;while(c--)(p=y[c])&&l.push(m[c]=p);i(null,y=[],l,u)}c=y.length;while(c--)(p=y[c])&&(l=i?M.call(o,p):f[c])>-1&&(o[l]=!(a[l]=p))}}else y=mt(y===a?y.splice(h,y.length):y),i?i(null,a,y,u):H.apply(a,y)})}function vt(e){var t,n,r,o=e.length,a=i.relative[e[0].type],s=a||i.relative[" "],u=a?1:0,c=ht(function(e){return e===t},s,!0),p=ht(function(e){return M.call(t,e)>-1},s,!0),f=[function(e,n,r){return!a&&(r||n!==l)||((t=n).nodeType?c(e,n,r):p(e,n,r))}];for(;o>u;u++)if(n=i.relative[e[u].type])f=[ht(gt(f),n)];else{if(n=i.filter[e[u].type].apply(null,e[u].matches),n[x]){for(r=++u;o>r;r++)if(i.relative[e[r].type])break;return yt(u>1&&gt(f),u>1&&dt(e.slice(0,u-1)).replace(W,"$1"),n,r>u&&vt(e.slice(u,r)),o>r&&vt(e=e.slice(r)),o>r&&dt(e))}f.push(n)}return gt(f)}function bt(e,t){var n=0,o=t.length>0,a=e.length>0,s=function(s,u,c,f,d){var h,g,m,y=[],v=0,b="0",x=s&&[],w=null!=d,T=l,C=s||a&&i.find.TAG("*",d&&u.parentNode||u),k=N+=null==T?1:Math.random()||.1;for(w&&(l=u!==p&&u,r=n);null!=(h=C[b]);b++){if(a&&h){g=0;while(m=e[g++])if(m(h,u,c)){f.push(h);break}w&&(N=k,r=++n)}o&&((h=!m&&h)&&v--,s&&x.push(h))}if(v+=b,o&&b!==v){g=0;while(m=t[g++])m(x,y,u,c);if(s){if(v>0)while(b--)x[b]||y[b]||(y[b]=L.call(f));y=mt(y)}H.apply(f,y),w&&!s&&y.length>0&&v+t.length>1&&st.uniqueSort(f)}return w&&(N=k,l=T),x};return o?ot(s):s}s=st.compile=function(e,t){var n,r=[],i=[],o=S[e+" "];if(!o){t||(t=ft(e)),n=t.length;while(n--)o=vt(t[n]),o[x]?r.push(o):i.push(o);o=S(e,bt(i,r))}return o};function xt(e,t,n){var r=0,i=t.length;for(;i>r;r++)st(e,t[r],n);return n}function wt(e,t,n,r){var o,a,u,l,c,p=ft(e);if(!r&&1===p.length){if(a=p[0]=p[0].slice(0),a.length>2&&"ID"===(u=a[0]).type&&9===t.nodeType&&!d&&i.relative[a[1].type]){if(t=i.find.ID(u.matches[0].replace(et,tt),t)[0],!t)return n;e=e.slice(a.shift().value.length)}o=U.needsContext.test(e)?0:a.length;while(o--){if(u=a[o],i.relative[l=u.type])break;if((c=i.find[l])&&(r=c(u.matches[0].replace(et,tt),V.test(a[0].type)&&t.parentNode||t))){if(a.splice(o,1),e=r.length&&dt(a),!e)return H.apply(n,q.call(r,0)),n;break}}}return s(e,p)(r,t,d,n,V.test(e)),n}i.pseudos.nth=i.pseudos.eq;function Tt(){}i.filters=Tt.prototype=i.pseudos,i.setFilters=new Tt,c(),st.attr=b.attr,b.find=st,b.expr=st.selectors,b.expr[":"]=b.expr.pseudos,b.unique=st.uniqueSort,b.text=st.getText,b.isXMLDoc=st.isXML,b.contains=st.contains}(e);var at=/Until$/,st=/^(?:parents|prev(?:Until|All))/,ut=/^.[^:#\[\.,]*$/,lt=b.expr.match.needsContext,ct={children:!0,contents:!0,next:!0,prev:!0};b.fn.extend({find:function(e){var t,n,r,i=this.length;if("string"!=typeof e)return r=this,this.pushStack(b(e).filter(function(){for(t=0;i>t;t++)if(b.contains(r[t],this))return!0}));for(n=[],t=0;i>t;t++)b.find(e,this[t],n);return n=this.pushStack(i>1?b.unique(n):n),n.selector=(this.selector?this.selector+" ":"")+e,n},has:function(e){var t,n=b(e,this),r=n.length;return this.filter(function(){for(t=0;r>t;t++)if(b.contains(this,n[t]))return!0})},not:function(e){return this.pushStack(ft(this,e,!1))},filter:function(e){return this.pushStack(ft(this,e,!0))},is:function(e){return!!e&&("string"==typeof e?lt.test(e)?b(e,this.context).index(this[0])>=0:b.filter(e,this).length>0:this.filter(e).length>0)},closest:function(e,t){var n,r=0,i=this.length,o=[],a=lt.test(e)||"string"!=typeof e?b(e,t||this.context):0;for(;i>r;r++){n=this[r];while(n&&n.ownerDocument&&n!==t&&11!==n.nodeType){if(a?a.index(n)>-1:b.find.matchesSelector(n,e)){o.push(n);break}n=n.parentNode}}return this.pushStack(o.length>1?b.unique(o):o)},index:function(e){return e?"string"==typeof e?b.inArray(this[0],b(e)):b.inArray(e.jquery?e[0]:e,this):this[0]&&this[0].parentNode?this.first().prevAll().length:-1},add:function(e,t){var n="string"==typeof e?b(e,t):b.makeArray(e&&e.nodeType?[e]:e),r=b.merge(this.get(),n);return this.pushStack(b.unique(r))},addBack:function(e){return this.add(null==e?this.prevObject:this.prevObject.filter(e))}}),b.fn.andSelf=b.fn.addBack;function pt(e,t){do e=e[t];while(e&&1!==e.nodeType);return e}b.each({parent:function(e){var t=e.parentNode;return t&&11!==t.nodeType?t:null},parents:function(e){return b.dir(e,"parentNode")},parentsUntil:function(e,t,n){return b.dir(e,"parentNode",n)},next:function(e){return pt(e,"nextSibling")},prev:function(e){return pt(e,"previousSibling")},nextAll:function(e){return b.dir(e,"nextSibling")},prevAll:function(e){return b.dir(e,"previousSibling")},nextUntil:function(e,t,n){return b.dir(e,"nextSibling",n)},prevUntil:function(e,t,n){return b.dir(e,"previousSibling",n)},siblings:function(e){return b.sibling((e.parentNode||{}).firstChild,e)},children:function(e){return b.sibling(e.firstChild)},contents:function(e){return b.nodeName(e,"iframe")?e.contentDocument||e.contentWindow.document:b.merge([],e.childNodes)}},function(e,t){b.fn[e]=function(n,r){var i=b.map(this,t,n);return at.test(e)||(r=n),r&&"string"==typeof r&&(i=b.filter(r,i)),i=this.length>1&&!ct[e]?b.unique(i):i,this.length>1&&st.test(e)&&(i=i.reverse()),this.pushStack(i)}}),b.extend({filter:function(e,t,n){return n&&(e=":not("+e+")"),1===t.length?b.find.matchesSelector(t[0],e)?[t[0]]:[]:b.find.matches(e,t)},dir:function(e,n,r){var i=[],o=e[n];while(o&&9!==o.nodeType&&(r===t||1!==o.nodeType||!b(o).is(r)))1===o.nodeType&&i.push(o),o=o[n];return i},sibling:function(e,t){var n=[];for(;e;e=e.nextSibling)1===e.nodeType&&e!==t&&n.push(e);return n}});function ft(e,t,n){if(t=t||0,b.isFunction(t))return b.grep(e,function(e,r){var i=!!t.call(e,r,e);return i===n});if(t.nodeType)return b.grep(e,function(e){return e===t===n});if("string"==typeof t){var r=b.grep(e,function(e){return 1===e.nodeType});if(ut.test(t))return b.filter(t,r,!n);t=b.filter(t,r)}return b.grep(e,function(e){return b.inArray(e,t)>=0===n})}function dt(e){var t=ht.split("|"),n=e.createDocumentFragment();if(n.createElement)while(t.length)n.createElement(t.pop());return n}var ht="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",gt=/ jQuery\d+="(?:null|\d+)"/g,mt=RegExp("<(?:"+ht+")[\\s/>]","i"),yt=/^\s+/,vt=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,bt=/<([\w:]+)/,xt=/<tbody/i,wt=/<|&#?\w+;/,Tt=/<(?:script|style|link)/i,Nt=/^(?:checkbox|radio)$/i,Ct=/checked\s*(?:[^=]|=\s*.checked.)/i,kt=/^$|\/(?:java|ecma)script/i,Et=/^true\/(.*)/,St=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,At={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],area:[1,"<map>","</map>"],param:[1,"<object>","</object>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:b.support.htmlSerialize?[0,"",""]:[1,"X<div>","</div>"]},jt=dt(o),Dt=jt.appendChild(o.createElement("div"));At.optgroup=At.option,At.tbody=At.tfoot=At.colgroup=At.caption=At.thead,At.th=At.td,b.fn.extend({text:function(e){return b.access(this,function(e){return e===t?b.text(this):this.empty().append((this[0]&&this[0].ownerDocument||o).createTextNode(e))},null,e,arguments.length)},wrapAll:function(e){if(b.isFunction(e))return this.each(function(t){b(this).wrapAll(e.call(this,t))});if(this[0]){var t=b(e,this[0].ownerDocument).eq(0).clone(!0);this[0].parentNode&&t.insertBefore(this[0]),t.map(function(){var e=this;while(e.firstChild&&1===e.firstChild.nodeType)e=e.firstChild;return e}).append(this)}return this},wrapInner:function(e){return b.isFunction(e)?this.each(function(t){b(this).wrapInner(e.call(this,t))}):this.each(function(){var t=b(this),n=t.contents();n.length?n.wrapAll(e):t.append(e)})},wrap:function(e){var t=b.isFunction(e);return this.each(function(n){b(this).wrapAll(t?e.call(this,n):e)})},unwrap:function(){return this.parent().each(function(){b.nodeName(this,"body")||b(this).replaceWith(this.childNodes)}).end()},append:function(){return this.domManip(arguments,!0,function(e){(1===this.nodeType||11===this.nodeType||9===this.nodeType)&&this.appendChild(e)})},prepend:function(){return this.domManip(arguments,!0,function(e){(1===this.nodeType||11===this.nodeType||9===this.nodeType)&&this.insertBefore(e,this.firstChild)})},before:function(){return this.domManip(arguments,!1,function(e){this.parentNode&&this.parentNode.insertBefore(e,this)})},after:function(){return this.domManip(arguments,!1,function(e){this.parentNode&&this.parentNode.insertBefore(e,this.nextSibling)})},remove:function(e,t){var n,r=0;for(;null!=(n=this[r]);r++)(!e||b.filter(e,[n]).length>0)&&(t||1!==n.nodeType||b.cleanData(Ot(n)),n.parentNode&&(t&&b.contains(n.ownerDocument,n)&&Mt(Ot(n,"script")),n.parentNode.removeChild(n)));return this},empty:function(){var e,t=0;for(;null!=(e=this[t]);t++){1===e.nodeType&&b.cleanData(Ot(e,!1));while(e.firstChild)e.removeChild(e.firstChild);e.options&&b.nodeName(e,"select")&&(e.options.length=0)}return this},clone:function(e,t){return e=null==e?!1:e,t=null==t?e:t,this.map(function(){return b.clone(this,e,t)})},html:function(e){return b.access(this,function(e){var n=this[0]||{},r=0,i=this.length;if(e===t)return 1===n.nodeType?n.innerHTML.replace(gt,""):t;if(!("string"!=typeof e||Tt.test(e)||!b.support.htmlSerialize&&mt.test(e)||!b.support.leadingWhitespace&&yt.test(e)||At[(bt.exec(e)||["",""])[1].toLowerCase()])){e=e.replace(vt,"<$1></$2>");try{for(;i>r;r++)n=this[r]||{},1===n.nodeType&&(b.cleanData(Ot(n,!1)),n.innerHTML=e);n=0}catch(o){}}n&&this.empty().append(e)},null,e,arguments.length)},replaceWith:function(e){var t=b.isFunction(e);return t||"string"==typeof e||(e=b(e).not(this).detach()),this.domManip([e],!0,function(e){var t=this.nextSibling,n=this.parentNode;n&&(b(this).remove(),n.insertBefore(e,t))})},detach:function(e){return this.remove(e,!0)},domManip:function(e,n,r){e=f.apply([],e);var i,o,a,s,u,l,c=0,p=this.length,d=this,h=p-1,g=e[0],m=b.isFunction(g);if(m||!(1>=p||"string"!=typeof g||b.support.checkClone)&&Ct.test(g))return this.each(function(i){var o=d.eq(i);m&&(e[0]=g.call(this,i,n?o.html():t)),o.domManip(e,n,r)});if(p&&(l=b.buildFragment(e,this[0].ownerDocument,!1,this),i=l.firstChild,1===l.childNodes.length&&(l=i),i)){for(n=n&&b.nodeName(i,"tr"),s=b.map(Ot(l,"script"),Ht),a=s.length;p>c;c++)o=l,c!==h&&(o=b.clone(o,!0,!0),a&&b.merge(s,Ot(o,"script"))),r.call(n&&b.nodeName(this[c],"table")?Lt(this[c],"tbody"):this[c],o,c);if(a)for(u=s[s.length-1].ownerDocument,b.map(s,qt),c=0;a>c;c++)o=s[c],kt.test(o.type||"")&&!b._data(o,"globalEval")&&b.contains(u,o)&&(o.src?b.ajax({url:o.src,type:"GET",dataType:"script",async:!1,global:!1,"throws":!0}):b.globalEval((o.text||o.textContent||o.innerHTML||"").replace(St,"")));l=i=null}return this}});function Lt(e,t){return e.getElementsByTagName(t)[0]||e.appendChild(e.ownerDocument.createElement(t))}function Ht(e){var t=e.getAttributeNode("type");return e.type=(t&&t.specified)+"/"+e.type,e}function qt(e){var t=Et.exec(e.type);return t?e.type=t[1]:e.removeAttribute("type"),e}function Mt(e,t){var n,r=0;for(;null!=(n=e[r]);r++)b._data(n,"globalEval",!t||b._data(t[r],"globalEval"))}function _t(e,t){if(1===t.nodeType&&b.hasData(e)){var n,r,i,o=b._data(e),a=b._data(t,o),s=o.events;if(s){delete a.handle,a.events={};for(n in s)for(r=0,i=s[n].length;i>r;r++)b.event.add(t,n,s[n][r])}a.data&&(a.data=b.extend({},a.data))}}function Ft(e,t){var n,r,i;if(1===t.nodeType){if(n=t.nodeName.toLowerCase(),!b.support.noCloneEvent&&t[b.expando]){i=b._data(t);for(r in i.events)b.removeEvent(t,r,i.handle);t.removeAttribute(b.expando)}"script"===n&&t.text!==e.text?(Ht(t).text=e.text,qt(t)):"object"===n?(t.parentNode&&(t.outerHTML=e.outerHTML),b.support.html5Clone&&e.innerHTML&&!b.trim(t.innerHTML)&&(t.innerHTML=e.innerHTML)):"input"===n&&Nt.test(e.type)?(t.defaultChecked=t.checked=e.checked,t.value!==e.value&&(t.value=e.value)):"option"===n?t.defaultSelected=t.selected=e.defaultSelected:("input"===n||"textarea"===n)&&(t.defaultValue=e.defaultValue)}}b.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(e,t){b.fn[e]=function(e){var n,r=0,i=[],o=b(e),a=o.length-1;for(;a>=r;r++)n=r===a?this:this.clone(!0),b(o[r])[t](n),d.apply(i,n.get());return this.pushStack(i)}});function Ot(e,n){var r,o,a=0,s=typeof e.getElementsByTagName!==i?e.getElementsByTagName(n||"*"):typeof e.querySelectorAll!==i?e.querySelectorAll(n||"*"):t;if(!s)for(s=[],r=e.childNodes||e;null!=(o=r[a]);a++)!n||b.nodeName(o,n)?s.push(o):b.merge(s,Ot(o,n));return n===t||n&&b.nodeName(e,n)?b.merge([e],s):s}function Bt(e){Nt.test(e.type)&&(e.defaultChecked=e.checked)}b.extend({clone:function(e,t,n){var r,i,o,a,s,u=b.contains(e.ownerDocument,e);if(b.support.html5Clone||b.isXMLDoc(e)||!mt.test("<"+e.nodeName+">")?o=e.cloneNode(!0):(Dt.innerHTML=e.outerHTML,Dt.removeChild(o=Dt.firstChild)),!(b.support.noCloneEvent&&b.support.noCloneChecked||1!==e.nodeType&&11!==e.nodeType||b.isXMLDoc(e)))for(r=Ot(o),s=Ot(e),a=0;null!=(i=s[a]);++a)r[a]&&Ft(i,r[a]);if(t)if(n)for(s=s||Ot(e),r=r||Ot(o),a=0;null!=(i=s[a]);a++)_t(i,r[a]);else _t(e,o);return r=Ot(o,"script"),r.length>0&&Mt(r,!u&&Ot(e,"script")),r=s=i=null,o},buildFragment:function(e,t,n,r){var i,o,a,s,u,l,c,p=e.length,f=dt(t),d=[],h=0;for(;p>h;h++)if(o=e[h],o||0===o)if("object"===b.type(o))b.merge(d,o.nodeType?[o]:o);else if(wt.test(o)){s=s||f.appendChild(t.createElement("div")),u=(bt.exec(o)||["",""])[1].toLowerCase(),c=At[u]||At._default,s.innerHTML=c[1]+o.replace(vt,"<$1></$2>")+c[2],i=c[0];while(i--)s=s.lastChild;if(!b.support.leadingWhitespace&&yt.test(o)&&d.push(t.createTextNode(yt.exec(o)[0])),!b.support.tbody){o="table"!==u||xt.test(o)?"<table>"!==c[1]||xt.test(o)?0:s:s.firstChild,i=o&&o.childNodes.length;while(i--)b.nodeName(l=o.childNodes[i],"tbody")&&!l.childNodes.length&&o.removeChild(l)
            }b.merge(d,s.childNodes),s.textContent="";while(s.firstChild)s.removeChild(s.firstChild);s=f.lastChild}else d.push(t.createTextNode(o));s&&f.removeChild(s),b.support.appendChecked||b.grep(Ot(d,"input"),Bt),h=0;while(o=d[h++])if((!r||-1===b.inArray(o,r))&&(a=b.contains(o.ownerDocument,o),s=Ot(f.appendChild(o),"script"),a&&Mt(s),n)){i=0;while(o=s[i++])kt.test(o.type||"")&&n.push(o)}return s=null,f},cleanData:function(e,t){var n,r,o,a,s=0,u=b.expando,l=b.cache,p=b.support.deleteExpando,f=b.event.special;for(;null!=(n=e[s]);s++)if((t||b.acceptData(n))&&(o=n[u],a=o&&l[o])){if(a.events)for(r in a.events)f[r]?b.event.remove(n,r):b.removeEvent(n,r,a.handle);l[o]&&(delete l[o],p?delete n[u]:typeof n.removeAttribute!==i?n.removeAttribute(u):n[u]=null,c.push(o))}}});var Pt,Rt,Wt,$t=/alpha\([^)]*\)/i,It=/opacity\s*=\s*([^)]*)/,zt=/^(top|right|bottom|left)$/,Xt=/^(none|table(?!-c[ea]).+)/,Ut=/^margin/,Vt=RegExp("^("+x+")(.*)$","i"),Yt=RegExp("^("+x+")(?!px)[a-z%]+$","i"),Jt=RegExp("^([+-])=("+x+")","i"),Gt={BODY:"block"},Qt={position:"absolute",visibility:"hidden",display:"block"},Kt={letterSpacing:0,fontWeight:400},Zt=["Top","Right","Bottom","Left"],en=["Webkit","O","Moz","ms"];function tn(e,t){if(t in e)return t;var n=t.charAt(0).toUpperCase()+t.slice(1),r=t,i=en.length;while(i--)if(t=en[i]+n,t in e)return t;return r}function nn(e,t){return e=t||e,"none"===b.css(e,"display")||!b.contains(e.ownerDocument,e)}function rn(e,t){var n,r,i,o=[],a=0,s=e.length;for(;s>a;a++)r=e[a],r.style&&(o[a]=b._data(r,"olddisplay"),n=r.style.display,t?(o[a]||"none"!==n||(r.style.display=""),""===r.style.display&&nn(r)&&(o[a]=b._data(r,"olddisplay",un(r.nodeName)))):o[a]||(i=nn(r),(n&&"none"!==n||!i)&&b._data(r,"olddisplay",i?n:b.css(r,"display"))));for(a=0;s>a;a++)r=e[a],r.style&&(t&&"none"!==r.style.display&&""!==r.style.display||(r.style.display=t?o[a]||"":"none"));return e}b.fn.extend({css:function(e,n){return b.access(this,function(e,n,r){var i,o,a={},s=0;if(b.isArray(n)){for(o=Rt(e),i=n.length;i>s;s++)a[n[s]]=b.css(e,n[s],!1,o);return a}return r!==t?b.style(e,n,r):b.css(e,n)},e,n,arguments.length>1)},show:function(){return rn(this,!0)},hide:function(){return rn(this)},toggle:function(e){var t="boolean"==typeof e;return this.each(function(){(t?e:nn(this))?b(this).show():b(this).hide()})}}),b.extend({cssHooks:{opacity:{get:function(e,t){if(t){var n=Wt(e,"opacity");return""===n?"1":n}}}},cssNumber:{columnCount:!0,fillOpacity:!0,fontWeight:!0,lineHeight:!0,opacity:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":b.support.cssFloat?"cssFloat":"styleFloat"},style:function(e,n,r,i){if(e&&3!==e.nodeType&&8!==e.nodeType&&e.style){var o,a,s,u=b.camelCase(n),l=e.style;if(n=b.cssProps[u]||(b.cssProps[u]=tn(l,u)),s=b.cssHooks[n]||b.cssHooks[u],r===t)return s&&"get"in s&&(o=s.get(e,!1,i))!==t?o:l[n];if(a=typeof r,"string"===a&&(o=Jt.exec(r))&&(r=(o[1]+1)*o[2]+parseFloat(b.css(e,n)),a="number"),!(null==r||"number"===a&&isNaN(r)||("number"!==a||b.cssNumber[u]||(r+="px"),b.support.clearCloneStyle||""!==r||0!==n.indexOf("background")||(l[n]="inherit"),s&&"set"in s&&(r=s.set(e,r,i))===t)))try{l[n]=r}catch(c){}}},css:function(e,n,r,i){var o,a,s,u=b.camelCase(n);return n=b.cssProps[u]||(b.cssProps[u]=tn(e.style,u)),s=b.cssHooks[n]||b.cssHooks[u],s&&"get"in s&&(a=s.get(e,!0,r)),a===t&&(a=Wt(e,n,i)),"normal"===a&&n in Kt&&(a=Kt[n]),""===r||r?(o=parseFloat(a),r===!0||b.isNumeric(o)?o||0:a):a},swap:function(e,t,n,r){var i,o,a={};for(o in t)a[o]=e.style[o],e.style[o]=t[o];i=n.apply(e,r||[]);for(o in t)e.style[o]=a[o];return i}}),e.getComputedStyle?(Rt=function(t){return e.getComputedStyle(t,null)},Wt=function(e,n,r){var i,o,a,s=r||Rt(e),u=s?s.getPropertyValue(n)||s[n]:t,l=e.style;return s&&(""!==u||b.contains(e.ownerDocument,e)||(u=b.style(e,n)),Yt.test(u)&&Ut.test(n)&&(i=l.width,o=l.minWidth,a=l.maxWidth,l.minWidth=l.maxWidth=l.width=u,u=s.width,l.width=i,l.minWidth=o,l.maxWidth=a)),u}):o.documentElement.currentStyle&&(Rt=function(e){return e.currentStyle},Wt=function(e,n,r){var i,o,a,s=r||Rt(e),u=s?s[n]:t,l=e.style;return null==u&&l&&l[n]&&(u=l[n]),Yt.test(u)&&!zt.test(n)&&(i=l.left,o=e.runtimeStyle,a=o&&o.left,a&&(o.left=e.currentStyle.left),l.left="fontSize"===n?"1em":u,u=l.pixelLeft+"px",l.left=i,a&&(o.left=a)),""===u?"auto":u});function on(e,t,n){var r=Vt.exec(t);return r?Math.max(0,r[1]-(n||0))+(r[2]||"px"):t}function an(e,t,n,r,i){var o=n===(r?"border":"content")?4:"width"===t?1:0,a=0;for(;4>o;o+=2)"margin"===n&&(a+=b.css(e,n+Zt[o],!0,i)),r?("content"===n&&(a-=b.css(e,"padding"+Zt[o],!0,i)),"margin"!==n&&(a-=b.css(e,"border"+Zt[o]+"Width",!0,i))):(a+=b.css(e,"padding"+Zt[o],!0,i),"padding"!==n&&(a+=b.css(e,"border"+Zt[o]+"Width",!0,i)));return a}function sn(e,t,n){var r=!0,i="width"===t?e.offsetWidth:e.offsetHeight,o=Rt(e),a=b.support.boxSizing&&"border-box"===b.css(e,"boxSizing",!1,o);if(0>=i||null==i){if(i=Wt(e,t,o),(0>i||null==i)&&(i=e.style[t]),Yt.test(i))return i;r=a&&(b.support.boxSizingReliable||i===e.style[t]),i=parseFloat(i)||0}return i+an(e,t,n||(a?"border":"content"),r,o)+"px"}function un(e){var t=o,n=Gt[e];return n||(n=ln(e,t),"none"!==n&&n||(Pt=(Pt||b("<iframe frameborder='0' width='0' height='0'/>").css("cssText","display:block !important")).appendTo(t.documentElement),t=(Pt[0].contentWindow||Pt[0].contentDocument).document,t.write("<!doctype html><html><body>"),t.close(),n=ln(e,t),Pt.detach()),Gt[e]=n),n}function ln(e,t){var n=b(t.createElement(e)).appendTo(t.body),r=b.css(n[0],"display");return n.remove(),r}b.each(["height","width"],function(e,n){b.cssHooks[n]={get:function(e,r,i){return r?0===e.offsetWidth&&Xt.test(b.css(e,"display"))?b.swap(e,Qt,function(){return sn(e,n,i)}):sn(e,n,i):t},set:function(e,t,r){var i=r&&Rt(e);return on(e,t,r?an(e,n,r,b.support.boxSizing&&"border-box"===b.css(e,"boxSizing",!1,i),i):0)}}}),b.support.opacity||(b.cssHooks.opacity={get:function(e,t){return It.test((t&&e.currentStyle?e.currentStyle.filter:e.style.filter)||"")?.01*parseFloat(RegExp.$1)+"":t?"1":""},set:function(e,t){var n=e.style,r=e.currentStyle,i=b.isNumeric(t)?"alpha(opacity="+100*t+")":"",o=r&&r.filter||n.filter||"";n.zoom=1,(t>=1||""===t)&&""===b.trim(o.replace($t,""))&&n.removeAttribute&&(n.removeAttribute("filter"),""===t||r&&!r.filter)||(n.filter=$t.test(o)?o.replace($t,i):o+" "+i)}}),b(function(){b.support.reliableMarginRight||(b.cssHooks.marginRight={get:function(e,n){return n?b.swap(e,{display:"inline-block"},Wt,[e,"marginRight"]):t}}),!b.support.pixelPosition&&b.fn.position&&b.each(["top","left"],function(e,n){b.cssHooks[n]={get:function(e,r){return r?(r=Wt(e,n),Yt.test(r)?b(e).position()[n]+"px":r):t}}})}),b.expr&&b.expr.filters&&(b.expr.filters.hidden=function(e){return 0>=e.offsetWidth&&0>=e.offsetHeight||!b.support.reliableHiddenOffsets&&"none"===(e.style&&e.style.display||b.css(e,"display"))},b.expr.filters.visible=function(e){return!b.expr.filters.hidden(e)}),b.each({margin:"",padding:"",border:"Width"},function(e,t){b.cssHooks[e+t]={expand:function(n){var r=0,i={},o="string"==typeof n?n.split(" "):[n];for(;4>r;r++)i[e+Zt[r]+t]=o[r]||o[r-2]||o[0];return i}},Ut.test(e)||(b.cssHooks[e+t].set=on)});var cn=/%20/g,pn=/\[\]$/,fn=/\r?\n/g,dn=/^(?:submit|button|image|reset|file)$/i,hn=/^(?:input|select|textarea|keygen)/i;b.fn.extend({serialize:function(){return b.param(this.serializeArray())},serializeArray:function(){return this.map(function(){var e=b.prop(this,"elements");return e?b.makeArray(e):this}).filter(function(){var e=this.type;return this.name&&!b(this).is(":disabled")&&hn.test(this.nodeName)&&!dn.test(e)&&(this.checked||!Nt.test(e))}).map(function(e,t){var n=b(this).val();return null==n?null:b.isArray(n)?b.map(n,function(e){return{name:t.name,value:e.replace(fn,"\r\n")}}):{name:t.name,value:n.replace(fn,"\r\n")}}).get()}}),b.param=function(e,n){var r,i=[],o=function(e,t){t=b.isFunction(t)?t():null==t?"":t,i[i.length]=encodeURIComponent(e)+"="+encodeURIComponent(t)};if(n===t&&(n=b.ajaxSettings&&b.ajaxSettings.traditional),b.isArray(e)||e.jquery&&!b.isPlainObject(e))b.each(e,function(){o(this.name,this.value)});else for(r in e)gn(r,e[r],n,o);return i.join("&").replace(cn,"+")};function gn(e,t,n,r){var i;if(b.isArray(t))b.each(t,function(t,i){n||pn.test(e)?r(e,i):gn(e+"["+("object"==typeof i?t:"")+"]",i,n,r)});else if(n||"object"!==b.type(t))r(e,t);else for(i in t)gn(e+"["+i+"]",t[i],n,r)}b.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(e,t){b.fn[t]=function(e,n){return arguments.length>0?this.on(t,null,e,n):this.trigger(t)}}),b.fn.hover=function(e,t){return this.mouseenter(e).mouseleave(t||e)};var mn,yn,vn=b.now(),bn=/\?/,xn=/#.*$/,wn=/([?&])_=[^&]*/,Tn=/^(.*?):[ \t]*([^\r\n]*)\r?$/gm,Nn=/^(?:about|app|app-storage|.+-extension|file|res|widget):$/,Cn=/^(?:GET|HEAD)$/,kn=/^\/\//,En=/^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,Sn=b.fn.load,An={},jn={},Dn="*/".concat("*");try{yn=a.href}catch(Ln){yn=o.createElement("a"),yn.href="",yn=yn.href}mn=En.exec(yn.toLowerCase())||[];function Hn(e){return function(t,n){"string"!=typeof t&&(n=t,t="*");var r,i=0,o=t.toLowerCase().match(w)||[];if(b.isFunction(n))while(r=o[i++])"+"===r[0]?(r=r.slice(1)||"*",(e[r]=e[r]||[]).unshift(n)):(e[r]=e[r]||[]).push(n)}}function qn(e,n,r,i){var o={},a=e===jn;function s(u){var l;return o[u]=!0,b.each(e[u]||[],function(e,u){var c=u(n,r,i);return"string"!=typeof c||a||o[c]?a?!(l=c):t:(n.dataTypes.unshift(c),s(c),!1)}),l}return s(n.dataTypes[0])||!o["*"]&&s("*")}function Mn(e,n){var r,i,o=b.ajaxSettings.flatOptions||{};for(i in n)n[i]!==t&&((o[i]?e:r||(r={}))[i]=n[i]);return r&&b.extend(!0,e,r),e}b.fn.load=function(e,n,r){if("string"!=typeof e&&Sn)return Sn.apply(this,arguments);var i,o,a,s=this,u=e.indexOf(" ");return u>=0&&(i=e.slice(u,e.length),e=e.slice(0,u)),b.isFunction(n)?(r=n,n=t):n&&"object"==typeof n&&(a="POST"),s.length>0&&b.ajax({url:e,type:a,dataType:"html",data:n}).done(function(e){o=arguments,s.html(i?b("<div>").append(b.parseHTML(e)).find(i):e)}).complete(r&&function(e,t){s.each(r,o||[e.responseText,t,e])}),this},b.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(e,t){b.fn[t]=function(e){return this.on(t,e)}}),b.each(["get","post"],function(e,n){b[n]=function(e,r,i,o){return b.isFunction(r)&&(o=o||i,i=r,r=t),b.ajax({url:e,type:n,dataType:o,data:r,success:i})}}),b.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:yn,type:"GET",isLocal:Nn.test(mn[1]),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":Dn,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText"},converters:{"* text":e.String,"text html":!0,"text json":b.parseJSON,"text xml":b.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(e,t){return t?Mn(Mn(e,b.ajaxSettings),t):Mn(b.ajaxSettings,e)},ajaxPrefilter:Hn(An),ajaxTransport:Hn(jn),ajax:function(e,n){"object"==typeof e&&(n=e,e=t),n=n||{};var r,i,o,a,s,u,l,c,p=b.ajaxSetup({},n),f=p.context||p,d=p.context&&(f.nodeType||f.jquery)?b(f):b.event,h=b.Deferred(),g=b.Callbacks("once memory"),m=p.statusCode||{},y={},v={},x=0,T="canceled",N={readyState:0,getResponseHeader:function(e){var t;if(2===x){if(!c){c={};while(t=Tn.exec(a))c[t[1].toLowerCase()]=t[2]}t=c[e.toLowerCase()]}return null==t?null:t},getAllResponseHeaders:function(){return 2===x?a:null},setRequestHeader:function(e,t){var n=e.toLowerCase();return x||(e=v[n]=v[n]||e,y[e]=t),this},overrideMimeType:function(e){return x||(p.mimeType=e),this},statusCode:function(e){var t;if(e)if(2>x)for(t in e)m[t]=[m[t],e[t]];else N.always(e[N.status]);return this},abort:function(e){var t=e||T;return l&&l.abort(t),k(0,t),this}};if(h.promise(N).complete=g.add,N.success=N.done,N.error=N.fail,p.url=((e||p.url||yn)+"").replace(xn,"").replace(kn,mn[1]+"//"),p.type=n.method||n.type||p.method||p.type,p.dataTypes=b.trim(p.dataType||"*").toLowerCase().match(w)||[""],null==p.crossDomain&&(r=En.exec(p.url.toLowerCase()),p.crossDomain=!(!r||r[1]===mn[1]&&r[2]===mn[2]&&(r[3]||("http:"===r[1]?80:443))==(mn[3]||("http:"===mn[1]?80:443)))),p.data&&p.processData&&"string"!=typeof p.data&&(p.data=b.param(p.data,p.traditional)),qn(An,p,n,N),2===x)return N;u=p.global,u&&0===b.active++&&b.event.trigger("ajaxStart"),p.type=p.type.toUpperCase(),p.hasContent=!Cn.test(p.type),o=p.url,p.hasContent||(p.data&&(o=p.url+=(bn.test(o)?"&":"?")+p.data,delete p.data),p.cache===!1&&(p.url=wn.test(o)?o.replace(wn,"$1_="+vn++):o+(bn.test(o)?"&":"?")+"_="+vn++)),p.ifModified&&(b.lastModified[o]&&N.setRequestHeader("If-Modified-Since",b.lastModified[o]),b.etag[o]&&N.setRequestHeader("If-None-Match",b.etag[o])),(p.data&&p.hasContent&&p.contentType!==!1||n.contentType)&&N.setRequestHeader("Content-Type",p.contentType),N.setRequestHeader("Accept",p.dataTypes[0]&&p.accepts[p.dataTypes[0]]?p.accepts[p.dataTypes[0]]+("*"!==p.dataTypes[0]?", "+Dn+"; q=0.01":""):p.accepts["*"]);for(i in p.headers)N.setRequestHeader(i,p.headers[i]);if(p.beforeSend&&(p.beforeSend.call(f,N,p)===!1||2===x))return N.abort();T="abort";for(i in{success:1,error:1,complete:1})N[i](p[i]);if(l=qn(jn,p,n,N)){N.readyState=1,u&&d.trigger("ajaxSend",[N,p]),p.async&&p.timeout>0&&(s=setTimeout(function(){N.abort("timeout")},p.timeout));try{x=1,l.send(y,k)}catch(C){if(!(2>x))throw C;k(-1,C)}}else k(-1,"No Transport");function k(e,n,r,i){var c,y,v,w,T,C=n;2!==x&&(x=2,s&&clearTimeout(s),l=t,a=i||"",N.readyState=e>0?4:0,r&&(w=_n(p,N,r)),e>=200&&300>e||304===e?(p.ifModified&&(T=N.getResponseHeader("Last-Modified"),T&&(b.lastModified[o]=T),T=N.getResponseHeader("etag"),T&&(b.etag[o]=T)),204===e?(c=!0,C="nocontent"):304===e?(c=!0,C="notmodified"):(c=Fn(p,w),C=c.state,y=c.data,v=c.error,c=!v)):(v=C,(e||!C)&&(C="error",0>e&&(e=0))),N.status=e,N.statusText=(n||C)+"",c?h.resolveWith(f,[y,C,N]):h.rejectWith(f,[N,C,v]),N.statusCode(m),m=t,u&&d.trigger(c?"ajaxSuccess":"ajaxError",[N,p,c?y:v]),g.fireWith(f,[N,C]),u&&(d.trigger("ajaxComplete",[N,p]),--b.active||b.event.trigger("ajaxStop")))}return N},getScript:function(e,n){return b.get(e,t,n,"script")},getJSON:function(e,t,n){return b.get(e,t,n,"json")}});function _n(e,n,r){var i,o,a,s,u=e.contents,l=e.dataTypes,c=e.responseFields;for(s in c)s in r&&(n[c[s]]=r[s]);while("*"===l[0])l.shift(),o===t&&(o=e.mimeType||n.getResponseHeader("Content-Type"));if(o)for(s in u)if(u[s]&&u[s].test(o)){l.unshift(s);break}if(l[0]in r)a=l[0];else{for(s in r){if(!l[0]||e.converters[s+" "+l[0]]){a=s;break}i||(i=s)}a=a||i}return a?(a!==l[0]&&l.unshift(a),r[a]):t}function Fn(e,t){var n,r,i,o,a={},s=0,u=e.dataTypes.slice(),l=u[0];if(e.dataFilter&&(t=e.dataFilter(t,e.dataType)),u[1])for(i in e.converters)a[i.toLowerCase()]=e.converters[i];for(;r=u[++s];)if("*"!==r){if("*"!==l&&l!==r){if(i=a[l+" "+r]||a["* "+r],!i)for(n in a)if(o=n.split(" "),o[1]===r&&(i=a[l+" "+o[0]]||a["* "+o[0]])){i===!0?i=a[n]:a[n]!==!0&&(r=o[0],u.splice(s--,0,r));break}if(i!==!0)if(i&&e["throws"])t=i(t);else try{t=i(t)}catch(c){return{state:"parsererror",error:i?c:"No conversion from "+l+" to "+r}}}l=r}return{state:"success",data:t}}b.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/(?:java|ecma)script/},converters:{"text script":function(e){return b.globalEval(e),e}}}),b.ajaxPrefilter("script",function(e){e.cache===t&&(e.cache=!1),e.crossDomain&&(e.type="GET",e.global=!1)}),b.ajaxTransport("script",function(e){if(e.crossDomain){var n,r=o.head||b("head")[0]||o.documentElement;return{send:function(t,i){n=o.createElement("script"),n.async=!0,e.scriptCharset&&(n.charset=e.scriptCharset),n.src=e.url,n.onload=n.onreadystatechange=function(e,t){(t||!n.readyState||/loaded|complete/.test(n.readyState))&&(n.onload=n.onreadystatechange=null,n.parentNode&&n.parentNode.removeChild(n),n=null,t||i(200,"success"))},r.insertBefore(n,r.firstChild)},abort:function(){n&&n.onload(t,!0)}}}});var On=[],Bn=/(=)\?(?=&|$)|\?\?/;b.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var e=On.pop()||b.expando+"_"+vn++;return this[e]=!0,e}}),b.ajaxPrefilter("json jsonp",function(n,r,i){var o,a,s,u=n.jsonp!==!1&&(Bn.test(n.url)?"url":"string"==typeof n.data&&!(n.contentType||"").indexOf("application/x-www-form-urlencoded")&&Bn.test(n.data)&&"data");return u||"jsonp"===n.dataTypes[0]?(o=n.jsonpCallback=b.isFunction(n.jsonpCallback)?n.jsonpCallback():n.jsonpCallback,u?n[u]=n[u].replace(Bn,"$1"+o):n.jsonp!==!1&&(n.url+=(bn.test(n.url)?"&":"?")+n.jsonp+"="+o),n.converters["script json"]=function(){return s||b.error(o+" was not called"),s[0]},n.dataTypes[0]="json",a=e[o],e[o]=function(){s=arguments},i.always(function(){e[o]=a,n[o]&&(n.jsonpCallback=r.jsonpCallback,On.push(o)),s&&b.isFunction(a)&&a(s[0]),s=a=t}),"script"):t});var Pn,Rn,Wn=0,$n=e.ActiveXObject&&function(){var e;for(e in Pn)Pn[e](t,!0)};function In(){try{return new e.XMLHttpRequest}catch(t){}}function zn(){try{return new e.ActiveXObject("Microsoft.XMLHTTP")}catch(t){}}b.ajaxSettings.xhr=e.ActiveXObject?function(){return!this.isLocal&&In()||zn()}:In,Rn=b.ajaxSettings.xhr(),b.support.cors=!!Rn&&"withCredentials"in Rn,Rn=b.support.ajax=!!Rn,Rn&&b.ajaxTransport(function(n){if(!n.crossDomain||b.support.cors){var r;return{send:function(i,o){var a,s,u=n.xhr();if(n.username?u.open(n.type,n.url,n.async,n.username,n.password):u.open(n.type,n.url,n.async),n.xhrFields)for(s in n.xhrFields)u[s]=n.xhrFields[s];n.mimeType&&u.overrideMimeType&&u.overrideMimeType(n.mimeType),n.crossDomain||i["X-Requested-With"]||(i["X-Requested-With"]="XMLHttpRequest");try{for(s in i)u.setRequestHeader(s,i[s])}catch(l){}u.send(n.hasContent&&n.data||null),r=function(e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete Pn[a]),i)4!==u.readyState&&u.abort();else{p={},s=u.status,l=u.getAllResponseHeaders(),"string"==typeof u.responseText&&(p.text=u.responseText);try{c=u.statusText}catch(f){c=""}s||!n.isLocal||n.crossDomain?1223===s&&(s=204):s=p.text?200:404}}catch(d){i||o(-1,d)}p&&o(s,c,p,l)},n.async?4===u.readyState?setTimeout(r):(a=++Wn,$n&&(Pn||(Pn={},b(e).unload($n)),Pn[a]=r),u.onreadystatechange=r):r()},abort:function(){r&&r(t,!0)}}}});var Xn,Un,Vn=/^(?:toggle|show|hide)$/,Yn=RegExp("^(?:([+-])=|)("+x+")([a-z%]*)$","i"),Jn=/queueHooks$/,Gn=[nr],Qn={"*":[function(e,t){var n,r,i=this.createTween(e,t),o=Yn.exec(t),a=i.cur(),s=+a||0,u=1,l=20;if(o){if(n=+o[2],r=o[3]||(b.cssNumber[e]?"":"px"),"px"!==r&&s){s=b.css(i.elem,e,!0)||n||1;do u=u||".5",s/=u,b.style(i.elem,e,s+r);while(u!==(u=i.cur()/a)&&1!==u&&--l)}i.unit=r,i.start=s,i.end=o[1]?s+(o[1]+1)*n:n}return i}]};function Kn(){return setTimeout(function(){Xn=t}),Xn=b.now()}function Zn(e,t){b.each(t,function(t,n){var r=(Qn[t]||[]).concat(Qn["*"]),i=0,o=r.length;for(;o>i;i++)if(r[i].call(e,t,n))return})}function er(e,t,n){var r,i,o=0,a=Gn.length,s=b.Deferred().always(function(){delete u.elem}),u=function(){if(i)return!1;var t=Xn||Kn(),n=Math.max(0,l.startTime+l.duration-t),r=n/l.duration||0,o=1-r,a=0,u=l.tweens.length;for(;u>a;a++)l.tweens[a].run(o);return s.notifyWith(e,[l,o,n]),1>o&&u?n:(s.resolveWith(e,[l]),!1)},l=s.promise({elem:e,props:b.extend({},t),opts:b.extend(!0,{specialEasing:{}},n),originalProperties:t,originalOptions:n,startTime:Xn||Kn(),duration:n.duration,tweens:[],createTween:function(t,n){var r=b.Tween(e,l.opts,t,n,l.opts.specialEasing[t]||l.opts.easing);return l.tweens.push(r),r},stop:function(t){var n=0,r=t?l.tweens.length:0;if(i)return this;for(i=!0;r>n;n++)l.tweens[n].run(1);return t?s.resolveWith(e,[l,t]):s.rejectWith(e,[l,t]),this}}),c=l.props;for(tr(c,l.opts.specialEasing);a>o;o++)if(r=Gn[o].call(l,e,c,l.opts))return r;return Zn(l,c),b.isFunction(l.opts.start)&&l.opts.start.call(e,l),b.fx.timer(b.extend(u,{elem:e,anim:l,queue:l.opts.queue})),l.progress(l.opts.progress).done(l.opts.done,l.opts.complete).fail(l.opts.fail).always(l.opts.always)}function tr(e,t){var n,r,i,o,a;for(i in e)if(r=b.camelCase(i),o=t[r],n=e[i],b.isArray(n)&&(o=n[1],n=e[i]=n[0]),i!==r&&(e[r]=n,delete e[i]),a=b.cssHooks[r],a&&"expand"in a){n=a.expand(n),delete e[r];for(i in n)i in e||(e[i]=n[i],t[i]=o)}else t[r]=o}b.Animation=b.extend(er,{tweener:function(e,t){b.isFunction(e)?(t=e,e=["*"]):e=e.split(" ");var n,r=0,i=e.length;for(;i>r;r++)n=e[r],Qn[n]=Qn[n]||[],Qn[n].unshift(t)},prefilter:function(e,t){t?Gn.unshift(e):Gn.push(e)}});function nr(e,t,n){var r,i,o,a,s,u,l,c,p,f=this,d=e.style,h={},g=[],m=e.nodeType&&nn(e);n.queue||(c=b._queueHooks(e,"fx"),null==c.unqueued&&(c.unqueued=0,p=c.empty.fire,c.empty.fire=function(){c.unqueued||p()}),c.unqueued++,f.always(function(){f.always(function(){c.unqueued--,b.queue(e,"fx").length||c.empty.fire()})})),1===e.nodeType&&("height"in t||"width"in t)&&(n.overflow=[d.overflow,d.overflowX,d.overflowY],"inline"===b.css(e,"display")&&"none"===b.css(e,"float")&&(b.support.inlineBlockNeedsLayout&&"inline"!==un(e.nodeName)?d.zoom=1:d.display="inline-block")),n.overflow&&(d.overflow="hidden",b.support.shrinkWrapBlocks||f.always(function(){d.overflow=n.overflow[0],d.overflowX=n.overflow[1],d.overflowY=n.overflow[2]}));for(i in t)if(a=t[i],Vn.exec(a)){if(delete t[i],u=u||"toggle"===a,a===(m?"hide":"show"))continue;g.push(i)}if(o=g.length){s=b._data(e,"fxshow")||b._data(e,"fxshow",{}),"hidden"in s&&(m=s.hidden),u&&(s.hidden=!m),m?b(e).show():f.done(function(){b(e).hide()}),f.done(function(){var t;b._removeData(e,"fxshow");for(t in h)b.style(e,t,h[t])});for(i=0;o>i;i++)r=g[i],l=f.createTween(r,m?s[r]:0),h[r]=s[r]||b.style(e,r),r in s||(s[r]=l.start,m&&(l.end=l.start,l.start="width"===r||"height"===r?1:0))}}function rr(e,t,n,r,i){return new rr.prototype.init(e,t,n,r,i)}b.Tween=rr,rr.prototype={constructor:rr,init:function(e,t,n,r,i,o){this.elem=e,this.prop=n,this.easing=i||"swing",this.options=t,this.start=this.now=this.cur(),this.end=r,this.unit=o||(b.cssNumber[n]?"":"px")},cur:function(){var e=rr.propHooks[this.prop];return e&&e.get?e.get(this):rr.propHooks._default.get(this)},run:function(e){var t,n=rr.propHooks[this.prop];return this.pos=t=this.options.duration?b.easing[this.easing](e,this.options.duration*e,0,1,this.options.duration):e,this.now=(this.end-this.start)*t+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),n&&n.set?n.set(this):rr.propHooks._default.set(this),this}},rr.prototype.init.prototype=rr.prototype,rr.propHooks={_default:{get:function(e){var t;return null==e.elem[e.prop]||e.elem.style&&null!=e.elem.style[e.prop]?(t=b.css(e.elem,e.prop,""),t&&"auto"!==t?t:0):e.elem[e.prop]},set:function(e){b.fx.step[e.prop]?b.fx.step[e.prop](e):e.elem.style&&(null!=e.elem.style[b.cssProps[e.prop]]||b.cssHooks[e.prop])?b.style(e.elem,e.prop,e.now+e.unit):e.elem[e.prop]=e.now}}},rr.propHooks.scrollTop=rr.propHooks.scrollLeft={set:function(e){e.elem.nodeType&&e.elem.parentNode&&(e.elem[e.prop]=e.now)}},b.each(["toggle","show","hide"],function(e,t){var n=b.fn[t];b.fn[t]=function(e,r,i){return null==e||"boolean"==typeof e?n.apply(this,arguments):this.animate(ir(t,!0),e,r,i)}}),b.fn.extend({fadeTo:function(e,t,n,r){return this.filter(nn).css("opacity",0).show().end().animate({opacity:t},e,n,r)},animate:function(e,t,n,r){var i=b.isEmptyObject(e),o=b.speed(t,n,r),a=function(){var t=er(this,b.extend({},e),o);a.finish=function(){t.stop(!0)},(i||b._data(this,"finish"))&&t.stop(!0)};return a.finish=a,i||o.queue===!1?this.each(a):this.queue(o.queue,a)},stop:function(e,n,r){var i=function(e){var t=e.stop;delete e.stop,t(r)};return"string"!=typeof e&&(r=n,n=e,e=t),n&&e!==!1&&this.queue(e||"fx",[]),this.each(function(){var t=!0,n=null!=e&&e+"queueHooks",o=b.timers,a=b._data(this);if(n)a[n]&&a[n].stop&&i(a[n]);else for(n in a)a[n]&&a[n].stop&&Jn.test(n)&&i(a[n]);for(n=o.length;n--;)o[n].elem!==this||null!=e&&o[n].queue!==e||(o[n].anim.stop(r),t=!1,o.splice(n,1));(t||!r)&&b.dequeue(this,e)})},finish:function(e){return e!==!1&&(e=e||"fx"),this.each(function(){var t,n=b._data(this),r=n[e+"queue"],i=n[e+"queueHooks"],o=b.timers,a=r?r.length:0;for(n.finish=!0,b.queue(this,e,[]),i&&i.cur&&i.cur.finish&&i.cur.finish.call(this),t=o.length;t--;)o[t].elem===this&&o[t].queue===e&&(o[t].anim.stop(!0),o.splice(t,1));for(t=0;a>t;t++)r[t]&&r[t].finish&&r[t].finish.call(this);delete n.finish})}});function ir(e,t){var n,r={height:e},i=0;for(t=t?1:0;4>i;i+=2-t)n=Zt[i],r["margin"+n]=r["padding"+n]=e;return t&&(r.opacity=r.width=e),r}b.each({slideDown:ir("show"),slideUp:ir("hide"),slideToggle:ir("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(e,t){b.fn[e]=function(e,n,r){return this.animate(t,e,n,r)}}),b.speed=function(e,t,n){var r=e&&"object"==typeof e?b.extend({},e):{complete:n||!n&&t||b.isFunction(e)&&e,duration:e,easing:n&&t||t&&!b.isFunction(t)&&t};return r.duration=b.fx.off?0:"number"==typeof r.duration?r.duration:r.duration in b.fx.speeds?b.fx.speeds[r.duration]:b.fx.speeds._default,(null==r.queue||r.queue===!0)&&(r.queue="fx"),r.old=r.complete,r.complete=function(){b.isFunction(r.old)&&r.old.call(this),r.queue&&b.dequeue(this,r.queue)},r},b.easing={linear:function(e){return e},swing:function(e){return.5-Math.cos(e*Math.PI)/2}},b.timers=[],b.fx=rr.prototype.init,b.fx.tick=function(){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length||b.fx.stop(),Xn=t},b.fx.timer=function(e){e()&&b.timers.push(e)&&b.fx.start()},b.fx.interval=13,b.fx.start=function(){Un||(Un=setInterval(b.fx.tick,b.fx.interval))},b.fx.stop=function(){clearInterval(Un),Un=null},b.fx.speeds={slow:600,fast:200,_default:400},b.fx.step={},b.expr&&b.expr.filters&&(b.expr.filters.animated=function(e){return b.grep(b.timers,function(t){return e===t.elem}).length}),b.fn.offset=function(e){if(arguments.length)return e===t?this:this.each(function(t){b.offset.setOffset(this,e,t)});var n,r,o={top:0,left:0},a=this[0],s=a&&a.ownerDocument;if(s)return n=s.documentElement,b.contains(n,a)?(typeof a.getBoundingClientRect!==i&&(o=a.getBoundingClientRect()),r=or(s),{top:o.top+(r.pageYOffset||n.scrollTop)-(n.clientTop||0),left:o.left+(r.pageXOffset||n.scrollLeft)-(n.clientLeft||0)}):o},b.offset={setOffset:function(e,t,n){var r=b.css(e,"position");"static"===r&&(e.style.position="relative");var i=b(e),o=i.offset(),a=b.css(e,"top"),s=b.css(e,"left"),u=("absolute"===r||"fixed"===r)&&b.inArray("auto",[a,s])>-1,l={},c={},p,f;u?(c=i.position(),p=c.top,f=c.left):(p=parseFloat(a)||0,f=parseFloat(s)||0),b.isFunction(t)&&(t=t.call(e,n,o)),null!=t.top&&(l.top=t.top-o.top+p),null!=t.left&&(l.left=t.left-o.left+f),"using"in t?t.using.call(e,l):i.css(l)}},b.fn.extend({position:function(){if(this[0]){var e,t,n={top:0,left:0},r=this[0];return"fixed"===b.css(r,"position")?t=r.getBoundingClientRect():(e=this.offsetParent(),t=this.offset(),b.nodeName(e[0],"html")||(n=e.offset()),n.top+=b.css(e[0],"borderTopWidth",!0),n.left+=b.css(e[0],"borderLeftWidth",!0)),{top:t.top-n.top-b.css(r,"marginTop",!0),left:t.left-n.left-b.css(r,"marginLeft",!0)}}},offsetParent:function(){return this.map(function(){var e=this.offsetParent||o.documentElement;while(e&&!b.nodeName(e,"html")&&"static"===b.css(e,"position"))e=e.offsetParent;return e||o.documentElement})}}),b.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(e,n){var r=/Y/.test(n);b.fn[e]=function(i){return b.access(this,function(e,i,o){var a=or(e);return o===t?a?n in a?a[n]:a.document.documentElement[i]:e[i]:(a?a.scrollTo(r?b(a).scrollLeft():o,r?o:b(a).scrollTop()):e[i]=o,t)},e,i,arguments.length,null)}});function or(e){return b.isWindow(e)?e:9===e.nodeType?e.defaultView||e.parentWindow:!1}b.each({Height:"height",Width:"width"},function(e,n){b.each({padding:"inner"+e,content:n,"":"outer"+e},function(r,i){b.fn[i]=function(i,o){var a=arguments.length&&(r||"boolean"!=typeof i),s=r||(i===!0||o===!0?"margin":"border");return b.access(this,function(n,r,i){var o;return b.isWindow(n)?n.document.documentElement["client"+e]:9===n.nodeType?(o=n.documentElement,Math.max(n.body["scroll"+e],o["scroll"+e],n.body["offset"+e],o["offset"+e],o["client"+e])):i===t?b.css(n,r,s):b.style(n,r,i,s)},n,a?i:t,a,null)}})}),e.jQuery=e.$=b,"function"==typeof define&&define.amd&&define.amd.jQuery&&define("jquery",[],function(){return b})})(window);
    }

    /*
    * imgAreaSelect jQuery plugin
    * version 0.9.2
    *
    * Copyright (c) 2008-2010 Michal Wojciechowski (odyniec.net)
    *
    * Dual licensed under the MIT (MIT-LICENSE.txt)
    * and GPL (GPL-LICENSE.txt) licenses.
    *
    * http://odyniec.net/projects/imgareaselect/
    *
    */
    (function($) {

        var abs = Math.abs,
          max = Math.max,
          min = Math.min,
          round = Math.round;

        function div() {
            return $('<div/>');
        }

        $.imgAreaSelect = function (img, options) {
            var

              $img = $(img),

              imgLoaded,

              $box = div(),
              $area = div(),
              $border = div().add(div()).add(div()).add(div()),
              $outer = div().add(div()).add(div()).add(div()),
              $handles = $([]),

              $areaOpera,

              left, top,

              imgOfs,

              imgWidth, imgHeight,

              $parent,

              parOfs,

              zIndex = 0,

              position = 'absolute',

              startX, startY,

              scaleX, scaleY,

              resizeMargin = 10,

              resize,

              minWidth, minHeight, maxWidth, maxHeight,

              aspectRatio,

              shown,

              x1, y1, x2, y2,

              selection = { x1: 0, y1: 0, x2: 0, y2: 0, width: 0, height: 0 },

              docElem = document.documentElement,

              $p, d, i, o, w, h, adjusted;

            function viewX(x) {
                return x + imgOfs.left - parOfs.left;
            }

            function viewY(y) {
                return y + imgOfs.top - parOfs.top;
            }

            function selX(x) {
                return x - imgOfs.left + parOfs.left;
            }

            function selY(y) {
                return y - imgOfs.top + parOfs.top;
            }

            function evX(event) {
                return event.pageX - parOfs.left;
            }

            function evY(event) {
                return event.pageY - parOfs.top;
            }

            function getSelection(noScale) {
                var sx = noScale || scaleX, sy = noScale || scaleY;

                return { x1: round(selection.x1 * sx),
                    y1: round(selection.y1 * sy),
                    x2: round(selection.x2 * sx),
                    y2: round(selection.y2 * sy),
                    width: round(selection.x2 * sx) - round(selection.x1 * sx),
                    height: round(selection.y2 * sy) - round(selection.y1 * sy) };
            }

            function setSelection(x1, y1, x2, y2, noScale) {
                var sx = noScale || scaleX, sy = noScale || scaleY;

                selection = {
                    x1: round(x1 / sx),
                    y1: round(y1 / sy),
                    x2: round(x2 / sx),
                    y2: round(y2 / sy)
                };

                selection.width = selection.x2 - selection.x1;
                selection.height = selection.y2 - selection.y1;
            }

            function adjust() {
                if (!$img.width())
                    return;

                imgOfs = { left: round($img.offset().left), top: round($img.offset().top) };

                imgWidth = $img.width();
                imgHeight = $img.height();

                minWidth = options.minWidth || 0;
                minHeight = options.minHeight || 0;
                maxWidth = min(options.maxWidth || 1<<24, imgWidth);
                maxHeight = min(options.maxHeight || 1<<24, imgHeight);

                if ($().jquery == '1.3.2' && position == 'fixed' &&
                  !docElem['getBoundingClientRect'])
                {
                    imgOfs.top += max(document.body.scrollTop, docElem.scrollTop);
                    imgOfs.left += max(document.body.scrollLeft, docElem.scrollLeft);
                }

                parOfs = $.inArray($parent.css('position'), ['absolute', 'relative']) + 1 ?
                  { left: round($parent.offset().left) - $parent.scrollLeft(),
                      top: round($parent.offset().top) - $parent.scrollTop() } :
                  position == 'fixed' ?
                    { left: $(document).scrollLeft(), top: $(document).scrollTop() } :
                    { left: 0, top: 0 };

                left = viewX(0);
                top = viewY(0);

                if (selection.x2 > imgWidth || selection.y2 > imgHeight)
                    doResize();
            }

            function update(resetKeyPress) {
                if (!shown) return;

                $box.css({ left: viewX(selection.x1), top: viewY(selection.y1) })
                  .add($area).width(w = selection.width).height(h = selection.height);

                $area.add($border).add($handles).css({ left: 0, top: 0 });

                $border
                  .width(max(w - $border.outerWidth() + $border.innerWidth(), 0))
                  .height(max(h - $border.outerHeight() + $border.innerHeight(), 0));

                $($outer[0]).css({ left: left, top: top,
                    width: selection.x1, height: imgHeight });
                $($outer[1]).css({ left: left + selection.x1, top: top,
                    width: w, height: selection.y1 });
                $($outer[2]).css({ left: left + selection.x2, top: top,
                    width: imgWidth - selection.x2, height: imgHeight });
                $($outer[3]).css({ left: left + selection.x1, top: top + selection.y2,
                    width: w, height: imgHeight - selection.y2 });

                w -= $handles.outerWidth();
                h -= $handles.outerHeight();

                switch ($handles.length) {
                    case 8:
                        $($handles[4]).css({ left: w / 2 });
                        $($handles[5]).css({ left: w, top: h / 2 });
                        $($handles[6]).css({ left: w / 2, top: h });
                        $($handles[7]).css({ top: h / 2 });
                    case 4:
                        $handles.slice(1,3).css({ left: w });
                        $handles.slice(2,4).css({ top: h });
                }

                if (resetKeyPress !== false) {
                    if ($.imgAreaSelect.keyPress != docKeyPress)
                        $(document).off($.imgAreaSelect.keyPress,
                          $.imgAreaSelect.onKeyPress);

                    if (options.keys)
                        $(document).on($.imgAreaSelect.keyPress, $.imgAreaSelect.onKeyPress = docKeyPress);
                }

                if (IGH.BrowserConstants._isIE && $border.outerWidth() - $border.innerWidth() == 2) {
                    $border.css('margin', '0');
                    setTimeout(function () { $border.css('margin', 'auto'); }, 0);
                }
            }

            function doUpdate(resetKeyPress) {
                if (!imgOfs) return;
                adjust();
                update(resetKeyPress);
                x1 = viewX(selection.x1); y1 = viewY(selection.y1);
                x2 = viewX(selection.x2); y2 = viewY(selection.y2);
            }

            function hide($elem, fn) {
                options.fadeSpeed ? $elem.fadeOut(options.fadeSpeed, fn) : $elem.hide();

            }

            function areaMouseMove(event) {
                var x = selX(evX(event)) - selection.x1,
                  y = selY(evY(event)) - selection.y1;

                if (!adjusted) {
                    adjust();
                    adjusted = true;

                    $box.one('mouseout', function () { adjusted = false; });
                }

                resize = '';

                if (options.resizable) {
                    if (y <= resizeMargin)
                        resize = 'n';
                    else if (y >= selection.height - resizeMargin)
                        resize = 's';
                    if (x <= resizeMargin)
                        resize += 'w';
                    else if (x >= selection.width - resizeMargin)
                        resize += 'e';
                }

                $box.css('cursor', resize ? resize + '-resize' :
                  options.movable ? 'move' : '');
                if ($areaOpera)
                    $areaOpera.toggle();
            }

            function docMouseUp(event) {
                $('body').css('cursor', '');

                if (options.autoHide || selection.width * selection.height == 0)
                    hide($box.add($outer), function () { $(this).hide(); });

                options.onSelectEnd(img, getSelection());

                $(document).off('mousemove', selectingMouseMove);
                $box.on('mousemove', areaMouseMove);
            }

            function areaMouseDown(event) {
                if (event.which != 1) return false;

                adjust();

                if (resize) {
                    $('body').css('cursor', resize + '-resize');

                    x1 = viewX(selection[/w/.test(resize) ? 'x2' : 'x1']);
                    y1 = viewY(selection[/n/.test(resize) ? 'y2' : 'y1']);

                    $(document).on('mousemove', selectingMouseMove)
                      .one('mouseup', docMouseUp);
                    $box.off('mousemove', areaMouseMove);
                }
                else if (options.movable) {
                    startX = left + selection.x1 - evX(event);
                    startY = top + selection.y1 - evY(event);

                    $box.off('mousemove', areaMouseMove);

                    $(document).on('mousemove', movingMouseMove)
                      .one('mouseup', function () {
                          options.onSelectEnd(img, getSelection());

                          $(document).off('mousemove', movingMouseMove);
                          $box.on('mousemove', areaMouseMove);
                      });
                }
                else
                    $img.on('mousedown', event);

                return false;
            }

            function fixAspectRatio(xFirst) {
                if (aspectRatio)
                    if (xFirst) {
                        x2 = max(left, min(left + imgWidth,
                          x1 + abs(y2 - y1) * aspectRatio * (x2 > x1 || -1)));

                        y2 = round(max(top, min(top + imgHeight,
                          y1 + abs(x2 - x1) / aspectRatio * (y2 > y1 || -1))));
                        x2 = round(x2);
                    }
                    else {
                        y2 = max(top, min(top + imgHeight,
                          y1 + abs(x2 - x1) / aspectRatio * (y2 > y1 || -1)));
                        x2 = round(max(left, min(left + imgWidth,
                          x1 + abs(y2 - y1) * aspectRatio * (x2 > x1 || -1))));
                        y2 = round(y2);
                    }
            }

            function doResize() {
                x1 = min(x1, left + imgWidth);
                y1 = min(y1, top + imgHeight);

                if (abs(x2 - x1) < minWidth) {
                    x2 = x1 - minWidth * (x2 < x1 || -1);

                    if (x2 < left)
                        x1 = left + minWidth;
                    else if (x2 > left + imgWidth)
                        x1 = left + imgWidth - minWidth;
                }

                if (abs(y2 - y1) < minHeight) {
                    y2 = y1 - minHeight * (y2 < y1 || -1);

                    if (y2 < top)
                        y1 = top + minHeight;
                    else if (y2 > top + imgHeight)
                        y1 = top + imgHeight - minHeight;
                }

                x2 = max(left, min(x2, left + imgWidth));
                y2 = max(top, min(y2, top + imgHeight));

                fixAspectRatio(abs(x2 - x1) < abs(y2 - y1) * aspectRatio);

                if (abs(x2 - x1) > maxWidth) {
                    x2 = x1 - maxWidth * (x2 < x1 || -1);
                    fixAspectRatio();
                }

                if (abs(y2 - y1) > maxHeight) {
                    y2 = y1 - maxHeight * (y2 < y1 || -1);
                    fixAspectRatio(true);
                }

                selection = { x1: selX(min(x1, x2)), x2: selX(max(x1, x2)),
                    y1: selY(min(y1, y2)), y2: selY(max(y1, y2)),
                    width: abs(x2 - x1), height: abs(y2 - y1) };

                update();

                options.onSelectChange(img, getSelection());
            }

            function selectingMouseMove(event) {
                x2 = resize == '' || /w|e/.test(resize) || aspectRatio ? evX(event) : viewX(selection.x2);
                y2 = resize == '' || /n|s/.test(resize) || aspectRatio ? evY(event) : viewY(selection.y2);

                doResize();

                return false;

            }

            function doMove(newX1, newY1) {
                x2 = (x1 = newX1) + selection.width;
                y2 = (y1 = newY1) + selection.height;

                $.extend(selection, { x1: selX(x1), y1: selY(y1), x2: selX(x2),
                    y2: selY(y2) });

                update();

                options.onSelectChange(img, getSelection());
            }

            function movingMouseMove(event) {
                x1 = max(left, min(startX + evX(event), left + imgWidth - selection.width));
                y1 = max(top, min(startY + evY(event), top + imgHeight - selection.height));

                doMove(x1, y1);

                event.preventDefault();

                return false;
            }

            function startSelection() {
                adjust();

                x2 = x1;
                y2 = y1;

                doResize();

                resize = '';

                if ($outer.is(':not(:visible)'))
                    $box.add($outer).hide().fadeIn(options.fadeSpeed||0);

                shown = true;

                $(document).off('mouseup', cancelSelection)
                  .on('mousemove', selectingMouseMove).one('mouseup', docMouseUp);
                $box.off('mousemove', areaMouseMove);

                options.onSelectStart(img, getSelection());
            }

            function cancelSelection() {
                $(document).off('mousemove', startSelection);
                hide($box.add($outer));

                selection = { x1: selX(x1), y1: selY(y1), x2: selX(x1), y2: selY(y1),
                    width: 0, height: 0 };

                options.onSelectChange(img, getSelection());
                options.onSelectEnd(img, getSelection());
            }

            function imgMouseDown(event) {
                if (event.which != 1 || $outer.is(':animated')) return false;

                adjust();
                startX = x1 = evX(event);
                startY = y1 = evY(event);

                $(document).one('mousemove', startSelection)
                  .one('mouseup', cancelSelection);

                return false;
            }

            function windowResize() {
                doUpdate(false);
            }

            function imgLoad() {
                imgLoaded = true;

                setOptions(options = $.extend({
                    classPrefix: 'imgareaselect',
                    movable: true,
                    resizable: true,
                    parent: 'body',
                    onInit: function () {},
                    onSelectStart: function () {},
                    onSelectChange: function () {},
                    onSelectEnd: function () {}
                }, options));

                $box.add($outer).css({ visibility: '' });

                if (options.show) {
                    shown = true;
                    adjust();
                    update();
                    $box.add($outer).hide().fadeIn(options.fadeSpeed||0);
                }

                setTimeout(function () { options.onInit(img, getSelection()); }, 0);
            }

            var docKeyPress = function(event) {
                var k = options.keys, d, t, key = event.keyCode;

                d = !isNaN(k.alt) && (event.altKey || event.originalEvent.altKey) ? k.alt :
                  !isNaN(k.ctrl) && event.ctrlKey ? k.ctrl :
                    !isNaN(k.shift) && event.shiftKey ? k.shift :
                      !isNaN(k.arrows) ? k.arrows : 10;

                if (k.arrows == 'resize' || (k.shift == 'resize' && event.shiftKey) ||
                  (k.ctrl == 'resize' && event.ctrlKey) ||
                  (k.alt == 'resize' && (event.altKey || event.originalEvent.altKey)))
                {
                    switch (key) {
                        case 37:
                            d = -d;
                        case 39:
                            t = max(x1, x2);
                            x1 = min(x1, x2);
                            x2 = max(t + d, x1);
                            fixAspectRatio();
                            break;
                        case 38:
                            d = -d;
                        case 40:
                            t = max(y1, y2);
                            y1 = min(y1, y2);
                            y2 = max(t + d, y1);
                            fixAspectRatio(true);
                            break;
                        default:
                            return;
                    }

                    doResize();
                }
                else {
                    x1 = min(x1, x2);
                    y1 = min(y1, y2);

                    switch (key) {
                        case 37:
                            doMove(max(x1 - d, left), y1);
                            break;
                        case 38:
                            doMove(x1, max(y1 - d, top));
                            break;
                        case 39:
                            doMove(x1 + min(d, imgWidth - selX(x2)), y1);
                            break;
                        case 40:
                            doMove(x1, y1 + min(d, imgHeight - selY(y2)));
                            break;
                        default:
                            return;
                    }
                }

                return false;
            };

            function styleOptions($elem, props) {
                for (option in props)
                    if (options[option] !== undefined)
                        $elem.css(props[option], options[option]);
            }

            function setOptions(newOptions) {
                if (newOptions.parent)
                    ($parent = $(newOptions.parent)).append($box.add($outer));

                $.extend(options, newOptions);

                adjust();

                if (newOptions.handles != null) {
                    $handles.remove();
                    $handles = $([]);

                    i = newOptions.handles ? newOptions.handles == 'corners' ? 4 : 8 : 0;

                    while (i--)
                        $handles = $handles.add(div());

                    $handles.addClass(options.classPrefix + '-handle').css({
                        position: 'absolute',
                        fontSize: '0',
                        zIndex: `${zIndex + 1 || 1}`
                    });

                    if (!parseInt($handles.css('width')))
                        $handles.width(5).height(5);

                    if (o = options.borderWidth)
                        $handles.css({ borderWidth: o, borderStyle: 'solid' });

                    styleOptions($handles, { borderColor1: 'border-color',
                        borderColor2: 'background-color',
                        borderOpacity: 'opacity' });
                }

                scaleX = options.imageWidth / imgWidth || 1;
                scaleY = options.imageHeight / imgHeight || 1;

                if (newOptions.x1 != null) {
                    setSelection(newOptions.x1, newOptions.y1, newOptions.x2,
                      newOptions.y2);
                    newOptions.show = !newOptions.hide;
                }

                if (newOptions.keys)
                    options.keys = $.extend({ shift: 1, ctrl: 'resize' },
                      newOptions.keys);

                $outer.addClass(options.classPrefix + '-outer');
                $area.addClass(options.classPrefix + '-selection');
                for (i = 0; i++ < 4;)
                    $($border[i-1]).addClass(options.classPrefix + '-border' + i);

                styleOptions($area, { selectionColor: 'background-color',
                    selectionOpacity: 'opacity' });
                styleOptions($border, { borderOpacity: 'opacity',
                    borderWidth: 'border-width' });
                styleOptions($outer, { outerColor: 'background-color',
                    outerOpacity: 'opacity' });
                if (o = options.borderColor1)
                    $($border[0]).css({ borderStyle: 'solid', borderColor: o });
                if (o = options.borderColor2)
                    $($border[1]).css({ borderStyle: 'dashed', borderColor: o });

                $box.append($area.add($border).add($handles).add($areaOpera));

                if (IGH.BrowserConstants._isIE) {
                    if (o = $outer.css('filter').match(/opacity=([0-9]+)/))
                        $outer.css('opacity', o[1]/100);
                    if (o = $border.css('filter').match(/opacity=([0-9]+)/))
                        $border.css('opacity', o[1]/100);
                }

                if (newOptions.hide)
                    hide($box.add($outer));
                else if (newOptions.show && imgLoaded) {
                    shown = true;
                    $box.add($outer).fadeIn(options.fadeSpeed||0);
                    doUpdate();
                }

                aspectRatio = (d = (options.aspectRatio || '').split(/:/))[0] / d[1];

                if (options.disable || options.enable === false) {
                    $box.off('mousemove', areaMouseMove).off('mousedown', areaMouseDown);
                    $img.add($outer).off('mousedown', imgMouseDown);
                    $(window).off('resize', windowResize);
                }
                else if (options.enable || options.disable === false) {
                    if (options.resizable || options.movable)
                        $box.on('mousemove', areaMouseMove).on('mousedown', areaMouseDown);

                    if (!options.persistent)
                        $img.add($outer).on('mousedown', imgMouseDown);

                    $(window).on('resize', windowResize);
                }

                options.enable = options.disable = undefined;
            }

            this.remove = function () {
                $img.off('mousedown', imgMouseDown);
                $box.add($outer).remove();
            };

            this.getOptions = function () { return options; };

            this.setOptions = setOptions;

            this.getSelection = getSelection;

            this.setSelection = setSelection;

            this.update = doUpdate;

            this.doResize = doResize;

            $p = $img;

            while ($p.length) {
                zIndex = max(zIndex,
                  !isNaN($p.css('z-index')) ? $p.css('z-index') : zIndex);
                if ($p.css('position') == 'fixed')
                    position = 'fixed';

                $p = $p.parent(':not(body)');
            }

            zIndex = options.zIndex || zIndex;

            if (IGH.BrowserConstants._isIE)
                $img.attr('unselectable', 'on');

            $.imgAreaSelect.keyPress = IGH.BrowserConstants._isIE ||
            IGH.BrowserConstants._isSafari ? 'keydown' : 'keypress';

            if (IGH.BrowserConstants._isOpera)
                $areaOpera = div().css({ width: '100%', height: '100%',
                    position: 'absolute', zIndex: `${zIndex + 2 || 2}` });

            $box.add($outer).css({ visibility: 'hidden', position: position,
                overflow: 'hidden', zIndex: `${zIndex || 0}` });
            $box.css({ zIndex: `${zIndex + 2 || 2}` });
            $area.add($border).css({ position: 'absolute', fontSize: '0' });

            img.complete || img.readyState == 'complete' || !$img.is('img') ?
              imgLoad() : $img.one('load', imgLoad);
        };

        $.fn.imgAreaSelect = function (options) {
            options = options || {};

            this.each(function () {
                if ($(this).data('imgAreaSelect')) {
                    if (options.remove) {
                        $(this).data('imgAreaSelect').remove();
                        $(this).removeData('imgAreaSelect');
                    }
                    else
                        $(this).data('imgAreaSelect').setOptions(options);
                }
                else if (!options.remove) {
                    if (options.enable === undefined && options.disable === undefined)
                        options.enable = true;

                    $(this).data('imgAreaSelect', new $.imgAreaSelect(this, options));
                }
            });

            if (options.instance)
                return $(this).data('imgAreaSelect');

            return this;
        };

    })(jQuery);

    /*
     * Wiki Cart
     *
     * This is the graph shopping cart, where users can add graphs to their shopping cart for later merging
     * and viewing in iGraph
     */
    IGH.WikiCart = {
        IGRAPH_BASE: MonitorPortalRoot + "/igraph?",
        MESSAGE_TIMEOUT_IN_MS: 5 * 1000,
        REFRESH_UPDATE_IN_MS: 500,
        REFRESH_COUNT: 60,      // This times REFRESH_UPDATE_IN_MS is how often cart refreshes (30s)
        REFRESH_PERCENT_MAX_WIDTH: 24,
        CART_STORAGE_KEY: 'MPWcartState',
        NOT_NEEDED_PARAMS: ['forceRefresh', 'wiki', 'iGHrefresh', 'fixed', 'actionSource', 'Action', 'Version', 'actionSource1'],

        initialize: function() {
            this.createCart();
            this.codec = IGH.graph.createMWSCodec();
            this.messageTimer = null;
            this.refreshTimer = null;
            this.refreshCounter = 0;
            this.numItems = 0;
            this.isMouseOverCart = false;
            this.restoreState();
            this.updateCartVisibility();
            this.lookForAlarm();
        },

        createCart: function() {
            this.cart = jQuery(this.getCartHtml());
            this.cartDropDetector = jQuery('textarea', this.cart);
            this.cartMessage = jQuery('.MPWcartMessage', this.cart);
            this.cartCheckoutButton  = jQuery('.MPWcartButton .checkoutButton', this.cart);
            this.cartAddAllGraphsButton   = jQuery('.MPWcartButton .addGraphButton', this.cart);
            this.cartEmptyButton   = jQuery('.MPWcartButton .emptyCartButton', this.cart);
            this.grabEvents();
            this.cart.appendTo('body');
            WikiBulkSnapshot.injectSnapshotButtonIntoCart();
        },

        lookForAlarm: function() {
            if (!isOnTicketingSite()) {
                return;
            }
            this.state.alarms = this.state.alarms || [];

            // Continually look for Carnaval alarm on page until one is found.
            // SIM and T.Corp are rendered asynchronously and ticket overview may load after many seconds
            this.alarmTimer = setInterval(() => { this.lookForAlarmOnTicketingSite(); }, 1000);
        },

        lookForAlarmOnTicketingSite: function() {
            const ticketIdField = jQuery('.ticket-id,#context_bar tbody td:first,.breadcrumb .label:last').text();
            if (!ticketIdField) {
                return;     // Nothing found
            }

            const ticketId = ticketIdField.trim().split(' ')[0];   // First word in field is the id

            // Check if the ticket is already mentioned in persisted state, for quick restore
            const alarmInfo = this.state.alarms.find(entry => entry.ticketId === ticketId);
            if (alarmInfo) {
                clearInterval(this.alarmTimer);
                this.currentAlarm = alarmInfo.carnavalId;
                this.updateCarnavalAlarmState();
            } else {
                // Let's try and find carnaval link on page
                const MATCH_CARNAVAL_LINK = 'a[href*="http://carnaval.amazon.com/v1/viewObject.do"]';
                const MATCH_CARNAVAL_ON_TICKET_SITE = `.overview-content-children ${MATCH_CARNAVAL_LINK},#details_readonly ${MATCH_CARNAVAL_LINK},#issue-description-container ${MATCH_CARNAVAL_LINK}`;
                const url = jQuery(MATCH_CARNAVAL_ON_TICKET_SITE).attr('href');
                if (url) {
                    const carnavalId = extractQueryValue(url, 'name');
                    if (carnavalId) {
                        const MAX_ALARMS_FOR_TICKETS_TO_CACHE = 5;
                        clearInterval(this.alarmTimer);
                        this.state.alarms.push({ticketId, carnavalId});
                        if (this.state.alarms.length > MAX_ALARMS_FOR_TICKETS_TO_CACHE) {
                            this.state.alarms.shift();
                        }
                        this.currentAlarm = carnavalId;
                        this.updateCarnavalAlarmState();
                        return;
                    }
                }
            }
        },

        retrieveCarnavalAlarmState: function(effectiveAlarm, effectiveSuppression) {
            if (!effectiveSuppression) {
                if (effectiveAlarm) {
                    return 'ALERT';
                } else {
                    return 'OK';
                }
            } else {
                if (effectiveAlarm) {
                    return 'SUPPRESSED';
                } else {
                    return 'AT_RISK';
                }
            }
        },

        displayCarnavalAlarmState: function(alarmName, state) {
            const carnavalAlarmUrl = `http://carnaval.amazon.com/v1/viewObject.do?name=${alarmName}`;

            jQuery('.MPWcartDragDrop').hide();
            jQuery('#MPWcartAlarmState')
              .removeClass()
              .show()
              .text(state)
              .addClass(`MPWcartAlarmState${state}`)
              .attr('title', `State of alarm '${alarmName}' is '${state}`)
              .attr('href', carnavalAlarmUrl);
        },

        updateCarnavalAlarmState: async function() {
            // Don't display if Cart is not shown
            if (this.state.isCancelled || ! this.currentAlarm) {
                return;
            }

            this.displayCarnavalAlarmState(this.currentAlarm, 'loading');

            const url = `http://carnaval-api.amazon.com/?AlarmName=${this.currentAlarm}&HistoryType=StateUpdate&MaxRecords=1&Operation=DescribeAlarmHistory&Version=2010-10-16&ContentType=JSON`;
            const self = this;

            await GMUtils.gmXmlHttpRequest({
                method: 'GET',
                url: url,
                headers: {
                    'User-agent': 'Mozilla/5.0 (compatible) Greasemonkey/iGraphHelper.user.js'
                },
                onload: function(response) {
                    let state = 'UNKNOWN';
                    if (response.status === 200) {
                        const fileContent = JSON.parse(response.responseText);
                        const alarmHistoryItems = fileContent.DescribeAlarmHistoryResponse.DescribeAlarmHistoryResult.AlarmHistoryItems;
                        if (alarmHistoryItems.length > 0) {
                            const historyItem = alarmHistoryItems[0];
                            const historyData = JSON.parse(historyItem.HistoryData);
                            state = self.retrieveCarnavalAlarmState(historyData.effectiveAlarm === 'true', historyData.effectiveSuppression === 'true');
                        }
                    } else if (response.status === 401 && response.finalUrl) {
                        state = 'MIDWAY ERROR';
                    }

                    self.displayCarnavalAlarmState(self.currentAlarm, state);
                    self.updateRefreshCycle();
                }
            });
        },

        grabEvents: function() {
            var that = this;

            if (this.cart.on) {
                this.cart.on('mouseenter', function () {
                    that.isMouseOverCart = true;
                    return that.restoreState();
                });
                this.cart.on('mouseleave', function () {
                    that.isMouseOverCart = false;
                    return that.updateCartVisibility();
                });
            }

            this.cartCheckoutButton.on('click', function() { return that.checkout(); });
            this.cartAddAllGraphsButton.on('click', function() {
                return isIgraph ? that.addGraphToCart(getGraphUrl()) : that.addAllGraphsToCart();
            });
            this.cartEmptyButton.on('click', function() { return that.empty(false); });
            jQuery('.MPWcartCancel', this.cart).on('click', function() { return that.cancel(); });
            jQuery('.MPWrefreshCartIcon', this.cart).on('click', function() { return that.doRefreshTick(true); });
            jQuery('.MPWmanageCartCloseIcon', this.cart).on('click', function() { return that.closeCartManagerBox(); });
            jQuery('.MPWmanageCartOpenIcon', this.cart).on('click', function() { return that.openCartManagerBox(); });
            jQuery('.MPWmoveCartToBottomIcon', this.cart).on('click', function() { return that.moveCartToBottom(); });
            jQuery('.MPWmoveCartToTopIcon', this.cart).on('click', function() { return that.moveCartToTop(); });
        },

        cartDropEventDetected: function(event) {
            let graphArgs;
            let isExternal = false;
            event.preventDefault();
            this.cartDropDetector.val("");
            if (event.dataTransfer) {
                const droppedUrl = event.dataTransfer.getData('text');
                isExternal = true;
                if (/^https*:\/\/carnaval/.test(droppedUrl)) {
                    const carnavalId = extractQueryValue(droppedUrl, 'name');
                    if (carnavalId) {
                        this.currentAlarm = carnavalId;
                        this.updateCarnavalAlarmState();
                    }
                    return;
                } else {
                    graphArgs = getGraphArgsFromPageDeepLink(droppedUrl);
                }
            } else {
                graphArgs = getGraphArgs(IGH.hoveredImage, false);
            }

            if (graphArgs) {
                this.addGraphToCart(graphArgs, isExternal);
            }
        },

        graphDoubleClicked: function(img) {
            this.addGraphToCart(getGraphArgs(IGH.hoveredImage, false));
        },

        addGraphToCart: function(graphUrl, isExternal) {
            this.restoreState();
            if (this.isGraphPresentOnCart(graphUrl)) {
                this.displayMessage("iGraph already present on cart.", 3000);
                return false;
            }
            this.state.graphArgs.push(this.getGraphUrlForCart(graphUrl));
            this.storeState();
            if (!isExternal) {
                this.updateCartIcon();
            }
            this.showOpenedCart();
            this.displayMessage("iGraph has been added to cart.", 3000);
            return false;
        },

        removeGraphFromCart: function(graphUrl) {
            this.restoreState();
            const index = this.state.graphArgs.indexOf(this.getGraphUrlForCart(graphUrl));
            if (index >= 0 && index < this.state.graphArgs.length) {
                this.state.graphArgs.splice(index, 1);
            }
            this.storeState();
            this.updateCartIcon();
            this.updateCartManagerBox();
            this.updateCartVisibility();
            this.numItems > 0 ? this.openCartManagerBox() : this.closeCartManagerBox();
            this.displayMessage('graph has been removed from cart.', 3000);
            return false;
        },

        addAllGraphsToCart: function() {
            const graphArgs = this.state.graphArgs;
            this.restoreState();
            let removeCount=0, addedCount=0;
            const graphsOnPage = jQuery('img[src*="Action=GetGraph"],img[src*="getMetricWidgetImage"],  .MPWgraphInteractiveParams').filter((':not(.MPWmanageCartImg)'));
            for (let i = 0; i < graphsOnPage.length; i++) {
                const element = graphsOnPage[i];
                const graphUrl = getGraphArgs(element, false);
                if (graphUrl != null) {
                    const url = this.getGraphUrlForCart(graphUrl);
                    const index = graphArgs.indexOf(url);
                    if (index >= 0 && index < graphArgs.length) {
                        graphArgs.splice(index, 1);
                        removeCount++;
                    }
                    graphArgs.push(url);
                    addedCount++;
                }
            }
            this.state.graphArgs = graphArgs;

            //Display message according to the count of graphs added to cart.
            if (addedCount == removeCount) {
                this.restoreState();
                this.displayMessage('All ' + (addedCount > 1 ? addedCount : '') + ' graphs already present on cart.', 3000);
            }
            else if (removeCount == 0) {
                this.displayMessage('All ' + (addedCount > 1 ? addedCount : '') + ' graphs have been added to cart.', 3000);
            }
            else {
                this.displayMessage(removeCount + ' of ' + addedCount + ' graphs already present on cart, ' + (addedCount - removeCount) + ' more added.', 4000);
            }

            this.storeState();
            this.updateCartVisibility();
            this.updateCartManagerBox();
            this.openCartManagerBox();
        },

        isGraphPresentOnCart: function(url) {
            this.restoreState();
            const index = this.state.graphArgs.indexOf(this.getGraphUrlForCart(url));
            return index >= 0 && index < this.state.graphArgs.length ? true : false;
        },

        mergeGraphUrls: function(newGraphUrl) {
            this.restoreState();
            let mergedModel;
            for (let i = 0; i < this.state.graphArgs.length; i++) {
                const newModel = IGH.graph.DataModelHelper.modelFromUrl("/igraph?" + this.state.graphArgs[i]);
                if(mergedModel) {
                    IGH.graph.DataModelHelper.mergeModels(mergedModel, newModel);
                }
                else {
                    mergedModel = newModel;
                }
            }
            mergedModel.options().leftYAxis().showYAxis("true");
            mergedModel.options().rightYAxis().showYAxis("true");
            mergedModel.options().showXAxisLabel("true");
            mergedModel.options().showLegend("true");
            const finalGraphUrl = this.IGRAPH_BASE + this.codec.toQueryString(jQuery.extend(this.codec.encode(mergedModel), this.codec.encodeFunctions(mergedModel)));
            return finalGraphUrl;
        },

        displayMessage: function(msg, durationInMS) {
            var that = this;
            this.cartMessage.html(msg);
            this.cartMessage.fadeIn();
            clearTimeout(this.messageTimer);
            this.messageTimer = setTimeout(function() { that.cartMessage.fadeOut(); }, durationInMS);
        },

        checkout: function() {
            var iGraphUrl = this.mergeGraphUrls();
            if (iGraphUrl !== "") {
                window.open(iGraphUrl);
            }
            return false;
        },

        showOpenedCart: function() {
            this.state.isCancelled = false;
            this.state.isCartManagerOpened = true;
            this.storeState();
            this.updateCartVisibility();
        },

        openCartManagerBox: function() {
            const self = this;
            this.state.isCartManagerOpened = true;
            this.storeState();
            const n = this.numItems;
            const boxWidth = n < 2 ? 350 : (n === 2 ? 670 : 985);

            jQuery('.MPWmanageCartBox').show();
            jQuery('.MPWmanageCartCloseIcon').show();
            jQuery('.MPWmanageCartOpenIcon').hide();
            jQuery('.MPWmanageCartBox').animate({
                'margin-left': `-${boxWidth}px`,
                'width' : `${boxWidth}px`
            }, 500);
            this.updateCartManagerBox();
            this.updateRefreshCycle();
        },

        closeCartManagerBox: function() {
            this.state.isCartManagerOpened = false;
            this.storeState();
            jQuery('.MPWmanageCartCloseIcon').hide();
            jQuery('.MPWmanageCartOpenIcon').show();
            jQuery('.MPWmanageCartBox').animate({
                'margin-left': '-36px',
                'width' : '36px'
            }, 500);
            this.updateRefreshCycle();
        },

        graphArgsToImageUrl: function(graphArgs) {
            const WIDTH = 300;
            const HEIGHT = 160;
            const queryString = IGH.util.removeQueryParams(graphArgs , ['Action', 'Version', 'WidthInPixels', 'HeightInPixels', 'ShowLegend', 'LabelLeft', 'LabelRight', 'width', 'height']);
            const params = IGH.util.parseQueryParams(graphArgs);
            let path;

            // Check if it's a CloudWatch graph
            if (params.metricWidget) {
                path = `/cw/getMetricWidgetImage?${queryString}&width=${WIDTH}&height=${HEIGHT}`;
            } else {
                path = `/mws?Action=GetGraph&Version=2007-07-07&${queryString}&ShowLegend=false&WidthInPixels=${WIDTH}&HeightInPixels=${HEIGHT}`;
            }

            return MonitorPortalRoot + path;
        },

        updateCartManagerBox: function() {
            var self = this;
            this.restoreState();
            var innerHtml = '<table><tr>';
            for (var i = 0; i < this.numItems; i++) {
                var graphArgs = this.state.graphArgs[i];
                var graphPreviewUrl = this.graphArgsToImageUrl(graphArgs);
                innerHtml += '<td>' +
                  '<div class="MPWremoveItem MPWbutton" data-index="' + i + '" title="Remove this graph from cart."></div>' +
                  '<img class="MPWmanageCartImg" src="' + graphPreviewUrl + '">' +
                  '</td>';
            }
            innerHtml += '</tr></table>';
            jQuery('.MPWmanageCartGraphContainer').html(innerHtml);
            jQuery('.MPWmanageCartGraphContainer .MPWbutton').on('click', function () {
                self.removeGraphFromCart(self.state.graphArgs[jQuery(this).attr('data-index')]);
            });
        },

        moveCartToBottom: function() {
            this.state.position = 'bottom';
            this.storeState();
            jQuery('.MPWcart').css('top', 'initial').css('bottom', '40px');
            jQuery('.MPWmoveCartToBottomIcon').hide();
            jQuery('.MPWmoveCartToTopIcon').show();
        },

        moveCartToTop: function() {
            this.state.position = 'top';
            this.storeState();
            jQuery('.MPWcart').css('top', '40px').css('bottom', 'initial');
            jQuery('.MPWmoveCartToBottomIcon').show();
            jQuery('.MPWmoveCartToTopIcon').hide();
        },

        empty: function(isCancelled) {
            this.state = this.state || { alarms: [] };
            this.state.graphArgs = [];
            this.state.isCartManagerOpened = false;
            this.state.isCancelled = isCancelled;
            this.numItems = 0;
            this.displayNumItems();
            this.storeState();
            this.cartMessage.hide();
            this.closeCartManagerBox();
            return false;
        },

        cancel: function() {
            this.state.isCancelled = true;
            this.storeState();
            this.isMouseOverCart = false;
            this.updateCartVisibility();
            return false;
        },

        updateRefreshCycle: function() {
            // If there are cart items and an open cart manager, or a current alarm make sure refresh timer is started
            if ((this.numItems > 0 && this.state.isCartManagerOpened) || this.currentAlarm) {
                if (! this.refreshTimer) {
                    this.refreshCounter = 0;
                    this.refreshTimer = setInterval(() => {
                        this.doRefreshTick();
                    }, this.REFRESH_UPDATE_IN_MS);

                    this.doRefreshTick(true);
                    jQuery('.MPWrefreshCounter,.MPWtimeSinceLastRefresh').show();
                }
            } else {
                // There shouldn't be a timer, stop it
                if (this.refreshTimer) {
                    clearInterval(this.refreshTimer);
                    this.refreshTimer = null;
                }

                jQuery('.MPWrefreshCounter,.MPWtimeSinceLastRefresh').hide();
            }
        },

        doRefreshTick: function(reset) {
            this.refreshCounter = reset ? 0 : (this.refreshCounter + 1) % this.REFRESH_COUNT;

            // When down to zero, refresh the graphs and alarm state
            if (this.refreshCounter === 0) {
                this.lastRefreshTimestamp = new Date();
                jQuery('.MPWmanageCartImg').each(function() {
                    _refreshImg(this);
                });
                this.updateCarnavalAlarmState();
            }

            // Update the countdown indicator bar
            const proportionRemaining = 1 - this.refreshCounter / this.REFRESH_COUNT;
            jQuery('.MPWrefreshCounterPercent').width(Math.round(proportionRemaining * this.REFRESH_PERCENT_MAX_WIDTH) + 'px');

            // Display seconds since last refresh
            if (this.lastRefreshTimestamp) {
                const now = new Date();
                const secondsSinceLastRefresh = Math.round((now.getTime() - this.lastRefreshTimestamp.getTime()) / 1000);
                jQuery('.MPWtimeSinceLastRefresh').text(`${secondsSinceLastRefresh}s ago`);
            }

            return false;
        },

        updateCartVisibility: function() {
            this.displayNumItems();
            if (this.isMouseOverCart || !this.state.isCancelled) {
                this.cart.show();
                jQuery('.MPWcartButton').show();
                this.state.isCartManagerOpened ?  this.openCartManagerBox() : this.closeCartManagerBox();
                this.state.position === 'bottom' ?  this.moveCartToBottom() : this.moveCartToTop();
            }
            else {
                this.cart.hide();
                jQuery('.MPWcartButton').hide();
            }
        },

        displayNumItems: function() {
            jQuery('.MPWcartNumItems').text(this.numItems == 0 ? '' : this.numItems + '');
            if (this.numItems) {
                jQuery('.MPWcartButton input').prop('disabled', false).css('opacity', '1').css('cursor', 'pointer');
                jQuery('.MPWcartNumItems').css('font-size', this.numItems <= 99 ? '25px' : '17px')
                  .css('top' , this.numItems <= 99 ? '44px' : '49px');
            }
            else {
                jQuery('.MPWcartButton input:not(.addGraphButton)').prop('disabled', true).css('opacity', '0.50')
                  .css('cursor', 'not-allowed');
            }
        },

        storeState: function() {
            if (localStorage) {
                localStorage.setItem(this.CART_STORAGE_KEY, JSON.stringify(this.state));
                this.numItems = this.state.graphArgs.length;
            }
        },

        restoreState: function() {
            try {
                this.state = JSON.parse(localStorage.getItem(this.CART_STORAGE_KEY));
                if (!this.state) {
                    this.empty(true);
                }
                this.state.graphArgs = this.state.graphArgs.filter(Boolean); // Remove any empty entries
                this.numItems = this.state.graphArgs.length;
                this.displayNumItems();
            } catch(e) {
                this.empty(true);
            }
        },

        updateCartIcon: function() {
            var graphUrl = isIgraph ? getGraphUrl() : getGraphArgs(IGH.hoveredImage, false);
            var isGraphPresentOnCart = this.isGraphPresentOnCart(graphUrl);
            jQuery('#iGraphCartIcon').addClass(isGraphPresentOnCart ? 'removeFromCartIcon' : 'addToCartIcon');
            jQuery('#iGraphCartIcon').removeClass(isGraphPresentOnCart ? 'addToCartIcon' : 'removeFromCartIcon');
            jQuery('#iGraphCartIcon').attr('title', isGraphPresentOnCart ? 'Remove from iGraph Shopping Cart.'
              : 'Add to Shopping Cart, for merging with other graphs, or live dashboard.');
        },

        getGraphUrlForCart: function(url) {
            return url ? IGH.util.removeQueryParams(IGH.util.removeDomainFromUrl(url), this.NOT_NEEDED_PARAMS).replace(/[&]+/g, '&').replace('=-PT0H','=P0D') : null;
        },

        getCartHtml: function() {
            return '<div class="MPWcart">' +
              '<textarea name="MPWcart" ondrop="iGraphHelper.IGH.WikiCart.cartDropEventDetected(event)"></textarea>' +
              '<span class="MPWcartDragDrop">Drag/drop or double click<br>graphs here for merging.</span>' +
              '<a id="MPWcartAlarmState" target="_blank"></a>' +
              '<span class="MPWcartNumItems">0</span>' +
              '<span class="MPWcartBigIcon" title="Drag/drop or double click graphs here for merging."></span>' +
              '<span class="MPWmoveCartToBottomIcon" title="Position cart at bottom right of page"></span>' +
              '<span class="MPWmoveCartToTopIcon" title="Position cart at top right of page"></span>' +
              '<div class="MPWcartMessage"></div>' +
              '<div class="MPWcartButton">' +
              '<input type="submit" class="MPWbutton primary checkoutButton" value="Merge graphs" title="Merge all graphs in cart and open in new window.">' +
              '<input type="submit" class="MPWbutton addGraphButton" value="Add all graphs" title="Add all graphs from this page to the cart (only manually refreshed snapshots will add).">' +
              '<input type="submit" class="MPWbutton emptyCartButton" value="Empty cart" title="Remove all graphs from cart.">' +
              '</div>' +
              '<a class="MPWcartCancel" href="#"></a>' +
              '<div class="MPWmanageCartBox">' +
              '<span class="MPWmanageCartCloseIcon"></span>' +
              '<span class="MPWmanageCartOpenIcon"></span>' +
              '<span class="MPWrefreshCartIcon"></span>' +
              '<span class="MPWtimeSinceLastRefresh" title="Time since the last cart refresh was triggered"></span>' +
              '<div class="MPWrefreshCounter">' +
              '<div class="MPWrefreshCounterPercent"></div>' +
              '</div>' +
              '<div class="MPWmanageCartGraphContainer"></div>' +
              '</div>' +
              '</div>';
        }
    };

    /*
     * TT integration, for displaying graphs within TT communication
     */
    IGH.TT = {
        CM_COMMUNICATION_TAB: "#tab-communication",
        CM_REFRESH_COMMUNICATION: "#update_communication_link",
        REFRESH_COMMUNICATION: "#update_chatter_link",
        SEARCH_RESULTS_HEADERS: "#search_results thead th",
        SEARCH_RESULTS_ROWS: "#search_results tbody tr",
        CORRESPONDENCE_TAB: "#tab_correspondence",
        CORRESPONDENCE_VIEW_ROWS: "#correspondence_view tr",
        CHATTER_TAB: "#tab_chatter",
        CHATTER_VIEW_ROWS: "#chatter_view tr",
        LAST_SAVED_TT_FIELD: "iGraphHelper.lastSavedTT",
        OVERVIEW_TAB_CONTENT: "#tab-overview",
        SEVERITY_COLORS: { '1': '#990000', '2': '#993333', '3': '#4881b6', '4': '#52789a', '5': '#666666' },
        PORTAL: "https://monitorportal.amazon.com",
        SEARCH_RESULTS_BUTTONS: "#hd table tr td:eq(1)",
        SIM_TICKETING: "SIM Ticketing",

        initialize: function() {
            if (this.isOnTT()) {
                this.addTTVerticalLines();
                this.displayEmbeddedImages();
                var oldRegisterActionMenus = registerActionMenus;
                registerActionMenus = function() {
                    oldRegisterActionMenus();
                    IGH.TT.displayCorrespondenceTabIfNeeded();
                    IGH.TT.displayEmbeddedImages();
                }
                this.trapTTSaves();
            }
            else if (this.isOnTTSearch()) {
                this.addTTSearchVerticalLines();
            }
            else if (this.isOnCM()) {
                this.addCMVerticalLines();
                this.displayEmbeddedImages();
                var old_convert_chatter_time = convert_chatter_time;
                convert_chatter_time = function(show_timezone) {
                    old_convert_chatter_time(show_timezone);
                    IGH.TT.displayCorrespondenceTabIfNeeded();
                    IGH.TT.displayEmbeddedImages();
                }
            }
            else if (this.isOnSIMTicketing()) {
                setInterval(function() {
                    IGH.TT.addSimTVerticalLines()
                }, 3000);

                // SIM Ticketing can update content at any time, so simplest is to periodically (every second) look for embedded images
                setInterval(function() {
                    IGH.TT.displayEmbeddedImages();
                }, 1000);
            }
        },

        displayEmbeddedImages: function() {
            $('a[href*="monitorportal.amazon.com/snap"],a[href*=iGraphSnapshot],a[href*=TT-EMBED]').filter(':not(.tt_button , a[href*=iGraphAnalyzer])').each(function(link) {
                if ($(this).children(".expandedIGraph,img").length == 0) {
                    const imgUrl = $(this).attr('href');
                    const sourceUrl = extractQueryValue(imgUrl, 'sourceUrl');
                    const sourceUrlParam = sourceUrl ? `data-sourceUrl="${decodeURIComponent(sourceUrl)}"` : '';
                    $(this).append(`<br/><div class="expandedIGraph" style="display: inline-block;">
                                <img src="${imgUrl}" ${sourceUrlParam} title="Inlined image provided by iGraph Helper"/>
                            </div><br/>`);
                }
            })
        },

        trapTTSaves: function() {
            $("#save-button").on('click', function() { IGH.TT.recordSavedTTId(); });
        },

        currentTTId: function() {
            return $("#case_id").val();
        },

        recordSavedTTId: function() {
            this.localStore(this.LAST_SAVED_TT_FIELD, this.currentTTId());
        },

        localStore: function(id, val) {
            if (typeof localStorage !== 'undefined') {
                if (typeof val !== 'undefined') {
                    localStorage.setItem(id, val);
                }
                else {
                    return localStorage.getItem(id);
                }
            }
            return null;
        },

        displayCorrespondenceTabIfNeeded: function() {
            if ($(this.OVERVIEW_TAB_CONTENT).is(':visible') && (this.localStore(this.LAST_SAVED_TT_FIELD) === this.currentTTId()) &&
              (($(this.CHATTER_VIEW_ROWS).length > 1) || ($(this.CORRESPONDENCE_VIEW_ROWS).length > 2))) {
                $(this.CHATTER_TAB).trigger('click');
                $(this.CORRESPONDENCE_TAB).trigger('click');
            }
            this.localStore(this.LAST_SAVED_TT_FIELD, null);
        },

        isOnTT: function() {
            return (($(this.REFRESH_COMMUNICATION).length || $(this.CORRESPONDENCE_TAB).length)
              && typeof registerActionMenus !== 'undefined');
        },

        isOnTTSearch: function() {
            return $(this.SEARCH_RESULTS_ROWS).length > 0;
        },

        isOnCM: function() {
            return ($(this.CM_REFRESH_COMMUNICATION).length && typeof convert_chatter_time !== 'undefined');
        },

        isOnSIMTicketing: function() {
            return this.SIM_TICKETING === document.title;
        },

        getGmtOffset: function(date) {
            var gmtOffset = date.replace(/.*GMT/, '').replace(')', '').substring(0, 5);
            gmtOffset = gmtOffset.substring(0, 3) + ':' + gmtOffset.substring(3);
            return gmtOffset;
        },

        getTTColor: function(severity) {
            var color = this.SEVERITY_COLORS[severity];
            return color ? color : 'red';
        },

        addTTVerticalLines: function() {
            var ttNum = $.trim($('#context_bar td:eq(0)').text().replace('TT', ''));
            var severity = parseInt($('#context_bar td:eq(1)').text());
            var start = $('#context_bar td:eq(2)').text();
            var end = $('#context_bar td:eq(3)').text();
            var gmtOffset = this.getGmtOffset($('#context_bar th:eq(2)').text());
            var verticalLineDef = IGH.util.createVerticalLine(ttNum, severity, this.ttDateToXmlDate(start, gmtOffset), this.ttDateToXmlDate(end, gmtOffset), gmtOffset)
            $('<div style="float: left; margin-top: 12px;"><a class="button iGraphVerticalLineButton" style="margin-left: 20px; font-weight: normal;">iGraph Vertical Lines...</a>' +
              '&nbsp;<span style="font-size: 12px;">(<a target="_blank" title="Open blank iGraph with vertical lines" href="' + this.iGraphUrl(verticalLineDef) + '">iGraph</a>)</span></div>').insertBefore('#nav-section');

            IGH.util.buttonAcknowledgmentMessageUtil(
              '.iGraphVerticalLineButton',
              "Vertical lines copied to clipboard",
              function () {
                  GMUtils.setClipboard(verticalLineDef);
              }
            );
        },

        convertDateToIsoFormat: function (dateStr) {
            let parts = dateStr.match(/(\d{4}-\d{2}-\d{2}) (\d{1,2}):(\d{2}):(\d{2}) (AM|PM)/);
            if (!parts) return null;

            let date = parts[1];
            let hours = parseInt(parts[2], 10);
            let minutes = parts[3];
            let seconds = parts[4];
            let ampm = parts[5];

            if (ampm === 'PM' && hours < 12) hours += 12;
            if (ampm === 'AM' && hours === 12) hours = 0;

            return new Date(`${date}T${hours.toString().padStart(2, '0')}:${minutes}:${seconds}Z`).toISOString();
        },

        addSimTVerticalLines: async function () {
            var container = $('.created-date') // This is the div that we will be injecting into
            var iGraphVerticalLineContainerClass = 'iGraphVerticalLineContainer'

            if($(`.${iGraphVerticalLineContainerClass}`).length < 1 && container.length > 0) { // Verify we have not already added our div, and that the container we need is present
                try {
                    var ticketDetails = $('.issue-detail-side')
                    var ttNum = ticketDetails.find('.ticket-id').text()
                    var severity = ticketDetails.find('.issue-summary-severity').find('.info-value').text()
                    var start = ticketDetails.find('.created-date').find('.info-value')
                    var startDateFormatted
                    try {
                        startDateFormatted = new Date(this.SimTDateToXmlDate(start[0].innerText)).toISOString();
                    } catch(e) {
                        startDateFormatted = this.convertDateToIsoFormat(this.SimTDateToXmlDate(start[0].innerText));
                    }

                    if (ttNum.match(/INSIGHTS-TT-|SIMTicketing-/)) {
                        const ttNumFromLocation = document.location.pathname.split('/')[1];

                        if (ttNumFromLocation) {
                            ttNum += ` - ${ttNumFromLocation}`;
                        }
                    }

                    var igraphVerticalLineDef = IGH.util.createVerticalLine(ttNum, severity, startDateFormatted)
                    var igraphButtonClass = 'iGraphVerticalLineButton'
                    var igraphButton = `<a class="button ${igraphButtonClass}" style="font-weight: normal; cursor: pointer;">iGraph</a>`
                    var igraphLink = `<span style="font-size: 12px;">(<a target="_blank" title="Open blank iGraph with vertical lines" href="${this.iGraphUrl(igraphVerticalLineDef)}">iGraph</a>)</span>`

                    var cloudwatchButtonClass = 'cloudwatchVerticalLineButton'
                    var cloudwatchVerticalLineDef = IGH.util.createCloudWatchVerticalLine(ttNum, severity, startDateFormatted)
                    var cloudwatchButton = `<a class="button ${cloudwatchButtonClass}" style="font-weight: normal; cursor: pointer;">Cloudwatch</a>`

                    container.prepend(`<div class="display-mode-container ${iGraphVerticalLineContainerClass}" style="position: relative;">` +
                        `<div class="info-key" style="font-weight: 700;">Vertical Lines:</div>` +
                        `<div class="info-value"><div>${cloudwatchButton}<span> | </span>${igraphButton}&nbsp;${igraphLink}</div></div>`)

                    IGH.util.buttonAcknowledgmentMessageUtil(
                        `.${igraphButtonClass}`,
                        "Vertical lines copied to clipboard",
                        function () {
                            GMUtils.setClipboard(igraphVerticalLineDef);
                        }
                    );
                    IGH.util.buttonAcknowledgmentMessageUtil(
                        `.${cloudwatchButtonClass}`,
                        "Vertical lines copied to clipboard",
                        function () {
                            GMUtils.setClipboard(cloudwatchVerticalLineDef);
                        }
                    );
                } catch (err) {
                    console.log("Error adding vertical lines", err)
                }
            }
        },

        getTTSearchColIndex: function() {
            var colIndex = {};
            $(this.SEARCH_RESULTS_HEADERS).each(function(index, col) {
                  var colText = $.trim($(col).text())
                  if (colText != "") {
                      colIndex[colText] = index;}
              }
            );
            return colIndex;
        },

        getCol: function(row, colName, colIndex) {
            var col = colIndex[colName];
            if (col) {
                return $.trim($('td:eq(' + col + ')', row).text());
            }
            return null;
        },

        addTTSearchVerticalLines: function() {
            var tickets = $(this.SEARCH_RESULTS_ROWS);
            var colIndex = this.getTTSearchColIndex();
            var verticalLineDef = '';
            var sep = '';
            tickets.each(function() {
                var createDate = IGH.TT.getCol(this, "Create Date", colIndex);
                var ttNum =  IGH.TT.getCol(this, "Case ID", colIndex);
                var severity =  IGH.TT.getCol(this, "Impact", colIndex);
                var desc =  IGH.TT.getCol(this, "Description", colIndex);
                if (createDate != null) {
                    var gmtOffset = IGH.TT.getGmtOffset(createDate);
                    verticalLineDef += sep + 'TT ' + ttNum + '[' + severity + ']: ' + encodeURIComponent(desc) + ' #color=' + IGH.TT.getTTColor(severity) + ' @' + IGH.TT.ttDateToXmlDate(createDate, gmtOffset);
                    sep = ',';
                }
            });
            if (verticalLineDef != '') {
                $('<div style="display: inline-block; margin-top: 18px;">' +
                  'iGraph: ' +
                  '<a class="button iGraphVerticalLineButton" title="View iGraph vertical line definitions for search results (added by iGraph Helper)"><span>Vertical Lines...</span></a>' +
                  '<a class="button iGraphEmbedButton" title="Embed an iGraph in search results page (added by iGraph Helper)"><span>Embed...</span></a>' +
                  '</div>').appendTo(this.SEARCH_RESULTS_BUTTONS);
                $('.iGraphVerticalLineButton').on('click', function() { prompt("Vertical Lines for pasting into iGraph", verticalLineDef);} );
                $('.iGraphEmbedButton').on('click', function() {
                    var iGraphUrl = prompt("Paste iGraph URL for graph to embed", "");
                    IGH.TT.addTTIGraph(verticalLineDef, iGraphUrl.replace(/.*[?]/, ""));
                });
                this.addTTIGraph(verticalLineDef);
            }
        },

        addTTIGraph: function(verticalLineDef, iGraph) {
            var queryParams = IGH.util.parseQueryParams();
            var fullTTLink;
            if (!iGraph) {
                if (queryParams['SchemaName1']) {
                    fullTTLink = window.location.href;
                    iGraph = IGH.util.removeQueryParams(window.location.search.replace(/^[?]/, ""), ["search"]);
                }
                else {
                    if (localStorage && localStorage.getItem("iGraph")) {
                        iGraph = localStorage.getItem("iGraph");
                        fullTTLink = window.location.href + '&' + iGraph;
                    }
                }
            }
            else {
                fullTTLink = window.location.href.replace(/search=Search..*/, 'search=Search!') + '&' + iGraph;
            }

            if (iGraph) {
                if (localStorage) {
                    localStorage.setItem("iGraph", iGraph);
                }
                var graph = this.iGraph(verticalLineDef, iGraph);
                $('.iGraphContainer,.iGraphWikiButtonContainer').remove();
                $('<div class="iGraphContainer"><a href="#" class="iGraphRemove">Remove this graph</a><br>' + graph + '</div>').insertBefore('#search_results');
                $('<div style="display: inline-block; margin-top: 18px;" class="iGraphWikiButtonContainer">' +
                  '<a class="button iGraphWikiButton" title="View Wiki code for dashboarding this page (added by iGraph Helper)"><span>Wiki...</span></a>' +
                  '</div>').appendTo(this.SEARCH_RESULTS_BUTTONS);
                $('.iGraphRemove').on('click', function() {
                    $('.iGraphContainer').remove();
                    if (localStorage) {
                        localStorage.removeItem("iGraph");
                    }
                });
                $('.iGraphWikiButton').on('click', function() {
                    var sanitizedLink = fullTTLink.replace(/\[/g, "%5B").replace(/\]/g, "%5D") + "#bd{{StringLinks/Inline|auto=on|width=1200|height=450}}";
                    IGH.util.lightbox('<span>Copy and paste this into Wiki (make sure you have <a target="_blank" href="https://w.amazon.com/index.php/StringLinks">StringLinks</a> installed)</span><br>' +
                      '<textarea class="iGraphWikiLink" style="width: 500px; height: 280px;">[' + sanitizedLink + ' My TT Embedded Graph (please change this text)]</textarea>', 500, 300);
                    $('.iGraphWikiLink').trigger('select');
                });
                decorateGraphs();
            }
        },

        ttDateToXmlDate: function(date, offset = "") {
            var m = date.match(/(\d+)-(\d+)-(\d+) (\d+):(\d+):(\d\d)( ?..)/);
            if (m) {
                m[4] = m[4] == "12" ? "00" : m[4];     // Convert '12' hour to '00' for 24 hour clock
                return m[1] + '-' + m[2] + '-' + m[3] + 'T' + (m[7].trim().toUpperCase() == "AM" ? m[4] : 12 + parseInt(m[4])) + ':' + m[5] + ':' + m[6] + offset;
            }
            return "now";
        },

        SimTDateToXmlDate: function(date) {
            /*
            It expects newline separated string.
            From something like
                2023-11-13T10:29:48-06:00
                2023-11-13T16:29:48Z
                Epoch: 1699892988
            return the first line which is something SimT user configured for themselves.
            The rest two lines are optional if user configured to show those.
            */
            return date.split('\n')[0]
        },


        addCMVerticalLines: function() {
            var cmId = $('#cm_id').text();
            var scheduledStart = $('#cm_scheduled_start').text();
            var scheduledEnd = $('#cm_scheduled_end').text();
            var actualStart = $('#cm_actual_start').text();
            var actualEnd = $('#cm_actual_end').text();
            var verticalLineDef = '(' + scheduledStart + ',CM ' + cmId + ' scheduled:' + this.getReadableDateFromXmlDate(scheduledEnd) + ' @' + scheduledEnd + ')';
            $('<div style="float: left; margin-top: 18px;"><a class="button iGraphVerticalLineButton" style="margin-left: 20px; font-weight: normal;">iGraph Vertical Lines...</a>' +
              '&nbsp;<span style="font-size: 12px;">(<a target="_blank" title="Open blank iGraph with vertical lines" href="' + this.iGraphUrl(verticalLineDef) + '">iGraph</a>)</span></div>').insertAfter('#header .logo');
            if (actualStart != '') {
                verticalLineDef += ',(' + actualStart + ',CM ' + cmId + ' actual:' + this.getReadableDateFromXmlDate(actualEnd) + ' @' + actualEnd + ')';
            }
            $('.iGraphVerticalLineButton').on('click', function() { prompt("Vertical Lines for pasting into iGraph", verticalLineDef);} );
        },

        getReadableDateFromXmlDate: function(xmlDate) {
            return xmlDate == "now" ? xmlDate : xmlDate.replace(/-/g, '/').replace('T', ' ').replace(/:..Z/, "") + " UTC";
        },

        iGraphUrl: function(verticalLineDef) {
            return this.PORTAL + '/igraph?VerticalLine1=' + encodeURIComponent(verticalLineDef);
        },

        iGraph: function(verticalLineDef, graphParams) {
            var allParams =  encodeURIComponent(verticalLineDef) +'&' + graphParams;
            return '<a class="iGraph" target="_blank" href="' + this.PORTAL + '/igraph?VerticalLine1=' + allParams + '"><img src="' + this.PORTAL + '/mws?Action=GetGraph&Version=2007-07-07&VerticalLine1=' + allParams + '" style="box-shadow: 5px 5px 17px rgb(136, 136, 136); margin-left: 50px;"></a>';
        }
    };

    IGH.util = typeof IGH.util === 'undefined'  ? {} : IGH.util;
    IGH.graph = typeof IGH.graph === 'undefined'  ? {} : IGH.graph;
    IGH.MWS = typeof IGH.MWS === 'undefined'  ? {} : IGH.MWS;

    // Some constants
    IGH.KEY_CODE_ENTER = 13;

    // For search syntax
    IGH.SEARCH_FIELD_DELIMITER = "=";
    IGH.SEARCH_EXACT_MATCH_DELIMITER = "$";
    IGH.SEARCH_CLAUSE_SEPARATOR = " ";
    IGH.SEARCH_AND_CLAUSE = "AND";
    IGH.SEARCH_NOT_CLAUSE = "NOT";
    IGH.SEARCH_NOT_CLAUSE_SHORT = "!";
    IGH.SEARCH_OR_CLAUSE = "OR";
    IGH.SEARCH_OPEN_PAREN = "(";
    IGH.SEARCH_CLOSE_PAREN = ")";

    IGH.SCHEMA_NAME_SEARCH_FIELD          = "schemaname";
    IGH.SCHEMA_NAME_ERROR_LOG             = "ErrorLog";
    IGH.SCHEMA_NAME_SNITCH                = "Snitch";
    IGH.SCHEMA_NAME_PAQ                   = "PAQ";
    IGH.SCHEMA_NAME_SUBSCRIPTION_SERVICES = "SubscriptionServices";

    IGH.METRIC_FIELD_HOST_GROUP     = "HostGroup";
    IGH.METRIC_FIELD_OPERATION_NAME = "OperationName";
    IGH.METRIC_FIELD_OPERATION      = "Operation";
    IGH.METRIC_FIELD_SERVICE_NAME   = "ServiceName";
    IGH.METRIC_FIELD_SERVICE        = "Service";
    IGH.METRIC_FIELD_SIGNATURE_NAME = "SignatureName";
    IGH.METRIC_FIELD_SIGNATURE      = "Signature";

    IGH.METRIC_VALUE_NONE           = "NONE";

    IGH.PERIOD_FIELD = "period";
    IGH.STAT_FIELD = "stat";
    IGH.METRIC_ID_SEPARATOR = "|";

    // MWS API
    IGH.MWS_BASE_URL = "/mws";
    IGH.MWS_ARG_ACTION = "Action";
    IGH.MWS_ARG_VERSION = "Version=2007-07-07";
    IGH.MWS_ARG_SCHEMA_NAME  = "SchemaName";
    IGH.MWS_ARG_PERIOD       = "Period";
    IGH.MWS_ARG_STAT         = "Stat";
    IGH.MWS_ACTION_GET_GRAPH = "GetGraph";
    IGH.MWS_ACTION_GET_METRIC_DATA = "GetMetricData";

    IGH.QPLOT_ARG_SCHEMA_NAME = "origin";
    IGH.QPLOT_ARG_PERIOD      = "period";
    IGH.QPLOT_ARG_STAT        = "statname";

    IGH.SUBMENU_PROPERTY = "submenu";

    IGH.IGRAPH_BASE_URL = "/igraph";
    IGH.IGRAPH_SEARCH_BASE_URL = "/igraph/search";

    /*
     * Lowercase the first letter of the parameter
     */
    IGH.util.getFunctionName = function(parameter){
        // lowercase the first letter ( for method names)
        return parameter.charAt(0).toLowerCase() + parameter.substring(1);
    };

    /*
     * Uppercase the first letter of the parameter
     */
    IGH.util.getAttributeName = function(parameter){
        // uppercase the first letter ( for method names)
        return parameter.charAt(0).toUpperCase() + parameter.substring(1);
    };
    /**
     *  constants that belong to the MWS API
     */
    // How we represent boolean in calls to MWS
    IGH.MWS.Boolean = {
        TRUE: "true",
        FALSE: "false"
    };

    //Defines valid time ranges types
    IGH.MWS.TimeRangeType = {
        FIXED: "Fixed",
        RELATIVE: "Relative",
        NATURAL: "Natural"
    };

    IGH.MWS.LegendPlacement = {
        BOTTOM: "bottom",
        RIGHT: "right"
    };

    IGH.MWS.GraphType = {
        BITMAP: "bitmap",
        ZOOMER: "zoomer",
        PIE: "pie",
        BAR: "bar"
    };

    IGH.MWS.MetricResult = {
        METRIC_DATA: "MetricData",
        NO_DATA: "NoData",
        NO_METRIC: "NoMetric",
        PROCESSING_ERROR: "ProcessingError",
        THROTTLED: "Throttled"
    };

    IGH.MWS.Operations = {
        ADDITION: "+",
        DIVISION: "/",
        MULTIPLICATION: "*",
        SUBTRACTION: "-"
    };

    IGH.MWS.StatOptions = {
        VAL: "Val",
        PREDICTIONS: "Predictions"
    };

    IGH.MWS.YAxisPreference = {
        LEFT: "left",
        RIGHT: "right"
    };

    IGH.MWS.AggregationFunction = {
        AVERAGE: "average",
        MINIMUM: "minimum",
        MAXIMUM: "maximum",
        MEDIAN: "median",
        SUM: "sum",
        WEIGHTED_AVERAGE: "weightedAverage"
    };

    IGH.MWS.ValueUnit = {
        NANOSECOND: "nanosecond",
        MICROSECOND: "microsecond",
        MILLISECOND: "millisecond",
        SECOND: "second",
        MINUTE: "minute",
        HOUR: "hour",
        DAY: "day",
        WEEK: "week",
        BYTE: "byte",
        KILOBYTE: "kilobyte",
        MEGABYTE: "megabyte",
        GIGABYTE: "gigabyte",
        TERABYTE: "terabyte",
        KIBIBYTE: "kibibyte",
        MEBIBYTE: "mebibyte",
        GIBIBYTE: "gibibyte",
        TEBIBYTE: "tebibyte",
        CPUSECOND: "cpuSecond",
        REQUEST: "request",
        PAGE: "page",
        ORDER: "order",
        PERCENT: "percent",
        FILE: "file",
        NONE: "none"
    };

    IGH.MWS.QS = {
        SCHEMA_NAME: "SchemaName",
        HEIGHT_IN_PIXELS: "HeightInPixels",
        WIDTH_IN_PIXELS: "WidthInPixels",
        GRAPH_TITLE: "GraphTitle",
        SHOW_LEGEND: "ShowLegend",
        SHOW_LEGEND_ERRORS: "ShowLegendErrors",
        LEGEND_PLACEMENT: "LegendPlacement",
        SHOW_X_AXIS_LABEL: "ShowXAxisLabel",
        DECORATE_POINTS: "DecoratePoints",
        GRAPH_TYPE: "GraphType",
        TIMEZONE: "Timezone",
        SHOW_GAPS: "ShowGaps",
        HORIZONTAL_LINE: "HorizontalLine",
        LOG_SCALING: "LogScaling",
        UPPER_VALUE: "UpperValue",
        LOWER_VALUE: "LowerValue",
        CLIP_UPPER_VALUE: "ClipUpperValue",
        SHOW_Y_AXIS: "ShowYAxis",
        SHRINK_BOUNDS_TO_GRAPH_DATA: "ShrinkBoundsToGraphData",
        LABEL: "Label",
        START_TIME: "StartTime",
        END_TIME: "EndTime",
        PERIOD: "Period",
        STAT: "Stat",
        VALUE_UNIT: "ValueUnit",
        STAT_OPTIONS: "StatOptions",
        Y_AXIS_PREFERENCE: "YAxisPreference",
        AGGREGATION_FUNCTION: "AggregationFunction",
        AGGREGATION_PERIOD: "AggregationPeriod",
        FUNCTION_EXPRESSION: "FunctionExpression",
        FUNCTION_LABEL: "FunctionLabel",
        FUNCTION_OPERATE_ON_PARTIAL_INPUT: "FunctionOperateOnPartialInput",
        FUNCTION_Y_AXIS_PREFERENCE: "FunctionYAxisPreference",
        VERTICAL_LINE: "VerticalLine"
    };

    IGH.MWS.QS_DEFAULTS = {
        WIDTH_IN_PIXELS: 640,
        HEIGHT_IN_PIXELS: 480,
        SHOW_LEGEND: IGH.MWS.Boolean.TRUE,
        SHOW_LEGEND_ERRORS: IGH.MWS.Boolean.TRUE,
        LEGEND_PLACEMENT: IGH.MWS.LegendPlacement.BOTTOM,
        SHOW_X_AXIS_LABEL: IGH.MWS.Boolean.TRUE,
        DECORATE_POINTS: IGH.MWS.Boolean.FALSE,
        GRAPH_TYPE: IGH.MWS.GraphType.BITMAP,
        SHOW_GAPS: IGH.MWS.Boolean.TRUE,
        LOG_SCALING: IGH.MWS.Boolean.FALSE,
        SHOW_Y_AXIS: IGH.MWS.Boolean.TRUE,
        SHRINK_BOUNDS_TO_GRAPH_DATA: IGH.MWS.Boolean.FALSE,
        Y_AXIS_PREFERENCE: IGH.MWS.YAxisPreference.LEFT,
        FUNCTION_OPERATE_ON_PARTIAL_INPUT:  IGH.MWS.Boolean.TRUE,
        STAT_OPTIONS: IGH.MWS.StatOptions.VAL,
        TIMEZONE: "",
        VALUE_UNIT: IGH.MWS.ValueUnit.NONE
        // can't default this until we add fallback in MWS FUNCTION_Y_AXIS_PREFERENCE: IGH.MWS.YAxisPreference.LEFT
    };

    //Defines valid MWS periods
    IGH.Period = {
        ONE_MINUTE: "OneMinute",
        FIVE_MINUTE: "FiveMinute",
        ONE_HOUR: "OneHour",
        ONE_DAY: "OneDay",
        ONE_WEEK: "OneWeek"
    }

    //Defines valid MWS stats
    IGH.Stat = {
        AVG: "avg",
        SUM: "sum",
        N: "n",
        P0: "p0",
        P10: "p10",
        P20: "p20",
        P25: "p25",
        P30: "p30",
        P40: "p40",
        P50: "p50",
        P60: "p60",
        P70: "p70",
        P75: "p75",
        P80: "p80",
        P90: "p90",
        P99: "p99",
        P99_9: "p99.9",
        P99_99: "p99.99",
        P100: "p100",
        GP0: "gp0",
        GP10: "gp10",
        GP20: "gp20",
        GP25: "gp25",
        GP50: "gp50",
        GP90: "gp90",
        GP99: "gp99",
        GP99_9: "gp99.9",
        GP99_99: "gp99.99",
        GP100: "gp100",
        GAVG: "gavg",
        GSUM: "gsum",
        U1000: "u1000",
        U2000: "u2000",
        U3500: "u3500",
        U6000: "u6000",
        O1000: "o1000",
        O2000: "o2000",
        O3500: "o3500",
        O6000: "o6000"
    }
    /*
     * Add observablity (Observer pattern) to the 'that' object
     */
    // 'event' is a string
    // 'listener' is the callback function
    IGH.util.observability = function(that){

        var registry = {};
        var _enabled = true;

        //May be used to temporarily enable/disabled all notifications
        that.enableNotification = function(enabled){
            _enabled = enabled;
        };

        // Send out a notification to all registered listeners for an event
        that.notify = function(event){
            if (_enabled) {
                var listeners = registry[event];
                if (listeners) {
                    for (var i = 0; i < listeners.length; ++i) {
                        listeners[i](event);
                    }
                }
            }
        };

        // Register a listener function with an event
        that.register = function(event, listener){
            if (registry[event]) {
                registry[event].push(listener);
            }
            else {
                registry[event] = [listener];
            }
        };

        // allow chaining
        return that;
    };
    /*
     * urlEncode utility function
     */
    IGH.util.urlEncode = function(string) {
        return escape(string).replace(/[+]/g, "%2B").replace(/\//g, "%2F");
    };

    /*
     * Utility function for getting size of window
     */
    IGH.util.getWindowSize = function() {
        var myWidth = 0, myHeight = 0;
        if (typeof( window.innerWidth ) == 'number' ) {
            //Non-IE
            myWidth = window.innerWidth;
            myHeight = window.innerHeight;
        } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
            //IE 6+ in 'standards compliant mode'
            myWidth = document.documentElement.clientWidth;
            myHeight = document.documentElement.clientHeight;
        } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
            //IE 4 compatible
            myWidth = document.body.clientWidth;
            myHeight = document.body.clientHeight;
        }
        return { width: myWidth, height: myHeight};
    };

    /*
     *  Given an event returns the absolute position of the mouse pointer
     */
    IGH.util.getMouseCoords = function(ev) {
        try {
            ev = ev || window.event;
            if (ev.pageX || ev.pageY) {
                return {
                    x: ev.pageX,
                    y: ev.pageY
                };
            }
            var windowOffset = IGH.util.getWindowOffset();
            return {
                x: ev.clientX + windowOffset.x - document.body.clientLeft,
                y: ev.clientY + windowOffset.y - document.body.clientTop
            };
        }
        catch (e) {
            // The event object was not obtainable or did not contain location information
            return null;
        }
    };

    /*
     * Return the offset of the top left of the window within the
     * current document
     */
    IGH.util.getWindowOffset = function() {
        return {
            x: IGH.util.filterAreaResults(window.pageXOffset ? window.pageXOffset : 0,
              document.documentElement ? document.documentElement.scrollLeft : 0,
              document.body ? document.body.scrollLeft : 0),
            y: IGH.util.filterAreaResults(window.pageYOffset ? window.pageYOffset : 0,
              document.documentElement ? document.documentElement.scrollTop : 0,
              document.body ? document.body.scrollTop : 0)
        }
    };

    /*
     * Utility function for getting the correct number in the DOM for x and y positions.
     * It is given numbers that come from the window, document and documeny body and
     * the algorithm figures out the correct one to use.
     */
    IGH.util.filterAreaResults = function(n_win, n_docel, n_body) {
        var n_result = n_win ? n_win : 0;
        if (n_docel && (!n_result || (n_result > n_docel)))
            n_result = n_docel;
        return n_body && (!n_result || (n_result > n_body)) ? n_body : n_result;
    };

    /* Prints an integer into a nice string format */
    IGH.util.numberWithCommas = function(nStr, decimalPlaces) {
        nStr += '';
        if (typeof decimalPlaces !== undefined) {
            nStr = parseFloat(nStr).toFixed(decimalPlaces) + '';
        }
        var beforeAfterDec = nStr.split('.');
        var beforeDec = beforeAfterDec[0];
        var afterDec = beforeAfterDec.length > 1 ? '.' + beforeAfterDec[1] : '';
        afterDec = afterDec.replace(/0*$/, "");
        if (afterDec === ".") {
            afterDec = "";
        }
        var regex = /(\d+)(\d{3})/;
        while (regex.test(beforeDec)) {
            beforeDec = beforeDec.replace(regex, '$1' + ',' + '$2');
        }
        return beforeDec + afterDec;
    };

    /*
     * Makes elements appear/disappear by "sliding" into/out of view
     */
    IGH.util.toggleExpander = function(expander, controlSelector){
        var expanderSpan = expander.firstChild.nextSibling;
        $(expanderSpan).toggleClass("expanderGrow");
        $(expanderSpan).toggleClass("expanderShrink");
        IGH.util.toggleSlide(controlSelector);
    };

    /*
     * Makes elements appear/disappear by "sliding" into/out of view
     */
    IGH.util.toggleSlide = function(jquerySelector){
        if ($(jquerySelector).is(":hidden")) {
            $(jquerySelector).slideDown("fast");
            return true;
        }
        else {
            $(jquerySelector).slideUp("fast");
            return false;
        }
    };

    /*
     * Makes elements appear/disappear by "fading" into/out of view
     */
    IGH.util.toggleFade = function(jquerySelector){
        if ($(jquerySelector).is(":hidden")) {
            $(jquerySelector).fadeIn();
            return true;
        }
        else {
            $(jquerySelector).fadeOut();
            return false;
        }
    };

    /*
     * Toggles visibility of items. Returns true if the items are now visible
     */
    IGH.util.toggleShowHide = function(jquerySelector) {
        if ($(jquerySelector).is(":hidden")) {
            $(jquerySelector).show();
            return true;
        }
        else {
            $(jquerySelector).hide();
            return false;
        }
    },

      /*
       * Scrolls to top of screen in animation
       */
      IGH.util.scrollToTop = function() {
          $('html, body').animate({scrollTop:0}, 'slow');
      },

      /*
       * Scrolls to Y value of particular object (jquery selector) on screen
       */
      IGH.util.scrollTo = function(jquerySelector) {

          $('html, body').animate({scrollTop: $(jquerySelector).offset().top}, 'slow');
      },

      /*
       * Return the URL parameters from the href that launched the current window.
       *
       * Remove any anchors from the end
       */
      IGH.util.getUrlParameters = function() {
          return window.location.href.replace(/.*[?]/, "").replace(/#\w*$/, "");
      };

    /*
     * Remove domain from a URL
     */
    IGH.util.removeDomainFromUrl = function(url) {
        return url.replace(/^http[s]*(?:\/[^\/]*){2}/, "")
    };

    /*
     * Utility function to help setting/getting of object properties
     *
     * Return property value if 'value' parameter is not specified else
     * set the property value and return the object, so that settings
     * can be 'chained' like so: a.prop1(10).prop2(20);
     */
    IGH.util.GetterSetter = function(obj, property, value) {
        if (value == undefined) {
            return obj[property];
        }
        else {
            obj[property] = value;
            return obj;
        }
    };

    //returns a function that will validate a value against the supplied enum
    IGH.util.createOptionalEnumValidator = function(validValues) {
        return function(value) {
            if(value === undefined) {
                return true;
            }
            for(var valid in validValues) {
                if(validValues[valid] === value) {
                    return true;
                }
            }
            return false;
        };
    };

    //returns a function that will validate a value against an MWS Boolean
    IGH.util.createOptionalBooleanValidator = function() {
        return function(value) {
            if(value === undefined) {
                return true;
            }
            for(var valid in  IGH.MWS.Boolean ) {
                if(IGH.MWS.Boolean[valid] === value.toLowerCase()) {
                    return true;
                }
            }
            return false;
        };
    };

    /* Helper for setting a query string arg*/
    IGH.util.GetQueryArg = function(field, value) {
        return "&" + field + "=" + this.urlEncode(value);
    };

    /* Helper for setting a qplot arg*/
    IGH.util.GetQplotArg = function(field, value) {
        return " -" + field.toLowerCase() + "=" + value;
    };

    /*
     *  Parses a single Query String parameter into a key/value pair.
     *  Returns a null for invalid, or '{ key: "key", value: "value"}' for valid parameters
     */
    IGH.util.queryParamToKeyValue = function(param) {
        var EQUALS = "=";
        var EQUALS_ENCODED = "%3D";

        var equals = param.indexOf(EQUALS);
        var equalsOffset = EQUALS.length;
        if (equals <= 0) {
            // No '=', try for '%3D'
            equals = param.indexOf(EQUALS_ENCODED);
            equalsOffset = EQUALS_ENCODED.length;
        }
        if (equals > 0) {
            var result = {};
            result.key = param.slice(0, equals);
            result.value = unescape(param.slice(equals + equalsOffset));
            return result;
        }
        return null;
    };

    /*
     * Returns a url in its parts: ['url', 'scheme', 'slash', 'host', 'port', 'path', 'query', 'hash']
     */
    IGH.util.URL_PARTS = ['url', 'scheme', 'slash', 'host', 'port', 'path', 'query', 'hash'];
    IGH.util.parseUrl = function(url) {
        var parse_url = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/;
        var result = parse_url.exec(jQuery.trim(url));
        if (result == null) {
            return null;
        }
        var parsedUrl = {};
        for (i = 0; i < this.URL_PARTS.length; i++) {
            parsedUrl[this.URL_PARTS[i]] = result[i] ? result[i] : "";
        }
        return parsedUrl;
    };

    IGH.util.parseQueryParams = function(query) {
        var str = query || window.location.search;
        var paramMap = {};
        str.replace(new RegExp( "([^?=&]+)(=([^&]*))?", "g" ),
          function($0, $1, $2, $3) {
              paramMap[$1] = $3;
          }
        );
        return paramMap;
    };

    IGH.util.lightbox = Lightbox.display;

    /*
     * Helper for making a batch update to the graph data model. It calls the function passed in
     * with specified parameters and guarantees only one update event is propagated.
     */
    IGH.util.BatchUpdate = function(fn, param1, param2, param3, param4, param5) {
        var model = IGH.graph.model();

        model.enableNotification(false);        // Switch off model events
        var ret = fn(param1, param2, param3, param4, param5);             // Call the passed-in function
        model.enableNotification(true);         // Re-enable model events
        model.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);    // Fire a model changed event
        return ret;
    };

    /*
     * Debugging utility, to display alert of object contents
     */
    IGH.util.LogObject = function(obj) {
        for (var key in obj) {
            try {
                console.log("obj[" + key + "] = " + obj[key]);
            }
            catch (e) {}
        }
    };

    /*
     * Converts XMLObject into string
     */
    IGH.util.xmlToString = function(xml){
        var serialized;
        try {
            serializer = new XMLSerializer();
            serialized = serializer.serializeToString(xml);
        }
        catch (e) {
            // Internet Explorer has a different approach to serializing XML
            serialized = xml.xml ? xml.xml : xml;
        }

        return serialized;
    };

    /*
     *  Given a list of param names, removes them from a URL of parameters and returns the trimmed URL
     */
    IGH.util.removeQueryParams = function(url, paramList) {
        var newUrl = url;
        for (var i = 0; i < paramList.length; i++) {
            var re = new RegExp(paramList[i] + "(=|%3D)[^&]*", "gi");
            newUrl = newUrl.replace(re, "");
        }
        return newUrl;
    };

    IGH.util.replaceQueryParam = function(url, param, value) {
        let newUrl = this.removeQueryParams(url, [param]);
        newUrl += '&' + param + '=' + encodeURIComponent(value);
        return newUrl.replace(/[&]+/g, '&');
    };

    IGH.util.isCloudWatchGraph = function(args) {
        return new RegExp(`\\b${METRIC_WIDGET_URL_PARAM}=`).test(args);
    };

    IGH.util.getMetricWidgetFromUrl = function(url) {
        try {
            const OVERRIDE_URL_PARAMS = [ 'start', 'end', 'width', 'height' ];
            const metricWidgetEncodedString = extractQueryValue(url, METRIC_WIDGET_URL_PARAM);
            const metricWidgetString = decodeURIComponent(metricWidgetEncodedString.replace(/\+/g, '%20'));
            const metricWidget = JSON.parse(metricWidgetString);

            // start, end, width, height as URL params can override JSON, so stick them into JSON if found
            OVERRIDE_URL_PARAMS.forEach((param) => {
                const paramValue = extractQueryValue(url, param);
                if (paramValue) {
                    metricWidget[param] = isFinite(paramValue) ? parseFloat(paramValue) : paramValue;
                }
            });

            return metricWidget;
        } catch (e) {
            console.error(e);
            return {};
        }
    };

    IGH.util.getConsoleUrl = function(imgUrl) {
        const DEFAULT_REGION = 'us-east-1';
        let region = DEFAULT_REGION;
        let consoleUrl = 'console.aws.amazon.com/cloudwatch/deeplink.js?region=';
        let metricWidget = {};

        if (imgUrl) {
            metricWidget = IGH.util.getMetricWidgetFromUrl(imgUrl);
            if (metricWidget.region) {
                region = metricWidget.region;
            }
        }

        consoleUrl += region;
        if (region !== DEFAULT_REGION) {
            consoleUrl = region + '.' + consoleUrl;
        }

        const metricWidgetJsonUrl = IGH.util.metricWidgetToJsonUrlParam(metricWidget);
        return `https://${consoleUrl}#metricsV2:graph=${metricWidgetJsonUrl}`;
    };

    IGH.util.metricWidgetToJsonUrlParam = function(metricWidget) {
        const metricWidgetString = JSON.stringify(metricWidget).replace(/[%]7C/g, '|');

        // Need to encode = to %3D and # to %23, to get through to Metrics page in console okay
        return encodeURIComponent(metricWidgetString)
          .replace(/#/g, '%23')
          .replace(/=/g, '%3D');
    };

    IGH.util.graphArgsToCloudWatchGraphUrl = function(args) {
        return `${MonitorPortalRoot}/cw/getMetricWidgetImage?${args}`;
    };

    IGH.util.getLocalTimezoneOffset = function(seperator = "") {
        const timezoneOffsetMin = new Date().getTimezoneOffset();
        let offsetHours = parseInt(Math.abs(timezoneOffsetMin / 60));
        let offsetMinutes = Math.abs(timezoneOffsetMin % 60);

        offsetHours   = (offsetHours < 10 ? '0' : '') + offsetHours;
        offsetMinutes = (offsetMinutes < 10 ? '0' : '') + offsetMinutes;

        // Negative offset means "ahead of UTC"
        return (timezoneOffsetMin <= 0 ? '+' : '-') + offsetHours + seperator + offsetMinutes;
    };

    IGH.util.createVerticalLine = function(ttNum, severity, start, end, gmtOffset) {
        var ttDescription = `TT ${ttNum} [${severity}]`

        if (end == null) { // If no end is specified, add a line
            return `${ttDescription} @ ${start}`;
        } else { // Otherwise add a band
            return `(${ttDescription} @ ${start} , ${end})`;
        }
    },

    IGH.util.createCloudWatchVerticalLine = function(ttNum, severity, start, end) {
        const color = severity === "2" || severity === "1" ? "#d62728" : "#ff7f0e"

        const ttDescription = `TT ${ttNum} [${severity}]`

        const startLine = `{"color": "${color}","label": "${ttDescription}","value": "${start}"}`

        if (end == null) { // If no end is specified, add a line
            return `"annotations": {"vertical": [${startLine}]}`;
        } else { // Otherwise add a band
            return `"annotations": {"vertical": [${startLine},{"color": "${color}","label": "${ttDescription}","value": "${start}"}]}`;
        }
    },

      IGH.util.waitForPageReady = async function(condition, retryDelay, maxRetries) {
          for (let i = 0; i < maxRetries; i++) { // Loop until max retries are exhausted
              await new Promise(resolve => { // Delay to slow down retries
                  setTimeout(() => {
                      resolve();
                  }, retryDelay);
              });

              if (condition() === true) {
                  return;
              }
          }
          throw `Wait for ready failed`
      };

    /*
     * This function takes an html element, a message, and a function and displays a small
     * tooltip with the message after the execution of the function.
     * Note: The containing div must have "position: relative" for the banner to scroll correctly.
     */
    IGH.util.buttonAcknowledgmentMessageUtil = function(buttonSelector, message, clickFunction) {
        $(buttonSelector).on('click', function(e) {
            const messageClass = "igh-copy-msg"
            $(`.${messageClass}`).remove() // Remove all existing messages
            $('<div>', { // Add a hidden div containing the success message to show
                class: messageClass,
                style: "display:none;position:absolute; z-index:1; background-color: white; color: green; padding: 2px; border: 1px solid green;",
                text: message
            }).appendTo(buttonSelector);

            clickFunction(e) // Run the provided click function
            $(`.${messageClass}`).fadeIn("slow", function() { // Fade in and out the message
                window.setTimeout(function() {
                    $(`.${messageClass}`).fadeOut("slow");
                }, 1000)
            })
        } );
    };

    IGH.startsWith = function(str, beginning) {
        return str.indexOf(beginning) == 0;
    };

    /*
     * Implement the DataModel for the graph page of iGraph
     */
    IGH.graph.PARAMS = {
        ENABLED: "enabled",
        USER_LABEL: "UserLabel",
        METRIC: "metric",
        Y_AXIS: "YAxis",
        FUNCTION: "function",
        TYPE: "type",
        MODEL_CHANGED_EVENT: "ModelChanged"
    };

    IGH.graph.createDataModel = function(){

        // lowercase the first letter (of method name) - this should always be safe
        var _getName = function(parameter){
            return parameter.charAt(0).toLowerCase() + parameter.substring(1);
        };

        var _createGetterAndSetter = function(obj, method, property, validator){

            obj[_getName(method)] = function(value){
                if (value === undefined) {
                    return property;
                }
                else {
                    // TODO only apply valid changes ( fail silently otherwise) - is this correct?
                    if (!validator || validator(value)) {
                        // only fire a change if the value changes
                        if (property !== value || typeof value === 'object') {
                            property = value;
                            that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
                        }
                    }
                    return obj;
                }
            };
        };

        var _createGetter = function(obj, method, property){
            obj[_getName(method)] = function(){
                return property;
            };
        };

        // We do this rather than use javascript array directly so that we can observe changes
        var _createArray = function(){
            var _array = [];

            var other = {};
            other.size = function(){
                return _array.length;
            };
            other.add = function(element){
                _array.push(element);
                that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
            };
            other.get = function(i){
                if (i >= 0 && i < _array.length) {
                    return _array[i];
                }
            };
            other.remove = function(i){
                if (i >= 0 && i < _array.length) {
                    _array.splice(i, 1);
                    that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
                }
            };
            other.clear = function(){
                // only fire event on real changes
                if(_array.length > 0) {
                    _array = [];
                    that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
                }
            };
            return other;
        };

        var _createSources = function(){
            return _createArray();
        };

        var _createFunctions = function(){
            return _createArray();
        };

        var _createYAxis = function(){
            var _horizontalLine = _createArray();
            var _logScaling = IGH.MWS.QS_DEFAULTS.LOG_SCALING;
            var _showYAxis = IGH.MWS.QS_DEFAULTS.SHOW_Y_AXIS;
            var _upperValue;
            var _lowerValue;
            var _clipUpperValue;
            var _shrinkBoundsToGraphData = IGH.MWS.QS_DEFAULTS.SHRINK_BOUNDS_TO_GRAPH_DATA;
            var _label;

            var that = {};
            _createGetter(that, IGH.MWS.QS.HORIZONTAL_LINE, _horizontalLine);
            _createGetterAndSetter(that, IGH.MWS.QS.LOG_SCALING, _logScaling, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_Y_AXIS, _showYAxis, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.UPPER_VALUE, _upperValue);
            _createGetterAndSetter(that, IGH.MWS.QS.LOWER_VALUE, _lowerValue);
            _createGetterAndSetter(that, IGH.MWS.QS.CLIP_UPPER_VALUE, _clipUpperValue);
            _createGetterAndSetter(that, IGH.MWS.QS.SHRINK_BOUNDS_TO_GRAPH_DATA, _shrinkBoundsToGraphData, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.LABEL, _label);
            return that;
        };

        var _createOptions = function(){
            var _heightInPixels;
            var _widthInPixels;
            var _leftYAxis = _createYAxis();
            var _rightYAxis = _createYAxis();
            var _graphTitle;
            var _showLegend = IGH.MWS.QS_DEFAULTS.SHOW_LEGEND;
            var _legendPlacement = IGH.MWS.QS_DEFAULTS.LEGEND_PLACEMENT;
            var _showXAxisLabel = IGH.MWS.QS_DEFAULTS.SHOW_X_AXIS_LABEL;
            var _decoratePoints = IGH.MWS.QS_DEFAULTS.DECORATE_POINTS;
            var _graphType = IGH.MWS.QS_DEFAULTS.GRAPH_TYPE;
            var _timezone = IGH.MWS.QS_DEFAULTS.TIMEZONE;
            var _showLegendErrors = IGH.MWS.QS_DEFAULTS.SHOW_LEGEND_ERRORS;
            var _showGaps = IGH.MWS.QS_DEFAULTS.SHOW_GAPS;
            var _verticalLine = _createArray();

            var that = {};
            _createGetterAndSetter(that, IGH.MWS.QS.HEIGHT_IN_PIXELS, _heightInPixels);
            _createGetterAndSetter(that, IGH.MWS.QS.WIDTH_IN_PIXELS, _widthInPixels);
            _createGetterAndSetter(that, IGH.MWS.QS.GRAPH_TITLE, _graphTitle);
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_LEGEND, _showLegend, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.LEGEND_PLACEMENT, _legendPlacement, IGH.util.createOptionalEnumValidator(IGH.MWS.LegendPlacement));
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_X_AXIS_LABEL, _showXAxisLabel, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.DECORATE_POINTS, _decoratePoints, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.GRAPH_TYPE, _graphType, IGH.util.createOptionalEnumValidator(IGH.MWS.GraphType));
            _createGetterAndSetter(that, IGH.MWS.QS.TIMEZONE, _timezone);
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_LEGEND_ERRORS, _showLegendErrors, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_GAPS, _showGaps, IGH.util.createOptionalBooleanValidator());
            _createGetter(that, IGH.MWS.YAxisPreference.LEFT + IGH.graph.PARAMS.Y_AXIS, _leftYAxis);
            _createGetter(that, IGH.MWS.YAxisPreference.RIGHT + IGH.graph.PARAMS.Y_AXIS, _rightYAxis);
            _createGetter(that, IGH.MWS.QS.VERTICAL_LINE, _verticalLine);
            return that;
        };

        var _createTimeRanges = function(){
            return _createArray();
        };


        var _timeRanges = _createTimeRanges();
        var _sources = _createSources();
        var _options = _createOptions();
        var _functions = _createFunctions();


        var that = {};
        _createGetter(that, "timeRanges", _timeRanges);
        _createGetter(that, "sources", _sources);
        _createGetter(that, "options", _options);
        _createGetter(that, "functions", _functions);

        that.reset = function(){
            _timeRanges = _createTimeRanges();
            _sources = _createSources();
            _functions = _createFunctions();
            _options = _createOptions();
            that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
        };

        that.createTimeRange = function(type, startTime, endTime){
            var _type = type;
            var _startTime = startTime;
            var _endTime = endTime;

            var that = {};
            _createGetterAndSetter(that, IGH.graph.PARAMS.TYPE, _type, IGH.util.createOptionalEnumValidator(IGH.MWS.TimeRangeType));
            _createGetterAndSetter(that, IGH.MWS.QS.START_TIME, _startTime);
            _createGetterAndSetter(that, IGH.MWS.QS.END_TIME, _endTime);
            return that;
        };

        that.createFunction = function(){
            var _function = {};
            var _expression;
            var _label;
            var _yAxisPreference = IGH.MWS.QS_DEFAULTS.Y_AXIS_PREFERENCE;
            var _operateOnPartialInput = IGH.MWS.QS_DEFAULTS.FUNCTION_OPERATE_ON_PARTIAL_INPUT;
            var that = {};
            _createGetterAndSetter(that, IGH.MWS.QS.FUNCTION_EXPRESSION, _expression);
            _createGetterAndSetter(that, IGH.MWS.QS.FUNCTION_LABEL, _label);
            _createGetterAndSetter(that, IGH.MWS.QS.FUNCTION_Y_AXIS_PREFERENCE, _yAxisPreference, IGH.util.createOptionalEnumValidator(IGH.MWS.YAxisPreference));
            _createGetterAndSetter(that, IGH.MWS.QS.FUNCTION_OPERATE_ON_PARTIAL_INPUT, _operateOnPartialInput, IGH.util.createOptionalBooleanValidator());
            return that;
        };

        that.createGraphSchemaDataSource = function(){
            var _metric = {}; //required
            var _period; //required
            var _stat; // required
            var _valueUnit = IGH.MWS.QS_DEFAULTS.VALUE_UNIT;
            var _statOptions = IGH.MWS.QS_DEFAULTS.STAT_OPTIONS;
            var _yAxisPreference = IGH.MWS.QS_DEFAULTS.Y_AXIS_PREFERENCE;
            var _label;
            var _userLabel; // this is not an MWS parameter to hold a user define label
            var that = {};
            _createGetterAndSetter(that, IGH.graph.PARAMS.METRIC, _metric);
            _createGetterAndSetter(that, IGH.MWS.QS.PERIOD, _period, IGH.util.createOptionalEnumValidator(IGH.Period));
            _createGetterAndSetter(that, IGH.MWS.QS.STAT, _stat, IGH.util.createOptionalEnumValidator(IGH.Stat));
            _createGetterAndSetter(that, IGH.MWS.QS.VALUE_UNIT, _valueUnit, IGH.util.createOptionalEnumValidator(IGH.MWS.ValueUnit));
            _createGetterAndSetter(that, IGH.MWS.QS.STAT_OPTIONS, _statOptions, IGH.util.createOptionalEnumValidator(IGH.MWS.StatOptions));
            _createGetterAndSetter(that, IGH.MWS.QS.Y_AXIS_PREFERENCE, _yAxisPreference, IGH.util.createOptionalEnumValidator(IGH.MWS.YAxisPreference));
            _createGetterAndSetter(that, IGH.MWS.QS.LABEL, _label);
            _createGetterAndSetter(that, IGH.graph.PARAMS.USER_LABEL, _userLabel);
            that.type = function(){
                return IGH.graph.PARAMS.METRIC;
            };
            return that;
        };

        IGH.util.observability(that);
        return that;
    };


    IGH.graph.DataModelHelper = {

        cloneDataSource: function(model, source){
            var clone;
            if (source.type() === IGH.graph.PARAMS.METRIC) {
                clone = model.createGraphSchemaDataSource();
            }
            else {
                clone = model.createBinaryFunctionDataSource();
            }

            for (var func in source) {
                // need a deep copy of the metric object
                if (func === IGH.graph.PARAMS.METRIC) {
                    clone[func](this._clone(source[func]()));
                }
                else {
                    clone[func](source[func]());
                }
            }
            return clone;
        },

        copyMetricsToFunctions: function(model) {
            var metrics = model.sources();
            for (var i = 1; i <= metrics.size(); ++i) {
                var metric = metrics.get(i - 1);
                metric.statOptions(IGH.MWS.StatOptions.VAL);     // Make sure predictions switched off, not valid with functions
                var func = model.createFunction();
                if (this.isSearchMetric(metric)) {
                    func.functionExpression("S" + i);
                    func.functionLabel("{metricLabel}");
                }
                else {
                    func.functionExpression("M" + i);
                    func.functionLabel(metric.label());
                }
                func.functionYAxisPreference(metric.yAxisPreference());
                model.functions().add(func);
            }
        },

        isSearchMetric: function(metric) {
            return metric.metric()['SchemaName'] === 'Search';
        },

        modelFromUrl: function(url) {
            var model = IGH.graph.createDataModel();
            var codec = IGH.graph.createMWSCodec();
            var queryParams = codec.fromQueryString(IGH.util.parseUrl(url)['query']);
            codec.decode(queryParams, model);
            codec.decodeFunctions(queryParams, model);
            return model;
        },

        mergeModels: function(toModel, fromModel) {
            var fromMetrics = fromModel.sources();
            if (fromMetrics.size() == 0) {      // Nothing to merge
                return null;
            }
            var toMetrics = toModel.sources();
            var fromFunctions = fromModel.functions();
            var toFunctions = toModel.functions();
            var newMetricsOffset = toMetrics.size();
            this._copyMetricsToFunctionsIfEitherModelContainsFunctions(toModel, fromModel);
            this._setFromAxisToRightIfAllAreLeft(toMetrics, toFunctions, fromMetrics, fromFunctions);

            this._mergeGraphTitles(toModel, fromModel);
            this._mergeMetrics(toMetrics, fromMetrics);

            if (((toFunctions.size() > 0) || (newMetricsOffset == 0)) && (fromMetrics.size() > 0)) {
                for (var i = 0; i < fromFunctions.size(); i++) {
                    var newFunction = fromFunctions.get(i);
                    newFunction.functionExpression(this._renumberFunctionExpression(newFunction.functionExpression(), newMetricsOffset));
                    toFunctions.add(fromFunctions.get(i));
                }
            }

            return newMetricsOffset;
        },

        _setFromAxisToRightIfAllAreLeft: function(toMetrics, toFunctions, fromMetrics, fromFunctions) {
            if (toMetrics.size() == 0) {
                return;
            }
            if (fromFunctions.size() > 0) {
                this._setFromAxisToRightIfAllAreLeftForFunctionsOrMetrics(toFunctions, fromFunctions, 'functionYAxisPreference');
            }
            this._setFromAxisToRightIfAllAreLeftForFunctionsOrMetrics(toMetrics, fromMetrics, 'yAxisPreference');
        },

        _setFromAxisToRightIfAllAreLeftForFunctionsOrMetrics: function(toArray, fromArray, yAxisFunc) {
            var toRight   = this._hasRightYAxisPreference(toArray,   yAxisFunc);
            var fromRight = this._hasRightYAxisPreference(fromArray, yAxisFunc);
            if (!toRight && !fromRight) {
                this._setYAxisPreference(fromArray, yAxisFunc, IGH.MWS.YAxisPreference.RIGHT);
            }
        },

        _hasRightYAxisPreference: function(array, yAxisFunc) {
            for (var i = 0; i < array.size(); i++) {
                if (array.get(i)[yAxisFunc]() === IGH.MWS.YAxisPreference.RIGHT) {
                    return true;
                }
            }
            return false;
        },

        _setYAxisPreference: function(array, yAxisFunc, axisPreference) {
            for (var i = 0; i < array.size(); i++) {
                array.get(i)[yAxisFunc](axisPreference);
            }
        },

        _renumberFunctionExpression: function(expr, offset) {
            return expr.replace(/\b([MS])(\d+)\b/g, function(fullMatch, metricType, index){
                return metricType + (parseInt(index) + offset);
            });
        },

        _mergeGraphTitles: function(toModel, fromModel) {
            var toTitle = toModel.options().graphTitle();
            var fromTitle = fromModel.options().graphTitle();
            if (fromTitle && fromTitle != "") {
                var newTitle = fromTitle;
                if (toTitle && toTitle != "") {
                    newTitle = toTitle + " / " + fromTitle;
                }
                toModel.options().graphTitle(newTitle);
            }
        },

        _mergeMetrics: function(toMetrics, fromMetrics) {
            for (var i = 0; i < fromMetrics.size(); i++) {
                toMetrics.add(fromMetrics.get(i));
            }
        },

        _copyMetricsToFunctionsIfEitherModelContainsFunctions: function(toModel, fromModel) {
            var toFunctions = toModel.functions();
            var fromFunctions = fromModel.functions();
            if ((toFunctions.size() > 0) || (fromFunctions.size() > 0)) {
                if (toFunctions.size() == 0) {
                    this.copyMetricsToFunctions(toModel);
                }
                if (fromFunctions.size() == 0) {
                    this.copyMetricsToFunctions(fromModel);
                }
            }
        },

        _clone: function(map){
            var newMap = {};
            for (var prop in map) {
                if (map.hasOwnProperty(prop)) {
                    newMap[prop] = map[prop];
                }
            }
            return newMap;
        }
    };
    /*
     * Implement conversions between model for IGraph graph tab and MWS requests
     */
    // TODO how will we deal with default values, mws treats undefined properties as default values ( it may not always default a boolean to false)

    IGH.graph.createMWSCodec = function(){
        var METRIC_PATTERN = new RegExp("^[M 0-9]*$");
        var AMPERSAND = "&";
        var EQUALS = "=";
        var EQUALS_ENCODED = "%3D";
        var EMPTY = "";
        var NO_SUFFIX = "";

        var _encodeSources = function(parameters, sources){
            parameters = _encodeMetrics(parameters, sources);
            return parameters;
        };

        var _encodeMetrics = function(parameters, sources){
            var numMetrics = 0;
            // metrics
            for (var i = 0; i < sources.size(); ++i) {
                var source = sources.get(i);
                if (source.type() === IGH.graph.PARAMS.METRIC) {
                    numMetrics++;
                    for (var func in source) {
                        if (func === IGH.graph.PARAMS.METRIC) {
                            parameters = _encodeMetric(parameters, source[func](), numMetrics);
                        }
                        else
                        if (func === IGH.graph.PARAMS.TYPE) {
                            // ignore Type distinguished Functions and GraphSchema
                        }
                        else
                        if (IGH.startsWith(func, IGH.graph.PARAMS.FUNCTION) || func === IGH.graph.PARAMS.ENABLED) {
                            // handle in _encodeFunctions
                        }
                        else
                        if (func === _getFunctionName(IGH.graph.PARAMS.USER_LABEL) || func === _getFunctionName(IGH.MWS.QS.LABEL)) {
                            // fallback does not make sense for user labels
                            parameters = _addParameter(parameters, source, func, numMetrics);
                        }
                        else {
                            parameters = _addParameterWithFallback(parameters, source, func, numMetrics);
                        }
                    }
                }
            }
            return parameters;
        };

        var _encodeMetric = function(parameters, metric, index){
            var schema = metric[IGH.MWS.QS.SCHEMA_NAME];
            parameters = _addParameterFromProperty(parameters, metric, IGH.MWS.QS.SCHEMA_NAME, index);
            var fields = IGH.MetricSchemas.schemaDefs[schema];
            if (fields) {
                for (var i = 0; i < fields.length; ++i) {
                    parameters = _addParameterFromPropertyWithFallback(parameters, metric, fields[i], index);
                }
            }
            return parameters;
        };

        var _encodeFunctions = function(parameters, functions){
            var numFunctions = 0;
            for (var i = 0; i < functions.size(); ++i) {
                var functionDef = functions.get(i);
                numFunctions++;
                for (var func in functionDef) {
                    parameters = _addParameter(parameters, functionDef, func, numFunctions);
                }
            }
            return parameters;
        };

        var _encodeTimeRanges = function(parameters, timeRanges){
            for (var i = 0; i < timeRanges.size(); ++i) {
                parameters = _addParameter(parameters, timeRanges.get(i), IGH.MWS.QS.START_TIME, i + 1);
                parameters = _addParameter(parameters, timeRanges.get(i), IGH.MWS.QS.END_TIME, i + 1);
            }
            return parameters;
        };

        var _encodeOptions = function(parameters, options){
            for (var func in options) {
                if (func === IGH.MWS.YAxisPreference.LEFT + IGH.graph.PARAMS.Y_AXIS) {
                    parameters = _encodeYAxis(parameters, options[func](), _getName(IGH.MWS.YAxisPreference.LEFT));
                } else if (func === IGH.MWS.YAxisPreference.RIGHT + IGH.graph.PARAMS.Y_AXIS) {
                    parameters = _encodeYAxis(parameters, options[func](), _getName(IGH.MWS.YAxisPreference.RIGHT));
                } else if (func === _getFunctionName(IGH.MWS.QS.VERTICAL_LINE)) {
                    parameters = _encodeLineOption(parameters, options, func, NO_SUFFIX);
                } else {
                    parameters = _addParameter(parameters, options, func, NO_SUFFIX);
                }
            }
            return parameters;
        };

        var _decodeMetric = function(parameters, source, numMetrics){
            for (var func in source) {
                if (func === IGH.graph.PARAMS.METRIC) {
                    _decodeMetricSchema(parameters, source[func](), numMetrics);
                }
                else
                if (func === IGH.graph.PARAMS.TYPE) {
                    // handled in _decodeSources
                }
                else
                if (IGH.startsWith(func, IGH.graph.PARAMS.FUNCTION) || func === IGH.graph.PARAMS.ENABLED) {
                    // handled in _decodeFunctions
                }
                else
                if (func === _getFunctionName(IGH.graph.PARAMS.USER_LABEL) || func === _getFunctionName(IGH.MWS.QS.LABEL)) {
                    // fallback is not appropriate for userLabels
                    _getParameter(parameters, source, func, numMetrics);
                }
                else {
                    _getParameterWithFallback(parameters, source, func, numMetrics);
                }
            }
        };

        var _decodeMetricSchema = function(parameters, metric, index){
            _getParameterFromProperty(parameters, metric, IGH.MWS.QS.SCHEMA_NAME, index);
            var schema = metric[IGH.MWS.QS.SCHEMA_NAME];
            var fields = IGH.MetricSchemas.schemaDefs[schema];
            if (fields) {
                for (var i = 0; i < fields.length; ++i) {
                    _getParameterFromPropertyWithFallback(parameters, metric, fields[i], index);
                }
            }
        };

        var _decodeMetrics = function(model, parameters, sources){
            sources.clear();
            var metrics = _getArray(parameters, IGH.MWS.QS.SCHEMA_NAME);
            var numMetrics = 0;
            var source;
            for (var i = 0; i < metrics.length; ++i) {
                numMetrics++;
                source = model.createGraphSchemaDataSource();
                source.type(IGH.graph.PARAMS.METRIC);
                _decodeMetric(parameters, source, i+1);
                sources.add(source);
            }
        };

        var _decodeFunctions = function(model, parameters, functions){
            functions.clear();
            var expressions = _getArray(parameters, IGH.MWS.QS.FUNCTION_EXPRESSION);
            var numFunctions = 0;
            var functionDef;
            for (var i = 0; i < expressions.length; ++i) {
                numFunctions++;
                functionDef = model.createFunction();
                _decodeFunction(parameters, functionDef, i+1);
                functions.add(functionDef);
            }
        };

        var _decodeFunction = function(parameters, functionDef, numFunctions){
            for (var func in functionDef) {
                _getParameter(parameters, functionDef, func, numFunctions);
            }
        };

        var _decodeTimeRanges = function(model, parameters, timeRanges){
            timeRanges.clear();
            var start = _getArray(parameters, IGH.MWS.QS.START_TIME);
            var end = _getArray(parameters, IGH.MWS.QS.END_TIME);
            // Switch to only understanding StartTime1, EndTime1 until full support for Period over Period
            for (var i = 0; i < Math.min(1, Math.min(start.length, end.length)); ++i) {
                var type = IGH.TimeRangeUtils.getTimeType(start[i]);
                timeRanges.add(model.createTimeRange(type, start[i], end[i]));
            }
        };

        var _decodeOptions = function(parameters, options){
            for (var func in options) {
                if (func === IGH.MWS.YAxisPreference.LEFT + IGH.graph.PARAMS.Y_AXIS) {
                    _decodeYAxis(parameters, options[func](), _getName(IGH.MWS.YAxisPreference.LEFT));
                } else if (func === IGH.MWS.YAxisPreference.RIGHT + IGH.graph.PARAMS.Y_AXIS) {
                    _decodeYAxis(parameters, options[func](), _getName(IGH.MWS.YAxisPreference.RIGHT));
                } else if (func === _getFunctionName(IGH.MWS.QS.VERTICAL_LINE)) {
                    _decodeLineOption(parameters, options, func, NO_SUFFIX);
                } else {
                    _getParameter(parameters, options, func, NO_SUFFIX);
                }
            }
        };

        var _decodeYAxis = function(parameters, object, axisName){
            for (var func in object) {
                if (func === _getFunctionName(IGH.MWS.QS.HORIZONTAL_LINE)) {
                    _decodeLineOption(parameters, object, func, axisName);
                }
                else {
                    _getParameter(parameters, object, func, axisName);
                }
            }
        };

        var _decodeLineOption = function(parameters, object, func, axisName) {
            object[func]().clear();
            var lines = _getArray(parameters, _getName(func) + axisName);
            for (var i = 0; i < lines.length; ++i) {
                object[func]().add(lines[i]);
            }
        };

        var _getArray = function(parameters, name){
            var result = [];
            var i = 1;
            do {
                value = parameters[name + i];
                if (value) {
                    result.push(value);
                }
                i++;
            }
            while (value);
            return result;
        };

        var _getParameter = function(parameters, object, func, suffix){
            object[_getFunctionName(func)](_getParameterInternal(parameters, _getName(func), suffix));
        };

        var _getParameterWithFallback = function(parameters, object, func, suffix){
            object[_getFunctionName(func)](_getParameterInternalWithFallback(parameters, _getName(func), suffix));
        };

        var _getParameterFromProperty = function(parameters, object, func, suffix){
            object[_getName(func)] = _getParameterInternal(parameters, _getName(func), suffix);
        };

        var _getParameterFromPropertyWithFallback = function(parameters, object, func, suffix){
            object[_getName(func)] = _getParameterInternalWithFallback(parameters, _getName(func), suffix);
        };

        var _getParameterInternalWithFallback = function(parameters, name, index){
            for (var i = index; i > 0; --i) {
                var value = parameters[name + i];
                if (value) {
                    return value;
                }
            }
        };

        var _getParameterInternal = function(parameters, name, suffix){
            return parameters[name + suffix];
        };

        var _encodeYAxis = function(parameters, object, axisName){
            for (var func in object) {
                if (func === _getFunctionName(IGH.MWS.QS.HORIZONTAL_LINE)) {
                    parameters = _encodeLineOption(parameters, object, func, axisName);
                }
                else {
                    parameters = _addParameter(parameters, object, func, axisName);
                }
            }
            return parameters;
        };

        var _encodeLineOption = function(parameters, object, func, suffix) {
            var lines = object[func]();
            for (var i = 0; i < lines.size(); ++i) {
                parameters[_getName(func) + suffix + (i + 1)] = lines.get(i);
            }
            return parameters;
        };

        var _addParameter = function(parameters, object, func, suffix){
            return _addParameterInternal(parameters, _getName(func), object[_getFunctionName(func)](), suffix);
        };

        var _addParameterWithFallback = function(parameters, object, func, suffix){
            return _addParameterWithFallbackInternal(parameters, _getName(func), object[_getFunctionName(func)](), suffix);
        };

        var _addParameterFromProperty = function(parameters, object, property, suffix){
            return _addParameterInternal(parameters, _getName(property), object[property], suffix);
        };

        var _addParameterFromPropertyWithFallback = function(parameters, object, property, suffix){
            return _addParameterWithFallbackInternal(parameters, _getName(property), object[property], suffix);
        };

        var _addParameterWithFallbackInternal = function(parameters, name, value, index){
            if (value && value !== _getPreviousValue(parameters, name, index)) {
                parameters[name + index] = value;
            }
            return parameters;
        };

        var _addParameterInternal = function(parameters, name, value, suffix){
            if (value && !(value.toString().toLowerCase() === _getDefaultValue(name, value, suffix))) {
                parameters[name + suffix] = value;
            }
            return parameters;
        };

        var _getDefaultValue = function(name, value, suffix){
            for (var prop in IGH.MWS.QS_DEFAULTS) {
                if (IGH.MWS.QS_DEFAULTS.hasOwnProperty(prop)) {
                    var defaulted = IGH.MWS.QS[prop];
                    if (defaulted === name) {
                        return IGH.MWS.QS_DEFAULTS[prop];
                    }
                }
            }
        };

        var _getPreviousValue = function(parameters, name, index){
            for (var i = index - 1; i > 0; --i) {
                if (parameters[name + i]) {
                    return parameters[name + i];
                }
            }
            return _getDefaultValue(name, name, index);
        };

        // uppercase the first letter ( for QS parameter names)
        var _getName = function(parameter){
            return parameter.charAt(0).toUpperCase() + parameter.substring(1);
        };

        // lowercase the first letter ( for method names)
        var _getFunctionName = function(parameter){
            return parameter.charAt(0).toLowerCase() + parameter.substring(1);
        };

        // public methods
        var that = {};

        // translates a data model into an object filed with key/value pairs
        that.encode = function(dataModel){
            var parameters = {};
            parameters = _encodeSources(parameters, dataModel.sources());
            parameters = _encodeOptions(parameters, dataModel.options());
            parameters = _encodeTimeRanges(parameters, dataModel.timeRanges());
            return parameters;
        };

        that.encodeFunctions = function(dataModel){
            var parameters = {};
            parameters = _encodeFunctions(parameters, dataModel.functions());
            return parameters;
        };

        // translates an object filled with key/value pairs into a url segment
        that.toQueryString = function(parameters){
            var out = EMPTY;
            for (var parameter in parameters) {
                if (parameters.hasOwnProperty(parameter)) {
                    out += IGH.util.GetQueryArg(parameter, parameters[parameter]);
                }
            }
            return out.length > 0 ? out.substring(1) : out;
        };

        // translates a url segment into an object filled with key/value pairs
        that.fromQueryString = function(urlSegment){
            var parameters = {};
            var params = urlSegment.split(AMPERSAND);
            for (var i = 0; i < params.length; ++i) {
                var keyValue = IGH.util.queryParamToKeyValue(params[i]);
                if (keyValue) {
                    parameters[keyValue.key] = keyValue.value;
                }
            }
            return parameters;
        };

        // translates an object filed with key/value pairs into a data model

        that.decode = function(parameters, dataModel){
            _decodeOptions(parameters, dataModel.options());
            _decodeTimeRanges(dataModel, parameters, dataModel.timeRanges());
            _decodeMetrics(dataModel, parameters, dataModel.sources());
            return dataModel;
        };

        that.decodeFunctions = function(parameters, dataModel){
            _decodeFunctions(dataModel, parameters, dataModel.functions());
            return dataModel;
        };

        return that;

    };
    IGH.TimeRangeUtils = {

        TZ_PDT: "PST8PDT",
        XML_DATE: new RegExp('(\\d{4})-(\\d{2})-(\\d{2})'),
        XML_TIME: new RegExp('T(\\d{2}):(\\d{2}):(\\d{2})'),
        XML_TZ: new RegExp('([-+]\\d{2}):00$'),
        DECIMAL: 10,
        MILLISECONDS_IN_MINUTE: 60 * 1000,

        PATTERN: {
            DAY: new RegExp('(\\d*)D'),
            HOUR: new RegExp('(\\d*)H'),
            MINUTE: new RegExp('(\\d*)M')
        },

        DURATIONS: {
            DAY: "D",
            HOUR: "H",
            MINUTE: "M"
        },

        MINUTES: {
            DAY: 24 * 60,
            HOUR: 60,
            MINUTE: 1
        },

        UNITS: {
            MINUTE: "MINUTE",
            HOUR: "HOUR",
            DAY: "DAY"
        },

        ORDERED_UNITS: ["MINUTE", "HOUR", "DAY"],

        // get units and corresponding value form a control
        getControlFromDuration: function(duration){
            var minutes = this.getMinutes(duration);
            var unit = this.getUnits(duration);
            var value = minutes / this.MINUTES[unit];
            var result = {};
            result[unit] = value;
            return result;
        },

        // get number of minutes corresponding to a duration
        getMinutes: function(duration){
            // sign is inverted sign widget is ago
            var sign = duration.match("-P") ? 1 : -1;
            var minutes = 0;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    minutes += this.MINUTES[index] * parseInt(results[1], this.DECIMAL);
                }
            }
            return sign * minutes;
        },

        // natural time from a duration
        getNaturalFromDuration: function(duration){
            var minutes = this.getMinutes(duration);
            var unit = this.getUnits(duration);
            var value = Math.round(minutes / this.MINUTES[unit]);
            if (value === 0) {
                return "now";
            }
            return value + " " + unit.toLowerCase() + (value === 1 ? "" : "s") + " ago";
        },

        // natural time from a XML calendar
        getNaturalFromXMLCalendar: function(calendar){
            var date = IGH.TimeRangeUtils.getControlFromXMLCalendar(calendar);
            var hours = date.getHours();
            var amPm = "am";
            if (hours >= 12) {
                hours -= 12;
                amPm = "pm";
            }
            if (hours === 0) {
                hours = 12;
            }
            var minutes = Math.floor(date.getMinutes() / 5) * 5;
            minutes = (minutes < 10) ? "0" + minutes : minutes;
            return $.datepicker.formatDate(IGH.TimeRanges.FORMAT, date) + " " + hours + ":" + minutes + amPm;
        },

        // get most significant Unit present in a duration
        getUnits: function(duration){
            var unit = this.UNITS.MINUTE;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    unit = index;
                }
            }
            return unit;
        },

        // create a duration form the screen widget
        getDurationFromControl: function(unit, value){
            // sign is inverted sign widget is ago
            var sign = value < 0 ? "" : "-";
            var minutes = Math.floor(this.MINUTES[unit] * Math.abs(value));
            var duration = sign + "P";
            if (minutes >= this.MINUTES.DAY || unit === this.UNITS.DAY) {
                var days = Math.floor(minutes / this.MINUTES.DAY);
                duration += days + this.DURATIONS.DAY;
                minutes = minutes % this.MINUTES.DAY;
            }
            duration += "T";
            if (minutes >= this.MINUTES.HOUR || unit === this.UNITS.HOUR) {
                var hours = Math.floor(minutes / this.MINUTES.HOUR);
                duration += hours + this.DURATIONS.HOUR;
                minutes = minutes % this.MINUTES.HOUR;
            }
            if (minutes >= this.MINUTES.MINUTE || unit === this.UNITS.MINUTE) {
                var mins = Math.floor(minutes / this.MINUTES.MINUTE);
                duration += mins + this.DURATIONS.MINUTE;
            }
            if( duration.charAt(duration.length-1) === "T") {
                duration= duration.slice(0,-1);
            }
            return duration;
        },

        // get a calendar string in UTC from the int values of a javascript date
        getXMLCalendarFromControl: function(year, month, dayOfMonth, hours, minutes){
            var date = new fleegix.date.Date(year, month, dayOfMonth, hours, minutes, this.TZ_PDT, false);
            return this.getXMLCalendarFromDate(date);
        },

        // get a calendar string in UTC from a date
        getXMLCalendarFromDate: function(date){
            return date.getUTCFullYear() + "-" + this.pad(date.getUTCMonth() + 1) + "-" + this.pad(date.getUTCDate()) + "T" + this.pad(date.getUTCHours()) + ":" + this.pad(date.getUTCMinutes()) + ":00Z";
        },

        // get a date in PDT from an xml calendar in UTC
        getControlFromXMLCalendar: function(xmlCalendar){
            var hour = 0;
            var minute = 0;
            var second = 0;
            var tz = 0;
            var results = this.XML_TZ.exec(xmlCalendar);
            if (results) {
                tz = parseInt(results[1], this.DECIMAL);
            }
            results = this.XML_TIME.exec(xmlCalendar);
            if (results) {
                hour = parseInt(results[1], this.DECIMAL);
                minute = parseInt(results[2], this.DECIMAL);
                second = parseInt(results[3], this.DECIMAL);
            }
            results = this.XML_DATE.exec(xmlCalendar);
            if (results) {
                var year = parseInt(results[1], this.DECIMAL);
                var month = parseInt(results[2], this.DECIMAL) - 1;
                var dayInMonth = parseInt(results[3], this.DECIMAL);
                var utc = Date.UTC(year, month, dayInMonth, hour, minute, second);
                if (window.fleegix) {
                    var offset = this.getPDTUTCOffset(utc) - tz;
                    return new fleegix.date.Date(year, month, dayInMonth, hour + offset, minute, second, this.TZ_PDT, false);
                } else {
                    return new Date(utc);
                }
            }
            return null;
        },

        // get an xml calendar in UTC from a date and an xml duration
        getXMLCalendarFromDuration: function(now, duration){
            var minutes = this.getMinutes(duration);
            now.setMinutes(now.getMinutes() - minutes);
            return this.getXMLCalendarFromDate(now);
        },

        // get an xml calendar in UTC from a date and an xml duration
        getDurationFromXMLCalendar: function(now, calendar){
            var then = this.getControlFromXMLCalendar(calendar);
            var minutes = (now.getTime() - then.getTime()) / this.MILLISECONDS_IN_MINUTE;
            return this.getDurationFromControl(this.UNITS.MINUTE, minutes);
        },

        // get current js date in PDT
        getNowInPDT: function(){
            var date = new Date();
            var offset = this.getPDTUTCOffset(date.getTime());
            return new fleegix.date.Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours() + offset, date.getUTCMinutes(), date.getUTCSeconds(), date.getUTCMilliseconds(), this.TZ_PDT, false);
        },

        // Convert a time range into minute durations
        getTimeRangeInMinutes: function(now, timeRange) {
            // Can't calculate range with natural time
            if (this.getTimeType(timeRange.startTime()) === IGH.MWS.TimeRangeType.NATURAL) {
                return null;
            }
            var minuteRange = new Object();
            minuteRange.startTime = this._getTimeInMinutes(now, timeRange.startTime());
            minuteRange.endTime   = this._getTimeInMinutes(now, timeRange.endTime());
            return minuteRange;
        },

        // Convert a time (duration or fixed) into number of minutes, compared to now
        _getTimeInMinutes: function(now, time) {
            var duration;
            if (! this.isDuration(time)) {
                duration = this.getDurationFromXMLCalendar(now, time);
            }
            else {
                duration = time;
            }
            return this.getMinutes(duration);
        },

        // Return true if time is a duration
        isDuration: function(time) {
            return IGH.TimeRanges.DURATION.test(time);
        },

        getTimeType: function(time) {
            if (this.isDuration(time)) {
                return IGH.MWS.TimeRangeType.RELATIVE;
            }
            if (this.getControlFromXMLCalendar(time) !== null) {
                return IGH.MWS.TimeRangeType.FIXED;
            }
            return IGH.MWS.TimeRangeType.NATURAL;
        },

        pad: function(number){
            if (number < 10) {
                return "0" + number;
            }
            return number;
        },

        // get PDT offset in hours for a input date
        getPDTUTCOffset: function(dateIn){
            var date = new fleegix.date.Date(dateIn);
            date.setTimezone(this.TZ_PDT);
            return -(date.getTimezoneOffset()) / this.MINUTES.HOUR;
        }
    };
    /*
     * Implements the controls in the Time Ranges section
     *  note only supports a single time range currently
     */
    IGH.TimeRanges = {

        FORMAT: 'yy/mm/dd',
        DURATION: new RegExp('^-?P'),
        DEFAULT_REL_START: '-PT3H',
        DEFAULT_REL_END:   '-PT0H',

        // Initialize.
        init: function(){
            // dates that know about PDT
            var _tz = fleegix.date.timezone;
            _tz.loadingScheme = _tz.loadingSchemes.MANUAL_LOAD;
            var data = {
                "zones": {
                    "PST8PDT": [["-8:00", "US", "P%sT"]]
                },
                "rules": {
                    "US": [["1918", "1919", "-", "Mar", "lastSun", "2:00", "1:00", "D"], ["1918", "1919", "-", "Oct", "lastSun", "2:00", "0", "S"], ["1942", "only", "-", "Feb", "9", "2:00", "1:00", "W", ""], ["1945", "only", "-", "Aug", "14", "23:00u", "1:00", "P", ""], ["1945", "only", "-", "Sep", "30", "2:00", "0", "S"], ["1967", "2006", "-", "Oct", "lastSun", "2:00", "0", "S"], ["1967", "1973", "-", "Apr", "lastSun", "2:00", "1:00", "D"], ["1974", "only", "-", "Jan", "6", "2:00", "1:00", "D"], ["1975", "only", "-", "Feb", "23", "2:00", "1:00", "D"], ["1976", "1986", "-", "Apr", "lastSun", "2:00", "1:00", "D"], ["1987", "2006", "-", "Apr", "Sun>=1", "2:00", "1:00", "D"], ["2007", "max", "-", "Mar", "Sun>=8", "2:00", "1:00", "D"], ["2007", "max", "-", "Nov", "Sun>=1", "2:00", "0", "S"]]
                }
            };
            _tz.loadZoneDataFromObject(data);
            this.model = IGH.graph.model();
            var options = {
                dateFormat: IGH.TimeRanges.FORMAT,
                showOn: 'button',
                buttonImage: '/images/calendar.png',
                buttonImageOnly: true
            };
            // initialize
            IGH.TimeRanges.syncControlsFromModel();
            // listen for changes to the model
            this.model.register(IGH.graph.PARAMS.MODEL_CHANGED_EVENT, function(event){
                IGH.TimeRanges.syncControlsFromModel();
            });
            // add UI listeners
            var self = this;
            $(".setFixedTimeType").on('click', function()    { return self.setTimeType(IGH.MWS.TimeRangeType.FIXED); });
            $(".setRelativeTimeType").on('click', function() { return self.setTimeType(IGH.MWS.TimeRangeType.RELATIVE); });
            $(".setNaturalTimeType").on('click', function()  { return self.setTimeType(IGH.MWS.TimeRangeType.NATURAL); });
            $(".startNow").on('click', this.start3HoursAgo);
            $(".endNow").on('click', this.endNow);
            var times = ["start", "end"];
            for (var i in times) {
                if (times.hasOwnProperty(i)) {
                    $("#" + times[i] + "TimeValue").on('change', this.updateDurationFromControl(times[i]));
                    $("select[name=" + times[i] + "Value]").on('change', this.updateDurationFromControl(times[i]));
                    $("select[name=" + times[i] + "Hours]").on('change', this.updateDateFromControl(times[i]));
                    $("select[name=" + times[i] + "Minutes]").on('change', this.updateDateFromControl(times[i]));
                    $("#" + times[i] + "Date").datepicker(options).on('change', this.updateDateFromControl(times[i]));
                    $("#" + times[i] + "Natural").on('change', this.updateNaturalFromControl(times[i]));
                }
            }
            this._addQuickZoomOnClickHandling();
        },

        syncControlsFromModel: function(){
            var self = IGH.TimeRanges;
            if (self.model.timeRanges().size() === 1) {
                var timeRange = self.model.timeRanges().get(0);
                var timeType = IGH.TimeRangeUtils.getTimeType(timeRange.startTime());
                if (timeType === IGH.MWS.TimeRangeType.RELATIVE) {
                    self.updateControlFromDuration("start");
                    self.updateControlFromDuration("end");
                    self.showControls("relative");
                }
                else if (timeType === IGH.MWS.TimeRangeType.FIXED) {
                    self.updateControlFromCalendar("start");
                    self.updateControlFromCalendar("end");
                    self.showControls("fixed");
                }
                else {
                    self.updateControlFromNatural("start");
                    self.updateControlFromNatural("end");
                    self.showControls("natural");
                }
            }
        },

        showControls: function(controlType) {
            $(".timeSwitch").show();
            $("." + controlType + "TimeSwitch").hide();
            $(".timePanel").hide();
            $("#" + controlType + "-time").show();
        },

        start3HoursAgo: function(){
            for (var i = 0; i < IGH.TimeRanges.model.timeRanges().size(); ++i) {
                var timeRange = IGH.TimeRanges.model.timeRanges().get(i);
                if (timeRange.type() === IGH.MWS.TimeRangeType.FIXED) {
                    var now = IGH.TimeRangeUtils.getNowInPDT();
                    now.setHours(now.getHours() - 3);
                    timeRange.startTime(IGH.TimeRangeUtils.getXMLCalendarFromDate(now));
                }
                else if (timeRange.type() === IGH.MWS.TimeRangeType.NATURAL) {
                    timeRange.startTime("3 hours ago");
                }
            }
            return false;
        },

        endNow: function(){
            for (var i = 0; i < IGH.TimeRanges.model.timeRanges().size(); ++i) {
                var timeRange = IGH.TimeRanges.model.timeRanges().get(i);
                if (timeRange.type() === IGH.MWS.TimeRangeType.FIXED) {
                    timeRange.endTime(IGH.TimeRangeUtils.getXMLCalendarFromDate(IGH.TimeRangeUtils.getNowInPDT()));
                }
                else if (timeRange.type() === IGH.MWS.TimeRangeType.NATURAL) {
                    timeRange.endTime("now");
                }
            }
            return false;
        },

        setTimeType: function(newTimeType){
            var self = IGH.TimeRanges;

            // only want one event from this change
            self.model.enableNotification(false);
            for (var i = 0; i < self.model.timeRanges().size(); ++i) {
                var timeRange = self.model.timeRanges().get(i);
                var currentTimeType = timeRange.type();
                self._convertFromCurrentTimeToNewTime(timeRange, newTimeType, currentTimeType);
                timeRange.type(newTimeType);
            }
            self.model.enableNotification(true);
            self.model.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
            return false;
        },

        _addQuickZoomOnClickHandling: function() {
            function setTime() {
                var startTime = "-" + IGH.TimeRanges._timeTextToDuration($(this).text());
                var model = IGH.graph.model();
                IGH.util.BatchUpdate(IGH.TimeRanges.setTimeRange, model.createTimeRange(IGH.MWS.TimeRangeType.RELATIVE, startTime, IGH.TimeRanges.DEFAULT_REL_END));
                IGH.GraphSection.displayGraph();
                return false;
            }

            $('.quickZoom a').attr('href', '#').on('click', setTime);
        },

        setTimeRange: function(range) {
            var model = IGH.graph.model();
            model.timeRanges().clear();
            model.timeRanges().add(range);
        },

        // Convert time text in format such as 1h, 2d, 3w to a duration
        _timeTextToDuration: function(timeText) {
            var timeValue = parseInt(timeText.substr(0, timeText.length - 1));
            var timeUnit = timeText.substr(timeText.length - 1).toUpperCase();
            if ("W" == timeUnit) {
                timeUnit = "D";
                timeValue *= 7;
            }

            return ("H" == timeUnit ? "PT" : "P") + timeValue + timeUnit;
        },

        _convertFromCurrentTimeToNewTime: function(timeRange, newTimeType, currentTimeType) {
            if (newTimeType === IGH.MWS.TimeRangeType.NATURAL) {
                if (currentTimeType === IGH.MWS.TimeRangeType.RELATIVE) {
                    timeRange.startTime(IGH.TimeRangeUtils.getNaturalFromDuration(timeRange.startTime()));
                    timeRange.endTime(IGH.TimeRangeUtils.getNaturalFromDuration(timeRange.endTime()));
                }
                else {
                    timeRange.startTime(IGH.TimeRangeUtils.getNaturalFromXMLCalendar(timeRange.startTime()));
                    timeRange.endTime(IGH.TimeRangeUtils.getNaturalFromXMLCalendar(timeRange.endTime()));
                }
            }
            else if (newTimeType === IGH.MWS.TimeRangeType.FIXED) {
                if (currentTimeType === IGH.MWS.TimeRangeType.RELATIVE) {
                    timeRange.startTime(IGH.TimeRangeUtils.getXMLCalendarFromDuration(IGH.TimeRangeUtils.getNowInPDT(), timeRange.startTime()));
                    timeRange.endTime(IGH.TimeRangeUtils.getXMLCalendarFromDuration(IGH.TimeRangeUtils.getNowInPDT(), timeRange.endTime()));
                }
                else {
                    timeRange.startTime(IGH.TimeRangeUtils.getXMLCalendarFromDuration(IGH.TimeRangeUtils.getNowInPDT(), IGH.TimeRanges.DEFAULT_REL_START));
                    timeRange.endTime(IGH.TimeRangeUtils.getXMLCalendarFromDuration(IGH.TimeRangeUtils.getNowInPDT(), IGH.TimeRanges.DEFAULT_REL_END));
                }
            }
            else if (newTimeType === IGH.MWS.TimeRangeType.RELATIVE) {
                if (currentTimeType === IGH.MWS.TimeRangeType.FIXED) {
                    timeRange.startTime(IGH.TimeRangeUtils.getDurationFromXMLCalendar(IGH.TimeRangeUtils.getNowInPDT(), timeRange.startTime()));
                    timeRange.endTime(IGH.TimeRangeUtils.getDurationFromXMLCalendar(IGH.TimeRangeUtils.getNowInPDT(), timeRange.endTime()));
                }
                else {
                    timeRange.startTime(IGH.TimeRanges.DEFAULT_REL_START);
                    timeRange.endTime(IGH.TimeRanges.DEFAULT_REL_END);
                }
            }
        },

        // only update the ui on real changes
        updateControlOnChange: function(control, value){
            if (control.val() !== value) {
                control.val(value);
            }
        },

        // duration has changes in model -> update the UI
        updateControlFromNatural: function(name){
            var naturalTime = IGH.TimeRanges.model.timeRanges().get(0)[name + "Time"]();
            IGH.TimeRanges.updateControlOnChange($("#" + name + "Natural"), naturalTime);
            return false;
        },

        // duration has changes in model -> update the UI
        updateControlFromDuration: function(name){
            var duration = IGH.TimeRanges.model.timeRanges().get(0)[name + "Time"]();
            var control = IGH.TimeRangeUtils.getControlFromDuration(duration);
            for (var prop in control) {
                if (control.hasOwnProperty(prop)) {
                    IGH.TimeRanges.updateControlOnChange($("#" + name + "TimeValue"), Math.round(control[prop] * 10) / 10);
                    IGH.TimeRanges.updateControlOnChange($("select[name=" + name + "Value]"), prop.toLowerCase() + "s");
                }
            }
            return false;
        },

        // calendar has changed in model -> update the UI
        updateControlFromCalendar: function(name){
            var calendar = IGH.TimeRanges.model.timeRanges().get(0)[name + "Time"]();
            var date = IGH.TimeRangeUtils.getControlFromXMLCalendar(calendar);
            // end dates must be after, start dates must be before
            // if end date is not aligned move to the following aligned value (see floor below)
            if (name === "end" && ( date.getSeconds() !== 0 || date.getMinutes() % 5 !== 0)) {
                date.setMinutes(date.getMinutes() + 5);
            }
            IGH.TimeRanges.updateControlOnChange($("#" + name + "Date"), $.datepicker.formatDate(IGH.TimeRanges.FORMAT, date));
            IGH.TimeRanges.updateControlOnChange($("select[name=" + name + "Hours]"), date.getHours());
            IGH.TimeRanges.updateControlOnChange($("select[name=" + name + "Minutes]"), Math.floor(date.getMinutes() / 5) * 5);
            return false;
        },

        // date control has changes update the model
        updateDateFromControl: function(name){
            return function(){
                var date = $("#" + name + "Date").val();
                var hours = parseInt($("select[name=" + name + "Hours]").val(), IGH.TimeRangeUtils.DECIMAL);
                var minutes = parseInt($("select[name=" + name + "Minutes]").val(minutes), IGH.TimeRangeUtils.DECIMAL);
                var parts = date.split('/');
                if (parts.length === 3) {
                    var year = parseInt(parts[0], IGH.TimeRangeUtils.DECIMAL);
                    var month = parseInt(parts[1], IGH.TimeRangeUtils.DECIMAL) - 1;
                    var dayInMonth = parseInt(parts[2], IGH.TimeRangeUtils.DECIMAL);
                    var timeRange = IGH.TimeRanges.model.timeRanges().get(0);
                    var newValue = IGH.TimeRangeUtils.getXMLCalendarFromControl(year, month, dayInMonth, hours, minutes);
                    timeRange[name + "Time"](newValue);
                }
                return false;
            };
        },

        // natural time control has changes, update the model
        updateNaturalFromControl: function(name){
            return function(){
                var timeRange = IGH.TimeRanges.model.timeRanges().get(0);
                timeRange[name + "Time"]($("#" + name + "Natural").val());
                return false;
            };
        },

        // duration control has changes update the model
        updateDurationFromControl: function(name){
            return function(){
                var value = $("#" + name + "TimeValue").val();
                var units = $("select[name=" + name + "Value]").val();
                units = units.slice(0, -1).toUpperCase();
                var timeRange = IGH.TimeRanges.model.timeRanges().get(0);
                var newValue = IGH.TimeRangeUtils.getDurationFromControl(units, value);
                timeRange[name + "Time"](newValue);
                return false;
            };
        }

    };

    jQuery.fn.iGHSingleDoubleClick = function(singleClickCallback, doubleClickCallback, timeout) {
        return this.each(function() {
            var clicks = 0, self = this;
            jQuery(this).on('click', function(event) {
                if (event.preventDefault) {
                    event.preventDefault();
                }
                if (event.stopPropagation) {
                    event.stopPropagation();
                }
                clicks++;
                if (clicks == 1) {
                    setTimeout(function() {
                        if (clicks == 1) {
                            singleClickCallback.call(self, event);
                        }
                        else {
                            doubleClickCallback.call(self, event);
                        }
                        clicks = 0;
                    }, timeout || 300);
                }
            });
        });
    }

    // Initialize and decorate strings
    initialize();
}

IGraphPage = {
    initialize: function() {
        if (!this.onIGraph()) {
            return;
        }
        this.MP = unsafeWindow.MP;
        if (!this.hasFeature('mpFontAwesome')) {
            this.injectFontAwesome();
        }
        if (!this.hasFeature('mpResetControls')) {
            this.addResetControls();
        }
        if (!this.hasFeature('mpMetricMathEnlargeControl')) {
            this.addMetricMathEnlargeControl();
        }
        if (!this.hasFeature('mpCopyPasteTimeControls')) {
            this.addCopyPasteTimeControls();
        }
        this.trapTinyLink();
        this.addSearchCsv();
    },

    hasFeature: function(id) {
        return $('#' + id).length > 0;
    },

    onIGraph: function(withArgs) {
        // Check if we're on iGraph
        var url = window.location.href;
        if (! /\/\/monitorportal.*.amazon.com\/igraph/.test(url)) {
            return false;
        }
        return true;
    },

    injectFontAwesome: function() {
        var heads = document.getElementsByTagName("head");
        if (heads.length > 0) {
            var link = document.createElement("link");
            link.type = "text/css";
            link.rel = "stylesheet";
            link.href = "https://m.media-amazon.com/images/G/01/Fonts/FontAwesome/css/font-awesome.min.css";
            heads[0].appendChild(link);
        }
    },

    updateModel: function(modelSettingsFunc) {
        var MP = IGraphPage.MP;
        var model = MP.graph.model();
        model.enableNotification(false);        // Switch off model events
        modelSettingsFunc();
        model.enableNotification(true);         // Re-enable model events
        model.notify(MP.graph.PARAMS.MODEL_CHANGED_EVENT);    // Fire a model changed event
        MP.GraphSection.displayGraph();
    },

    addMetricMathEnlargeControl: function() {
        var extraOptionsHeader = $('.extraOptionsHeader .headerRight');
        extraOptionsHeader.append('<i class="fa fa-angle-double-left iGHicon metricMathEnlargeIcon" title="Expand panel size (added by iGraphHelper)"></i>');
        extraOptionsHeader.append('<i class="fa fa-angle-double-right iGHicon metricMathReduceIcon" style="display: none;" title="Reset size of panel (added by iGraphHelper)"></i>');
        $('.metricMathEnlargeIcon').on('click', function() {
            $(this).css('display', 'none');
            $('.metricMathReduceIcon').css('display', '');
            $('#extraOptions').addClass('iGHextraOptionsWide');
            $('#extraEditor').attr('rows', 20);
            IGraphPage.MP.SectionHelper._slidingFinished(IGraphPage.MP.SectionHelper, 'extraOptions', true);
        });
        $('.metricMathReduceIcon').on('click', function() {
            $(this).css('display', 'none');
            $('.metricMathEnlargeIcon').css('display', '');
            $('#extraOptions').removeClass('iGHextraOptionsWide');
            $('#extraEditor').attr('rows', 6);
        });
    },

    addResetControls: function() {
        var MP = IGraphPage.MP;
        ['timeRanges', 'generalOptions', 'yAxisOptions', 'extraOptions'].forEach(function(section) {
            $('.' + section + 'Header .headerRight').append('<i class="fa fa-undo iGHicon ' + section + 'ResetIcon" title="Reset settings (added by iGraphHelper)"></i>');
        });
        $('.timeRangesResetIcon').on('click', function() {
            IGraphPage.updateModel(function() {
                var model = MP.graph.model();
                MP.TimeRanges.setTimeRange(model.createTimeRange(MP.MWS.TimeRangeType.RELATIVE, '-PT3H', MP.TimeRanges.DEFAULT_REL_END));
            });
        });
        $('.generalOptionsResetIcon').on('click', function() {
            IGraphPage.updateModel(function() {
                try {
                    var defs = MP.MWS.QS_DEFAULTS;
                    var model = MP.graph.model();
                    var options = model.options();
                    options.graphTitle('');
                    options.decoratePoints(MP.MWS.Boolean.TRUE);
                    options.showXAxisLabel(defs.SHOW_X_AXIS_LABEL);
                    options.showGaps(defs.SHOW_GAPS);
                    options.showLegend(defs.SHOW_LEGEND);
                    options.showLegendErrors(defs.SHOW_LEGEND_ERRORS);
                    options.splitLegend(defs.SPLIT_LEGEND);
                    options.legendPlacement(defs.LEGEND_PLACEMENT);
                    options.verticalLine().clear();
                } catch (e) { console.error(e); }
            });
        });
        $('.yAxisOptionsResetIcon').on('click', function() {
            IGraphPage.updateModel(function() {
                var defs = MP.MWS.QS_DEFAULTS;
                var model = MP.graph.model();
                var options = model.options();
                [ options.leftYAxis(), options.rightYAxis() ].forEach(function(axis) {
                    axis.label('');
                    axis.horizontalLine().clear();
                    axis.showYAxis(defs.SHOW_Y_AXIS)
                    axis.logScaling(defs.LOG_SCALING)
                    axis.shrinkBoundsToGraphData(defs.LOG_SCALING)
                    axis.upperValue('');
                    axis.lowerValue('');
                    axis.clipUpperValue('');
                });
            });
        });
        $('.extraOptionsResetIcon').on('click', function() {
            IGraphPage.updateModel(function() {
                MP.ExtraOptions.setExtra('');
            });
        });
    },

    addCopyPasteTimeControls: function() {
        var MP = IGraphPage.MP;
        $('#timeRanges .topLeft').prepend(
          '<div class="iGHcopyPasteTimeRanges">'
          + '    <i class="fa fa-copy iGHicon copyTimeRangesIcon" style="position: relative;"  title="Copy time range to clipboard for pasting to iGraph or to Wiki dashboard URL (added by iGraphHelper)"></i>'
          + '    <i class="fa fa-paste iGHicon pasteTimeRangesIcon" title="Pastes time ranges from clipboard (added by iGraphHelper)"></i>'
          + '</div>');

        $('.copyTimeRangesIcon').on('click', function() {
            var model = MP.graph.model();
            var timeRangeString = 'No time range was found in iGraph';
            if (model.timeRanges().size() > 0) {
                var timeRange = model.timeRanges().get(0);
                timeRangeString = '?StartTime1=' + timeRange.startTime() + '&EndTime1=' + timeRange.endTime();
            }
            $(this).animate({top: "-5px" }).animate({top: "0" })
            GM_setClipboard(timeRangeString);
        });
        $('.pasteTimeRangesIcon').on('click', function() {
            try {
                var timeRangeString = prompt('Paste iGraph URL or time range copied from another iGraph', '');
                if (timeRangeString) {
                    var params = VerticalLineUtils.parseQueryParams(timeRangeString);
                    var startTime = params['StartTime1'];
                    var endTime = params['EndTime1'];
                    if (startTime && endTime) {
                        var timeType = MP.TimeRangeUtils.getTimeType(startTime);
                        var model = MP.graph.model();
                        var timeRanges = model.timeRanges();
                        IGraphPage.updateModel(function () {
                            timeRanges.clear();
                            timeRanges.add(model.createTimeRange(timeType, startTime, endTime));
                        });
                    }
                }
            } catch (e) { console.error(e);}

        });
    },

    addSearchCsv: function() {
        function showCsv() {
            var csv = IGraphPage.processSearchResultRows();
            Lightbox.display('<span>Search Results in CSV format ' +
              '(<a href="data:text/csv,' + encodeURIComponent(csv) + '" download="iGraphSearch.csv">download link</a>)</span><br>' +
              '<textarea style="width: 500px; height: 280px;" wrap="off">' + csv + '</textarea>', 500, 300);
            $('.iGraphWikiLink').trigger('select');
            return false;
        }

        $('<li><a href="#">CSV</a></li>')
          .insertBefore('.globalFeatureContainer .linkToThisPageClass:last')
          .on('click', showCsv);
    },

    /**
     * Processes each row, creating a corresponding comma-separated
     * row, and deliminate each row with a newline.
     *
     * @return The CSV as a string.
     */
    processSearchResultRows: function() {
        var result = '';

        var rows = document.querySelector('.yui3-tab-panel-selected .yui3-datatable-data, .yui3-tab-panel-selected .yui-dt-data').children;
        for (var rowI = 0; rowI < rows.length; rowI++) {
            var row = rows[rowI];

            var firstPass = true;
            var columns = row.getElementsByTagName('a');
            for (var columnI = 0; columnI < columns.length; columnI++) {
                var column = columns[columnI];

                if(firstPass) {
                    firstPass = false;
                }
                else {
                    result += ',';
                }
                result += column.text;
            }
            result += '\n';
        }

        return result;
    },

    selectText: function(element) {
        var doc = document;
        var text = doc.getElementById(element);
        var selection = window.getSelection();
        var range = doc.createRange();
        range.selectNodeContents(text);
        selection.removeAllRanges();
        selection.addRange(range);
    },

    trapTinyLink: function() {
        if (! jQuery) {
            return;
        }
        var SPINNER = '<img src="/images/spinner.gif">',
          link = document.getElementById('linkToThisGraphTiny'),
          self = this;
        jQuery(link).after('<div id="urlToThisGraphTiny" style="display:none;display:inline;"></div>');
        link.addEventListener('click', function (e) {
            var url = jQuery(link).attr("href");
            url = url.replace(/\/\/tiny\//, "//tiny.amazon.com/");          // Speed up lookup of tiny
            url = url.replace(/[?]comment=undefined/, "?comment=iGraph");   // Fix undefined comment
            jQuery(link).hide();
            jQuery("#urlToThisGraphTiny").html(SPINNER).fadeIn();
            GMUtils.getTinyLinkForUrl(url, function(tinyUrl) {
                jQuery(link).hide();
                jQuery("#urlToThisGraphTiny").html('<span id="tinyUrl">' + tinyUrl + '</span>&nbsp;' +
                  '<span">has been copied to clipboard</span>');
                GM_setClipboard(tinyUrl);
                IGraphPage.selectText("tinyUrl");
                setTimeout(function() {
                    jQuery("#urlToThisGraphTiny").fadeOut(function() {
                        jQuery("#linkToThisGraphTiny").fadeIn();
                    });
                }, 3000);
            });
            e.preventDefault();
            return false;
        });
    }
};

IGraphSettings = {
    settings: {},

    initialize: function() {
        if (! $) {
            return;
        }
        var settingsJSON = $('.IGraphSettings').text();
        if (settingsJSON != '') {
            this.settings = JSON.parse(settingsJSON);
        }
    }
};

VerticalLineUtils = {
    getReadableDateFromXmlDate: function(xmlDate) {
        return xmlDate == "now" ? xmlDate : xmlDate.replace(/-/g, '/').replace('T', ' ').replace(/:..Z/, "") + " UTC";
    },

    epochDaysAgo: function(numberOfDays) {
        return Math.floor(new Date().getTime() / 1000) - numberOfDays * 24 * 60 * 60;
    },

    iGraphUrl: function(verticalLineDef) {
        return 'https://monitorportal.amazon.com/igraph?VerticalLine1=' + encodeURIComponent(verticalLineDef);
    },

    pad: function(number){
        if (number < 10) {
            return "0" + number;
        }
        return number;
    },

    parseQueryParams: function(queryParams) {
        var str = queryParams || window.location.search;
        var paramMap = {};
        str.replace(new RegExp( "([^?=&]+)(=([^&]*))?", "g" ),
          function($0, $1, $2, $3) {
              paramMap[$1] = decodeURIComponent($3);
          }
        );
        return paramMap;
    },

    queryParamsToUrl: function(paramMap) {
        var fieldVals = [];
        for (var key in paramMap) {
            fieldVals.push(encodeURIComponent(key) + "=" + encodeURIComponent(paramMap[key]));
        }
        return fieldVals.join('&');
    }
};

ApolloDeployments = {
    CHECK_DELAY_MS: 250,
    verticalLineSettings: null,
    autoDisplay: false,
    fleetWideOnly: true,
    loadAll: false,
    days: 30,
    COLORS: ['#0000FF', '#00FF00', '#FF00FF', '#00E0E0', '#FFC000', '#FF0000', '#B24DE8',       // Taken from iGraph line colors
        '#808080', '#00B200', '#B200B2', '#00B2B2', '#B28600', '#B20000', '#B3B306',
        '#000000', '#007C00', '#800780', '#007C7C', '#7C5D00', '#FFAFAF', '#E0E000' ],
    DAYS_SELECTION: [ 1, 3, 7, 14, 30, 60, 90, 180 ],
    colorIndex: 0,

    initialize: function() {
        if (! $) {
            return;
        }

        if (IGraphSettings.settings.apolloVerticalLines) {
            for (key in IGraphSettings.settings.apolloVerticalLines) {
                this[key] = IGraphSettings.settings.apolloVerticalLines[key];
            }
        }
        this.displayVerticalLinesLinksOnApolloPage();
    },

    isNewApolloWebsite: function() {
        return $('.awsui').length > 0;
    },

    displayVerticalLinesLinksOnApolloPage: function() {
        var self = this,
          links = [],
          linesHtml;

        ApolloDeployments.DAYS_SELECTION.forEach(function(day) {
            links.push('<a class="iGraphVerticalLineDays" href="#">' + day + '</a>');
        });

        linesHtml = '<span class="iGraphStuff"><span style="display: inline-block; margin-left: 20px; ">iGraph Vertical Lines: ' +
          links.join('&nbsp;') + ' days</span> (include partial <input style="position: relative; top: 2px;" class="iGraphPartial" type="checkbox">) ' +
            '(CloudWatchVLines <input style="position: relative; top: 2px;" class="cloudWatchVLines" type="checkbox">)</span>';

        $('.iGraphStuff').remove();
        if (ApolloDeployments.isNewApolloWebsite()) {
            $(linesHtml).insertBefore('#environmentStageSection ul.awsui-tabs-header.awsui-util-container-header');
        }
        else {
            $(linesHtml).insertBefore('#tabcontainer div.content');
        }
        $('.iGraphVerticalLineDays').on('click', function() {
            var days = parseInt($(this).text(), 10);
            self.loadDeploymentTimesForApollo(days, !$('.iGraphPartial').is(':checked'), $('.cloudWatchVLines').is(':checked'));
        });
    },

    loadDeploymentTimesForApollo: function(days, doFleetWideOnly, isCloudwatchAction) {
        var envUrl;
        if (ApolloDeployments.isNewApolloWebsite()) {
            var stage = $('#environmentStageSection .awsui-tabs-header a.awsui-tabs-tab-active.awsui-tabs-tab-link').attr('data-testid');
            envUrl = window.location.href.replace(/#$/, '').replace(/\/$/, '').replace('https://apollo.amazon.com', '');
            if (!envUrl.includes('/stages/')) {
                envUrl = envUrl + `/stages/${stage}`;
            }
        }
        else {
            envUrl = $('#environment .tabs .selected > a').attr('href');
        }
        if (envUrl != null) {
            var env = envUrl.replace('/environments/', '').replace('-/stages/', '').replace('stages/', '');
            ApolloDeployments.loadDeploymentTimes(env, days, true, null, doFleetWideOnly, isCloudwatchAction);
        }
    },

    loadDeploymentTimes: async function(apolloStage, days, isApolloPage, element, doFleetWideOnly, isCloudwatchAction) {
        var start = VerticalLineUtils.epochDaysAgo(days),
          end = VerticalLineUtils.epochDaysAgo(0);

        if (apolloStage == '') {
            this.displayVerticalLinesOniGraphs(null, element);
            this.colorIndex = 0;
        }
        var deployments = await ApolloDeployments.getDeploymentTimes(apolloStage, [], doFleetWideOnly, start, end);
        if (deployments) {
            ApolloDeployments.displayDeploymentTimes(deployments, days, apolloStage, isApolloPage, element, doFleetWideOnly, isCloudwatchAction);
        }
    },

    getDeploymentTimes: function(apolloStage, deployments, doFleetWideOnly, start, end, ) {
        return new Promise((resolve, reject) => {
            var post_data = JSON.stringify({EnvironmentStageIdentifier: ApolloDeployments.toNameAndStage(apolloStage),
                ...(doFleetWideOnly && { Fleetwide: doFleetWideOnly }),
                Queued: false,
                NotBefore: start,
                NotAfter: end,
                MaxResults: 100});
            GM_xmlhttpRequest({
                method: "POST",
                url: "https://apollo-api-tcp-iad.iad.proxy.amazon.com/",
                data: post_data,
                headers: {
                    "Content-Encoding": "amz-1.0",
                    "Accept": "text/javascript, */*",
                    "Content-Type": "application/json; charset=UTF-8",
                    "X-Amz-Target": "com.amazon.apolloapi.coral.generated.ApolloAPIService.ListDeploymentsForEnvironmentStageV2"
                },
                onload: function(response) {
                    if (response.responseText) {
                        if (/Midway auth/i.test(response.responseText)) {
                            alert("Failed to contact Apollo API service due to Midway auth. Please close the new tab that will open next, then return here and try again.\n\n**If tab fails to load, then please connect to VPN before trying again**");
                            GM_openInTab('https://apollo-api-tcp-iad.iad.proxy.amazon.com', false);
                            resolve(null);
                        }
                        else {
                            try {
                                var deployments = JSON.parse(response.responseText).Deployments;
                                resolve(deployments || []);
                            } catch (e) {
                                // Not a JSON response, so treat as no deployments
                                console.error(error);
                                resolve([]);
                            }
                        }
                    }
                    else {
                        resolve([]);
                    }
                }
            })
        });
    },

    toNameAndStage: function(apolloStage) {
        var stageIndex = apolloStage.lastIndexOf('/')
        var envName = apolloStage.substr(0, stageIndex)
        var stageName = apolloStage.substr(stageIndex + 1)
        return {EnvironmentName: envName, Stage: stageName}
    },

    wasRequestThrottled: function(response) {
        return response.status != 200 && response.responseText && /throttled/.test(response.responseText);
    },

    pushDeployments: function(deployments, currentDeployments) {
        var lastDeploymentId = deployments.length > 0 ? this.getTagValue(deployments[deployments.length - 1], 'deploymentId') : null;
        for (var i = 0; i < currentDeployments.length; i++) {
            var currentDeployment = currentDeployments[i],
              currentDeploymentId = this.getTagValue(currentDeployment, 'deploymentId');
            if (currentDeploymentId !== lastDeploymentId) {
                return deployments.push.apply(deployments, currentDeployments.slice(i));
            }
        }
    },

    parseDeployments: function(response) {
        var goodResponse = response.status == 200,
          xml = new DOMParser().parseFromString(response.responseText, "text/xml"),
          apolloDeployments = xml.getElementsByTagName("entry");

        if (!goodResponse) {
            return;
        }

        return Array.prototype.slice.call(apolloDeployments);
    },

    getOldestDeployment: function(deployments) {
        if (deployments.length > 0) {
            return deployments[deployments.length - 1];
        }
    },

    displayDeploymentTimes: function(deployments, days, apolloStage, isApolloPage, element, doFleetWideOnly, isCloudwatchAction) {
        var verticalLines = [],
          color = this.color || this.COLORS[this.colorIndex ++ % this.COLORS.length],
          verticalLineDef;

        if (deployments.length === 0) {
            alert('No deployments found in last ' + days + ' day' + (days > 1 ? 's': ''));
            return;
        }

        for (var i = 0; i < deployments.length; i++) {
            var deployment = deployments[i];
            verticalLines.push(this.getVerticalLineString(deployment, color));
        }
        verticalLineDef = verticalLines.join(",");

        if (isCloudwatchAction) {
            this.convert_iGraph_To_Cloud_Watch_VLines(verticalLineDef, days);
            return;
        }

        if (isApolloPage) {
            this.displayVerticalLinesOnApolloPage(verticalLineDef, days);
        }
        else {
            this.displayVerticalLinesOniGraphs(verticalLineDef, element);
        }
        this.ifLoadAllSetLoadNextEnv(element);
    },

    getVerticalLineString: function(deployment, color) {
        var startTime = new Date(deployment.StartTime * 1000).toISOString();
        var endTime = new Date(deployment.EndTime * 1000).toISOString();
        var depId = deployment.Id;
        var colorDef = color ? ('#color=' + color) : "";
        return "(Deployment " + depId + " " + colorDef + " @ " + startTime +
          ", ends " + colorDef + " @ " + endTime + ")";
    },

    convert_iGraph_To_Cloud_Watch_VLines: function(iGraphVLines, days) {
        const regex = /\((.*?) #color=(#[A-Fa-f0-9]*) @ (.*?),(.*?) #color=(#[A-Fa-f0-9]*) @ (.*?)\)/gm;
        const deployments = [];

        let m;
        while ((m = regex.exec(iGraphVLines)) !== null) {
            // This is necessary to avoid infinite loops with zero-width matches
            if (m.index === regex.lastIndex) {
                regex.lastIndex++;
            }
            const deploymentStart = '[{"label":"' + m[1] + '", "color": "' + m[2] + '", "value": "' + m[3] + '"}';
            const deploymentEnd = '{"label":"' + m[4] + '", "color": "' + m[5] + '", "value": "' + m[6] + '"}]';
            deployments.push(deploymentStart);
            deployments.push(deploymentEnd);
        }
        const result = deployments.join();

        GMUtils.setClipboard(result);
        alert('Cloudwatch vertical lines (days: ' + days + ') have been copied to the clipboard');
    },

    ifLoadAllSetLoadNextEnv: function(element) {
        if (this.loadAll) {
            var numEnvs = $('option', element).length;
            if (element.selectedIndex + 1 < numEnvs) {
                element.selectedIndex += 1;
                $(element).trigger('change');
            }
        }
    },

    displayVerticalLinesOnApolloPage: function(verticalLineDef, days) {
        GMUtils.setClipboard(verticalLineDef);
        alert('Vertical lines (days: ' + days + ') have been copied to the clipboard');
    },

    getCpuGraphUrl: function(hostclass, host, period, verticalLineDef, days) {
        return 'https://monitorportal.amazon.com/igraph?SchemaName1=Snitch&DataSet1=prod&HostGroup1=' + hostclass + '&Host1=' + host + '&Class1=CPU&Object1=cpu&Metric1=CapacityCPUUtilization&Period1=' + period + '&Stat1=avg&HeightInPixels=250&WidthInPixels=600&VerticalLine1=' + encodeURIComponent(verticalLineDef) + '&StartTime1=-P' + days  + 'D&EndTime1=-PT0H';
    },

    displayVerticalLinesOniGraphs: function(verticalLineDef, element) {
        var verticalLineField = { text: "VerticalLine1", value: "VerticalLine1" };
        var MPW = unsafeWindow.MPW;
        var images = MPW.WikiWidgets._getImages(element);
        for (var i = 0; i < images.length; i++) {
            var image = images[i];
            var imageUrl = MPW.getGraphArgs(image, true);
            if (imageUrl != null) {
                var graphParams = VerticalLineUtils.parseQueryParams(imageUrl);
                var origVerticalLine = graphParams['VerticalLine1'];
                var newVerticalLine = verticalLineDef == null ? '' : (origVerticalLine ? origVerticalLine + "," + verticalLineDef : verticalLineDef);
                graphParams['VerticalLine1'] = newVerticalLine.replace(/,+/g, ",");
                MPW.Util.loadingImg(image);
                var newUrl = MPW.Util.cleanImgUrl(VerticalLineUtils.queryParamsToUrl(graphParams));
                image.src = MPW.GET_GRAPH_LINK + newUrl;
                $(image).parent('a').attr('href', MPW.IGRAPH_LINK.url + newUrl);
            }
        }
        MPW.decorateGraphs(true);
    },

    deploymentTimeClicked: function() {
        var deploymentDays = parseInt($(this).text());
        if (deploymentDays > 0) {
            ApolloDeployments.loadDeploymentTimesForApollo(deploymentDays);
        }
    },

    getDateString: function(deployment, tag) {
        var date = this.getTagValue(deployment, tag);
        return date == null ? "now" : date;
    },

    getTagValue: function(deployment, tag) {
        var el = deployment.getElementsByTagName(tag);
        if (! el[0]) {
            el = deployment.getElementsByTagName("apollo:" + tag);
        }
        if (! el[0]) {
            return null;
        } else {
            return el[0].textContent;
        }
    }
};

InteractiveWikiGraphs = {
    initialize: function() {
        WebLabTimes.waitFor(function () {
            return document.querySelector('.MPWwidgetContainer') != null;
        }, InteractiveWikiGraphs.displayInteractiveButton);
    },

    addChildWindowOpening: function() {
        function interactiveGraphOpening() {
            var CHILD_URI = 'https://cloudwatch-console-tools.iad.amazon.com',
              CHILD_URL = CHILD_URI + '/igraph/GoInteractive.html',
              childWindow;

            window.openInteractiveGraphWindow = function() {
                childWindow = window.open(CHILD_URL);
            }
            function childReady(event) {
                childWindow.postMessage(window.dashboardDef, CHILD_URI);
            }
            window.addEventListener("message", childReady, false);
        }
        var script = document.createElement('script');
        script.appendChild(document.createTextNode('('+ interactiveGraphOpening +')();'));
        (document.head || document.body).appendChild(script);
    },

    getGraphDefinition: function(graphArgs) {
        var title = WikiSnapshot.extractQueryValue(graphArgs, 'GraphTitle') || '',
          graphDef =
            'metrics:\n' +
            '- {iGraph: "' + graphArgs + '" }\n' +
            'title: "' + title + '"\n' +
            'period: 300\n' +
            'stat: Average\n' +
            'yAxis: \n' +
            '  left: \n' +
            '  right: \n' +
            'region: us-east-1\n';
        return graphDef;
    },

    getDashboardDefinition: function() {
        var dashboardDef = [],
          imageIndex = 0;

        for (var i = 0; i < document.images.length; i++) {
            var image = document.images[i];
            var graphArgs = unsafeWindow.MPW.getGraphArgs(image, true);
            if (graphArgs != null) {
                dashboardDef.push(this.getGraphDefinition(graphArgs));
            }
        }
        return JSON.stringify(dashboardDef);
    },

    displayInteractiveGraphs: function() {
        unsafeWindow.dashboardDef = InteractiveWikiGraphs.getDashboardDefinition();
        unsafeWindow.openInteractiveGraphWindow();
    },

    displayInteractiveGraph: function(graphArgs) {
        unsafeWindow.dashboardDef = JSON.stringify([ InteractiveWikiGraphs.getGraphDefinition(graphArgs) ]);
        unsafeWindow.openInteractiveGraphWindow();
    },

    displayInteractiveButton: function() {
        InteractiveWikiGraphs.addChildWindowOpening();
        var button = document.createElement('span');
        button.style.float = 'right';
        button.innerHTML = '<input value="Interactive Graphs" class="MPWbutton primary IGHinteractiveGraphs" type="submit">';
        button.onclick = InteractiveWikiGraphs.displayInteractiveGraphs;
        document.querySelector('.MPWwidgetContainer').appendChild(button);
    }
};

var addStyle = GM_addStyle;

function localGMCode(win, unsafeWin) {
    win.Lightbox = {
        display: function (content, width, height) {
            function initLightbox() {
                var STYLES = '\
                #iGraphLightbox {\
                    visibility:hidden;\
                    position:fixed;\
                    background:white;\
                    border:2px solid #3c3c3c;\
                    color:black;\
                    z-index:15100;\
                    padding:20px;\
                }\
                #iGraphLightboxDimmer{\
                    background: #000;\
                    position: fixed;\
                    opacity: .5;\
                    top: 0;\
                    z-index:1509;\
                }';
                addStyle(STYLES);
                $('body').append('<div id="iGraphLightbox"></div><div id="iGraphLightboxDimmer"></div>');
            }

            if (!this.initialized) {
                initLightbox();
                this.initialized = true;
            }

            var lightbox = document.getElementById("iGraphLightbox"),
              dimmer = document.getElementById("iGraphLightboxDimmer");
            $(lightbox).html(content);

            lightbox.style.width = width + 'px';
            lightbox.style.height = height + 'px';
            dimmer.style.width = window.innerWidth + 'px';
            dimmer.style.height = window.innerHeight + 'px';

            dimmer.onclick = function () {
                lightbox.style.visibility = 'hidden';
                dimmer.style.visibility = 'hidden';
                $(lightbox).html('');
            }

            dimmer.style.visibility = 'visible';
            lightbox.style.visibility = 'visible';
            lightbox.style.top = (window.innerHeight - height) / 2 + 'px';
            lightbox.style.left = (window.innerWidth - width) / 2 + 'px';
            $('.iGraphChimeRoomManagerControls').hide();
            return false;
        }
    };

    win.GMUtils = {
        initialize: function() {
            this.injectFunctionsIntoPage();
        },

        injectFunctionsIntoPage: function () {
            var gmInjectFuncs = {
                getAccountName: function(accountId) { if (typeof AccountName !== 'undefined') { return AccountName.getAccountName(accountId); } },
                accountIdToName: async function(accountId) { if (typeof AccountName !== 'undefined') { return await AccountName.accountIdToName(accountId); } },
                addStyle: function(styles) { return setTimeout(() => { GM_addStyle(styles); }, 0); },
                domToImage: function() { return domtoimage; },
                getIsengardLinkForUrl: function(url) { return getIsengardLinkForUrl(url); },
                getTinyLinkForUrl: function(url, callback) { return getTinyLinkForUrl(url, callback); },
                getValue: function(name, def) { return GM_getValue(name, def); },
                gmXmlHttpRequest: function(object) { return GM_xmlhttpRequest(object); },
                sendFormDataToS3: function(object) { return sendFormDataToS3(object); },
                sendJSONtoURL: function(webhookUrl, message) { return sendJSONtoURL(webhookUrl, message); },
                setClipboard: function(value, type) { return setTimeout(() => { GM_setClipboard(value, type) }, 0); },
                setValue: function(name, value) { return GM_setValue(name, value); },
                snapshotDisplay: function(snapshotUrl, iGraphUrl, graphId) { if (typeof WikiSnapshot != 'undefined') { WikiSnapshot.snapshotDisplay(snapshotUrl, iGraphUrl, graphId); } },
                snapshotDisplayInPopup: function(graphModel, id) { if (typeof WikiSnapshot != 'undefined') { WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, graphModel, 'CloudWatch graph', false, id); } }
            };

            // Support for GreaseMonkey implementations that don't proxy the
            // Firefox Components.utils API (e.g. ViolentMonkey)
            if (typeof createObjectIn === "undefined") {
                createObjectIn = function(scope, opts) {
                    return scope[opts.defineAs] = new scope.Object();
                }
            }

            if (typeof exportFunction === "undefined") {
                exportFunction = function(func, scope, options) {
                    if (options && options.defineAs) {
                        scope[options.defineAs] = func;
                    }
                    return func;
                };
            }

            var injectedGM = createObjectIn(unsafeWin, {defineAs: "iGraphHelperGM"});
            exportFunction(gmInjectFuncs.accountIdToName, injectedGM, {defineAs: "accountIdToName" });
            exportFunction(gmInjectFuncs.getAccountName, injectedGM, {defineAs: "getAccountName" });
            exportFunction(gmInjectFuncs.addStyle, injectedGM, {defineAs: "addStyle" });
            exportFunction(gmInjectFuncs.domToImage, injectedGM, {defineAs: "domToImage" });
            exportFunction(gmInjectFuncs.getValue, injectedGM, {defineAs: "getValue" });
            exportFunction(gmInjectFuncs.gmXmlHttpRequest, injectedGM, {defineAs: "gmXmlHttpRequest" });
            exportFunction(gmInjectFuncs.getTinyLinkForUrl, injectedGM, {defineAs: "getTinyLinkForUrl" });
            exportFunction(gmInjectFuncs.sendFormDataToS3, injectedGM, {defineAs: "sendFormDataToS3" });
            exportFunction(gmInjectFuncs.sendJSONtoURL, injectedGM, {defineAs: "sendJSONtoURL" });
            exportFunction(gmInjectFuncs.setClipboard, injectedGM, {defineAs: "setClipboard" });
            exportFunction(gmInjectFuncs.setValue, injectedGM, {defineAs: "setValue" });
            exportFunction(gmInjectFuncs.snapshotDisplay, injectedGM, {defineAs: "snapshotDisplay" });
            exportFunction(gmInjectFuncs.snapshotDisplayInPopup, injectedGM, {defineAs: "snapshotDisplayInPopup" });
            return true;
        },

        log: function(msg) {
            win.console.log(msg);
        },

        getValue: function(key) {
            if (typeof GM_getValue !== 'undefined') {
                return GM_getValue(key);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.getValue(key);
            }
            return null;
        },

        setValue: function(key, value) {
            if (typeof GM_setValue !== 'undefined') {
                return GM_setValue(key, value);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.setValue(key, value);
            }
            return null;
        },

        gmXmlHttpRequest: function(object) {
            if (typeof GM_xmlhttpRequest !== 'undefined') {
                return GM_xmlhttpRequest(object);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.gmXmlHttpRequest(object);
            }
            return null;
        },

        getTinyLinkForUrl: function(url, callback) {
            if (typeof getTinyLinkForUrl !== 'undefined') {
                return getTinyLinkForUrl(url, callback);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.getTinyLinkForUrl(url, callback);
            }
            return null;
        },

        sendFormDataToS3: function(object) {
            if (typeof sendFormDataToS3 !== 'undefined') {
                return sendFormDataToS3(object);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.sendFormDataToS3(object);
            }
            return null;
        },

        sendJSONtoURL: function(webhookUrl, message) {
            if (typeof sendJSONtoURL !== 'undefined') {
                return sendJSONtoURL(webhookUrl, message);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.sendJSONtoURL(webhookUrl, message);
            }
            return null;
        },

        setClipboard: function(value, type) {
            if (typeof GM_setClipboard !== 'undefined') {
                return GM_setClipboard(value, type);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.setClipboard(value, type);
            }
            return null;
        },

        addStyle: function(styles) {
            if (typeof GM_addStyle !== 'undefined') {
                return GM_addStyle(styles);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.addStyle(styles);
            }
            return null;
        },

        domToImage: function(styles) {
            if (typeof domtoimage !== 'undefined') {
                return domtoimage;
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.domToImage();
            }
            return null;
        }
    };

    win.WikiSourceEditor = {
        CW_CONSOLE: 'https://console.aws.amazon.com/cloudwatch/home?region=us-east-1',
        NOT_FOUND: 'Could not find a CloudWatch graph definition. Is the cursor inside a \'{{transclude name="CloudWatch.Graph"... /}}\' definition?',
        $textarea: null,
        _metricWidgetStr: null,
        _cwConsoleChildWindow: null,

        initialize: function() {
            this.$textarea = jQuery('#content');
            if (/transclude.*name="CloudWatch.Graph"/.test(this.$textarea.val())) {
                GM_registerMenuCommand("iGraph Helper: open current graph in console (Ctrl-Alt-C)", function() { WikiSourceEditor._openCurrentGraph(); } );
                GM_registerMenuCommand("iGraph Helper: select current graph (Ctrl-Alt-V)", function() { WikiSourceEditor._selectCurrentGraph(); } );
                unsafeWin.addEventListener('keydown', function(e) { WikiSourceEditor._keyListen(e); }, true);
            }
        },

        onEditPage: function() {
            return /^[/]bin[/]edit[/]/.test(window.location.pathname);
        },

        onSourceEditor: function() {
            return /editor=wiki/.test(window.location.search);
        },

        _keyListen: function(e) {
            if (e.ctrlKey && e.altKey) {
                if (e.code === 'KeyC') {
                    this._openCurrentGraph();
                } else if (e.code === 'KeyV') {
                    this._selectCurrentGraph();
                }
            }
        },

        _getCurrentGraph: function() {
            var wikiSource = this.$textarea.val(),
              cursor = this.$textarea.prop('selectionStart'),
              before = wikiSource.substr(0, cursor),
              after = wikiSource.substr(cursor),
              start = this._lastIndexOf(before, /{{transclude name="CloudWatch.Graph"/g),
              end = after.search(/\/}}/);

            if (start >= 0 && end >= 0) {
                return {
                    start: start,
                    end: before.length + end + 3,
                    text: before.substr(start) + after.substr(0, end)
                };
            }

            return null;
        },

        _openCurrentGraph: function() {
            var currentGraph = this._getCurrentGraph(),
              metricWidgetStr,
              jsonStart,
              jsonEnd,
              graphText;

            if (currentGraph) {
                // Found graph - now find Metric Widget definition - it's the JSON in {} - skip past the {{ and }} at start/end
                graphText = currentGraph.text.replace(/^{{/, '').replace(/}}$/, '');
                jsonStart = graphText.indexOf('{');
                jsonEnd = graphText.lastIndexOf('}');

                if (jsonStart >= 0 && jsonEnd >= 0) {
                    metricWidgetStr = graphText.substr(jsonStart, jsonEnd - jsonStart + 1);
                    this._openInCloudWatchConsole(metricWidgetStr);
                    return;
                }
            }

            alert(this.NOT_FOUND);
        },

        _selectCurrentGraph: function() {
            var currentGraph = this._getCurrentGraph();

            if (currentGraph) {
                // Select graph text and set focus to textarea
                this.$textarea.prop('selectionStart', currentGraph.start);
                this.$textarea.prop('selectionEnd', currentGraph.end);
                this.$textarea.focus();
            } else {
                alert(this.NOT_FOUND);
            }
        },

        _receiveMessagesInit: function () {
            var self = this;
            if (! this._receiveInitialized) {
                this._receiveInitialized = true;
                unsafeWin.addEventListener('message', function(event) {
                    self._receiveChildPostMessageEvents(event);
                }, false);
            }
        },

        _openInCloudWatchConsole: function(metricWidgetStr) {
            this._receiveMessagesInit();
            this._metricWidgetStr = metricWidgetStr;
            this._cwConsoleChildWindow = unsafeWin.open(this.CW_CONSOLE);
        },

        _receiveChildPostMessageEvents: function(event) {
            var encodedGraph;
            if (event && event.data === 'CloudWatchDashboardsReady' && this._cwConsoleChildWindow && this._metricWidgetStr) {
                // % chars in URL need special handling to get through console's GWT URL handling, quadruple encoded!
                encodedGraph = encodeURIComponent(this._metricWidgetStr.replace(/[%]/g, '%252525').replace(/[#]/g, '%252523'));
                this._cwConsoleChildWindow.postMessage(JSON.stringify({
                    action: 'DeepLink',
                    deepLink: '#metricsV2:graph=' + encodedGraph
                }), '*');

                // Forget graph, so that a refresh of the child page does not trigger continuous deep link posting events
                this._metricWidgetStr = null;
            }
        },

        _lastIndexOf: function(str, regex) {
            var lastIndexOf = -1,
              nextStop = 0,
              result;

            while((result = regex.exec(str)) != null) {
                lastIndexOf = result.index;
                regex.lastIndex = ++nextStop;
            }
            return lastIndexOf;
        }
    };

    win.RefreshGraphs = {
        DELAY_IN_MS: 500,   // Refresh 2 every second

        refreshSlowly: function() {
            var images = unsafeWin.jQuery('img[src*="Action=GetGraph"],img[src*="/cw/getMetricWidgetImage"]').sortByDistanceFromView();
            for (var i = 0; i < images.length; i++) {
                this.refreshAfter(images[i], i * this.DELAY_IN_MS);
            }
        },

        refreshAfter: function(image, millis) {
            setTimeout(function() {
                console.log(image);
                unsafeWin.MPW.refreshImage(image);
            }, millis);
        }
    };

    win.Tinify = {
        initialize: function() {
            function checkForCtrlY(event) {
                if (event.key === 'y' && event.ctrlKey) {
                    win.Tinify.tiny();
                }
            }
            document.addEventListener('keydown', checkForCtrlY, false);
        },

        tiny: function() {
            const url = win.location.href;
            const pageTitle = (win.document.title || '').substring(0, 20);  // Max 20 chars
            const tinyCommandUrl = `https://tiny.amazon.com/submit/url?comment=${encodeURIComponent(pageTitle)}&name=${encodeURIComponent(url)}`;

            GMUtils.getTinyLinkForUrl(tinyCommandUrl, function(tinyUrl) {
                setTimeout(() => { GM_setClipboard(tinyUrl); }, 0);      // call clipboard asynchronously, more reliable

                GM_notification({
                    title: 'iGraph Helper',
                    text: 'Tiny URL copied to clipboard: ' + tinyUrl,
                    timeout: 2000
                });
            });
        }
    };

    win.AccountName = {
        accountIdNamePairs: {},
        getAccountName: function (accountId) {
            return this.accountIdNamePairs[accountId];
        },

        accountIdToName: async function (accountId) {
            const trimmedAccountId = accountId.trim();
            if (/^\d{12}$/.test(trimmedAccountId)) {
                let name = await this.getAccountNameFromIsengard(trimmedAccountId);
                if (!name) {
                    name = await this.getAccountNameFromConduit(trimmedAccountId);
                }
                this.accountIdNamePairs[trimmedAccountId] = name;
                return name;
            }
        },
  
        getAccountNameFromIsengard: async function(accountId) {
            const response = await GM.xmlHttpRequest({
                method: 'POST',
                url: 'https://isengard-service.amazon.com',
                headers: {
                    'Content-Encoding': 'amz-1.0',
                    'X-Amz-Target': 'com.amazon.isengard.coral.IsengardService.GetAWSAccount',
                    'Content-Type': 'application/json; charset=UTF-8'
                },
                xhrFields: {
                    withCredentials : true
                },
                data: `{"AWSAccountID": "${accountId}"}`
            });

            if (response && response.responseText) {
                const accountInfo = JSON.parse(response.responseText);
                if (accountInfo && accountInfo.AWSAccount) {
                    let name = accountInfo.AWSAccount.Name;

                    // Name field may not be set - take the email address before @ instead
                    if (!name || /^\s*$/.test(name)) {
                        name = accountInfo.AWSAccount.Email.split("@")[0];
                    }
                    
                    return name;
                }
            }
        },

        getAccountNameFromConduit: async function(accountId) {
            const response = await GM.xmlHttpRequest({
                method: 'GET',
                url: `https://conduit.security.a2z.com/api/accounts/partition/aws/accountId/${accountId}`,
                xhrFields : {
                    withCredentials : true
                }
            });

            if (response && response.responseText && !/EntityNotFoundException/.test(response.responseText)) {
                const accountInfo = JSON.parse(response.responseText);
                if (accountInfo && accountInfo.account) {
                    return accountInfo.account.name;
                }
            }
        }
    };

    win.WikiSnapshot = {
        SPINNER_IMG: 'data:image/gif;base64,R0lGODlhEAAQALMAAN7e3s7Ozrm5uampqZiYmIiIiHd3d2dnZ1ZWVkZGRjExMQAAAP///wAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFBwAMACwAAAAAEAAQAAAEZ5BJBqgxM8+QAlBKoGXB0oFAqgUisRDKklYZohABaBwqRQOHhULgmcwqswFCRMoQDrsBLdMrHK6D0fEoKEwlPXAhwVsRxQkCgIBjSQFnRlGAEAzUuJHEoL4DAmpaXmsEFAJfIwICehEAIfkEBQcADAAsAAAAAA8AEAAABFmQycnKDHQemSRIQ8YoyMct2ARMQ6IQyzYZ3ZcUhrKsVJ6kDIFAJDnwiIOCckhkAAgGQ4HZvBCqrIOBeCQcQowBYJUKHBkBQ0AYPE8swSGASrkGxWhsADiJAAAh+QQFBwAMACwAAAAAEAAQAAAEWpDJyUiRgFKTUeqCxmTckTAGE06ZpDDeCgAhUCBCgBwWIhULReuSygACBEVwQBFcKANFoSWwEAKi1mhQeIq+EiZYUyBkNdyQYDU6j6YBrFY0qMnnUEl8rJl9IwAh+QQFBwAMACwAAAAAEAAPAAAEVpDJKQmgGBRpEMdSgGzGwWygNDBCKaHBtAFHMRCHwgw6NQIxiSCRSsUMAcBlwEwZFNCDgEANUnILBUKpFBi5IcIKZGURYoGy5BKaDMDFUJILLM7pykkEACH5BAUHAAwALAAAAAAQAA8AAARbkMnJxqBYElnMDBlwbEzBGAqYMUdQmEp2gaZwJYzA4FpBBABJELHTfUgTQIIQZAQEAmCmgKgWAhYjxhM7UFRJxTWgAkAxgcUi0XwKmxPDIsWAwym2O0B/p/QzEQAh+QQFBwAMACwAAAAAEAAQAAAEWpDJyYSgWA5JCs9SsRUEQyRg5UkBKgGSMMBEKRSIlBzTJcCTwEGBCGAuFCEFEAAAMQPD4UBgBpqZE8qwzCCqjKczuWHwJmMKYtFNDRbcFCaxQKaMFUVZHnxGAAAh+QQFBwAMACwAAAAAEAAQAAAEVZDJyQK9U0wyAWaENUyHh1nAwCEjFWjMIAQBYUjHLb3WVTAGkwTQ6xhaH0zBoPMIKQPEAfFLSo7WjkABtBIKCUWgoEAkFYpfFYZB94oft4X9OSSclAgAIfkEBQcADAAsAgAAAA4AEAAABFeQyRmmlZUJIcfVgMYJxQeMAlBaoVYBQxkYBAPcV4isUmsVnM9FQCgUBr6hYVkTMoA2TI+SUPAkCusAkWgdJoWFIZGo1TKMwEIRqAIQbAtBEYwmPq+lMAIAIfkEBQcADAAsAAAAABAAEAAABFCQyckAoBiHIEWWF7NJxAeKHMGZVjdUhYkRsUyVNpXmUlD8r07Cc8scFgsc6MBQKhYISeJViBISMQCB2EREFaAVJQHwMpghioeTiJZZkt8nAgAh+QQFBwAMACwAAAEAEAAOAAAETZBJBqoFYWp9xf6TAIAc5jHDQGoCca6SkEmFkigFmA7CsSyKA4hAfBEYs8kgiQxtDAhNgmFgIIQBQrXnZBypB48KpIgehIUoSH2WGJIRACH5BAUHAAwALAAAAgAQAA4AAARWkMlJGaihzkuDWkQFcELGCJ8iYGVXLAPGSQlTa4CgB4biFzjBYGAKDBCzDQVgYChMk0IhJkEoJoaAEMiYSoiMgWIgZSA0ksuhCySsNYF3odlFUwYhTQQAIfkECQcADAAsAAAAABAAEAAABFuQSSCrvUykgLtYSdcdywBQGIAwBbMoaRWsDDFYJzoRinDpEsSBhgkYAYVEAkHoGAMogMCA8Vk4itBlQLAyqC1Di9MEdCVWnzVg4DCADESryRi0OneWhADH3DARADs=',
        SNAPSHOT_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsEAAA7BAbiRa+0AAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAAEVSURBVDhPpZOxDcIwEEUviBIqOliBJRALMAKhYwaHikSICegII7AAYgkKMkDomAH8D184B6cIeZJ1Z/v738lOIiJ62dEZNrJ8Zn8SRRH1XN6Zxo42SeIyn22auuwLOgIw8kiMcdkvoT14eB1JF6GqmrrO60hXQh6qXF/f73Yc4eFdNpwTW204GHC1VRx7QzpAR9Dei4LnoO9iRZZlaJEPjicTOj/ndDvMuAAOYw/RGEOPsnSn6Pf5IRBgAqbrK6Xq3qBBQU1lVFr3kECAmQCNLgi8jrQgP51oMbpwDnTeVJBvPl4uX1bALyBrkofWoMUZtfY1EoHEOnoPsdGoLdrI+7Lx5G045jlHfA6NP20bKqPPtAtEbw8iYxB46Q0cAAAAAElFTkSuQmCC',
        COLOR_BLIND_FRIENDY_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAAEbSURBVDhPrVQxDsIwDHS6dEMVLEiwVDDxBt7CQ3hO39C3MCF1YWAgbcWOSs5xQhJRQMBJp9jx+eQ0bRURDYY/g42Gq02+hZoQZRJTu1lL9DnSHkzE1Mu1j0HUUj7TSu1RdALXNEZouq57beSEXKzOEZVSvlaWJethiNw/IwAPDZidjmQabBLgslhxDWiahvpbR0VRcA5414hmgvCYHJu9PM8jnTuFvf5hIDO2CQNUZ170fssrTyJ7tJvb1QB96Oej9X1PdV1zYRRPTIC2bSWS8UCtdTS2Ow7o46Dubk7yhxGYZRkX0MixGHmzxGTUCAwbHHH1WFFL9aKJN1OhiJhvNOOCVwy18Ig+2unBvmyfANrwo/3bb+RPPzaiO3OWgslMWGyFAAAAAElFTkSuQmCC',
        INTERACTIVE_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAABdSURBVDhPY2RgYPgPxBQDsEH/j5hCeGQCRpvTDExQNsWAlgaBfAvCIPCRIR3obEabBwzboSK4ABaDQGFPevjTK7B/MEzMINtr5IFRgwgDqhk0jDMt2GsQJiWAgQEAZyAY3kmtuyIAAAAASUVORK5CYII=',
        SNAPSHOT_HISTORY_KEY: 'iGraphHelper.snapshotHistory',
        SNAPSHOT_HISTORY_PREVIOUS_KEY: 'iGraphHelper.snapshotHistoryPrevious',
        SNAPSHOT_OUTPUT_MODE_KEY: 'iGraphHelper.snapshotOutputMode',
        SNAPSHOT_AUTOSNAP_KEY: 'iGraphHelper.snapshotAutoSnap',
        SNAPSHOT_OBEY_FIT_KEY: 'iGraphHelper.snapshotObeyFit',
        SNAPSHOT_CHIME_ROOMS_KEY: 'iGraphHelper.chimeRooms',
        SNAPSHOT_CURRENT_CHIME_ROOM_KEY: 'iGraphHelper.currentChimeRoom',
        COLOR_BLIND_FRIENDLY_PALETTE: [ // Taken from iGraph cbf palette
            '#781c81', '#55a1b2', '#ceb641', '#531b7f', '#62ac9a', '#dbab3b', '#452d8a',
            '#72b582', '#e39a36', '#3f479c', '#83ba6d', '#e78232', '#4063b0', '#97bd5d',
            '#e6642c', '#447cbf', '#abbe51', '#e14226', '#4b91c0', '#bebc48'
        ],
        MAX_HISTORY_ITEMS: 200,
        DECIMAL: 10,
        DURATION: new RegExp('^-?P'),
        PATTERN: {
            DAY: new RegExp('(\\d*)D'),
            HOUR: new RegExp('(\\d*)H'),
            MINUTE: new RegExp('(\\d*)M')
        },
        DURATIONS: {
            DAY: "D",
            HOUR: "H",
            MINUTE: "M"
        },
        MINUTES: {
            DAY: 24 * 60,
            HOUR: 60,
            MINUTE: 1
        },
        UNITS: {
            MINUTE: "MINUTE",
            HOUR: "HOUR",
            DAY: "DAY"
        },
        ORDERED_UNITS: ["MINUTE", "HOUR", "DAY"],
        MODES: { RAW: "Raw", TT: "TT", NEW_WIKI: "New Wiki", OLD_WIKI: "Old Wiki", MARKDOWN: "Markdown (SIM etc)", JIRA: "JIRA", EMAIL: "Email", CHIME_MARKDOWN: "ChimeMarkdown", CHIME: "Chime", SLACK: "Slack", QUIP2WIKI: "Quip2Wiki", },

        // Add good jQuery DOM selector defaults for Amazon pages here
        PAGE_TO_SNAPSHOT_SELECTOR_MATCHER: [
            { urlRegex: /cloudwatch[/]home.*#alpine/, selector: '#gwt-debug-dashboards', name: 'CloudWatch Alpine' },
            { urlRegex: /cloudwatch[/]home.*#contributor-insights:rules/, selector: '#gwt-debug-dashboards', name: 'CloudWatch Contributor Insights' },
            { urlRegex: /cloudwatch[/]home.*#dashboards:name/, selector: '.cwdb-dashboard-content', name: 'CloudWatch Dashboard' },
            { urlRegex: /cloudwatch[/]home.*#alarmsV2:alarm/, selector: '.graph-section-content', name: 'CloudWatch Alarm' },
            { urlRegex: /cloudwatch[/]home.*#logsV2:logs-insights/, selector: '.histogram', name: 'CloudWatch Insights' },
            { urlRegex: /cloudwatch[/]home.*#xray:service-map\/map/, selector: '.graph', name: 'X-Ray Trace Map' },
            { urlRegex: /retro.corp.amazon.com/, selector: '.main-content', name: 'Simple Retrospectives' },
            { urlRegex: /rtla.amazon.com.explore.do/, selector: '#chart', name: 'RTLA' },
            { urlRegex: /w.amazon.*index.php/, selector: '#mainContent', name: 'Old Wiki' },
            { urlRegex: /^https:..k2[.]/, selector: '.highcharts-container', name: 'K2 graph' },
            { urlRegex: /profiler.amazon.com[/]profile/, selector: '.flame-graph svg', name: 'Amazon Profiler' }
        ],
        K2_ENDPOINT: {
            'aws': 'https://k2.amazon.com',
            'aws-cn': 'https://k2.bjs.aws-border.com',
            'aws-us-gov': 'https://k2.amazon.com',
            'aws-iso': 'https://k2.us-iso-east-1.c2s.ic.gov',
            'aws-isob': 'https://k2.lck.aws-border.com'
        },

        // All public regions before HKG do not have to be "opted-in" to, see https://w.amazon.com/bin/view/AWSAuth/Onboarding/OptInRegions/
        // For these regions we can use GetMetricWidgetImage API to snapshot graphs, but all other regions
        // require using the in-browser method (which can be less reliable)
        NOT_AUTH_OPT_IN_REGION: {
            "ap-northeast-1": true,
            "ap-northeast-2": true,
            "ap-northeast-3": true,
            "ap-south-1": true,
            "ap-southeast-1": true,
            "ap-southeast-2": true,
            "ca-central-1": true,
            "eu-central-1": true,
            "eu-north-1": true,
            "eu-west-1": true,
            "eu-west-2": true,
            "eu-west-3": true,
            "sa-east-1": true,
            "us-east-1": true,
            "us-east-2": true,
            "us-west-1": true,
            "us-west-2": true
        },

        STYLES: '\
            .iGraphWikiSpinner {\
                left: -1px !important;\
                position: relative !important;\
                top: 4px !important;\
                margin-right: 6px !important;\
                visibility: hidden;\
                vertical-align: unset !important;\
                padding-top: 0px !important;\
            }\
            .iGraphWikiSnapshotPopup, .iGraphWikiSnapshotMessage {\
                font-family: Arial, Helvetica, sans-serif !important;\
                font-size: 12px !important;\
                text-align: left !important;\
            }\
            .iGraphWikiSnapshotControls, .iGraphChimeRoomManagerControls {\
                position: relative !important;\
                margin-bottom: 5px !important;\
            }\
            .iGraphWikiSnapshotControls .MPWbutton,\
            .iGraphWikiSnapshotControls .iGHbutton {\
                margin-right: 10px !important;\
            }\
            .iGraphWikiSnapshotMessage {\
                position: absolute !important;\
                bottom: 20px !important;\
                left: 25px !important;\
            }\
            .iGraphWikiSnapshotImageContainer {\
                width: 400px !important;\
                height: 200px !important;\
                display: inline-block !important;\
                vertical-align: top !important;\
                margin-right: 10px !important;\
                overflow: hidden !important;\
            }\
            .iGraphWikiSnapshotImage {\
                max-width: 100% !important;\
                max-height: 100% !important;\
            }\
            .iGraphWikiSnapshotImageControls {\
                width: 305px !important;\
                height: 200px !important;\
                display: inline-block !important;\
                vertical-align: top !important;\
            }\
            .iGraphWikiSnapshotPreview {\
                border: 1px solid #999 !important;\
                margin-left: 5px !important;\
                width: 750px !important;\
                height: 250px !important;\
                vertical-align: top !important;\
                display: inline-block !important;\
                overflow: auto !important;\
            }\
            .iGraphWikiSnapshotTitle {\
                font-size: 15px !important;\
                font-weight: bold !important;\
            }\
            .iGraphWikiChimeRooms {\
                width: 98px !important;\
                padding: 0 !important;\
                font-size: 12px !important;\
                height: 20px !important;\
                margin: 0px 10px !important;\
            }\
            .iGHbutton-bar {\
                display: inline-block !important;\
                vertical-align: top !important;\
                margin: 0 0 5px 5px !important;\
            }\
            .iGHbutton-bar:after {\
                clear: both !important;\
            }\
            .iGHbutton-bar .iGHbutton-group {\
                margin-right: 0.55556rem !important;\
            }\
            .iGHbutton-bar .iGHbutton-group div {\
                overflow: hidden !important;\
            }\
            .iGHbutton-group {\
                left: 0 !important;\
                list-style: outside none none !important;\
                margin: 0 !important;\
                padding: 0 !important;\
            }\
            .iGHbutton-group:before, .iGHbutton-group:after {\
                content: " " !important;\
                display: table !important;\
            }\
            .iGHbutton-group:after {\
                clear: both !important;\
            }\
            .iGHbutton-group > li {\
                display: inline-block !important;\
                margin: 0 -2px !important;\
            }\
            .iGHbutton-group > li > iGHbutton, .iGHbutton-group > li .iGHbutton {\
                border-color: rgba(255, 255, 255, 0.5) !important;\
                border-left: 1px solid rgba(255, 255, 255, 0.5) !important;\
            }\
            .iGHbutton-group > li:first-child iGHbutton, .iGHbutton-group > li:first-child .iGHbutton {\
                border-left: 0 none !important;\
            }\
            .iGHbutton-group.iGHround > * {\
                display: inline-block !important;\
                margin: 0 -2px !important;\
            }\
            .iGHbutton-group.iGHround > * > iGHbutton, .iGHbutton-group.iGHround > * .iGHbutton {\
                border-color: rgba(255, 255, 255, 0.5) !important;\
                border-left: 1px solid rgba(255, 255, 255, 0.5) !important;\
            }\
            .iGHbutton-group.iGHround > *:first-child iGHbutton, .iGHbutton-group.iGHround > *:first-child .iGHbutton {\
                border-left: 0 none !important;\
            }\
            .iGHbutton-group.iGHround > *, .iGHbutton-group.iGHround > * > a, .iGHbutton-group.iGHround > * > iGHbutton, .iGHbutton-group.iGHround > * > .iGHbutton {\
                border-radius: 0 !important;\
            }\
            .iGHbutton-group.iGHround > *:first-child, .iGHbutton-group.iGHround > *:first-child > a, .iGHbutton-group.iGHround > *:first-child > iGHbutton, .iGHbutton-group.iGHround > *:first-child > .iGHbutton {\
                border-bottom-left-radius: 1000px !important;\
                border-top-left-radius: 1000px !important;\
            }\
            .iGHbutton-group.iGHround > *:last-child, .iGHbutton-group.iGHround > *:last-child > a, .iGHbutton-group.iGHround > *:last-child > iGHbutton, .iGHbutton-group.iGHround > *:last-child > .iGHbutton {\
                border-bottom-right-radius: 1000px !important;\
                border-top-right-radius: 1000px !important;\
            }\
            .iGHbutton-group.iGHround.stack > * {\
                display: block !important;\
                margin: 0 !important;\
            }\
            .iGHbuttonFlat {\
                background-color: #008cba !important;\
                border-color: #007095 !important;\
                border-radius: 0 !important;\
                border-style: solid !important;\
                border-width: 1px !important;\
                color: #ffffff !important;\
                cursor: pointer !important;\
                display: inline-block !important;\
                font-family: Lucida Sans Unicode,Lucida Grande,Verdana,Arial,sans-serif !important;\
                font-size: 0.88889rem !important;\
                font-weight: normal !important;\
                line-height: normal !important;\
                padding: 0.5rem 1rem !important;\
                position: relative !important;\
                text-align: center !important;\
                text-decoration: none !important;\
                transition: background-color 300ms ease-out 0s !important;\
            }\
            .iGHbuttonFlat:hover, .iGHbuttonFlat:focus {\
                background-color: #007095 !important;\
                text-decoration: none !important;\
            }\
            .iGHbuttonFlat:hover, .iGHbuttonFlat:focus {\
                color: #ffffff !important;\
            }\
            .iGHbuttonFlat.iGHsecondary {\
                background-color: #e7e7e7 !important;\
                border-color: #b9b9b9 !important;\
                color: #333333 !important;\
            }\
            .iGHbuttonFlat.iGHsecondary:hover {\
                background-color: #dcdcdc !important;\
            }\
            .iGHbuttonFlat.iGHsecondary.iGHselected {\
                background-color: #b9b9b9 !important;\
            }\
            iGHbuttonFlat.iGHsmall, .iGHbuttonFlat.iGHsmall {\
                font-size: 11px !important;\
                padding: 2px 15px !important;\
            }\
            .iGraphChimeManagerTextbox {\
                width: 220px !important !important;\
                height: 20px !important !important;\
                margin-right: 10px; !important;\
                padding: 0px !important;\
                border: 1px solid #ccc !important;\
                border-radius: 4px !important;\
                display: inline-block !important;\
                font-size: 12px !important;\
            }\
            .iGraphChimeRoomContainer {\
                margin: 15px !important;\
                width: 100% !important;\
                max-width: 100% !important;\
                font-weight: bold !important;\
                font-size: 12px !important;\
            }\
            .iGraphChimeRoomContainer > tbody > tr > td{\
                border: 0px !important;\
            }\
            .iGraphWebhookManagerPageTitle {\
                font-size: 15px !important;\
                font-weight: bold !important;\
                margin: 0px 0px 10px 10px !important;\
                display: inline-block !important;\
            }\
            #iGraphWebhookManager, #iGraphAddChimeRoomButton, #iGraphWebhookPageBackButton {\
                margin-top: -1px !important;\
            }\
        ',
        callbackFunction: 'WikiSnapshot.snapshotDisplay',
        snapshotHistory: [],
        snapshotHistoryPrevious: [],
        chimeRooms: {},
        outputMode: null,
        stylesAdded: false,
        autoSnap: true,
        snapWithData: false,
        takingBulkSnap: false,
        noOfSnapshotsToBeCopied: 0,

        initialize: function() {
            WebLabTimes.waitFor(function () {
                return unsafeWin.MPW;
            }, WikiSnapshot.interceptGraphHover);
            this.injected = GMUtils.injectFunctionsIntoPage();
            if (this.injected) {
                this.callbackFunction = 'iGraphHelperGM.snapshotDisplay';
            }
            this.loadChimeRoomDefinitions();
            this.decorateChimeRoomLinks();
            OCLSettingsManager.setOCLConfigInitialValue();

            this.getHistory();

            this.outputMode = GMUtils.getValue(this.SNAPSHOT_OUTPUT_MODE_KEY) || this.MODES.RAW;
        },

        decorateChimeRoomLinks: function() {
            const chimeRoomsHeader = $('.iGraphHelperChimeRooms');
            const chimeRoomsDoneAlready = $('.iGHsnapshotSaveChimeRooms');
            const self = this;

            if ((chimeRoomsHeader.length > 0) && (chimeRoomsDoneAlready.length === 0)) {
                this.addStyles();
                chimeRoomsHeader.prepend('<div>' +
                  '<input type="submit" value="Save Slack channels/Chime rooms to iGraph Helper" class="iGHsnapshotSaveChimeRooms" style="background-color: orange;"><br><br>' +
                  '<input type="submit" value="Clear All Channels/Rooms from iGraph Helper ..." class="iGHsnapshotClearChimeRooms" style="color: white; background-color: red;">' +
                  '</div><br>');
                $('.iGHsnapshotSaveChimeRooms').on('click', function() {
                    $('.iGraphHelperChimeRooms a').each(function () {
                        var name = $.trim($(this).text()),
                          url = $.trim($(this).attr('href'));

                        self.chimeRooms[name] = { url: url };
                    });
                    self.saveChimeRoomDefinitions();
                    alert('Slack channel/Chime room webhook saved to iGraph Helper');
                });
                $('.iGHsnapshotClearChimeRooms').on('click', function() {
                    if (confirm('Are you sure you want to clear all stored Slack/Chime webhooks in iGraph Helper?')) {
                        self.chimeRooms = {};
                        self.saveChimeRoomDefinitions();
                    }
                });
            }
        },

        addStyles: function() {
            if (!this.stylesAdded) {
                addStyle(this.STYLES);
                this.stylesAdded = true;
            }
        },

        storeHistory: function() {
            GMUtils.setValue(this.SNAPSHOT_HISTORY_KEY, JSON.stringify(this.snapshotHistory));
            GMUtils.setValue(this.SNAPSHOT_HISTORY_PREVIOUS_KEY, JSON.stringify(this.snapshotHistoryPrevious));
        },

        getHistory: function() {
            var storedHistory = GMUtils.getValue(this.SNAPSHOT_HISTORY_KEY),
              storedHistoryPrevious = GMUtils.getValue(this.SNAPSHOT_HISTORY_PREVIOUS_KEY);

            if (storedHistory) {
                this.snapshotHistory = JSON.parse(storedHistory);
            }
            if (storedHistoryPrevious) {
                this.snapshotHistoryPrevious = JSON.parse(storedHistoryPrevious);
            }
        },

        loadChimeRoomDefinitions: function() {
            var chimeRooms = GMUtils.getValue(this.SNAPSHOT_CHIME_ROOMS_KEY);

            this.currentChimeRoomName = GMUtils.getValue(this.SNAPSHOT_CURRENT_CHIME_ROOM_KEY);
            if (chimeRooms) {
                var rooms = JSON.parse(chimeRooms);
                if (typeof rooms === 'object') {
                    this.chimeRooms = rooms;
                }
            }
        },

        saveChimeRoomDefinitions: function() {
            GMUtils.setValue(this.SNAPSHOT_CHIME_ROOMS_KEY, JSON.stringify(this.chimeRooms));
            GMUtils.setValue(this.SNAPSHOT_CURRENT_CHIME_ROOM_KEY, this.currentChimeRoomName);
        },

        interceptGraphHover: function () {
            WikiSnapshot.MPW = unsafeWin.MPW;
            $('#iGraphHoverBorderTop').append('<div id="iGraphColorBlindFriendlyIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraphHelper: Color Blind Friendly..." style="background: url(' + WikiSnapshot.COLOR_BLIND_FRIENDY_IMG + ') no-repeat scroll center center transparent;"></div>');
            $('#iGraphHoverBorderTop').append('<div id="iGraphSnapshotIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraphHelper: Snapshot..." style="background: url(' + WikiSnapshot.SNAPSHOT_IMG + ') no-repeat scroll center center transparent;"></div>');
            $('#iGraphHoverBorderTop').append('<div id="iGraphInteractiveIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraphHelper: Go Interactive..." style="background: url(' + WikiSnapshot.INTERACTIVE_IMG + ') no-repeat scroll center center transparent;"></div>');
            $('#iGraphHoverBorderTop').append('<div id="iGraphCloudWatchApplicationLogsIcon" class="iGraphHelperIcons iGraphHelperTopIcons OCLIcons" title="iGraphHelper: Go to Cloudwatch application logs for this graph" style="background: url(' + OCLLinksManager.CLOUDWATCH_APPLICATION_LOG_IMG + ') no-repeat scroll center transparent;"></div>');
            $('#iGraphHoverBorderTop').append('<div id="iGraphCloudWatchServiceLogsIcon" class="iGraphHelperIcons iGraphHelperTopIcons OCLIcons" title="iGraphHelper: Go to Cloudwatch service logs for this graph" style="background: url(' + OCLLinksManager.CLOUDWATCH_SERVICE_LOG_IMG + ') no-repeat scroll center transparent;"></div>');
            document.getElementById('iGraphColorBlindFriendlyIcon').addEventListener('click', function () {
                return WikiSnapshot.displayColorBlindFriendly();
            });
            document.getElementById('iGraphSnapshotIcon').addEventListener('click', function () {
                return WikiSnapshot.displaySnapshotPopup();
            });
            document.getElementById('iGraphInteractiveIcon').addEventListener('click', function () {
                return WikiSnapshot.goInteractive();
            });
            document.getElementById('iGraphCloudWatchServiceLogsIcon').addEventListener('click', function () {
                WikiSnapshot.goToCloudWatchConsole(OCLLinksManager.SERVICE_LOG_KEY);
            });
            document.getElementById('iGraphCloudWatchApplicationLogsIcon').addEventListener('click', function () {
                WikiSnapshot.goToCloudWatchConsole(OCLLinksManager.APPLICATION_LOG_KEY);
            });
            WikiSnapshot.addOCLIconsMouseOverEventListener();
        },

        addOCLIconsMouseOverEventListener: function() {
            for (let i = 0; i < document.images.length; i++) {
                var image = document.images[i];
                var searchString = this.MPW.getGraphArgs(image, true);
                if (searchString != null) {
                    image.addEventListener("mouseover", function() { WikiSnapshot.setOCLIconsVisibility();}, false);
                }
            }
        },

        setOCLIconsVisibility: function() {
            if (this.MPW.hoveredImage) {
                var graphArgs = this.MPW.getGraphArgs(this.MPW.hoveredImage);
                OCLLinksManager.setOCLIconsVisibility(graphArgs);
            }
        },

        goToCloudWatchConsole: function(logType) {
            if (this.MPW.hoveredImage) {
                var graphArgs = this.MPW.getGraphArgs(this.MPW.hoveredImage);
                OCLLinksManager.goToCloudWatchConsole(logType, graphArgs);
            }
        },

        goInteractive: function() {
            if (this.MPW.hoveredImage) {
                var graphArgs = this.MPW.getGraphArgs(this.MPW.hoveredImage);
                InteractiveWikiGraphs.displayInteractiveGraph(graphArgs);
            }
            return false;
        },

        displayColorBlindFriendly: function(imgParam, graphArgsParam) {
            let img = imgParam || this.MPW.hoveredImage;
            const graphArgs = graphArgsParam || this.MPW.getGraphArgs(img);

            if (img) {
                let newImgParams;

                if (this.isCloudWatchGraph(graphArgs)) {
                    const metricWidget = this.getMetricWidgetFromUrl(graphArgs);
                    const metrics = metricWidget.metrics;
                    let visibleMetricIndex = 0;
                    if (metrics) {
                        // Go through each entry in metrics array and assign successive color from color blind friendly palette
                        metrics.forEach((metric, i) => {
                            const cbfColor = this.COLOR_BLIND_FRIENDLY_PALETTE[visibleMetricIndex % this.COLOR_BLIND_FRIENDLY_PALETTE.length];
                            const last = metric[metric.length - 1];

                            // Check for custom options/expression at end of a visible metric
                            if (typeof last === 'object') {
                                if (last.visible !== false) {
                                    if (last.expression) {
                                        // Give expressions the full color palette, "round-robin", starting from current visible metric index
                                        last.color = this.COLOR_BLIND_FRIENDLY_PALETTE.slice(visibleMetricIndex).concat(this.COLOR_BLIND_FRIENDLY_PALETTE.slice(0, visibleMetricIndex));
                                    } else {
                                        last.color = cbfColor;
                                    }
                                    visibleMetricIndex ++;
                                }
                            } else {
                                metric.push({ color: cbfColor});
                                visibleMetricIndex ++;
                            }
                        });
                    }

                    const metricWidgetStr = this.metricWidgetToJsonUrlParam(metricWidget);
                    newImgParams = this.removeQueryParams(graphArgs, ["metricWidget"]) + `&metricWidget=${metricWidgetStr}`;
                } else {
                    newImgParams = this.removeQueryParams(graphArgs, ["Palette"]);
                    newImgParams += `&Palette=cbf`;
                }

                img.src = img.src.replace(/[?].*/, '?') + newImgParams;
            }
            return false;
        },

        displaySnapshotPopup: function() {
            if (this.MPW.hoveredImage) {
                var graphArgs = this.MPW.getGraphArgs(this.MPW.hoveredImage);
                this.snapshotDisplayInPopup(Lightbox.display, graphArgs, this.getSnapshotSizeMessage());
            }
        },

        getSnapshotSizeMessage: function() {
            var msg = "The graph to be snapshotted is " + this.MPW.hoveredImage.width + " by " + this.MPW.hoveredImage.height + " pixels";
            return msg;
        },

        isCloudWatchGraph: function(graphArgs) {
            return this.isCloudWatchInteractiveGraph(graphArgs) || this.isCloudWatchBitmapGraph(graphArgs);
        },

        isCloudWatchInteractiveGraph: function(graphArgs) {
            return (graphArgs && typeof graphArgs === 'object');
        },

        isCloudWatchBitmapGraph: function(graphArgs) {
            return  /\bmetricWidget=/.test(graphArgs);
        },

        getMetricWidgetFromUrl: function(url) {
            try {
                url = (url.includes('+') && !url.includes('%20') && !url.includes(" ")) ? url.replace(/\+/g, ' ') : url;
                const metricWidgetString = this.extractQueryValue(url, 'metricWidget');
                const metricWidget = JSON.parse(metricWidgetString);
                const start = this.extractQueryValue(url, 'start');
                const end = this.extractQueryValue(url, 'end');

                // + is explicitly converted to space above, but this is invalid within the time range and timezone
                // where you actually want a + to denote timezone offset
                metricWidget.start = (start || metricWidget.start).replace(' ', '%2b');
                metricWidget.end = (end || metricWidget.end).replace(' ', '%2b');
                if (metricWidget.timezone) {
                    metricWidget.timezone = metricWidget.timezone.replace(' ', '%2b');
                }

                return metricWidget;
            } catch (e) {
                return {};
            }
        },

        metricWidgetToJsonUrlParam: function(metricWidget) {
            const metricWidgetString = JSON.stringify(metricWidget).replace(/[%]7C/g, '|');

            // Need to encode = to %3D and # to %23, to get through to Metrics page in console okay
            return encodeURIComponent(metricWidgetString)
              .replace(/#/g, '%23')
              .replace(/=/g, '%3D');
        },

        setSnapshotSizeSettingFromString: function(string) {
            try {
                if(string !== null) {
                    parsedInputs = string.replace('"', '').split(",").map(input => parseInt(input))
                    if(parsedInputs.length === 2 && Number.isInteger(parsedInputs[0]) && Number.isInteger(parsedInputs[1])) {
                        WikiSnapshot.setSnapshotSizeSetting(parsedInputs[0], parsedInputs[1])
                    } else {
                        throw "Invalid string"
                    }
                }
            } catch (error) {
                alert(`Unable to set default width and height from ${string} (${error})`)
            }
        },

        setSnapshotSizeSetting: function(width, height) {
            if(width === 0 && height === 0) {
                console.log("Unsetting fixed graph size")
                GMUtils.setValue("igraph.defaults.width", null)
                GMUtils.setValue("igraph.defaults.height", null)
            } else {
                console.log(`Setting fixed graph size to ${width}, ${height}`)
                GMUtils.setValue("igraph.defaults.width", width)
                GMUtils.setValue("igraph.defaults.height", height)
            }
        },

        setSnapshotSize: function(graphArgs) {
            if(GMUtils.getValue('iGraphHelper.snapshotObeyFit') == "false") {
                // graphArgs can either be a URL string or an Object
                const fixedHeight = GMUtils.getValue('igraph.defaults.height')
                const fixedWidth = GMUtils.getValue('igraph.defaults.width')

                if (typeof graphArgs === 'string' || graphArgs instanceof String) {
                    if(fixedHeight != null && fixedWidth != null && unsafeWindow.iGraphHelper && unsafeWindow.iGraphHelper.IGH) { // If the user has not set the fixed size setting we will skip updating the url and fall back to igraph general settings
                        graphArgs = unsafeWindow.iGraphHelper.IGH.util.removeQueryParams(graphArgs, ["WidthInPixels", "HeightInPixels"]) + `&WidthInPixels=${fixedWidth}&HeightInPixels=${fixedHeight}`;
                    }
                } else {
                    // For CW we can't fall back to igraph so fall back to a sane default
                    graphArgs.height = fixedHeight || 250
                    graphArgs.width = fixedWidth || 500
                }
            }
            return graphArgs
        },

        snapshotDomElement: function() {
            let url = window.location.href;
            let match = WikiSnapshot.PAGE_TO_SNAPSHOT_SELECTOR_MATCHER.find(function(matcher) {
                return matcher.urlRegex.test(url)
            }) || { selector: '', name: 'current page' };

            let selector = prompt(`Snapshot a DOM element on the page. This is an experimental feature that may or may not work, depending on the content in the page.\n\nPlease enter a jQuery selector for the element that should be snapshotted on ${match.name}.`, match.selector);
            if (selector) {
                WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, null, 'Snapshot jQuery selector: ' + selector, false, selector);
            }
        },

        snapshotHtmlNode: function(selector, deepLinkUrl, isRetry) {
            let self = this;
            this.setSpinnerVisibility(true);
            this.displayMessage('Snapshotting ...');
            let $htmlNode = jQuery(selector);
            let $iframe = jQuery('iframe');
            let options = {};

            // Also look for the selector in the iframes
            try {
                if ($iframe.length > 0) {
                    for (let i = 0; i < $iframe.length; i++) {
                        try {
                            let searchNode = jQuery($iframe[i]).contents().find(selector);
                            if (searchNode.length > 0) {
                                $htmlNode = searchNode;
                            }
                        } catch(error) {
                            console.log(`Unable to iterate frame ${error}`);
                        }
                    }
                }
            } catch(error) {
                console.log(`Unable to iterate iframes: ${error}`);
            }

            if ($htmlNode.length < 1) {
                self.setSpinnerVisibility(false);
                this.displayMessage(`Unable to locate selector: ${selector}`);
                return;
            }

            if ((jQuery('.cwdb-dark').length != 0) && (selector === '.cwdb-standalone-graph-container')) {
                options.bgcolor = '#2a2e33'
            }
            // Convert HTML to base64 PNG image
            GMUtils.domToImage().toPng($htmlNode[0], options)
              .then(dataUrl => {
                  this.uploadImage(dataUrl, deepLinkUrl);
              })
              .catch(function(error) {
                  console.error(error);
                  if (isRetry) {
                      // We were doing a retry, time to give up
                      self.setSpinnerVisibility(false);
                      alert('Unexpected error converting graph to image');
                  } else {
                      // Browser can fail to render SVG sometimes, randomly. Try a single automatic retry on error
                      console.log('retrying in-browser snapshot');
                      self.snapshotHtmlNode(selector, deepLinkUrl, true);
                  }
              });
        },

        uploadImage: function(dataUrl, deepLinkUrl) {
            // Strip away URL preamble to leave just pure base64 image content
            let base64image = dataUrl.replace(/^data:.*base64,/, ''),
              portalUrl = this.portalUrl(),
              self = this;

            this.setSpinnerVisibility(true);
            this.displayMessage('Uploading image ...');

            // Save image as snapshot
            setTimeout(function() {
                GMUtils.gmXmlHttpRequest({
                    method : 'POST',
                    timeout : 45000,
                    url: portalUrl + '/snap/saveImage',
                    data: JSON.stringify({ base64image }),
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    onload: response => {
                        try {
                            let responseData = response.responseText;
                            let snapshotInfo = JSON.parse(responseData);
                            WikiSnapshot.snapshotDisplay(snapshotInfo.snapshotUrl, deepLinkUrl || win.location.href, '');
                        } catch (exc) {
                            console.error(exc);
                            self.setSpinnerVisibility(false);
                            alert('Unexpected error uploading snapshot');
                        }
                    },
                    onerror: (error) => {
                        console.error(error);
                        self.setSpinnerVisibility(false);
                        alert('Unexpected error uploading snapshot');
                    },
                    ontimeout: () => {
                        self.setSpinnerVisibility(false);
                        alert('Request timeout. Please try again after some time');
                    }
                });
            },0);
        },

        portalUrl: function() {
            return ((unsafeWin || {}).portalData || {}).portalURL || 'https://monitorportal.amazon.com';
        },

        fromSvg: function() {
            if (this.MPW && this.MPW.hoveredImage && this.MPW.hoveredImage.farthestViewportElement
              && this.MPW.hoveredImage.farthestViewportElement.tagName === 'svg') {
                return this.MPW.hoveredImage.farthestViewportElement;
            } else {
                const iGraphSvg = jQuery('#monitor-amazon-com #chartdiv svg');
                if (iGraphSvg.length === 1) {
                    return iGraphSvg[0];
                }
            }
            return undefined;
        },

        snapshotGraphUrl: function(graphArgs, idSelector = undefined) {
            try {
                // Take Portal URL from what is defined on Wiki page, for easier testing - default to main Portal
                var url = this.portalUrl(),
                  metricWidget;
                let deepLinkUrl = window.location.href;
                const svg = this.fromSvg();

                graphArgs = this.setSnapshotSize(graphArgs)

                if (svg) {
                    return this.snapshotHtmlNode(svg, deepLinkUrl);
                } else  if (this.isCloudWatchBitmapGraph(graphArgs)) {
                    metricWidget = this.getMetricWidgetFromUrl(graphArgs);
                    if (metricWidget.start && metricWidget.end) {
                        if (this.isDuration(metricWidget.start)) {
                            var startMins = this.getDurationInMinutes(metricWidget.start),
                              endMins   = this.getDurationInMinutes(metricWidget.end),
                              now = new Date();
                            metricWidget.start = this.getFixedTimeFromDuration(now, startMins);
                            metricWidget.end = this.getFixedTimeFromDuration(now, endMins);
                        }
                        url += "/cw/snapshot?metricWidget=" + encodeURIComponent(JSON.stringify(metricWidget));
                    } else {
                        url += "/cw/snapshot?" + graphArgs;
                    }
                } else if (this.isCloudWatchInteractiveGraph(graphArgs)) {
                    // Only line/stack graphs in non Opt-In regions should be snapshotted using bitmap API
                    const region = graphArgs.region || unsafeWin.region;
                    const partition = (unsafeWin.partition && unsafeWin.partition.name) ? unsafeWin.partition.name : 'aws';
                    const isNotOptInRegion = this.NOT_AUTH_OPT_IN_REGION[region];
                    const isK2Mode = jQuery('.k2-mock').length > 0;
                    const k2Account = jQuery('.k2-mock a:first').text();
                    const graphHasMetrics = graphArgs.metrics;
                    const jsonMetrics = JSON.stringify(graphArgs.metrics);
                    const hasAnomalyBand = /ANOMALY_DETECTION/.test(jsonMetrics);
                    const hasDbPiMetrics = /DB_PERF_INSIGHTS/.test(jsonMetrics);
                    const hasLambdaCalls = /\bLAMBDA\b/.test(jsonMetrics);
                    const hasAccountLabelProp = /\${\s*PROP\s*\(\s*'AccountLabel'\s*\)\s*}/.test(jsonMetrics);
                    const isDarkMode = jQuery('.cwdb-dark').length != 0;
                    const safeToCallBitmapAPI = graphHasMetrics && !(graphArgs.annotations && graphArgs.annotations.alarms) &&
                      !graphArgs.alpine && graphArgs.view !== 'singleValue' && !hasLambdaCalls &&
                      !graphArgs.role && isNotOptInRegion && !isK2Mode && !hasAnomalyBand && !hasDbPiMetrics && !hasAccountLabelProp;

                    if (graphArgs.annotations && graphArgs.annotations.horizontal) {
                        graphArgs.annotations.horizontal.map((annotation) => {
                            if (annotation.unitValue) {
                                delete annotation.unitValue;
                            }
                        });
                    }

                    if (isK2Mode) {
                        const encodedUrl = encodeURIComponent(deepLinkUrl);
                        const k2Domain = this.K2_ENDPOINT[partition] || this.K2_ENDPOINT.aws;
                        deepLinkUrl = `${k2Domain}/workbench/scripts/${partition}/CloudWatch-Console-Justify?AccountId=${k2Account}&Partition=${partition}&Destination=${encodedUrl}&_run=1`;
                    }

                    if (safeToCallBitmapAPI) {
                        if (graphArgs.timezone === 'Local') {
                            graphArgs.timezone = IGH.util.getLocalTimezoneOffset();
                        } else  if (graphArgs.timezone === 'UTC') {
                            delete graphArgs.timezone;
                        }
                        graphArgs.theme = isDarkMode ? 'dark' : 'light';
                        url += "/cw/snapshot?metricWidget=" + encodeURIComponent(JSON.stringify(graphArgs)) +
                          "&width=" + graphArgs.width + "&height=" + graphArgs.height;
                    } else {
                        // Generic snapshotting, by converting DOM element in-browser to PNG

                        // Check that id exists, fallback to standalone graph container if it doesn't
                        // Also, override the id for standalone graph page as the original does not work for this kind
                        // of snapshotting
                        if (!unsafeWin.document.querySelector(idSelector) || (idSelector === '.metrics-view-graph')) {
                            idSelector = '.cwdb-standalone-graph-container';
                        }

                        console.log('snapshotting ' + idSelector);
                        return this.snapshotHtmlNode(idSelector, deepLinkUrl);
                    }
                } else if (graphArgs === null) {
                    // No graph, indicates it is a DOM node or selector
                    return this.snapshotHtmlNode(idSelector, deepLinkUrl);
                } else { // Snapshotting from iGraph
                    url += "/mws/snapshot?" + this.replaceRelativeWithFixedTime(graphArgs);
                }
                url += "&snapshotCallback=" + this.callbackFunction + (typeof idSelector != "undefined" ? "&graphId=" + idSelector : "&graphId=0");

                this.includeScript(url);
                this.setSpinnerVisibility(true);
                !this.takingBulkSnap ? this.displayMessage('Snapshotting ...') : undefined;
            } catch (e) { console.log(e); }
        },

        /* Function to fetch graph data using chart.cgi if 'snapWithData' is true,
           If snapshot is taking from wiki page than this function uses GMUtils.gmXmlHttpRequest, and from iGraph page it uses .ajax call because
           win.snapshot code get injected in iGraph page so callback function of gmXmlHttpRequest does not work because of injection, however
           this is not the case in Wiki page
         */
        getChartData: function(snapshotUrl , iGraphUrl, tinyUrl, graphId) {
            try {
                var self = this,
                  snapshotName = this.getSnapshotId(snapshotUrl),
                  snapshotName = snapshotName.substring(0,snapshotName.lastIndexOf('.')),
                  chartCgiUrl = iGraphUrl.replace(/.*[/]igraph[?]/, 'https://monitorportal.amazon.com/igraph/chart?');

                chartCgiUrl = chartCgiUrl.replace(/\bHeightInPixels=\d+\b/,"HeightInPixels=400");
                chartCgiUrl = chartCgiUrl.replace(/\bWidthInPixels=\d+\b/,"WidthInPixels=900");

                if (window.location.href.search(/monitorportal.*.amazon.com/) >= 0) {
                    self.sendRequestFromIGraph(snapshotUrl , iGraphUrl , chartCgiUrl , snapshotName, tinyUrl, graphId);
                }
                else {
                    self.sendRequestFromWiki(snapshotUrl , iGraphUrl , chartCgiUrl , snapshotName, tinyUrl, graphId);
                }
            } catch (e) { console.log(e); }
        },

        sendRequestFromWiki: function(snapshotUrl , iGraphUrl , chartCgiUrl , snapshotName, tinyUrl, graphId) {
            try {
                var self = this;
                setTimeout(function() {
                    GMUtils.gmXmlHttpRequest({
                        method : 'POST',
                        timeout : 45000,
                        url: chartCgiUrl,
                        onload: function(response){
                            var responseData = response.responseText;
                            var snapshot = self.getSnapshotObject(snapshotUrl, tinyUrl);
                            snapshot.hasSnappedData = self.uploadDataToS3(responseData, snapshotName);
                            self.takingBulkSnap ? WikiBulkSnapshot.onSnapshotComplete(snapshot, graphId) : self.addHistoryItem(snapshot);
                        }.bind(WikiSnapshot),
                        ontimeout : function(response){
                            alert("Request timeout \nPlease try again after some time");
                        }
                    });
                },0);
            } catch (e) { console.log(e); }
        },

        sendRequestFromIGraph: function(snapshotUrl , iGraphUrl , chartCgiUrl , snapshotName, tinyUrl, graphId) {
            try {
                var self = this;
                $.ajax({
                    url: chartCgiUrl,
                    success: function(responseData){
                        var snapshot = self.getSnapshotObject(snapshotUrl, tinyUrl);
                        snapshot.hasSnappedData = self.uploadDataToS3(responseData, snapshotName);
                        self.takingBulkSnap ? WikiBulkSnapshot.onSnapshotComplete(snapshot, graphId) : self.addHistoryItem(snapshot);
                    }
                });
            } catch (e) { console.log(e); }
        },

        uploadDataToS3: function(responseData, snapshotName) {
            var self = this;
            var chartJson = responseData.substring(responseData.indexOf('{'),responseData.lastIndexOf('}')+1);
            if (eval ("("+ chartJson +")").error.length > 0) {
                alert(eval ("("+ chartJson +")").error+"\n\n*** For this snapshot will be taken without data ***");
                return false;
            }
            else {
                var blob = new Blob([JSON.stringify(chartJson, null, 2)], {type : 'application/json'});
                var formData = new FormData();
                formData.append("data", blob);
                formData.append("f", snapshotName + ".json");
                GMUtils.sendFormDataToS3(formData);
                return true;
            }
        },

        snapshotDisplay: function(snapshotUrl, iGraphUrl, graphId) {
            var self = this;

            var federationUrl = null, federationComment = null;
            var iGraphUrlIsengard = this.getIsengardLinkForUrl(iGraphUrl);
            if (iGraphUrlIsengard) {
                federationUrl = iGraphUrlIsengard;
                federationComment = 'IsenLink';
            }

            var onObserve = (/\/(observe.aka.amazon|observe-gamma.aka.amazon)/.test(window.location.href));
            var urlToTinyify = onObserve ? window.location.href : iGraphUrl;

            if (!this.takingBulkSnap) { this.displayMessage('Tinyfying graph URL ...'); }
            GMUtils.getTinyLinkForUrl('https://tiny.amazon.com/submit/url?comment=snapshot&name=' + escape(urlToTinyify), function(tinyUrl) {
                if (self.snapWithData) {
                    if (!self.takingBulkSnap) { self.displayMessage('Collecting graph data ...'); }
                    self.getChartData(snapshotUrl, iGraphUrl, tinyUrl, graphId);
                }
                else if (federationUrl) {
                    if (!this.takingBulkSnap) { self.displayMessage('Tinyfying federation URL ...'); }
                    GMUtils.getTinyLinkForUrl('https://tiny.amazon.com/submit/url?comment=' + escape(federationComment) + '&name=' + escape(federationUrl), function(tinyFederationUrl) {
                        var snapshot = self.getSnapshotObject(snapshotUrl, tinyUrl, tinyFederationUrl, federationComment);
                        self.takingBulkSnap ? WikiBulkSnapshot.onSnapshotComplete(snapshot, graphId) : self.addHistoryItem(snapshot);
                    });
                } else {
                    var snapshot = self.getSnapshotObject(snapshotUrl, tinyUrl);
                    self.takingBulkSnap ? WikiBulkSnapshot.onSnapshotComplete(snapshot, graphId) : self.addHistoryItem(snapshot);
                }
            });
        },

        getSnapshotObject: function(snapshotUrl, tinyUrl, tinyFederationUrl=null, federationDescription=null) {
            return  {
                snapshotUrl: snapshotUrl,
                iGraphUrl: tinyUrl,
                federationUrl: tinyFederationUrl,
                federationDescription: federationDescription,
                timestamp: new Date().toLocaleString(),
                hasSnappedData: this.snapWithData
            }
        },

        setSpinnerVisibility: function(isVisible) {
            $('.iGraphWikiSpinner').css('visibility', isVisible ? 'visible' : 'hidden');
        },

        displayMessage: function(message, delay) {
            if (message) {
                $('.iGraphWikiSnapshotMessage').html(message).css('display', 'block').fadeIn('slow');
                if (delay) {
                    setTimeout(function() { $('.iGraphWikiSnapshotMessage').fadeOut('slow') }, delay);
                }
            }
        },

        enable: function(selector, enabled) {
            if (enabled) {
                $(selector).prop('disabled', false).css('opacity', '1').css('cursor', 'pointer');
            } else {
                $(selector).prop('disabled', true).css('opacity', '0.35').css('cursor', 'not-allowed');
            }
        },

        snapshotDisplayInPopup: function(lightboxDisplay, graphArgs, message, takingBulkSnap = false, id = null) {
            var self = this;

            lightboxDisplay(this.getPopupHtml(), 800, 385);
            this.displayMessage(message, 5000);
            this.setChimeSelectOptions();
            this.takingBulkSnap = takingBulkSnap;
            this.enable('#iGraphWikiSnapshot', true);
            this.enable('#iGraphSnapshotWithData', true);

            if (this.takingBulkSnap) {
                this.enable('#iGraphWikiSnapshot', false);
                this.enable('#iGraphSnapshotWithData', false);
                WikiBulkSnapshot.snapshotCartGraphs();
            }
            if (this.isCloudWatchGraph(graphArgs)) {
                this.enable('#iGraphSnapshotWithData', false);
            }
            $('#iGraphWikiSnapshot').on('click', function () {
                self.snapWithData = false ;
                self.snapshotGraphUrl(graphArgs, id);
            });
            $('#iGraphSnapshotWithData').on('click', function () {
                self.snapWithData = true ;
                self.snapshotGraphUrl(graphArgs, id);
            });
            $('#iGraphWikiSnapshotClear').on('click', function () {
                self.clearHistory();
            });
            $('#iGraphWikiSnapshotCopyAll').on('click', function () {
                self.noOfSnapshotsToBeCopied = self.snapshotHistory.length;
                self.copyAllHistoryToClipboard();
            });
            $('#iGraphWikiSnapshotRestoreHistory').on('click', function () {
                self.restoreHistory();
            });
            $('.iGHSnapshotOutputMode').on('click', function () {
                self.outputModeClicked(this)
            });
            $('#iGraphWikiSnapshotAuto').on('click', function () {
                self.setAutoSnap(this);
            });
            $('#iGraphWikiSnapshotObeyFit').on('click', function () {
                self.setObeyFit(this);
            });
            $('#iGraphWebhookManager').on('click', function () {
                self.showChimeWebhookManagerPage(this)
            });
            $('#iGraphWebhookPageBackButton').on('click', function() {
                self.showSnapshotControllerPage();
            });
            $('#iGraphAddChimeRoomButton').on('click', function () {
                self.addChimeRoom(this);
            });

            // Support drag and drop of image files, for snapshotting
            let popup = $('.iGraphWikiSnapshotPopup')[0];
            popup.addEventListener('dragover', e => {
                this.filesBeingDraggedOver(e);
            });
            popup.addEventListener('drop', e => {
                this.filesDropped(e);
            });

            // If there is nothing to snapshot then prepare for pasting images from clipboard
            if (!graphArgs && !id) {
                let $preview = $('.iGraphWikiSnapshotPreview');
                if ($preview.pastableContenteditable) {
                    $preview
                      .attr('contenteditable', 'true')
                      .pastableContenteditable()
                      .on('pasteImage', (ev, data) => {
                          this.uploadImage(data.dataURL);
                      })
                      .on('pasteImageError', (ev, data) => {
                          alert('Error pasting image: ' + data.message);
                      });

                }
            }

            this.updateOutputMode();
            this.initObeyFit();
            this.initAutoSnap(graphArgs, id);
        },

        filesBeingDraggedOver: function(dragOverEvent) {
            dragOverEvent.stopPropagation();
            dragOverEvent.preventDefault();
            dragOverEvent.dataTransfer.dropEffect = 'copy';
        },

        filesDropped: function(dropEvent) {
            dropEvent.stopPropagation();
            dropEvent.preventDefault();
            let files = dropEvent.dataTransfer.files; // Array of all files

            [].slice.call(files).forEach(file => {
                if (file.type.includes('image')) {
                    let reader = new FileReader();

                    reader.onload = loadEvent => {
                        this.uploadImage(loadEvent.target.result);
                    };

                    reader.readAsDataURL(file); // start reading the file data.
                }
            });
        },

        initAutoSnap: function(graphArgs, id) {
            this.autoSnap = GMUtils.getValue(this.SNAPSHOT_AUTOSNAP_KEY) != "false";
            GMUtils.setValue(this.SNAPSHOT_AUTOSNAP_KEY, this.autoSnap + '');
            $('#iGraphWikiSnapshotAuto').prop('checked', this.autoSnap);

            // Only auto-snap if autoSnap is on, not taking bulk snapshot and there is
            // a graph or DOM element to snap
            if (!this.isTakingBulkSnap && this.autoSnap && (graphArgs || id)) {
                this.snapshotGraphUrl(graphArgs, id);
            }
        },

        setAutoSnap: function(checkbox) {
            this.autoSnap = $('#iGraphWikiSnapshotAuto:checked').length != 0;
            GMUtils.setValue(this.SNAPSHOT_AUTOSNAP_KEY, this.autoSnap + '');
        },

        initObeyFit: function() {
            this.obeyFit = GMUtils.getValue(this.SNAPSHOT_OBEY_FIT_KEY) != "false";
            GMUtils.setValue(this.SNAPSHOT_OBEY_FIT_KEY, this.obeyFit + '');
            $('#iGraphWikiSnapshotObeyFit').prop('checked', this.obeyFit);
        },

        setObeyFit: function(checkbox) {
            this.obeyFit = $('#iGraphWikiSnapshotObeyFit:checked').length != 0;
            GMUtils.setValue(this.SNAPSHOT_OBEY_FIT_KEY, this.obeyFit + '');
        },

        outputModeClicked: function(button) {
            this.outputMode = $(button).attr('data-mode');
            this.updateOutputMode();
            if (this.snapshotHistory.length > 0) {
                if (this.takingBulkSnap) {
                    this.copyAllHistoryToClipboard();
                }
                else {
                    this.copyCodeToClipboard(this.getSnapshotCode(0));
                    this.displayMessage("Code for last snapshot copied to clipboard", 2000);
                }
            }
        },

        updateOutputMode: function() {
            if (this.outputMode == null) {
                this.outputMode = GMUtils.getValue(this.SNAPSHOT_OUTPUT_MODE_KEY) || this.MODES.RAW;
            }
            GMUtils.setValue(this.SNAPSHOT_OUTPUT_MODE_KEY, this.outputMode);
            $('.iGHSnapshotOutputMode').removeClass("iGHselected");
            $('.iGHSnapshotOutputMode[data-mode="' + this.outputMode + '"]').addClass("iGHselected");
            this.updateSnapshots();
        },

        showSnapshotControllerPage: function(button) {
            this.displayMessage(" ");
            $('.iGraphWikiSnapshotControls').show();
            $('.iGraphChimeRoomManagerControls').hide();
            this.updateSnapshots();
        },

        showChimeWebhookManagerPage: function(button) {
            this.displayMessage(" ");
            $('.iGraphWikiSnapshotControls').hide();
            $('.iGraphChimeRoomManagerControls').show();
            this.updateChimeRoomList();
        },

        updateChimeRoomList: function() {
            this.loadChimeRoomDefinitions();
            var self = this;
            var roomListHtml = '<table class="iGraphChimeRoomContainer" cellspacing="15">';
            var index=1;
            Object.keys(this.chimeRooms).sort().forEach(function(roomName) {
                roomListHtml += '<tr>' +
                  '<td><span>' + index++  + '.</span></td>' +
                  '<td><span>' + roomName + '</span></td>' +
                  '<td><a target="_blank" href="' + self.chimeRooms[roomName].url + '">' + roomName + '\'s Slack/Chime webhook url...</a></td>' +
                  '<td><input type="submit" value="Delete" class="iGHbutton MPWbutton iGHdeleteChimeRoom" data-code="' + roomName + '"></td>' +
                  '</tr>';
            });
            roomListHtml += '</table>';
            $('.iGraphWikiSnapshotPreview').html(roomListHtml);
            $('.iGHdeleteChimeRoom').on('click', function() {
                var room = $(this).attr('data-code');
                delete self.chimeRooms[room];
                self.saveChimeRoomDefinitions();
                self.updateChimeRoomList();
                self.setChimeSelectOptions();
                self.displayMessage("Slack/Chime webhook has been deleted.", 2000);
            });
        },

        copyCodeToClipboard: function(code) {
            GMUtils.setClipboard(code, this.outputMode == "Email" ? "html" : "text");
        },

        displayCurrent: function() {
            var index = this.snapshotHistory.length - this.current;
            if (this.current) {
                $('.iGraphWikiLink').text(index >= 0 ? this.getSnapshotCode(index) : '');
                $('.iGraphWikiSnapshotPreview').html(this.getSnapshotImagePreviewHtml(index));
            }
            $('#iGraphWikiSnapshotPrevious').val('Previous (' + index + ')');
            if (index == 0) {
                $('#iGraphWikiSnapshotPrevious').prop('disabled', true).css('opacity', '0.5');
            } else {
                $('#iGraphWikiSnapshotPrevious').prop('disabled', false).css('opacity', '1');
            }
        },

        clearHistory: function() {
            if (this.snapshotHistory.length == 0) {
                return;
            }
            this.saveCurrentHistory();
            this.snapshotHistory = [];
            this.storeHistoryAndUpdate();
        },

        addHistoryItem: function(snapshot) {
            this.saveCurrentHistory();
            this.snapshotHistory.unshift(snapshot);
            if (!this.takingBulkSnap) {
                this.copyCodeToClipboard(this.getSnapshotCode(0));
                this.displayMessage("Snapshot code copied to clipboard.", 5000);
            }
            if (this.snapshotHistory.length > this.MAX_HISTORY_ITEMS) {
                this.snapshotHistory.pop();
            }
            this.storeHistoryAndUpdate();
        },

        removeHistoryItem: function(index) {
            if (index >= this.snapshotHistory.length) {
                return;
            }
            this.saveCurrentHistory();
            this.snapshotHistory.splice(index, 1);
            this.storeHistoryAndUpdate();
        },

        restoreHistory: function() {
            if (this.snapshotHistoryPrevious.length == 0) {
                return;
            }
            this.snapshotHistory = this.snapshotHistoryPrevious.slice(0);
            this.snapshotHistoryPrevious = [];
            this.storeHistoryAndUpdate();
        },

        storeHistoryAndUpdate: function() {
            this.storeHistory();
            this.updateSnapshots();
        },

        saveCurrentHistory: function() {
            this.snapshotHistoryPrevious = this.snapshotHistory.slice(0);
        },

        copyAllHistoryToClipboard: function() {
            var self = this;
            var count = self.noOfSnapshotsToBeCopied;
            var allCode = this.snapshotHistory.slice(0, count).map(function(snapshot, i) {
                return self.getSnapshotCode(i);
            });
            if (allCode.length > 0) {
                this.copyCodeToClipboard(allCode.join('\n\n'));
                this.displayMessage(this.outputMode + " code for first " + count + " snapshot" + ((count > 1)? "s" : "") + " copied to clipboard.", 7000);
            }
            else {
                this.displayMessage("There isn't any snapshot to copy.", 4000);
            }
        },

        addChimeRoom: function() {
            var roomName = $.trim($('#iGraphChimeRoomName').val()),
              url = $.trim($('#iGraphChimeWebhookUrl').val());

            if (roomName !== "" && url !== "") {
                this.chimeRooms[roomName] = { url: url };
                this.currentChimeRoomName = roomName;
                this.setChimeSelectOptions();
                this.saveChimeRoomDefinitions();
                $('#iGraphChimeRoomName').val('');
                $('#iGraphChimeWebhookUrl').val('');
                this.updateChimeRoomList();
                this.displayMessage("Slack/Chime webhook has been added successfully.", 2000);
            }
            else {
                alert("Enter both Slack channel/Chime room and its webhook URL.");
            }
        },

        getUsername: function() {
            var wikiUser = $('.userpage').text(),
              newWikiUser = $('.avatarLink').attr('href'),
              portalUser = $('.username').text(),
              isengardRole = $('#nav-usernameMenu div').text(),
              wikiParts;

            if (wikiUser !== '') {
                wikiParts = $.trim(wikiUser).split(' ');
                return wikiParts[wikiParts.length - 1].toLowerCase();
            } else if (newWikiUser) {
                wikiParts = $.trim(newWikiUser).split('/');
                return wikiParts[wikiParts.length - 1];
            } else if (portalUser !== '') {
                return portalUser;
            } else if (isengardRole !== '') {
                return isengardRole.replace(/.*\//, '').replace(/-.*/, '');
            }

            return null;
        },

        handleSendToChimeClick: function(button, doPresent, doMarkdown) {
            var self = this,
              chimeCode = decodeURIComponent($(button).attr('data-chime')),
              slackCode = decodeURIComponent($(button).attr('data-slack')),
              selectedRoomUrl = $('.iGraphWikiChimeRooms').val(),
              bold = doMarkdown ? '**' : '',
              username = self.getUsername() || 'someone',
              message;

            if (selectedRoomUrl === '') {
                if (Object.keys(self.chimeRooms).length > 0) {
                    alert('First select a Slack channel/Chime room from the dropdown above');
                } else {
                    alert('First you must configure a Slack channel/Chime room webhook.');
                    self.showChimeWebhookManagerPage();
                }
            }

            if (selectedRoomUrl) {
                message = prompt('Enter message to accompany Slack/Chime post, emojis are allowed\n', 'Snapshot of ');

                if (message !== null) {
                    if (/hooks.slack.com.services/.test(selectedRoomUrl)) {
                        // Raw slack webhook
                        const slackMessage = {
                            text: `${username} shared a snapshot direct from iGraph Helper`,
                            blocks: [
                                {
                                    type: "section",
                                    text: {
                                        type: "mrkdwn",
                                        text: `*${username}* shared a snapshot direct from iGraph Helper\n${message}`
                                    }
                                },
                                {
                                    type: "section",
                                    text: {
                                        type: "mrkdwn",
                                        text: slackCode,
                                    }
                                }
                            ]
                        };
                        GMUtils.sendJSONtoURL(selectedRoomUrl, slackMessage);
                    } else {
                        // Chime or Chime-compatible Slack workflow
                        const content = (doMarkdown ? '/md\n' : '') +
                          (doPresent ? '@Present ' : '') +
                          (username ? bold + '(from: ' + username + ')' + bold + ' ' : '') +
                          (message === '' ? chimeCode : message + '\n' + chimeCode);
                        GMUtils.sendJSONtoURL(selectedRoomUrl, { Content: content });
                    }
                }
            }
        },

        updateSnapshots: function() {
            var self = this;
            this.getHistory();
            var history = this.snapshotHistory.map(function(snapshot, i) {
                snapshot.iGraphUrl = snapshot.iGraphUrl || '';
                return self.getSnapshotImagePreviewHtml(i, self.getSnapshotCode(i), self.getSnapshotCode(i, 'Chime'), self.getSnapshotCode(i, 'ChimeMarkdown'), self.getSnapshotCode(i, 'Slack'));
            });
            $('.iGraphWikiSnapshotPreview').html(history.join('<br>'));
            $('#iGraphWikiSnapshotClear').val('Clear History (' + history.length + ')');
            $('.iGHsnapshotCopyCode').on('click', function() {
                var code = $(this).attr('data-code');
                self.displayMessage("Snapshot code copied to clipboard", 3000);
                self.copyCodeToClipboard(decodeURIComponent(code));
            });
            $('.iGHsnapshotCopyImage').on('click', function() {
                self.copyImageToClipboard(this);
            });
            $('.iGHsnapshotDelete').on('click', function() {
                var index = parseInt($(this).attr('data-index'));
                self.removeHistoryItem(index);
            });
            $('.iGHsnapshotSendToChime').on('click', function() { self.handleSendToChimeClick(this, false, false); });
            $('.iGHsnapshotSendToChimePresent').on('click', function() { self.handleSendToChimeClick(this, true, false); });
            $('.iGHsnapshotSendToChimeMarkdown').on('click', function() { self.handleSendToChimeClick(this, false, true); });
            this.setSpinnerVisibility(false);
        },

        copyImageToClipboard: function(button) {
            function selectText(element) {
                if (document.body.createTextRange) {
                    var range = document.body.createTextRange();
                    range.moveToElementText(element);
                    range.select();
                } else if (unsafeWin.getSelection) {
                    var selection = unsafeWin.getSelection();
                    var range = document.createRange();
                    range.selectNodeContents(element);
                    selection.removeAllRanges();
                    selection.addRange(range);
                }
            }

            var container = $(button).parent().parent();
            container.attr("contenteditable", true);
            selectText($(container).find('a').get(0));
            document.execCommand('copy');
            unsafeWin.getSelection().removeAllRanges();
            container.removeAttr("contenteditable");
        },

        getSnapshotId: function(snapshotUrl) {
            return snapshotUrl.replace(/.*[=/]/, '');
        },

        getConsoleUsername: function() {
            var usernameEl = document.getElementById('nav-usernameMenu');
            return usernameEl ? usernameEl.textContent : undefined;
        },

        getFederatedPathForDeeplinking: function(pathname) {
            // deeplink.js mechanism somehow doesn't work correctly with Isengard federation
            if (pathname.endsWith('/cloudwatch/deeplink.js')) {
                pathname = pathname.replace(/\/deeplink.js$/, '/home');
            }
            return pathname;
        },

        getIsengardLinkForUrl: function(fullUrl) {
            var self = this;
            var url = new URL(fullUrl);

            if (! /Isengard/.test(self.getConsoleUsername())) {
                return undefined;
            }

            url.pathname = self.getFederatedPathForDeeplinking(url.pathname);

            try {
                var awsUserInfoRegex = /(?:(?:^|.*;\s*)aws-userInfo\s*\=\s*([^;]*).*$)|^.*$/,
                  awsUserInfo = JSON.parse(
                    decodeURIComponent(document.cookie).replace(awsUserInfoRegex, '$1')
                  ),
                  issuer = awsUserInfo.issuer;

                var issuerUrl = new URL(issuer);
                var searchParams = issuerUrl.searchParams;
                searchParams.set('destination', url.pathname + url.search + url.hash);
                issuerUrl.search = searchParams.toString();
                return issuerUrl.toString();

            } catch (e) {
                return undefined;
            }
        },

        getSnapshotCode: function(index, outputMode) {
            const MAX_SHORT_URL_LEN = 256;
            const snapshot = this.snapshotHistory[index];
            const MODES = this.MODES;
            const sourceUrlParam = snapshot.iGraphUrl.length > MAX_SHORT_URL_LEN ? '' : '?sourceUrl=' + encodeURIComponent(snapshot.iGraphUrl);

            outputMode = outputMode || this.outputMode;
            var iGraphAnalyzerUrl = this.getAnalyzerUrl(snapshot, outputMode),
              snapshotId = this.getSnapshotId(snapshot.snapshotUrl);

            switch (outputMode) {
                case MODES.TT:
                    return (snapshot.snapshotUrl + sourceUrlParam + '#TT-EMBED (source: ' + snapshot.iGraphUrl +
                      (snapshot.federationUrl ? ' | ' + snapshot.federationDescription + ': ' + snapshot.federationUrl : '') +
                      ').' + iGraphAnalyzerUrl);
                case MODES.OLD_WIKI:
                    return '{{iGraph/snapshotTinyMP|1=' + snapshotId + '|2=' + snapshot.iGraphUrl + iGraphAnalyzerUrl +'}}';
                case MODES.NEW_WIKI:
                    if (iGraphAnalyzerUrl === "") {
                        return '{{transclude name="iGraph.Snapshot" args="f=' + snapshotId + '|tiny=' + snapshot.iGraphUrl + '" /}}';
                    } else {
                        return '{{transclude name="iGraph.Snapshot.Data" args="f=' + snapshotId + '|tiny=' + snapshot.iGraphUrl + iGraphAnalyzerUrl + '" /}}';
                    }
                case MODES.CHIME_MARKDOWN:
                case MODES.MARKDOWN:
                    return ('[![snapshot](' + snapshot.snapshotUrl + ')](' + snapshot.iGraphUrl + ')\n[source](' + snapshot.iGraphUrl + ')' +
                      (snapshot.federationUrl ? ' | [' + snapshot.federationDescription + '](' + snapshot.federationUrl + ') ' : ' ') + iGraphAnalyzerUrl);
                case MODES.JIRA:
                    return ('Snapshot ([Link to source|' + snapshot.iGraphUrl + ']' +
                      (snapshot.federationUrl ? ' \| [' + snapshot.federationDescription + '|' + snapshot.federationUrl + ']' : '') +
                      '):\n!'+ snapshot.snapshotUrl + '!');
                case MODES.CHIME:
                    return (`:camera: snapshot: ${snapshot.snapshotUrl}\n:chart_with_upwards_trend: source: ${snapshot.iGraphUrl}` +
                      (snapshot.federationUrl ? `\n:unlock: ${snapshot.federationDescription}: ${snapshot.federationUrl}` : '') +
                      iGraphAnalyzerUrl);
                case MODES.SLACK:
                    return (`:camera: <${snapshot.snapshotUrl}|snapshot image> - :chart_with_upwards_trend: <${snapshot.iGraphUrl}|source>` +
                      (snapshot.federationUrl ? ` - :unlock: <${snapshot.federationUrl}|${snapshot.federationDescription}>` : '') +
                      iGraphAnalyzerUrl);
                case MODES.EMAIL:
                    return '' +
                      '<div>' +
                      '<h3 style="margin-bottom: 0px;">Snapshot: ' + snapshot.timestamp + '</h3>' +
                      '<hr style="height: 1px;">' +
                      '<a href="' + snapshot.iGraphUrl + '">' +
                      '<img src="' + snapshot.snapshotUrl + '">' +
                      '</a>' +
                      (snapshot.federationUrl ? '<br/><a href="' + snapshot.federationUrl + '">' + snapshot.federationDescription + '</a>' : "") +
                      iGraphAnalyzerUrl +
                      '</div>';
                case MODES.QUIP2WIKI:
                    return `--wiki-macro: "macro_name=transclude, name='iGraph.Snapshot', args='f=` + snapshotId + `|tiny=` + snapshot.iGraphUrl + `'"--`;
                default:
                    return snapshot.snapshotUrl + sourceUrlParam;
            }
        },

        getAnalyzerUrl: function(snapshot, outputMode) {
            var directLink, id,
              MODES = this.MODES;
            if (snapshot.hasSnappedData) {
                id = this.getSnapshotId(snapshot.snapshotUrl);
                directLink = 'https://monitorportal.amazon.com/iGraphAnalyzer.html?snapshot=' + id;

                switch (outputMode) {
                    case MODES.TT:
                    case MODES.QUIP2WIKI:
                        return "\n(Link to iGraphAnalyzer: " + directLink + ").";
                    case MODES.OLD_WIKI:
                    case MODES.NEW_WIKI:
                        return " | data=" + id;
                    case MODES.CHIME_MARKDOWN:
                    case MODES.MARKDOWN:
                        return ' ([Open with iGraphAnalyzer](' + directLink + '))';
                    case MODES.EMAIL:
                        return '<br/><a href="' + directLink + '">'+
                          '<span style="font-size:78%;font-family:Trebuchet MS">Open with iGraphAnalyzer</span></a>';
                    case MODES.CHIME:
                        return ' - iGraph analyzer :mag: ' + directLink;
                    case MODES.SLACK:
                        return ` - :mag: <${directLink}|iGraph analyzer>`;

                    default:
                        return "";
                }
            }
            return "";
        },

        getSnapshotImagePreviewHtml: function(index, code, chimeCode, chimeMarkdownCode, slackCode) {
            var snapshot = this.snapshotHistory[index];
            return '' +
              '<div>' +
              '<div class="iGraphWikiSnapshotImageContainer">' +
              '<a href="' + snapshot.iGraphUrl + '" target="_blank">' +
              '<img src="' + snapshot.snapshotUrl + '" class="iGraphWikiSnapshotImage">' +
              '</a>' +
              '</div>' +
              '<div class="iGraphWikiSnapshotImageControls">' +
              '<span class="iGraphWikiSnapshotTitle">' + (index + 1) + '. Captured on ' + (snapshot.timestamp ? snapshot.timestamp : "unknown date") + '</span>' +
              '<br><br>' +
              '<input type="submit" value="Copy Code to Clipboard" class="iGHbutton MPWbutton primary iGHsnapshotCopyCode" data-code="' + encodeURIComponent(code) + '">' +
              '<input type="submit" value="Copy Image to Clipboard" class="iGHbutton MPWbutton iGHsnapshotCopyImage">' +
              '<br>' +
              '<input type="submit" value="Clear from History" class="iGHbutton MPWbutton iGHsnapshotDelete" data-index="' + index + '">' +
              '<br>' +
              '<input type="submit" value="To Slack/Chime ..." title="Send to Slack channel/Chime room" class="iGHbutton MPWbutton iGHsnapshotSendToChime"' +
              ' data-chime="' + encodeURIComponent(chimeCode) + '"' +
              ' data-slack="' + encodeURIComponent(slackCode) + '">' +
              '</div>' +
              '</div>';
        },

        setChimeSelectOptions: function() {
            var options = '<option value="">Slack/Chime...</option>',
              self = this;

            Object.keys(this.chimeRooms).sort().forEach(function(roomName) {
                var selected = roomName === self.currentChimeRoomName ? 'selected="selected" ' : '';

                options += '<option ' + selected + 'value="' + self.chimeRooms[roomName].url +'">' + roomName + '</option>';
            });

            $('.iGraphWikiChimeRooms').html(options);
            $('.iGraphWikiChimeRooms').on('change', function() {
                var optionSelected = $("option:selected", this);
                self.currentChimeRoomName = optionSelected.text();
                self.saveChimeRoomDefinitions();
            });
        },

        getPopupHtml: function() {
            this.addStyles();
            this.loadChimeRoomDefinitions();
            var PREVIEW = '<center><div style="margin-top: 50px;">No Snapshot History</div></center>';

            return '' +
              '<div class="iGraphWikiSnapshotPopup">' +
              '<div class="iGraphWikiSnapshotControls">' +
              this.getOutputTypeHtml() +
              '<select class="iGraphWikiChimeRooms"></select>&nbsp;' +
              '<input type="submit" value="Manage Slack/Chime" class="iGHbutton MPWbutton" id="iGraphWebhookManager"><br>' +
              '<input type="submit" value="Snapshot" class="iGHbutton MPWbutton primary" id="iGraphWikiSnapshot" title="Snapshot the underlying graph">' +
              '<img class="iGraphWikiSpinner" src="' + this.SPINNER_IMG + '"/>' +
              '<input type="submit" value="Snapshot with Data" class="iGHbutton MPWbutton primary" id="iGraphSnapshotWithData" title="Snapshot graph with data for future analysis as zoomer">' +
              '<input type="submit" value="Copy All to Clipboard" class="iGHbutton MPWbutton" id="iGraphWikiSnapshotCopyAll" title="Copy snapshot code for all graphs (present in snapshot history) to clipboard">' +
              '<input type="submit" value="Clear History" class="iGHbutton MPWbutton" id="iGraphWikiSnapshotClear" title="Clear the graphs below from the snapshot history. Reverse with Undo button.">' +
              '<input type="submit" value="Undo" class="iGHbutton MPWbutton" id="iGraphWikiSnapshotRestoreHistory" title="Undo the last change to the snapshot history below">' +
              '<input type="checkbox" id="iGraphWikiSnapshotAuto">&nbsp;' +
              '<label for="iGraphWikiSnapshotAuto" title="Tick here to snapshot automatically on launch" style="display:inline-block;">Auto-snap</label>&nbsp;' +
              '<input type="checkbox" id="iGraphWikiSnapshotObeyFit">&nbsp;' +
              '<label for="iGraphWikiSnapshotObeyFit" title="Untick to snapshot on iGraph page using width/height in General options (activates on next snapshot)" style="display:inline-block;">Obey fit</label>&nbsp;' +
              '</div>' +
              '<div class="iGraphChimeRoomManagerControls" style="display:none;">' +
              '<input type="submit" value=" <-Back " class="iGHbutton MPWbutton" id="iGraphWebhookPageBackButton">' +
              '<span class="iGraphWebhookManagerPageTitle">Manage Slack/Chime room webhooks for iGraphHelper</span><br>' +
              '<span style="margin: 5px;">Room/Channel:</span>&nbsp;' +
              '<input type="text" class="iGraphChimeManagerTextbox" id="iGraphChimeRoomName" maxlength="30">' +
              '<span style="margin: 5px;">Webhook Url:</span>&nbsp;' +
              '<input type="text" class="iGraphChimeManagerTextbox" id="iGraphChimeWebhookUrl" size="42">' +
              '<input type="submit" value="Add Slack/Chime Webhook" class="iGHbutton MPWbutton primary" id="iGraphAddChimeRoomButton" title="test">' +
              '</div>' +
              '<div class="iGraphWikiSnapshotPreview">' + PREVIEW + '</div>' +
              '</div>' +
              '<span class="iGraphWikiSnapshotMessage" style="display: none;"></span>';
        },

        getOutputTypeHtml: function() {
            var self = this,
              MODES = this.MODES,
              modesInOrder = [ MODES.RAW, MODES.TT, MODES.NEW_WIKI, MODES.MARKDOWN, MODES.JIRA, MODES.EMAIL, MODES.OLD_WIKI, MODES.QUIP2WIKI ],
              html = '<div class="iGHbutton-bar"><ul class="iGHbutton-group iGHround" title="Choose format for snapshot code: raw graph links, or pasting into TT, Wiki, SIM, as markdown or into an email">';

            modesInOrder.forEach(function(mode) {
                html += '<li><a class="iGHsmall iGHbuttonFlat iGHsecondary iGHSnapshotOutputMode" data-mode="' + mode + '" href="javascript:void(0)">' + mode + '</a></li>';
            });
            html += '</ul></div>';
            return html;
        },

        // Includes a Javascript a file, given by 'url', in the current document
        includeScript: function (url) {
            if (unsafeWin.document.body || unsafeWin.document.head) {
                var script = unsafeWin.document.createElement('script');
                script.setAttribute('language', 'javascript');
                script.setAttribute('type', 'text/javascript');
                script.setAttribute('src', url);
                (unsafeWin.document.body || unsafeWin.document.head).appendChild(script);
            }
        },

        pad: function(number){
            if (number < 10) {
                return "0" + number;
            }
            return number;
        },

        replaceRelativeWithFixedTime: function(graphArgs) {
            var time = this.getTimeRange(graphArgs);
            if (time.startTime && this.isDuration(time.startTime)) {
                var startMins = this.getDurationInMinutes(time.startTime),
                  endMins   = this.getDurationInMinutes(time.endTime),
                  now = new Date();
                graphArgs = this.removeQueryParams(graphArgs, ["StartTime1", "EndTime1"]);
                graphArgs += '&StartTime1=' + this.getFixedTimeFromDuration(now, startMins) +
                  '&EndTime1=' + this.getFixedTimeFromDuration(now, endMins);
            }
            return graphArgs;
        },

        getFixedTimeFromDuration: function(date, minutes){
            var offsetDate = new Date(date.getTime());
            offsetDate.setMinutes(date.getMinutes() - minutes);
            return this.getFixedTimeFromDate(offsetDate);
        },

        getFixedTimeFromDate: function(date){
            return date.getUTCFullYear() + "-" + this.pad(date.getUTCMonth() + 1) + "-" + this.pad(date.getUTCDate()) + "T" + this.pad(date.getUTCHours()) + ":" + this.pad(date.getUTCMinutes()) + ":00Z";
        },

        // get number of minutes corresponding to a duration
        getDurationInMinutes: function(duration){
            // sign is inverted sign widget is ago
            var sign = duration.match("-P") ? 1 : -1;
            var minutes = 0;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    minutes += this.MINUTES[index] * parseInt(results[1], this.DECIMAL);
                }
            }
            return sign * minutes;
        },

        extractQueryValue: function(url, param) {
            var re = new RegExp(param + "=([^&]*)");
            if (null !== url.match(re)) {
                return decodeURIComponent(RegExp.$1);
            }
            return null;
        },

        removeQueryParams: function(url, paramList) {
            var newUrl = url;
            for (var i = 0; i < paramList.length; i++) {
                var re = new RegExp(paramList[i] + "(=|%3D)[^&]*", "gi");
                newUrl = newUrl.replace(re, "");
            }
            return newUrl;
        },

        isDuration: function(time) {
            return this.DURATION.test(time);
        },

        getTimeRange: function(graphArgs) {
            return { startTime: this.extractQueryValue(graphArgs, "StartTime1"),
                endTime:   this.extractQueryValue(graphArgs, "EndTime1")};
        }
    };

    win.WikiBulkSnapshot = {

        graphArgs: [],
        snapshots: [],
        numItems: 0,
        completedSnapCount: 0,
        CART_STORAGE_KEY_OLD: 'MPWcartGraphUrl',
        CART_STORAGE_KEY: 'MPWcartState',

        initialize: function() {
            WebLabTimes.waitFor(function () {
                return unsafeWin.MPW;
            }, WikiBulkSnapshot.injectSnapshotButtonIntoCart);
        },

        injectSnapshotButtonIntoCart: function() {
            jQuery('.MPWcartButton .dummySnapButton').remove();
            jQuery('.MPWcartButton').append('<input type="submit" class="MPWbutton iGraphSnapshotButton" value="Bulk Snapshot" title="Take snapshot of all graphs. (Use Ctrl/Cmd-click for Snapshot with data)">');
            jQuery('.iGraphSnapshotButton').on('click', function(event) {
                WikiSnapshot.snapWithData = false;
                var message = "Started taking bulk snapshots...";
                if (event.ctrlKey || event.metaKey) {
                    WikiSnapshot.snapWithData = true;
                    message = "Started taking bulk snapshots with data...";
                }
                WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, undefined, message, true);
            });
        },

        snapshotCartGraphs: function() {
            this.restoreState();
            var counter = 0;
            var cartGraphs = this.graphArgs;
            var timer = setInterval(function() {
                WikiSnapshot.snapshotGraphUrl(cartGraphs[counter].replace(/.*[?]/, ""), counter);
                if ( counter ==  cartGraphs.length-1) {
                    clearInterval(timer);
                }
                counter++;
            }, 100);
        },

        onSnapshotComplete: function(snapshot, uniqueId) {
            this.snapshots[uniqueId] = snapshot;
            this.completedSnapCount++;
            WikiSnapshot.displayMessage("Snapshotting graphs : " + this.completedSnapCount + " of " + this.numItems + " completed.");
            if (this.completedSnapCount == this.numItems) {
                for (var i=this.snapshots.length-1; i >= 0; i--) {
                    WikiSnapshot.addHistoryItem(this.snapshots[i]);
                }
                this.completedSnapCount = 0;
                this.snapshots = [];
                WikiSnapshot.noOfSnapshotsToBeCopied = this.numItems;
                WikiSnapshot.copyAllHistoryToClipboard();
            }
        },

        restoreState: function() {
            if (localStorage) {
                if (localStorage.getItem(this.CART_STORAGE_KEY)) {
                    this.graphArgs = JSON.parse(localStorage.getItem(this.CART_STORAGE_KEY)).graphArgs;
                }

                if (Object.keys(this.graphArgs).length === 0 && localStorage.getItem(this.CART_STORAGE_KEY_OLD)) {
                    this.graphArgs = JSON.parse(localStorage.getItem(this.CART_STORAGE_KEY_OLD));
                }
            }
            this.numItems = this.graphArgs.length;
        },

        storeState: function() {
            if (localStorage) {
                localStorage.setItem(this.CART_STORAGE_KEY, JSON.stringify({graphArgs: this.graphArgs}));
                localStorage.setItem(this.CART_STORAGE_KEY_OLD, JSON.stringify(this.graphArgs));
            }
        },
    };
};

function sendJSONtoURL(url, json) {
    setTimeout(function() {
        GM_xmlhttpRequest({
            method: 'POST',
            url: $.trim(url),
            headers: {
                'Content-Type': 'application/json'
            },
            timeout: 10000,
            data: JSON.stringify(json),
            onload: function (response) {
                if (response.status !== 200) {
                    console.log(response);
                    alert("Failed to post, please try again");
                }
            },
            onerror: function (response) {
                console.log(response);
                alert("Failed to post, please try again");
            },
            ontimeout: function (response) {
                console.log(response);
                alert("Request timeout while sending, please try again after some time");
            }
        });
    }, 0);
};

function sendFormDataToS3(formData){
    setTimeout(function() {
        GM_xmlhttpRequest({
            method : 'POST',
            url : 'https://monitorportal.amazon.com/snap/saveGraphData',
            timeout : 45000,
            data : formData,
            onload : function(response) {
                if (response.status == 200) {
                }
                else {
                    alert("Facing difficulty while uploading data file to S3\nPlease try again");
                    console.log("iGraphHelper:- Rsp.status: " + response.status + ", Text: " + response.responseText);
                    console.log('failed1');
                }
            },
            onerror: function(response) {
                console.log("iGraphHelper: onError from sending form data to S3");
                console.log(response);
            },
            ontimeout: function(response){
                alert("Request timeout while uploading file to S3 \nPlease try again after some time");
            }
        });
    }, 0);
};

function getTinyLinkForUrl(url, callback) {
    function tinyError(response) {
        alert("Facing difficulty tinyfying graph link, will use full URL instead");
        if (response) {
            console.log("iGraphHelper:" + JSON.stringify(response));
        }
        callback(url);
    }
    setTimeout(function() {
        try {
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                onload: function(response) {
                    var tinyUrl = jQuery("#url_box", jQuery(response.responseText)).html();
                    if (tinyUrl) {
                        tinyUrl = tinyUrl.replace(/\/\/tiny\//, "//tiny.amazon.com/");          // Speed up lookup of tiny
                        callback(tinyUrl);
                    } else {
                        tinyError(response);
                    }
                },
                onabort: tinyError,
                onerror: tinyError,
                ontimeout: tinyError
            });
        } catch (e) {
            tinyError();
        }
    }, 0);
}

var WebLabTimes = {
    BTN_TEMPLATE: "<a class='igraph-helper btn btn-small' style='display: block'><small>iGraph Vertical Lines</small></a>",
    initialize: function() {
        this.addControls();
    },
    addControls: function() {
        $(document).on('click', '.expand-activation-history', function(ev) {
            var colapsible_div = $(this.getAttribute('href'));

            // remove old controls
            $('.igraph-helper', colapsible_div.parent()).remove();

            // add control only if expanded
            if (colapsible_div.hasClass('in')) {
                var $html = $(WebLabTimes.BTN_TEMPLATE);
                $html.on('click', function() {
                    WebLabTimes.createLines(colapsible_div);
                });
                colapsible_div.parent().prepend($html);
            }
        });
    },
    createLines: function(parent_table) {
        var text_lines = [];
        var last_line_description = '';
        var weblab_name = $('h1').text().split(':')[0];

        $('tbody tr', parent_table).each(function() {
            var all_tds = $('td', this);
            var wtype = all_tds[0].innerText;
            // clear new lines
            var wallocation = all_tds[1].innerText.replace(/(?:\r\n|\r|\n)/g, ' ');
            // remove timezone from date, since the date is in browser timezone
            var wdate = $.trim(all_tds[2].innerText).replace(/\s[A-Z0-9]*$/, '');
            var line_date = new Date(wdate).toISOString();
            // line of igraph
            var line_description = weblab_name + ': ' + wtype + ' ' + wallocation;

            // if last line is equal current line, remove last to add again with last time
            if (line_description === last_line_description) {
                text_lines.pop();
            }
            text_lines.push([line_description, line_date].join(' @ '));
            last_line_description = line_description;
        });

        WebLabTimes.display_vlines(text_lines.join(','));
    },
    display_vlines: function(content) {
        GM_setClipboard(content);
        alert('Vertical lines copied to clipboard.');
    },
    waitFor: function(condition, callback) {
        if (condition()) {
            callback();
        } else {
            window.setTimeout(WebLabTimes.waitFor, ApolloDeployments.CHECK_DELAY_MS, condition, callback);
        }
    }
};

/*
 * Pipelines RediFork integration, for displaying iGraph links within Pipeline RediFork approval workflow steps
 */

var PipelinesRediForkIntegration = (function () {
    "use strict";

    var PipelinesRediForkIntegration = {};
    PipelinesRediForkIntegration.initialize = function() {
        if (/pipelines\.amazon\.com\/pipelines/.test(window.location.href)) {
            initializePipelinesPage();
        } else if (/pipelines\.amazon\.com\/approval_attempts/.test(window.location.href)) {
            initializeWorkflowDetailsPage();
        }

    };

    var initializePipelinesPage = function() {
        $.map(PipelineView.forCurrentPage().getWorkflows(), function(workflow) {
            var attemptDetailsLink = workflow.getAttemptDetailsLink();
            if (!attemptDetailsLink) {
                return;
            }

            var loadAttemptDetailsPageAndAddLinksForRediForkSteps = function() {
                $.get(attemptDetailsLink, function(response, status, xhr) {
                    if (status != "success") {
                        return;
                    }

                    var workflowDetails = WorkflowDetailsView.forDocument(response);

                    $.map(workflowDetails.getSteps(), function(step) {
                        if (step.getType() != "RediFork") {
                            return;
                        }

                        var iGraphLinks = calculateIGraphLinksForRediForkStep(step);

                        var pipelineViewWorkflowStep = workflow.getStepByName(step.getName());

                        pipelineViewWorkflowStep._jqStep.find("div.last-instance")
                          .append("<div style='font-size: 11px;'>"+iGraphLinks+"</div>");
                    });
                });
            };

            if (workflow.areStepsExpanded()) {
                loadAttemptDetailsPageAndAddLinksForRediForkSteps();
            } else {
                workflow._jqWorkflow.find('.expand-indicator')
                  .one('click', loadAttemptDetailsPageAndAddLinksForRediForkSteps);
            }
        });
    };

    var initializeWorkflowDetailsPage = function() {
        $.map(WorkflowDetailsView.forCurrentPage().getSteps(), function(step) {
            if (step.getType() != "RediFork") {
                return;
            }

            var iGraphLinks = calculateIGraphLinksForRediForkStep(step);

            step._jqStep.find("span.extra").append(iGraphLinks);
        });
    };

    var PipelineView = (function() {
        var clazz = {};

        clazz.forCurrentPage = function() {
            return clazz.forDocument(document);
        };

        clazz.forDocument = function(doc) {
            var details = new Object();

            details._doc = doc;
            details.getWorkflows = _getWorkflows;
            return details;
        };

        var _getWorkflows = function() {
            return $('div.workflows div.workflow', this._doc).map(function() {
                return PipelineWorkflowView.fromWorkflowElement(this);
            }).get();
        };

        return clazz;
    })();

    var PipelineWorkflowView = (function() {
        var clazz = {};

        clazz.fromWorkflowElement = function(workflowElement) {
            if (workflowElement == null) throw "workflowElement must not be null";
            return clazz.fromJQueryWorkflow($(workflowElement));
        };

        clazz.fromJQueryWorkflow = function(jqWorkflow) {
            if (jqWorkflow == null) throw "jqWorkflow must not be null";

            var workflow = new Object();
            workflow._jqWorkflow = jqWorkflow;
            workflow._steps = $.map(workflow._jqWorkflow.find("li.workflow_step").toArray(), PipelineWorkflowStepView.fromStepElement);
            workflow._stepsByName = (function() {
                var stepsByName = {};
                $.each(workflow._steps, function(idx, step) {
                    stepsByName[step.getName()] = step;
                });
                return stepsByName;
            })();
            workflow.getAttemptDetailsLink = _getAttemptDetailsLink;
            workflow.getSteps = _getSteps;
            workflow.getStepByName = _getStepByName;
            workflow.areStepsExpanded = _areStepsExpanded;
            return workflow;
        };

        var _getAttemptDetailsLink = function() {
            return this._jqWorkflow.find("span.attempt-details a").attr('href')
        };

        var _getSteps = function() {
            return this._steps.slice(0);
        };

        var _getStepByName = function(stepName) {
            return this._stepsByName[stepName];
        };

        var _areStepsExpanded = function() {
            return this._jqWorkflow.find('.workflow_steps').is(':visible');
        };

        return clazz;
    })();

    var PipelineWorkflowStepView = (function() {
        var clazz = {};

        clazz.fromStepElement = function(stepElement) {
            if (stepElement == null) throw "stepElement must not be null";
            return clazz.fromJQueryStep($(stepElement));
        };

        clazz.fromJQueryStep = function(jqStep) {
            if (jqStep == null) throw "jqStep must not be null";

            var step = new Object();
            step._jqStep = jqStep;
            step.getName = _getName;
            return step;
        };

        var _getName = function() {
            return $.trim(this._jqStep.find("h3").text())
        };

        return clazz;
    })();

    var WorkflowDetailsView = (function() {
        var clazz = {};

        clazz.forCurrentPage = function() {
            return clazz.forDocument(document);
        };

        clazz.forDocument = function(doc) {
            var details = new Object();

            details._doc = doc;
            details.getSteps = _getWorkflowSteps;
            return details;
        };

        var _getWorkflowSteps = function() {
            return $.map($('li.step', this._doc).toArray(), WorkflowDetailsViewStep.fromStepElement);
        };

        return clazz;
    })();

    var WorkflowDetailsViewStep = (function() {
        var clazz = {};

        clazz.fromStepElement = function(stepElement) {
            if (stepElement == null) throw "stepElement must not be null";
            return clazz.fromJQueryStep($(stepElement));
        };

        clazz.fromJQueryStep = function(jqStep) {
            if (jqStep == null) throw "jqStep must not be null";

            var step = new Object();
            step._jqStep = jqStep;
            step.getName = _getName;
            step.getType = _getType;
            step.getField = _getField;
            step.getStartMillis = _getStartMillis;
            step.getStatusNote = _getStatusNote;
            step.getCurrentState = _getCurrentState;
            return step;
        };

        var _getName = function() {
            return $.trim(this._jqStep.find("h3 span")[0].previousSibling.nodeValue);
        };

        var _getField = function(fieldName) {
            var fieldLabel = this._jqStep.find("ul.parameters li:contains('" + fieldName + ":') b");
            if (!fieldLabel.length) {
                throw "field: '" + fieldName + "' doesn't exist in pipeline workflow step: '" + this.getName() + "'";
            }
            return $.trim(fieldLabel[0].nextSibling.nodeValue);
        }

        var _getType = function() {
            return this.getField('Type');
        };

        var _getStartMillis = function() {
            return parseInt(this._jqStep.find("div.time span.relative-time").attr("data-millis"));
        };

        var _getStatusNote = function() {
            return $.trim(this._jqStep.find("p.note").text() || "");
        };

        var _getCurrentState = function() {
            return $.trim(this._jqStep.find("h3 span").text());
        };

        return clazz;
    })();

    var calculateIGraphLinksForRediForkStep = function(step) {
        var successThresholds = step.getField('Metric Count').split(";");

        return step.getField('Metric').split(";").map(function (metric, index, _) {
            var verticalLineAndRange = getVerticalLineAndTimeRangeFromRediForkStep(step);

            var iGraphTimeWindow = calculateTimeWindowForRediForkIGraphDisplay(verticalLineAndRange.startTime, verticalLineAndRange.endTime);

            var baseIGraphUrl = createIGraphUrlForRediForkMetric.apply(null, metric.split(","));

            var iGraphUrl = baseIGraphUrl +
              "&VerticalLine1=" + encodeURIComponent(verticalLineAndRange.verticalLine) +
              "&StartTime1=" + iGraphTimeWindow.start +
              "&EndTime1=" + iGraphTimeWindow.end;

            var iGraphLinks = "&nbsp;-&nbsp;<a target='_blank' href='"+iGraphUrl+"'>iGraph</a>";

            var iGraphRunningSumTimeWindow = calculateRunningSumTimeWindowForRediForkIGraphDisplay(verticalLineAndRange.startTime, verticalLineAndRange.endTime);

            if (!iGraphRunningSumTimeWindow) {
                return iGraphLinks;
            }

            var successThreshold = successThresholds[index];

            var iGraphRunningSumUrl = baseIGraphUrl +
              "&VerticalLine1=" + encodeURIComponent(verticalLineAndRange.verticalLine) +
              "&StartTime1=" + iGraphRunningSumTimeWindow.start +
              "&EndTime1=" + iGraphRunningSumTimeWindow.end +
              "&HorizontalLineLeft1=" + encodeURIComponent("RediFork success threshold #color=green - @ " + successThreshold)  +
              "&FunctionExpression1=" + encodeURIComponent("RUNNING_SUM(M1)") +
              "&FunctionLabel1=" + encodeURIComponent("{Running sum since start of RediFork workflow} [last: {last}]") +
              "&FunctionYAxisPreference1=left";

            return iGraphLinks + "&nbsp;(<a target='_blank' href='"+iGraphRunningSumUrl+"'>Running sum iGraph</a>)";
        }).join("");
    };

    var calculateRunningSumTimeWindowForRediForkIGraphDisplay = function(startTime, endTime) {
        if (startTime && endTime == "now") {
            var nowMillis = new Date().getTime();
            var hoursSinceStart = (nowMillis - startTime) / (1000 * 3600);
            var hoursWindowStart = hoursSinceStart;
            var minutesWindowStart = (hoursWindowStart * 60.0) | 0;
            return {
                start: "-PT" + minutesWindowStart + "M",
                end: "-PT0M"
            };
        }

        if (startTime && endTime) {
            return {
                start: millisToIgraphFixedTime(startTime),
                end: millisToIgraphFixedTime(endTime)
            };
        }

        return null;
    };

    var calculateTimeWindowForRediForkIGraphDisplay = function(startTime, endTime) {
        if (startTime && endTime == "now") {
            var nowMillis = new Date().getTime();
            var hoursSinceStart = (nowMillis - startTime) / (1000 * 3600);
            var hoursWindowStart = 1.25 * hoursSinceStart;
            var minutesWindowStart = (hoursWindowStart * 60) | 0;
            return {
                start: "-PT" + minutesWindowStart + "M",
                end: "-PT0M"
            };
        }

        if (startTime && endTime) {
            var durationMillis = endTime - startTime;
            var windowStartMillis = startTime - (durationMillis * 0.125);
            var windowEndMillis = endTime + (durationMillis * 0.125);

            return {
                start: millisToIgraphFixedTime(windowStartMillis),
                end: millisToIgraphFixedTime(windowEndMillis)
            };
        }

        return {
            start: "-PT3H",
            end: "-PT0M"
        };
    };

    var millisToIgraphFixedTime = function(epochMillis) {
        var d = new Date(epochMillis);

        var year = d.getUTCFullYear();
        var month = d.getUTCMonth() + 1;
        var day = d.getUTCDate();

        var hour = d.getUTCHours();
        var minute = d.getUTCMinutes();

        return year + "-" + pad(month, 2) + "-" + pad(day, 2) + "T" + pad(hour, 2) + ":" + pad(minute, 2) + ":00Z";
    };

    var createIGraphUrlForRediForkMetric = function(dataset, marketplace, hostGroup, host, serviceName, methodName, client, metricClass, instance, metric, stat) {
        stat = stat || "n";

        return "https://monitorportal.amazon.com/igraph?SchemaName1=Service"+
          "&DataSet1="+dataset+
          "&Marketplace1="+marketplace+
          "&HostGroup1="+hostGroup+
          "&Host1="+host+
          "&ServiceName1="+serviceName+
          "&MethodName1="+methodName+
          "&Client1="+client+
          "&MetricClass1="+metricClass+
          "&Instance1="+instance+
          "&Metric1="+metric+
          "&Stat1="+stat+
          "&Period1=FiveMinute"+
          "&DecoratePoints=true";
    };

    var getVerticalLineAndTimeRangeFromRediForkStep = function(step) {
        var startMillis = step.getStartMillis();
        var endMillis = null;

        if (!startMillis) {
            return {
                verticalLine: "",
                startTime: null,
                endTime: null
            };
        }

        var start = millisToIgraphFixedTime(startMillis);
        var end = "now";

        var statusNote = step.getStatusNote();

        var m = statusNote.match(/Total time: ((\d+) hours?, )?(\d+) minutes?/);
        if (m) {
            var hours = parseInt(m[2] || "0");
            var minutes = parseInt(m[3] || "0");

            endMillis = startMillis + (3600 * 1000 * hours) + (60 * 1000 * minutes);
            end = millisToIgraphFixedTime(endMillis);
        }

        if (statusNote.indexOf("Timeout reached") != -1) {
            var hours = parseInt(step.getField('Maximum Time'));
            endMillis = startMillis + (3600 * 1000 * hours);
            end = millisToIgraphFixedTime(endMillis);
        }

        var currentState = step.getCurrentState();

        var color = "green";
        if (currentState == "Failed") {
            color = "red";
        } else if (currentState == "In progress") {
            color = "#df8d00";
        }

        return {
            verticalLine: "(Start: " + step.getName() + " #color=" + color + " - @ " + start + ", " + currentState + " #color=" + color + " - @ " + end + ")",
            startTime: startMillis,
            endTime: endMillis ? endMillis : "now"
        };
    };

    var pad = function(n, width) {
        n = n + '';
        return n.length >= width ? n : new Array(width - n.length + 1).join(0) + n;
    };

    return PipelinesRediForkIntegration;
})();

/*
* dom-to-image plugin
*
* Copyright (c) 2015 Anatolii Saienko
*
* Licensed under MIT License (MIT)
*
* Use this URL to get the latest version
* https://code.amazon.com/packages/CloudWatchDashboardsJS/blobs/mainline/--/src/app/data/domToImage.js
*/

(function (global) {
    'use strict';

    var util = newUtil();
    var inliner = newInliner();
    var fontFaces = newFontFaces();
    var images = newImages();

    // Default impl options
    var defaultOptions = {
        // Default is to fail on error, no placeholder
        imagePlaceholder: undefined,
        // Default cache bust is false, it will use the cache
        cacheBust: false
    };

    // owning window for the node initialize
    var ownerWindow = window;

    var domtoimage = {
        toSvg: toSvg,
        toPng: toPng,
        toJpeg: toJpeg,
        toBlob: toBlob,
        toPixelData: toPixelData,
        impl: {
            fontFaces: fontFaces,
            images: images,
            util: util,
            inliner: inliner,
            options: {}
        }
    };

    if (typeof module !== 'undefined')
        module.exports = domtoimage;
    else
        global.domtoimage = domtoimage;


    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options
     * @param {Function} options.filter - Should return true if passed node should be included in the output
     *          (excluding node means excluding it's children as well). Not called on the root node.
     * @param {String} options.bgcolor - color for the background, any valid CSS color value.
     * @param {Number} options.width - width to be applied to node before rendering.
     * @param {Number} options.height - height to be applied to node before rendering.
     * @param {Object} options.style - an object whose properties to be copied to node's style before rendering.
     * @param {Number} options.quality - a Number between 0 and 1 indicating image quality (applicable to JPEG only),
                defaults to 1.0.
     * @param {String} options.imagePlaceholder - dataURL to use as a placeholder for failed images, default behaviour is to fail fast on images we can't fetch
     * @param {Boolean} options.cacheBust - set to true to cache bust by appending the time to the request url
     * @return {Promise} - A promise that is fulfilled with a SVG image data URL
     * */

    function updateWindowForNode(node) {
        if (node) ownerWindow = node.ownerDocument ? node.ownerDocument.defaultView : window;
    }

    function toSvg(node, options) {
        updateWindowForNode(node);
        options = options || {};
        copyOptions(options);
        return Promise.resolve(node)
            .then(function (node) {
                return cloneNode(node, options.filter, true);
            })
            .then(embedFonts)
            .then(inlineImages)
            .then(applyOptions)
            .then(function (clone) {
                return makeSvgDataUri(clone,
                    options.width || util.width(node),
                    options.height || util.height(node)
                );
            });

        function applyOptions(clone) {
            if (options.bgcolor) clone.style.backgroundColor = options.bgcolor;

            if (options.width) clone.style.width = options.width + 'px';
            if (options.height) clone.style.height = options.height + 'px';

            if (options.style)
                Object.keys(options.style).forEach(function (property) {
                    clone.style[property] = options.style[property];
                });

            return clone;
        }
    }

    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options, @see {@link toSvg}
     * @return {Promise} - A promise that is fulfilled with a Uint8Array containing RGBA pixel data.
     * */
    function toPixelData(node, options) {
        updateWindowForNode(node);
        return draw(node, options || {})
            .then(function (canvas) {
                return canvas.getContext('2d').getImageData(
                    0,
                    0,
                    util.width(node),
                    util.height(node)
                ).data;
            });
    }

    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options, @see {@link toSvg}
     * @return {Promise} - A promise that is fulfilled with a PNG image data URL
     * */
    function toPng(node, options) {
        updateWindowForNode(node);
        return draw(node, options || {})
            .then(function (canvas) {
                return canvas.toDataURL();
            });
    }

    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options, @see {@link toSvg}
     * @return {Promise} - A promise that is fulfilled with a JPEG image data URL
     * */
    function toJpeg(node, options) {
        updateWindowForNode(node);
        options = options || {};
        return draw(node, options)
            .then(function (canvas) {
                return canvas.toDataURL('image/jpeg', options.quality || 1.0);
            });
    }

    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options, @see {@link toSvg}
     * @return {Promise} - A promise that is fulfilled with a PNG image blob
     * */
    function toBlob(node, options) {
        updateWindowForNode(node);
        return draw(node, options || {})
            .then(util.canvasToBlob);
    }

    function copyOptions(options) {
        // Copy options to impl options for use in impl
        if(typeof(options.imagePlaceholder) === 'undefined') {
            domtoimage.impl.options.imagePlaceholder = defaultOptions.imagePlaceholder;
        } else {
            domtoimage.impl.options.imagePlaceholder = options.imagePlaceholder;
        }

        if(typeof(options.cacheBust) === 'undefined') {
            domtoimage.impl.options.cacheBust = defaultOptions.cacheBust;
        } else {
            domtoimage.impl.options.cacheBust = options.cacheBust;
        }
    }

    function draw(domNode, options) {
        return toSvg(domNode, options)
            .then(util.makeImage)
            .then(util.delay(100))
            .then(function (image) {
                var canvas = newCanvas(domNode);
                canvas.getContext('2d').drawImage(image, 0, 0);
                return canvas;
            });

        function newCanvas(domNode) {
            var canvas = document.createElement('canvas');
            canvas.width = options.width || util.width(domNode);
            canvas.height = options.height || util.height(domNode);

            if (options.bgcolor) {
                var ctx = canvas.getContext('2d');
                ctx.fillStyle = options.bgcolor;
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            }

            return canvas;
        }
    }

    function cloneNode(node, filter, root) {
        if (!root && filter && !filter(node)) return Promise.resolve();

        return Promise.resolve(node)
            .then(makeNodeCopy)
            .then(function (clone) {
                return cloneChildren(node, clone, filter);
            })
            .then(function (clone) {
                return processClone(node, clone);
            });

        function makeNodeCopy(node) {
            if (node instanceof ownerWindow.HTMLCanvasElement || node instanceof HTMLCanvasElement) return util.makeImage(node.toDataURL());
            return node.cloneNode(false);
        }

        function cloneChildren(original, clone, filter) {
            var children = original.childNodes;
            if (children.length === 0) return Promise.resolve(clone);

            return cloneChildrenInOrder(clone, util.asArray(children), filter)
                .then(function () {
                    return clone;
                });

            function cloneChildrenInOrder(parent, children, filter) {
                var done = Promise.resolve();
                children.forEach(function (child) {
                    done = done
                        .then(function () {
                            return cloneNode(child, filter);
                        })
                        .then(function (childClone) {
                            if (childClone) parent.appendChild(childClone);
                        });
                });
                return done;
            }
        }

        function processClone(original, clone) {
            if (!(clone instanceof ownerWindow.Element) && !(clone instanceof Element)) return clone;

            return Promise.resolve()
                .then(cloneStyle)
                .then(clonePseudoElements)
                .then(copyUserInput)
                .then(fixSvg)
                .then(function () {
                    return clone;
                });

            function cloneStyle() {
                copyStyle(window.getComputedStyle(original), clone.style);

                function copyStyle(source, target) {
                    if (source.cssText) target.cssText = source.cssText;
                    else copyProperties(source, target);

                    function copyProperties(source, target) {
                        util.asArray(source).forEach(function (name) {
                            if (!name.includes('--')) {
                                target.setProperty(
                                    name,
                                    source.getPropertyValue(name),
                                    source.getPropertyPriority(name)
                                );
                            };
                        });
                    }
                }
            }

            function clonePseudoElements() {
                [':before', ':after'].forEach(function (element) {
                    clonePseudoElement(element);
                });

                function clonePseudoElement(element) {
                    var style = window.getComputedStyle(original, element);
                    var content = style.getPropertyValue('content');

                    if (content === '' || content === 'none') return;

                    var className = util.uid();
                    clone.className = clone.className + ' ' + className;
                    var styleElement = document.createElement('style');
                    styleElement.appendChild(formatPseudoElementStyle(className, element, style));
                    clone.appendChild(styleElement);

                    function formatPseudoElementStyle(className, element, style) {
                        var selector = '.' + className + ':' + element;
                        var cssText = style.cssText ? formatCssText(style) : formatCssProperties(style);
                        return document.createTextNode(selector + '{' + cssText + '}');

                        function formatCssText(style) {
                            var content = style.getPropertyValue('content');
                            return style.cssText + ' content: ' + content + ';';
                        }

                        function formatCssProperties(style) {

                            return util.asArray(style)
                                .map(formatProperty)
                                .join('; ') + ';';

                            function formatProperty(name) {
                                return name + ': ' +
                                    style.getPropertyValue(name) +
                                    (style.getPropertyPriority(name) ? ' !important' : '');
                            }
                        }
                    }
                }
            }

            function copyUserInput() {
                if ((original instanceof ownerWindow.HTMLTextAreaElement) || (original instanceof HTMLTextAreaElement)) clone.innerHTML = original.value;
                if ((original instanceof ownerWindow.HTMLInputElement) || (original instanceof HTMLInputElement)) clone.setAttribute('value', original.value);
            }

            function fixSvg() {
                if (!(clone instanceof ownerWindow.SVGElement) && !(clone instanceof SVGElement)) return;
                clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

                if (!(clone instanceof ownerWindow.SVGRectElement) && !(clone instanceof SVGRectElement)) return;
                ['width', 'height'].forEach(function (attribute) {
                    var value = clone.getAttribute(attribute);
                    if (!value) return;

                    clone.style.setProperty(attribute, value);
                });
            }
        }
    }

    function embedFonts(node) {
        return fontFaces.resolveAll()
            .then(function (cssText) {
                var styleNode = document.createElement('style');
                node.appendChild(styleNode);
                styleNode.appendChild(document.createTextNode(cssText));
                return node;
            });
    }

    function inlineImages(node) {
        return images.inlineAll(node)
            .then(function () {
                return node;
            });
    }

    function makeSvgDataUri(node, width, height) {
        return Promise.resolve(node)
            .then(function (node) {
                node.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
                return new XMLSerializer().serializeToString(node);
            })
            .then(function (xhtml) {
                return '<foreignObject x="0" y="0" width="100%" height="100%">' + xhtml + '</foreignObject>';
            })
            .then(function (foreignObject) {
                return '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '">' +
                    foreignObject + '</svg>';
            })
            .then(function (svg) {
                return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
            });
    }

    function newUtil() {
        return {
            escape: escape,
            parseExtension: parseExtension,
            mimeType: mimeType,
            dataAsUrl: dataAsUrl,
            isDataUrl: isDataUrl,
            canvasToBlob: canvasToBlob,
            resolveUrl: resolveUrl,
            getAndEncode: getAndEncode,
            uid: uid(),
            delay: delay,
            asArray: asArray,
            escapeXhtml: escapeXhtml,
            makeImage: makeImage,
            width: width,
            height: height
        };

        function mimes() {
            /*
             * Only WOFF and EOT mime types for fonts are 'real'
             * see https://www.iana.org/assignments/media-types/media-types.xhtml
             */
            var WOFF = 'application/font-woff';
            var JPEG = 'image/jpeg';

            return {
                'woff': WOFF,
                'woff2': WOFF,
                'ttf': 'application/font-truetype',
                'eot': 'application/vnd.ms-fontobject',
                'png': 'image/png',
                'jpg': JPEG,
                'jpeg': JPEG,
                'gif': 'image/gif',
                'tiff': 'image/tiff',
                'svg': 'image/svg+xml'
            };
        }

        function parseExtension(url) {
            var match = /\.([^\.\/]*?)$/g.exec(url);
            if (match) return match[1];
            else return '';
        }

        function mimeType(url) {
            var extension = parseExtension(url).toLowerCase();
            return mimes()[extension] || '';
        }

        function isDataUrl(url) {
            return url.search(/^(data:)/) !== -1;
        }

        function toBlob(canvas) {
            return new Promise(function (resolve) {
                var binaryString = window.atob(canvas.toDataURL().split(',')[1]);
                var length = binaryString.length;
                var binaryArray = new Uint8Array(length);

                for (var i = 0; i < length; i++)
                    binaryArray[i] = binaryString.charCodeAt(i);

                resolve(new Blob([binaryArray], {
                    type: 'image/png'
                }));
            });
        }

        function canvasToBlob(canvas) {
            if (canvas.toBlob)
                return new Promise(function (resolve) {
                    canvas.toBlob(resolve);
                });

            return toBlob(canvas);
        }

        function resolveUrl(url, baseUrl) {
            var doc = document.implementation.createHTMLDocument();
            var base = doc.createElement('base');
            doc.head.appendChild(base);
            var a = doc.createElement('a');
            doc.body.appendChild(a);
            base.href = baseUrl;
            a.href = url;
            return a.href;
        }

        function uid() {
            var index = 0;

            return function () {
                return 'u' + fourRandomChars() + index++;

                function fourRandomChars() {
                    /* see https://stackoverflow.com/a/6248722/2519373 */
                    return ('0000' + (Math.random() * Math.pow(36, 4) << 0).toString(36)).slice(-4);
                }
            };
        }

        function makeImage(uri) {
            return new Promise(function (resolve, reject) {
                var image = new Image();
                image.onload = function () {
                    resolve(image);
                };
                image.onerror = reject;
                image.src = uri;
            });
        }

        function isValidUrl(string) {
            try {
                new URL(string);
                return true;
            } catch (err) {
                return false;
            }
        }

        function getAndEncode(url) {
            var TIMEOUT = 30000;
            if(domtoimage.impl.options.cacheBust) {
                // Cache bypass so we dont have CORS issues with cached images
                // Source: https://developer.mozilla.org/en/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest#Bypassing_the_cache
                url += ((/\?/).test(url) ? '&' : '?') + (new Date()).getTime();
            }
            if(!isValidUrl(url)) {
                url = location.origin + url;
            }

            return new Promise(function (resolve) {
                var request = new XMLHttpRequest();

                request.onreadystatechange = done;
                request.ontimeout = timeout;
                request.responseType = 'blob';
                request.timeout = TIMEOUT;
                request.open('GET', url, true);
                request.send();

                var placeholder;
                if(domtoimage.impl.options.imagePlaceholder) {
                    var split = domtoimage.impl.options.imagePlaceholder.split(/,/);
                    if(split && split[1]) {
                        placeholder = split[1];
                    }
                }

                function done() {
                    if (request.readyState !== 4) return;

                    if (request.status !== 200) {
                        if(placeholder) {
                            resolve(placeholder);
                        } else {
                            fail('cannot fetch resource: ' + url + ', status: ' + request.status);
                        }

                        return;
                    }

                    var encoder = new FileReader();
                    encoder.onloadend = function () {
                        var content = encoder.result.split(/,/)[1];
                        resolve(content);
                    };
                    encoder.readAsDataURL(request.response);
                }

                function timeout() {
                    if(placeholder) {
                        resolve(placeholder);
                    } else {
                        fail('timeout of ' + TIMEOUT + 'ms occured while fetching resource: ' + url);
                    }
                }

                function fail(message) {
                    console.error(message);
                    resolve('');
                }
            });
        }

        function dataAsUrl(content, type) {
            return 'data:' + type + ';base64,' + content;
        }

        function escape(string) {
            return string.replace(/([.*+?^${}()|\[\]\/\\])/g, '\\$1');
        }

        function delay(ms) {
            return function (arg) {
                return new Promise(function (resolve) {
                    setTimeout(function () {
                        resolve(arg);
                    }, ms);
                });
            };
        }

        function asArray(arrayLike) {
            var array = [];
            var length = arrayLike.length;
            for (var i = 0; i < length; i++) array.push(arrayLike[i]);
            return array;
        }

        function escapeXhtml(string) {
            return string.replace(/#/g, '%23').replace(/\n/g, '%0A');
        }

        function width(node) {
            var leftBorder = px(node, 'border-left-width');
            var rightBorder = px(node, 'border-right-width');
            return node.scrollWidth + leftBorder + rightBorder;
        }

        function height(node) {
            var topBorder = px(node, 'border-top-width');
            var bottomBorder = px(node, 'border-bottom-width');
            return node.scrollHeight + topBorder + bottomBorder;
        }

        function px(node, styleProperty) {
            var value = window.getComputedStyle(node).getPropertyValue(styleProperty);
            return parseFloat(value.replace('px', ''));
        }
    }

    function newInliner() {
        var URL_REGEX = /url\(['"]?([^'"]+?)['"]?\)/g;

        return {
            inlineAll: inlineAll,
            shouldProcess: shouldProcess,
            impl: {
                readUrls: readUrls,
                inline: inline
            }
        };

        function shouldProcess(string) {
            return string.search(URL_REGEX) !== -1;
        }

        function readUrls(string) {
            var result = [];
            var match;
            while ((match = URL_REGEX.exec(string)) !== null) {
                result.push(match[1]);
            }
            return result.filter(function (url) {
                return !util.isDataUrl(url);
            });
        }

        function inline(string, url, baseUrl, get) {
            return Promise.resolve(url)
                .then(function (url) {
                    return baseUrl ? util.resolveUrl(url, baseUrl) : url;
                })
                .then(get || util.getAndEncode)
                .then(function (data) {
                    return util.dataAsUrl(data, util.mimeType(url));
                })
                .then(function (dataUrl) {
                    return string.replace(urlAsRegex(url), '$1' + dataUrl + '$3');
                });

            function urlAsRegex(url) {
                return new RegExp('(url\\([\'"]?)(' + util.escape(url) + ')([\'"]?\\))', 'g');
            }
        }

        function inlineAll(string, baseUrl, get) {
            if (nothingToInline()) return Promise.resolve(string);

            return Promise.resolve(string)
                .then(readUrls)
                .then(function (urls) {
                    var done = Promise.resolve(string);
                    urls.forEach(function (url) {
                        done = done.then(function (string) {
                            return inline(string, url, baseUrl, get);
                        });
                    });
                    return done;
                });

            function nothingToInline() {
                return !shouldProcess(string);
            }
        }
    }

    function newFontFaces() {
        return {
            resolveAll: resolveAll,
            impl: {
                readAll: readAll
            }
        };

        function resolveAll() {
            return readAll(document)
                .then(function (webFonts) {
                    return Promise.all(
                        webFonts.map(function (webFont) {
                            return webFont.resolve();
                        })
                    );
                })
                .then(function (cssStrings) {
                    return cssStrings.join('\n');
                });
        }

        function readAll() {
            return Promise.resolve(util.asArray(document.styleSheets))
                .then(getCssRules)
                .then(selectWebFontRules)
                .then(function (rules) {
                    return rules.map(newWebFont);
                });

            function selectWebFontRules(cssRules) {
                return cssRules
                    .filter(function (rule) {
                        return rule.type === CSSRule.FONT_FACE_RULE;
                    })
                    .filter(function (rule) {
                        return inliner.shouldProcess(rule.style.getPropertyValue('src'));
                    });
            }

            function getCssRules(styleSheets) {
                var cssRules = [];
                styleSheets.forEach(function (sheet) {
                    try {
                        util.asArray(sheet.cssRules || []).forEach(cssRules.push.bind(cssRules));
                    } catch (e) {
                        console.log('Error while reading CSS rules from ' + sheet.href, e.toString());
                    }
                });
                return cssRules;
            }

            function newWebFont(webFontRule) {
                return {
                    resolve: function resolve() {
                        var baseUrl = (webFontRule.parentStyleSheet || {}).href;
                        return inliner.inlineAll(webFontRule.cssText, baseUrl);
                    },
                    src: function () {
                        return webFontRule.style.getPropertyValue('src');
                    }
                };
            }
        }
    }

    function newImages() {
        return {
            inlineAll: inlineAll,
            impl: {
                newImage: newImage
            }
        };

        function newImage(element) {
            return {
                inline: inline
            };

            function inline(get) {
                if (util.isDataUrl(element.src)) return Promise.resolve();

                return Promise.resolve(element.src)
                    .then(get || util.getAndEncode)
                    .then(function (data) {
                        return util.dataAsUrl(data, util.mimeType(element.src));
                    })
                    .then(function (dataUrl) {
                        return new Promise(function (resolve, reject) {
                            element.onload = resolve;
                            element.onerror = reject;
                            element.src = dataUrl;
                        });
                    });
            }
        }

        function inlineAll(node) {
            if (!(node instanceof ownerWindow.Element) && !(node instanceof Element)) return Promise.resolve(node);

            return inlineBackground(node)
                .then(function () {
                    if ((node instanceof ownerWindow.HTMLImageElement) || (node instanceof HTMLImageElement))
                        return newImage(node).inline();
                    else
                        return Promise.all(
                            util.asArray(node.childNodes).map(function (child) {
                                return inlineAll(child);
                            })
                        );
                });

            function inlineBackground(node) {
                var background = node.style.getPropertyValue('background');

                if (!background) return Promise.resolve(node);

                return inliner.inlineAll(background)
                    .then(function (inlined) {
                        node.style.setProperty(
                            'background',
                            inlined,
                            node.style.getPropertyPriority('background')
                        );
                    })
                    .then(function () {
                        return node;
                    });
            }
        }
    }
})(this);

/* END-OF-domToImage-CODE */

/*

 Copyright (c) 2012, Stephen Woods
 All rights reserved. (BSD License)

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

var  Ascii = (function(){
    DEFAULT_CHAR_MAP = "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\|()1{}[]?-_+~i!lI;:,\"^`'. ";
    CHAR_ASPECT_RATIO = 0.6;
    var AsciiArt = function(config) {
        this.config = config;
        this.config.maxPixels = this.config.maxPixels || 5000;
        this.config.scalingFactor = this.config.scalingFactor || 1.0;
        this.color = false;
        this.charMap = this.config.charMap || DEFAULT_CHAR_MAP;
    }

    AsciiArt.prototype.makeAscii = function(img){
        var map = this.charMap;
        var grays = map.length;
        var canvas = document.createElement('canvas'),
          ctx = canvas.getContext('2d'),
          w = img.width,
          h = img.height,
          thisRow,
          out = [];

        if (w * h > this.config.maxPixels) {
            var scaleDownFactor = Math.sqrt(1.0 * this.config.maxPixels / (w * h));
            w = w * scaleDownFactor;
            h = h * scaleDownFactor;
        }
        w = w * Math.sqrt(this.config.scalingFactor);
        h = h * Math.sqrt(this.config.scalingFactor);

        canvas.width = w;
        canvas.height = h;
        console.time('calc');
        ctx.drawImage(img, 0, 0, w, h);

        var data = ctx.getImageData(0, 0, w, h),
          i, avg, color, ch;

        for(var y = 0; y < data.height; y++){
            thisRow = [];
            for(var x = 0; x < data.width; x++){
                i = (y * 4) * data.width + x * 4;
                avg = (data.data[i] + data.data[i + 1] + data.data[i + 2]) / 3;
                color = [data.data[i], data.data[i + 1], data.data[i + 2]];

                ch = map[Math.round((avg/255) * grays)];
                if (!ch){
                    ch = map[map.length-1];
                }
                thisRow.push(ch);
            }
            out.push(thisRow);
        }
        ctx.putImageData(data, 0, 0);

        var outStr = '';

        var len = out.length;
        for (var i=0; i < len; i++) {
            outStr += out[i].join('');
            outStr += '\n';
        };
        console.timeEnd('calc');
        return outStr;
    }

    return AsciiArt;
}());

AsciiArtGraphGenerator = {
    GRAPH: "https://monitorportal.amazon.com/igraph?SchemaName1=OrdersCreated&Family1=us&Merchant1=ALL&ProductGroup1=ALL&Event1=OrderRate&Period1=FiveMinute&Stat1=sum&Label1=sum&HeightInPixels=900&WidthInPixels=800&GraphTitle=US%20Order%20Rate%20-%20Ascii%20Art&Timezone=UTC&ShowLegendErrors=false&HorizontalLineRight1={ASCII}&UpperValueRight={UPPER}&LowerValueRight=0&StartTime1=-P1D&EndTime1=-PT0H&FunctionExpression1=M1&FunctionLabel1=US%20OrderRate%20[max%3A%20{max}]&FunctionYAxisPreference1=left&FunctionExpression2=-1*M1&FunctionLabel2=AsciiArt&FunctionYAxisPreference2=right&ShowYAxisRight=false",
    MAX_URL_LEN: 27500,

    initialize: function() {
        unsafeWindow.AsciiArtGraphGenerator = this;
        this.displayAsciiArtEditor();
        this.trapImageClicks();
        this.autoDoAsciiArtIfOnImagePage();
    },

    displayAsciiArtEditor: function() {
        if (!onWiki || ($('.iGraphHelperAsciiEditor').length == 0)) {
            return;
        }

        var user = unsafeWindow.wgUserName.toLowerCase();
        var editorCode = $('.iGraphHelperAsciiEditor').text();
        editorCode = editorCode.replace(/{USER}/g, user);
        $('.iGraphHelperAsciiEditor').html(editorCode).show();
        $('.install').hide();
    },

    trapImageClicks: function(imgs) {
        var images = imgs || document.getElementsByTagName("img");
        for (var i = 0; i < images.length ; i++) {
            images[i].addEventListener("click",
              function (ev) {
                  if (ev.shiftKey && ev.altKey) {
                      ev.preventDefault();
                      window.open(ev.target.src + "#DOASCIIART", "_blank");
                  }
              },
              false);
        }
    },

    autoDoAsciiArtIfOnImagePage: function() {
        if (!/#DOASCIIART/.test(unsafeWindow.location.href)) {
            return;
        }

        window.focus();
        var instructions = document.createElement("div");
        instructions.innerHTML = '\
                <style> \
                    .label { text-align: right; } \
                    table { margin-top: 50px; color: black; font-family: Verdana, Arial, Sans-serif; font-size: 14px; background-color: white; } \
                    th { background-color: #DEF3F7; padding: 6px; border: 1px solid grey;} \
                </style>\
                <div><center>\
                   <table>\
                        <tr><th colspan="2">Select options for generating image in iGraph, then click button below</th></tr>\
                        <tr><td class="label">Character Map:</td><td><input id="charMap" type="text" size=40 value="$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\|()1{}[]?-_+~i!lI;:, "> dark chars to lighter, e.g. try: @80GCLft1i;:,.</td></tr>\
                        <tr><td class="label">Color:</td><td><input id="color" type="text" value="#FF0000"> #RRGGBB, or black, blue, green etc works too</td></tr>\
                        <tr><td class="label">Font Size:</td><td><input id="size" type="text" value="5"> reduce to fit image in smaller area on graph</td></tr>\
                        <tr><td class="label">Max Pixels:</td><td><input id="maxPixels" type="text" value="20000"> reduce if graph does not load - URL will get too long if there is too many "pixels"</td></tr>\
                    </table>\
                   <button class="iGraphButton" style="font-size: 32px; margin-top: 20px;">Click here to load this image into iGraph</button>\
                </center></div>';
        document.body.insertBefore(instructions, document.body.firstChild);
        document.getElementsByClassName("iGraphButton")[0].addEventListener("click", function() {
            var self = AsciiArtGraphGenerator;
            var config = {
                charMap:   document.getElementById("charMap").value,
                color:     document.getElementById("color").value,
                fontSize:  parseInt(document.getElementById("size").value),
                maxPixels: parseInt(document.getElementById("maxPixels").value),
                scalingFactor: 1.0
            };
            var image = document.getElementsByTagName("img")[0];
            var graph = self.getGraphFromAsciiArtString(new Ascii(config).makeAscii(image), config);
            if (graph.length > self.MAX_URL_LEN) {
                config.scalingFactor = 1.0 * self.MAX_URL_LEN / graph.length;
                GM_log("First graph URL too long (" + graph.length + " > " + self.MAX_URL_LEN + "), scaling down to " + config.scalingFactor);
                graph = self.getGraphFromAsciiArtString(new Ascii(config).makeAscii(image), config);    // Try again, scaled down
                GM_log("Second graph URL: " + graph.length);
            }
            window.open(graph);
        });
    },

    getGraphFromAsciiArtString: function(str, config) {
        var color = config.color != "#FF0000" ? " #color=" + config.color : "";
        var fontSize = config.fontSize != 10 ? " #size=" + config.fontSize : "";
        var lines = str.split('\n');
        var upper = lines.length;
        var longestLine = this.longestLine(lines);
        for (var i = 0; i < lines.length; i++) {
            lines[i] = this.encodeSingleLine(this.padLine(lines[i], longestLine)) + " #family=Monospaced #line=false" + color + fontSize + " @" + (upper - i);
        }
        var graph = AsciiArtGraphGenerator.GRAPH.replace("{ASCII}", this.urlEncode(lines.join(",")));
        graph = graph.replace("{UPPER}", "" + upper);
        return graph;
    },

    longestLine: function(lines) {
        var len = 0;
        for (var i = 0; i < lines.length; i++) {
            if (lines[i].length > len) {
                len = lines[i].length;
            }
        }
        return len;
    },

    encodeSingleLine: function(line) {
        return line.replace(/[%]/g, "%25").replace(/[(]/g, "%28").replace(/[)]/g, "%29").replace(/@/g, '%40').replace(/,/g, "%2C").replace(/#/g, '%23');
    },

    urlEncode: function(string) {
        return escape(string).replace(/[+]/g, "%2B").replace(/\//g, "%2F");
    },

    padLine: function(line, len) {
        return line + Array(len - line.length).join(" ") + ".";
    }

};

Carnaval = {
    COLORS: { OK: '0x669966', ALERT: 'red', ALARM: 'red', SUPPRESSED: 'red', AUTO_SUPPRESSED: 'red', AT_RISK: '0x669966' },
    ISENGARD_ENDPOINTS: {
        'aws': 'isengard.amazon.com',
        'aws-us-gov': 'isengard.pdt.aws-border.com',
        'aws-cn': 'isengard.bjs.aws-border.com',
        'aws-iso': 'isengard.dca.c2s-border.ic.gov',
        'aws-iso-b': 'isengard.lck.aws-border.com'
    },
    CONSOLE_ENDPOINT_SUFFIXES: {
        'aws': 'console.aws.amazon.com',
        'aws-us-gov': 'console.amazonaws-us-gov.com',
        'aws-cn': 'console.amazonaws.cn',
        'aws-iso': 'console.c2shome.ic.gov',
        'aws-iso-b': 'console.sc2shome.sgov.gov'
    },
    ALARM_VIEWER_ROLE_NAME: 'ReadOnly',

    initialize: function() {
        this.addControls();
    },

    addControls: function() {
        var controlsHtml = '' +
          '<button type="button" class="button iGraphVerticalLinesButton" title="Generate iGraph vertical line definition from history times (added by iGraphHelper)">'
          + 'iGraph Vertical Lines' +
          '</button> ' +
          '<span class="iGraphAddedToClipboard" style="display: none;">Vertical lines definition copied to clipboard</span>';
        $('#historyForm').append(controlsHtml);
        $('.iGraphVerticalLinesButton').on('click', this.createLines);

        this.addCloudWatchLinkIfRelevant();
    },

    addCloudWatchLinkIfRelevant: function() {
        var agentDetailsSourceRow = $("tr td.default:contains('source')").parent().filter("tr:has(td.default:contains('CloudWatch'))");
        var cloudWatchMonitorArn = agentDetailsSourceRow.parent().find("tr td.default:contains('name')").next().text();

        if (!cloudWatchMonitorArn) {
            return;
        }

        var arnMatch = /arn:([^:]+):cloudwatch:([^:]+):([^:]+):alarm:(.*)/.exec(cloudWatchMonitorArn);
        if (!arnMatch) {
            return;
        }

        var awsPartition = arnMatch[1];
        var awsRegion = arnMatch[2];
        var accountId = arnMatch[3];
        var alarmName = arnMatch[4];

        var addConduitLinkRow = function() {
            var baseCloudWatchConsoleDomain = (awsPartition == 'aws-cn') ? 'amazonaws.cn' : 'aws.amazon.com';

            var consoleCloudWatchAlarmUrl = `https://console.${baseCloudWatchConsoleDomain}/cloudwatch/home?region=${awsRegion}#alarmsV2:alarm/${alarmName}`;

            var accessFederatedUrl = `https://conduit.security.a2z.com/api/consoleUrl?awsAccountId=${accountId}&awsPartition=${awsPartition}&redirect=true&destination=${encodeURIComponent(consoleCloudWatchAlarmUrl)}`;

            agentDetailsSourceRow.after(`<tr><td class="default">Links</td><td class="default"><a target=_blank id='iGraphHelperConduitCloudWatchMonitorLink' href='${accessFederatedUrl}'>Open via Conduit</a></td></tr>`);
        };

        const addIsengardLinkRow = () => {
            const isengardEndpoint = Carnaval.ISENGARD_ENDPOINTS[awsPartition];
            const consoleEndpoint = `https://${awsRegion}.${Carnaval.CONSOLE_ENDPOINT_SUFFIXES[awsPartition]}`;
            const cwAlarmName = alarmName.replace(/ /g, '+');
            const alarmDeepLink = encodeURIComponent(`${consoleEndpoint}/cloudwatch/home?region=${awsRegion}#alarmsV2:alarm/${cwAlarmName}`);
            const isengardUrl = `https://${isengardEndpoint}/federate?account=${accountId}&role=${Carnaval.ALARM_VIEWER_ROLE_NAME}&destination=${alarmDeepLink}`;

            agentDetailsSourceRow.after(`<tr><td class="default">Links</td><td class="default"><a target=_blank id='iGraphHelperIsengardCloudWatchMonitorLink' href='${isengardUrl}' title='Isengard link will only work if the role ${Carnaval.ALARM_VIEWER_ROLE_NAME} is configured in account ${accountId} and you have access'>Open via Isengard (role: ${Carnaval.ALARM_VIEWER_ROLE_NAME})</a></td></tr>`);
        };

        var accountNameCacheKey = 'iGraphHelperConduitAcctById_' + accountId;

        var accountName = GM_getValue(accountNameCacheKey);

        if (accountName !== undefined && accountName !== null && accountName !== '') {
            if (accountName) {
                addConduitLinkRow();
            }
            return;
        }

        var conduitUrl = `https://conduit.security.a2z.com/api/accounts/partition/${awsPartition}/accountId/${accountId}`;

        GM_xmlhttpRequest({
            method: "GET",
            url: conduitUrl,
            onload: function (response) {
                try {
                    const jsonResponse = response.responseText;
                    const accountInfo = JSON.parse(jsonResponse);
                    const accountName = accountInfo.account.name;

                    GM_setValue(accountNameCacheKey, accountName);

                    if (!accountName) {
                        // Account not recognized by Conduit, assume it's Isengard account
                        addIsengardLinkRow();
                    }
                    else {
                        addConduitLinkRow();
                    }
                } catch (e) {
                    console.log(`Could not load Conduit AWS account by partition=${awsPartition} id=${accountId}`);
                    console.log(e);

                    // Fallback to Isengard
                    addIsengardLinkRow();
                }
            }
        });
    },

    /**
     * Driver function for creating the vertical lines pop-up.
     */
    createLines: function() {
        // Compute the output.
        var lines = [];
        $('#AuditLogTable tr:gt(0)').each(function() {
            if (! $(this).attr('id')) {
                var timestamp = $('td:eq(0)', this).text().trim();
                var className = $('td:eq(1) div', this).attr('class');
                var state = $('td:eq(1)', this).text().trim();

                var color = Carnaval.COLORS[className] || 'red';
                var hourMin = timestamp.replace(/.* /, '').replace(/:\d\d$/, '');
                var utcXml = timestamp.replace(/ /, 'T') + 'Z';
                lines.push(state + ' #color=' + color + ' (' + hourMin + ') @ ' + utcXml);
            }
        });
        var linesStr = lines.join(',');
        GM_setClipboard(linesStr);
        $('.iGraphAddedToClipboard').css('display', 'inline').fadeIn().delay(2000).fadeOut();
    }
};

// CloudWatch Insights uses JSURL for url generation
/**
 * Copyright (c) 2011 Bruno Jouhier <bruno.jouhier@sage.com>
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
!function(e){"use strict";var f={true:!0,false:!(e.stringify=function r(t){function e(r){return/[^\w-.]/.test(r)?r.replace(/[^\w-.]/g,function(r){return"$"===r?"!":(r=r.charCodeAt(0))<256?"*"+("00"+r.toString(16)).slice(-2):"**"+("0000"+r.toString(16)).slice(-4)}):r}var n;switch(typeof t){case"number":return isFinite(t)?"~"+t:"~null";case"boolean":return"~"+t;case"string":return"~'"+e(t);case"object":if(!t)return"~null";if(n=[],Array.isArray(t)){for(var a=0;a<t.length;a++)n[a]=r(t[a])||"~null";return"~("+(n.join("")||"~")+")"}for(var i in t)if(t.hasOwnProperty(i)){var s=r(t[i]);s&&n.push(e(i)+s)}return"~("+n.join("~")+")";default:return}}),null:null};e.parse=function(i){if(!i)return i;i=i.replace(/%(25)*27/g,"'");var s=0,u=i.length;function o(r){if(i.charAt(s)!==r)throw new Error("bad JSURL syntax: expected "+r+", got "+(i&&i.charAt(s)));s++}function c(){for(var r,t=s,e="";s<u&&"~"!==(r=i.charAt(s))&&")"!==r;)switch(r){case"*":t<s&&(e+=i.substring(t,s)),t="*"===i.charAt(s+1)?(e+=String.fromCharCode(parseInt(i.substring(s+2,s+6),16)),s+=6):(e+=String.fromCharCode(parseInt(i.substring(s+1,s+3),16)),s+=3);break;case"!":t<s&&(e+=i.substring(t,s)),e+="$",t=++s;break;default:s++}return e+i.substring(t,s)}return function r(){var t,e,n;switch(o("~"),e=i.charAt(s)){case"(":if(s++,"~"===i.charAt(s))if(t=[],")"===i.charAt(s+1))s++;else for(;t.push(r()),"~"===i.charAt(s););else if(t={},")"!==i.charAt(s))do{t[c()]=r()}while("~"===i.charAt(s)&&++s);o(")");break;case"'":s++,t=c();break;default:for(n=s++;s<u&&/[^)~]/.test(i.charAt(s));)s++;var a=i.substring(n,s);if(/[\d\-]/.test(e))t=parseFloat(a);else if(void 0===(t=f[a]))throw new Error("bad value keyword: "+a)}return t}()},e.tryParse=function(r,t){try{return e.parse(r)}catch(r){return t}}}("undefined"!=typeof exports?exports:window.JSURL=window.JSURL||{});

OCLLinksManager = {
    CLOUDWATCH_SERVICE_LOG_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAAEMUlEQVRIDbVVXWgcVRQ+d+bub3bT3W6TbGL+1zTZDaS0EUp8aDYP+iBUUNkFlYrQ0ELF0kXwBx8yDypEoS/SBxUpiCI0UMQHQRS61BDUtj4l/hRXacMmMTU/y+7M7mR+rufOZpKd7aYB0cOcufece+Y7555z7lyA/5nIfvipFIgAKevhtjPpGRMHtt93/3pdkiRBupakjMG+wXEnextxAALsxOODfT2jgefbY02LxHB/MX3224IdnSQlqSRldVtuNDZ0kEwmaTab1Z++MNpeWq3Mtsf8/Q8dDoBWMf5EkKuEsCvvTn73YyPAel1DB2jE9ezkqZE+zTQWwh0e2hUPmtQleESRQEXWdUJgDvnS9OnrV+pBa2WhVsC55fD48YeDT06OTEXjvg+ohzDMN7ejmmroHBytaCDsOWEyeNP+XpIsG1vcGR0OMDXYMQCBTrEXQSS3T3xMoMQPjHE7vkY5OI5bZVnDAYrIe2WBrzf2KpqCiWGva6pZYSa2JC+3kwRBwA6o6h/Yso4dODHAhbAuzPOeXU+qrVrv3AHzIAeAANXobCcNYsUzYaV1aqrx4WvoYMsRQ1XA1kQEHQxTA9PUwWQGlsbQpYnqOUjPpBpi8YLtUEtL1orR7/cTQrCI25vnbcTr7HMdAhd1A6aNiFQAXTBa3v78uRdluXDznfTMPNrhdxhJDTm83htOWpBffXZL03UNUQkIAgVKKazlVVi+rWL0gLvQxbJaZhVNHgDvxmXFWHmKYyK4A4/rHIqsVN3B9MevBtxuL61o60KhuASaUWFbFQ3y+UUoyEtQUu9BsbxMikqeyUoBopHBZg6GZFSH3bdVIBTtTmCnX3/ijbbWlvcSQ8OeruigWzQPCExQiYyg62vLrLWnCZiwRbw0DO2RONGLTWTlNz0xPjF2LjHWGvxpNnd9G97CrK0BV7D8Uq5nU853Hwx0Qm93TEkMxZk/eNSlKIor15ojkYNeOBSKMr8noCmyqv8wN0vdnXdCEAmG7txa7+fg/E9rtTfO7ci53nKQyoz5ShuFZ0vK6isGrCXCgSHoaj+sxvpiWrSjjbq8BDZLa/qmuuj6PfeLZ/7GzzBx8tFfO/rCr708fvVLDoRkYdkTS7P92lm4eDHjm7v9/Qul8sZ5zSwkyuW/oSUSV2NHD4DgLXqo6AFVFm9+88kfq/NzKyH8/mvkj5CXkXlt+cXk2AGXgf+0stkkcrW/M5mU727l7im1XDnvDprDA8dCeADpvGmI76cn+y8/Qj7kP6Ujza3iWaVodutl9gzKKvKOE5zfT9zRmTOjrt2VXm/6wrGXMpfGz+Hp9W7rxZGRtqZdG5jDed+2XFvfGpO6KXfEL6A6tSV2xpsHcPIp8lvIM8jTyDbxdN+fInu1fuSOFhZShN//nPDyt3v+CIpx5L+QryFz2qllVfxv31bkNuQ/6QmDzBSaM80AAAAASUVORK5CYII=',
    CLOUDWATCH_APPLICATION_LOG_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAAEP0lEQVRIDbVVXWhcRRQ+M3f27k/uJtmmm2Zr/re2+cFKm4faB8u2oA9CCxZ2IYoitDaIoi2CtPiQ+1CFqFQQigSVPoVKYsUi9UnsYkoppRVLawqFEEmyCeZ/u393c3/GM3f3prtxk6DgsLNnzpkz33dmzpk7AP9zI1vhR6MgAUTtn/AdiY1YKPhW6/7zvKqqVL0eYZzDlsEJko2dBAABfujFPW0tPcqroXDVFDHlHwb6fk460alqhKlq3HD0SrIiQSQSYfF43Dh+uieUntNuhMK+9qd2K6Br5gSCfE8IH/7k5OjtSoDrbRUJ0EnY+dHX9rbplvlHYKebNXX6LeaibkkioGUMgxC4if3iwIlfh9eDluq0VMGxTXjgwC7/sZN7+xs6vYPMTTiet/Bjet40BDh6MSXgPmRx+NBZr6q2j6OuyTICPBqsGAClUWpFEFX2Si9QRnzAufATc0yAo1zNZXQUkMK+0SmI+cqskkUtDHtJz1sat7AkRbrLG6UUK6Bg37Rky3ZQjgEuhHXhOW9Y9aRQquvJy2A2IwAEKETnkFSIFe+Efaz9/ZUvX0WC1bIYCgqWJiIYYFo6WJYBFjcxNaahHi7cg9hItCKWSNhaCwbjdow+n48Qgkksbl6Ukciz17UdXEwGPDYiMQoGNYMfXX7ljUwmeefj2MgD9MN1GElJK2Od747YkD8N3dUNQ0dUApQyYIzBYiIPs4/yGD3gLgwpl89xTc8+Dd6VS1lz7mWBSWKkDE/YygxxtbCDgW8+UGTZwzR9iSZTM6CbGl/VdEgkpiCZmYF0fh5SuVmSyk7zx6kFCNXt8gswGAHTliV/doJQdyqBnzj70rkd9cFPuzq63U0Ne2TJqqGc5kkGQZcWZ3l9SxWGpRNZqoXG7d1EW/KRqftad9/Z4289d6zB98uVsdEino1ZmgNh4ImZ8ZaVTKJ5m9IIrc3hbFdHJ/f597my2axrvH6c1G1zQzAQ4m5WpQPlxsS93+WvP7taq7T/Vev1e5pF8JiyQsSI6EQu7DZB9MxBb3o52ZvOzr1vwmJXQOmAptDufLgtrDfs3MFcHgIr6UVjMTspzy9PyL/deGAFapq1mT+Xrt2+9kUvITEsL8TCe+iACuk0m0QoFy6c8d58dOv1dG75Xd1KduVyCxCs68yH99UA9abcFGSYn9RXR7+bHnr2SMP5K5/f78dlb2IXVS5yKx4m+/si5ForfLQi0uDgt6tjd6bvHj1y+FKewqRMA+0uHw8FmzyMWsrD6uravqtfjk2P31vY//DWHHcrtLe2no3mHlsJBBNHbxOsAa8fCKJTp3pcT+ytntjp/W+/d/H5d65z1cndj1V19Jy/nh1Ev8vYzxf9neJ5snyjkSASD9D6+faewDOeajpUYhckX5XoZVegxF55KIii0agUHY5KxffYjZ7eoreIWORPwf7vgIsAm4nSSvyH399InITuoxR4MwAAAABJRU5ErkJggg==',

    // The hash args property prevents an unnecessary redirect (essential to detect signed-out scenarios)
    AWS_CONSOLE_URL: "https://console.aws.amazon.com/console/home?region=us-east-1&state=hashArgs%23",
    AWS_CONSOLE_BASE_URL: "https://console.aws.amazon.com/",
    AWS_ACCOUNT_SIGN_OUT_URL: "https://signin.aws.amazon.com/oauth?Action=logout&redirect_uri=aws.amazon.com",
    CLOUDWATCH_BASE_URL: "https://console.aws.amazon.com/cloudwatch/home?",
    CONDUIT_BASE_URL: "https://access.amazon.com/aws/accounts/fetchConsoleUrl?",
    ISENGARD_BASE_URL: "https://isengard.amazon.com/federate?",
    APPLICATION_LOG_KEY: "application",
    SERVICE_LOG_KEY: "service",

    setOCLIconsVisibility: function(graphArgs) {
        var graphParams = this.getDecodedGraphParams(graphArgs);
        if (OCLSettingsManager.isOCLConfigPresent(graphParams.ServiceName1, graphParams.Marketplace1, graphParams.DataSet1)) {
            $('.OCLIcons').show();
        } else {
            $('.OCLIcons').hide();
        }
    },

    getCookie: function(name) {
        var value = "; " + document.cookie;
        var parts = value.split("; " + name + "=");
        if (parts.length === 2) {
            return parts.pop().split(";").shift();
        }
    },

    getAwsUserCookie: function() {
        try {
            return JSON.parse(decodeURIComponent(this.getCookie("aws-userInfo")));
        } catch (error) {
            return undefined;
        }
    },

    getDecodedGraphParams: function(graphParamString) {
        var params = {};
        if (graphParamString) {
            graphParamString.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m, key, value) {
                params[key] = decodeURIComponent(value);
            });
        }
        return params;
    },

    generateConduitDeepLinkedUrl: function(accountName, url) {
        return this.CONDUIT_BASE_URL + "account_name=" + accountName + "&destination=" + encodeURIComponent(url);
    },

    generateIsengardDeepLinkedUrl: function(accountId, role, url) {
        // Isengard auto-appends aws-console url, hence removing it.
        var destinationUrl = url.replace(this.AWS_CONSOLE_BASE_URL, "")
        return this.ISENGARD_BASE_URL + "account=" + accountId + "&role=" + encodeURIComponent(role) + "&destination=" + encodeURIComponent(destinationUrl);
    },

    generateDeepLinkedCloudWatchUrl: function(accountType, accountName, accountId, role, cloudWatchUrl) {
        if (accountType === "Conduit") {
            return this.generateConduitDeepLinkedUrl(accountName, cloudWatchUrl);
        }
        return this.generateIsengardDeepLinkedUrl(accountId, role, cloudWatchUrl);
    },

    // How SSO works in AWS - https://tiny.amazon.com/10eu9dahs/wamazindeAWSDeveConsProjSess
    loggedIntoOtherAccount: function(expectedAwsAccountId) {
        var awsUserInfo = this.getAwsUserCookie();
        return awsUserInfo && awsUserInfo.alias !== expectedAwsAccountId;
    },

    logOutAndGoToCloudWatch: function(cloudWatchUrl) {
        GMUtils.gmXmlHttpRequest({
            method: "GET",
            url: this.AWS_ACCOUNT_SIGN_OUT_URL,
            onload: function(response) {
                window.open(cloudWatchUrl)
            }
        });
    },

    logInAndGoToCloudWatch: function(deepLinkedCloudWatchUrl, directCloudWatchUrl) {
        var awsUserInfo = this.getAwsUserCookie();
        if (awsUserInfo && awsUserInfo.keybase) {
            GMUtils.gmXmlHttpRequest({
                method: "GET",
                url: this.AWS_CONSOLE_URL,
                onload: function(response) {
                    // AWS Console returns 200 even if there is a redirect to signin.aws.amazon.com
                    if (response.status === 200 && (response.finalUrl == null || response.finalUrl.indexOf("signin") === -1)) {
                        window.open(directCloudWatchUrl)
                    } else {
                        window.open(deepLinkedCloudWatchUrl)
                    }
                },
                onerror: function (response) {
                    window.open(deepLinkedCloudWatchUrl);
                },
            });
        } else {
            window.open(deepLinkedCloudWatchUrl);
        }
    },

    generateDirectCloudWatchEventViewerUrl: function(region, logGroupName, logType, startTime, endTime, metric) {
        var cloudWatchUrl = this.CLOUDWATCH_BASE_URL + "region=" + region + "#" +
          "logEventViewer:group=" + logGroupName[logType] + ";" +
          "start=" + startTime + ";" +
          "end=" + endTime + ";";
        if (logType === this.SERVICE_LOG_KEY) {
            cloudWatchUrl = cloudWatchUrl + "filter=" + "%22" + metric + "%22"
        }
        return cloudWatchUrl;
    },

    generateDirectCloudWatchInsightsUrl: function(region, logGroupName, logType, startTime, endTime, methodName, metric) {
        var params = {
            end: endTime,
            source: logGroupName[logType],
            start: startTime,
            timeType: "ABSOLUTE",
            tz: "UTC"
        };
        // Since ALL is PMET way of aggregating the data and is not present in service logs, we can't add a filter on top of it.
        if (logType === this.SERVICE_LOG_KEY && methodName !== "ALL") {
            params.editorString = "fields @timestamp, RequestId, @message | filter Operation='" + methodName + "' and " + metric + " > 0 | sort @timestamp";
        } else if (logType === this.SERVICE_LOG_KEY) {
            params.editorString = "fields @timestamp, RequestId, @message | filter " + metric + " > 0 | sort @timestamp";
        } else {
            params.editorString = "fields @timestamp, @message | sort @timestamp";
        }
        return this.CLOUDWATCH_BASE_URL + "region=" + region + "#" + "logs-insights:queryDetail=" + JSURL.stringify(params);
    },

    generateDirectCloudWatchUrl: function(region, logGroupName, logType, startTime, endTime, methodName, metric) {
        if ((logType === this.APPLICATION_LOG_KEY && OCLSettingsManager.isTraditionalViewEnabledForApplicationLogs()) ||
          (logType === this.SERVICE_LOG_KEY && OCLSettingsManager.isTraditionalViewEnabledForServiceLogs())) {
            return this.generateDirectCloudWatchEventViewerUrl(region, logGroupName, logType, startTime, endTime, metric);
        }
        return this.generateDirectCloudWatchInsightsUrl(region, logGroupName, logType, startTime, endTime, methodName, metric);
    },

    /*
     * Takes care of below scenarios if deep linking is enabled:
     * 1. If the user is logged into correct aws account then directly go to cloudwatch.
     * 2. If the user is logged into some other aws account then log out and login.
     * 3. If the user's AWS session has expired then relogin.
     * 4. If the user never logged into AWS console before then login.
     */
    goToCloudWatchConsole: function(logType, graphArgs) {
        var graphParams = this.getDecodedGraphParams(WikiSnapshot.replaceRelativeWithFixedTime(graphArgs));
        var serviceName = graphParams.ServiceName1;
        var marketplace = graphParams.Marketplace1;
        var dataSet = graphParams.DataSet1;
        var methodName = graphParams.MethodName1;
        var startTime = graphParams.StartTime1;
        var endTime = graphParams.EndTime1;
        var metric = graphParams.Metric1;

        var cloudwatchConsoleParams = OCLSettingsManager.getOCLConfig(serviceName, marketplace, dataSet)
        var directCloudWatchUrl = this.generateDirectCloudWatchUrl(cloudwatchConsoleParams.region, cloudwatchConsoleParams.logGroupName, logType, startTime, endTime, methodName, metric);
        var deepLinkedCloudWatchUrl = this.generateDeepLinkedCloudWatchUrl(cloudwatchConsoleParams.accountType,
          cloudwatchConsoleParams.accountName,
          cloudwatchConsoleParams.accountId,
          cloudwatchConsoleParams.role,
          directCloudWatchUrl)

        if (!OCLSettingsManager.isDeepLinkEnabled()) {
            window.open(directCloudWatchUrl);
        } else if (this.loggedIntoOtherAccount(cloudwatchConsoleParams.accountId)) {
            this.logOutAndGoToCloudWatch(deepLinkedCloudWatchUrl);
        } else {
            this.logInAndGoToCloudWatch(deepLinkedCloudWatchUrl, directCloudWatchUrl);
        }
        return false;
    }

}

OCLSettingsManager = {
    REMOTE_CONFIG_ENDPOINT: 'https://ttbots.aka.amazon.com/getOCLConfigurations',

    STYLES : '\
        .OCLConfigPopup {\
            display: none; \
            position: fixed; \
            z-index: 1600; \
            padding-top: 30px; \
            width: 100%; \
            height: 100%; \
            overflow: auto; \
            background-color: rgb(0,0,0); \
            background-color: rgba(0,0,0,0.4); \
            font-family: "Amazon Ember", Helvetica, Arial, sans-serif;\
            text-align: left !important;\
         }\
        .OCLConfigPopupContent {\
            background-color: #f2f3f3;\
            margin: auto;\
            padding: 20px;\
            border: 1px solid #888;\
            width: 80%;\
        }\
        .OCLConfigPopupCloseButton {\
            color: #aaaaaa;\
            float: right;\
            font-size: 28px;\
            font-weight: bold;\
        }\
        .OCLConfigPopupCloseButton:hover,\
        .OCLConfigPopupCloseButton:focus {\
            color: #000;\
            text-decoration: none;\
            cursor: pointer;\
        }\
        .OCLConfigInput {\
            width: 100%; /* Specifying in percentage to account for variable window sizes*/\
            height: 15em; /* Specifying in em as by default the height is too low */\
            display: none;\
        }\
        .OCLConfigPopupHeader {\
            position: relative;\
            margin-bottom: 1rem;\
            border: 1px solid transparent;\
            border-radius: .25rem;\
            display: inline-block;\
            font-size: 24px;\
        }\
        .OCLConfigPopupErrorMessage {\
            color: #d13212;\
        }\
        .OCLRemoteConfigInput {\
            background-color: #eaeded;\
        }\
        .OCLFormButton {\
            background-color: #fff;\
            border-radius: 2px;\
            border: 1px solid;\
            padding: .4rem 2rem;\
            font-weight: 700;\
            letter-spacing: .25px;\
            display: inline-block;\
            cursor: pointer;\
        }\
        .OCLUserConfigToggleButton {\
            margin-top: 0.5rem;\
        }\
        .OCLFormButton:hover {\
            background-color: #f2f3f3;\
        }\
        .OCLSubmitFormButton {\
            background-color: #ec7211;\
            color: #fff;\
            font-size: small;\
        }\
        .OCLSubmitFormButton:hover {\
            background-color: #eb5f07;\
        }\
    ',

    HTML : '\
        <div id="OCLConfigPopup" class="OCLConfigPopup">\
            <div class="OCLConfigPopupContent">\
                <span id="OCLConfigPopupCloseButton" class="OCLConfigPopupCloseButton">&times;</span>\
                <h2 class="OCLConfigPopupHeader"> Go to cloudwatch logs from iGraph via single click. See video and instructions <a target="_blank" href="https://w.amazon.com/bin/view/OneClickLogs/">here</a></h2>\
                <form id="OCLConfigForm">\
                    <input type="checkbox" value="true" name="OCLAllowRemoteSyncOption" checked> Sync configurations from remote periodically <br>\
                    <input type="checkbox" value="true" name="OCLDeepLinksOption" checked> Automatically login into relevant AWS account (experimental) <br>\
                    <input type="checkbox" value="true" name="OCLApplicationLogTraditionalViewOption" checked> Use traditional CloudWatch Logs UI for Application Logs<br>\
                    <input type="checkbox" value="true" name="OCLServiceLogTraditionalViewOption"> Use traditional CloudWatch Logs UI for Service Logs<br><br>\
                    <button id="OCLToggleRemoteConfigButton" class="OCLFormButton">Remote configurations</button>\
                    <h3 id="OCLRemoteConfigSyncFailureMessage" class="OCLConfigPopupErrorMessage"> Failed refreshing config from remote, please ensure you are connected to Amazon network and signed into Midway. </h3>\
                    <textarea id="OCLRemoteConfigInput" class="OCLConfigInput OCLRemoteConfigInput" disabled></textarea><br>\
                    <button id="OCLToggleUserConfigButton" class="OCLFormButton OCLUserConfigToggleButton">Manually added configurations</button>\
                    <textarea id="OCLUserConfigInput" class="OCLConfigInput"></textarea><br>\
                    <h3 id="OCLUserConfigValidationFailureMessage" class="OCLConfigPopupErrorMessage"> Syntax validation failed, please check instructions and resubmit </h3><br>\
                    <button id="OCLFormSubmitButton" class="OCLFormButton OCLSubmitFormButton">Submit</button>\
                </form>\
            </div>\
        </div>\
    ',

    // Dummy OCL config
    DEFAULT_CLOUDWATCH_USER_CONFIG : {
        "ServiceName#Marketplace#DataSet": {
            accountId: "AWSAccountId",
            region: "AWSRegion",
            accountType: "Conduit",
            accountName: "AWSAccountName/ApplicableForConduitAWSAccounts",
            role: "AWSRole/ApplicableForIsengardAWSAccounts",
            logGroupName: {
                application : "CloudWatchLogGroupForApplicationLogs",
                service : "CloudWatchLogGroupForServiceLogs"
            }
        },
        "ServiceName2#Marketplace2#DataSet2": {
            accountId: "AWSAccountId2",
            region: "AWSRegion2",
            accountType: "Isengard",
            accountName: "AWSAccountName2/ApplicableForConduitAWSAccounts",
            role: "AWSRole2/ApplicableForIsengardAWSAccounts",
            logGroupName: {
                application : "CloudWatchLogGroupForApplicationLogs",
                service : "CloudWatchLogGroupForServiceLogs"
            }
        }
    },

    userConfig: undefined,
    remoteConfig: undefined,
    mergedConfig: undefined,

    initialize: function() {
        if (this.initialized) {
            return;
        }
        GM_addStyle(this.STYLES)
        var popupContainer = document.createElement("div");
        popupContainer.innerHTML = this.HTML
        document.body.insertBefore(popupContainer, document.body.firstChild);

        // Hide the popup when the user clicks outside of it.
        jQuery(window)[0].addEventListener("click", function(event) {
            if (event.target.id === "OCLConfigPopup") {
                jQuery("#OCLConfigPopup").hide();
            }
        })

        jQuery("#OCLConfigPopupCloseButton")[0].addEventListener("click", function() { jQuery("#OCLConfigPopup").hide(); }, false);
        jQuery("#OCLToggleRemoteConfigButton")[0].addEventListener("click", function(e) { e.preventDefault(); jQuery("#OCLRemoteConfigInput").toggle(); }, false);
        jQuery("#OCLToggleUserConfigButton")[0].addEventListener("click", function(e) { e.preventDefault(); jQuery("#OCLUserConfigInput").toggle(); }, false);
        jQuery("#OCLConfigForm")[0].addEventListener("submit", this.saveOCLConfig.bind(this), false);
        this.setOCLConfigInitialValue();
        this.initialized = true;
    },

    showSettingsPopup: function() {
        jQuery("#OCLConfigPopup").show();
        jQuery("#OCLUserConfigValidationFailureMessage").hide();
        jQuery("#OCLRemoteConfigSyncFailureMessage").hide();
    },

    decodeJSON: function(text) {
        try{
            return JSON.parse(text);
        } catch (error){
            return undefined;
        }
    },

    isValidConfig: function(userOCLConfig) {
        var configIsValid = true;
        if (userOCLConfig) {
            for(key in userOCLConfig) {
                var value = userOCLConfig[key];
                // All keys should include certain elements and # in name.
                configIsValid = configIsValid && key.indexOf("#") !== -1;
                configIsValid = configIsValid && value.region;
                configIsValid = configIsValid && value.accountId;
                configIsValid = configIsValid && value.logGroupName;
                configIsValid = configIsValid && (value.accountType === "Conduit" || value.accountType === "Isengard");

                if (value.accountType === "Conduit") {
                    configIsValid = configIsValid && value.accountName;
                } else {
                    configIsValid = configIsValid && value.role;
                }
            }
            return configIsValid;
        }
        return false;
    },

    saveOCLConfig: function(event) {
        event.preventDefault();
        var configValue = this.decodeJSON(jQuery("#OCLUserConfigInput")[0].value);
        var remoteSyncOption = document.querySelector('input[name="OCLAllowRemoteSyncOption"]').checked;
        var deepLinkOption = document.querySelector('input[name="OCLDeepLinksOption"]').checked;
        var applicationLogTraditionalViewOption = document.querySelector('input[name="OCLApplicationLogTraditionalViewOption"]').checked;
        var serviceLogTraditionalViewOption = document.querySelector('input[name="OCLServiceLogTraditionalViewOption"]').checked;

        if (this.isValidConfig(configValue)) {
            var OCLConfig = {
                cwConfig : configValue,
                options : {
                    allowRemoteSync: remoteSyncOption,
                    useDeepLinks : deepLinkOption,
                    useTraditionalViewForApplicationsLogs : applicationLogTraditionalViewOption,
                    useTraditionalViewForServiceLogs : serviceLogTraditionalViewOption
                }
            }
            GM_setValue("OCLConfig", JSON.stringify(OCLConfig));
            jQuery("#OCLConfigPopup").hide();
            location.reload();
        } else {
            jQuery("#OCLUserConfigValidationFailureMessage").show();
        }
        return false;
    },

    handleRemoteConfigSyncFailure: function() {
        // Update lastUpdated flag even in failures so that we avoid spamming remote endpoint
        this.updateRemoteConfigWithLastUpdatedTimestamp();
        jQuery("#OCLRemoteConfigSyncFailureMessage").show();
    },

    updateRemoteConfigWithLastUpdatedTimestamp: function() {
        GM_setValue("RemoteOCLConfig", JSON.stringify(Object.assign(this.remoteConfig, {lastUpdated: Date.now()})));
        // Refresh the remote config portion on OCL Settings menu.
        this.setOCLPopupRemoteConfigValue();
    },

    refreshRemoteOCLConfig: function(isUserViewingOCLSettings) {
        var lastUpdatedTime = this.remoteConfig.lastUpdated || 0;
        // Refresh once a day or when user opens up OCLSettings menu.
        if ((this.isRemoteSyncEnabled() && Date.now() - lastUpdatedTime > (24 * 60 * 60 * 1000)) || isUserViewingOCLSettings) {
            GMUtils.gmXmlHttpRequest({
                method: "GET",
                url: this.REMOTE_CONFIG_ENDPOINT,
                headers: {
                    'Referer': window.location.href
                },
                onload: function (response) {
                    var remoteConfig = this.decodeJSON(response.responseText);
                    // Only change remoteConfig if server response is valid JSON and valid OCL config
                    if (remoteConfig && this.isValidConfig(remoteConfig.cwConfig)) {
                        this.remoteConfig = remoteConfig
                        this.updateRemoteConfigWithLastUpdatedTimestamp();
                    } else {
                        this.handleRemoteConfigSyncFailure();
                    }
                }.bind(this),
                onabort: this.handleRemoteConfigSyncFailure.bind(this),
                onerror: this.handleRemoteConfigSyncFailure.bind(this),
                ontimeout: this.handleRemoteConfigSyncFailure.bind(this)
            });
        }
    },

    // Load remote and local config and then merge to use as final config.
    setOCLConfigInitialValue: function() {
        this.userConfig = this.decodeJSON(GM_getValue("OCLConfig")) || {};
        this.remoteConfig = this.decodeJSON(GM_getValue("RemoteOCLConfig")) || {};
        this.mergedConfig = {
            cwConfig: Object.assign({}, this.remoteConfig.cwConfig, this.userConfig.cwConfig),
            options: this.userConfig.options
        }
        this.setOCLConfigPopupValues();
        this.refreshRemoteOCLConfig();
    },

    setOCLConfigPopupValues: function() {
        if (this.userConfig.cwConfig && this.userConfig.options) {
            var options = this.userConfig.options;
            var userConfigButtonTextSuffix = " (" + Object.keys(this.userConfig.cwConfig).length + " services)";
            // Pretty print the value
            jQuery("#OCLUserConfigInput").val(JSON.stringify(this.userConfig.cwConfig, null, 4));
            jQuery("#OCLToggleUserConfigButton").html(jQuery("#OCLToggleUserConfigButton").html() + userConfigButtonTextSuffix);
            jQuery('input[name="OCLAllowRemoteSyncOption"]').prop('checked', options.allowRemoteSync);
            jQuery('input[name="OCLDeepLinksOption"]').prop('checked', options.useDeepLinks);
            jQuery('input[name="OCLApplicationLogTraditionalViewOption"]').prop('checked', options.useTraditionalViewForApplicationsLogs);
            jQuery('input[name="OCLServiceLogTraditionalViewOption"]').prop('checked', options.useTraditionalViewForServiceLogs);
        } else {
            jQuery("#OCLUserConfigInput").val(JSON.stringify(this.DEFAULT_CLOUDWATCH_USER_CONFIG, null, 4));
        }
        this.setOCLPopupRemoteConfigValue();
    },

    setOCLPopupRemoteConfigValue: function() {
        if (this.remoteConfig.cwConfig) {
            var remoteConfigButtonTextSuffix = " (" + Object.keys(this.remoteConfig.cwConfig).length + " services)";
            jQuery("#OCLToggleRemoteConfigButton").html("Remote configurations" + remoteConfigButtonTextSuffix);
            jQuery("#OCLRemoteConfigInput").val(JSON.stringify(this.remoteConfig, null, 4));
        }
    },

    isOCLConfigPresent: function(service, marketplace, dataset) {
        return this.mergedConfig.cwConfig && this.mergedConfig.cwConfig[service + "#" + marketplace + "#" + dataset];
    },

    getOCLConfig: function(service, marketplace, dataset) {
        return this.isOCLConfigPresent(service, marketplace, dataset) ? this.mergedConfig.cwConfig[service + "#" + marketplace + "#" + dataset] : {};
    },

    isRemoteSyncEnabled: function() {
        return this.mergedConfig.options && this.mergedConfig.options.allowRemoteSync;
    },

    isDeepLinkEnabled: function() {
        return this.mergedConfig.options && this.mergedConfig.options.useDeepLinks;
    },

    isTraditionalViewEnabledForApplicationLogs: function() {
        return this.mergedConfig.options && this.mergedConfig.options.useTraditionalViewForApplicationsLogs;
    },

    isTraditionalViewEnabledForServiceLogs: function() {
        return this.mergedConfig.options && this.mergedConfig.options.useTraditionalViewForServiceLogs;
    }

};

function fixCutOffIconsAndLinksOnEmbeddedGraphPopins() {
    // If we're running on the grapher.cgi page, inside an iFrame, then add padding
    // to the top of the documentso that the toolbar for the popin window won't cover
    // the iGraph helper icons.
    // This is to fix the case when grapher.cgi is embedded on the show servcies page
    // E.G. on this page: http://tiny/16nvko8ie/lbdaamazcgibshow )
    if (/grapher.cgi/.test(window.location.pathname) && window.parent !== window) {
        $(document.body).css({paddingTop: '25px'});
    }

    // Poll and look for graphs from grapher.cgi that are inside popin windows,
    // make the iFrame fit the jQuery dialog and increase the side of the dialog
    // a little. This prevents the links at the bottom of grapher.cgi from being
    // cut off/hidden.
    // I don't know what specific pages embed graphs like this. I know it's on
    // the showServices tool, but I don't know where else it happens. I need to
    // poll because these dialogs are added dynamically after page load. To
    // avoid too large a performance hit, I'll poll rapidly for the first five
    // seconds and then only poll every 5 seconds after that point.
    var fixGrapherPopinSizing = function(){
        $('iframe[src*="grapher.cgi"]:not(.resizeFixed)').addClass('resizeFixed').css({
            width:'100%',
            height:'100%'
        }).parents('div.ui-dialog-content').css({
            height:'500px'
        });
    }
    for(var time=0; time < 5000; time += 500) {
        window.setTimeout(fixGrapherPopinSizing,time);
    }
    window.setInterval(fixGrapherPopinSizing,5000);
}

function injectMainIGraphHelper() {
    if(!allowsInlineScripts()) {
        return;
    }

    codeWrapper(localGMCode);

    setTimeout(() => {
        const IGHVersion = Number(GM_info && GM_info.script ? GM_info.script.version : -1) || -1;
        console.log('IGH Version', IGHVersion);
        // Not present if blocked by Content-Security-Policy
        if(unsafeWindow.iGraphHelper) {
            unsafeWindow.iGraphHelper.IGH.version = IGHVersion;
        }
    }, 0);
}

function initWikiSnapshot() {
    if (! this.WikiSnapshot) {
        localGMCode(window, unsafeWindow);
        WikiSnapshot.initialize();
    }
}

// Checks whether Content-Security-Policy in <meta> tag allows injecting inlines scripts.
// Covers AWS Console use cases, but best effort only. By design there is no way to test
// it without causing an actual violation.
function allowsInlineScripts() {
    var csp = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
    if(!csp || !csp.content) {
        return true;
    }
    var getDirective = function(directiveName) {
        return csp.content.split(";").find(d => d.includes(directiveName + " "));
    }
    var scriptSrcElem = getDirective("script-src-elem");
    if(scriptSrcElem) {
        return scriptSrcElem.includes("'unsafe-inline'");
    }
    var scriptSrc = getDirective("script-src");
    if(scriptSrc) {
        return scriptSrc.includes("'unsafe-inline'");
    }
    var defaultSrc = getDirective("default-src");
    if(defaultSrc) {
        return defaultSrc.includes("'unsafe-inline'");
    }
    return true;
}

// Refresh Alpine link visibility on CloudWatch Console, needed in restricted regions
function refreshAlpineLinkVisibility(win) {
    if (win.CloudWatchBridge && win.CloudWatchBridge.refreshAlpineLinkVisibility) {
        win.CloudWatchBridge.refreshAlpineLinkVisibility();
    }
}

function exposeSnapshotFunction(unsafeWin) {
    if (typeof createObjectIn !== 'undefined') {
        function snapshot(selector) {
            initWikiSnapshot();
            WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, null, 'Snapshot jQuery selector: ' + selector, false, selector);
        };
        const iGraphHelperSnapshot = createObjectIn(unsafeWin, {defineAs: "iGraphHelperSnapshot"});
        exportFunction(snapshot, iGraphHelperSnapshot, {defineAs: "snapshot" });
    }
}

// Check if on Wiki or Apollo
var onWiki = (null != document.body.className.match("mediawiki")) || (/http[s]*:..apollo.([a-zA-Z]{3}.)?(amazon.com|[a-zA-Z0-9]{3}-border.[.a-zA-Z0-9]+)/.test(window.location.href));
var isDashboardInternal = (/dashboardInternal/.test(window.location.pathname));
var onCloudWatchUI = (/cloudwatch\/home/.test(window.location.pathname));
var onObserve = (/(observe|observe-gamma|cw-dashboards|cw-dashboards-gamma).aka.amazon/.test(window.location.hostname));
var onPremonition = (/(premonition-ui|pui|ui.premonition|awsdashboard)/.test(window.location.hostname));

(function() {
    try {
        GM_registerMenuCommand("iGraph Helper: snapshot settings", () => {
            const inputString = prompt(
                'To use a fixed size for snapshots please enter your desired size in the format "width,height".\n' +
                'For this value to take effect, you must uncheck "Obey Fit".\nEnter "0,0" to clear.'
            )
            console.log("Setting snapshot size from input", inputString)
            WikiSnapshot.setSnapshotSizeSettingFromString(inputString)
        });

        GM_registerMenuCommand("iGraph Helper: snapshot DOM element", () => {
            initWikiSnapshot();
            WikiSnapshot.snapshotDomElement();
        });

        GM_registerMenuCommand("iGraph Helper: snapshot clipboard image", () => {
            initWikiSnapshot();
            WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, null, 'Click into box above and paste image from clipboard, or drop image files in (Chrome, FF)', false, null);
        });

        GM_registerMenuCommand("iGraph Helper: set OneClickLogs settings", () => {
            OCLSettingsManager.initialize();
            OCLSettingsManager.showSettingsPopup();
            OCLSettingsManager.refreshRemoteOCLConfig(true);
        });

        GM_registerMenuCommand("iGraph Helper: refresh graphs slowly", () => {
            RefreshGraphs.refreshSlowly();
        });

        GM_registerMenuCommand('iGraph Helper: show cart', () => {
            if (unsafeWindow.iGraphHelper && unsafeWindow.iGraphHelper.IGH) {
                unsafeWindow.iGraphHelper.IGH.WikiCart.showOpenedCart();
            } else {
                alert('Shopping cart not supported on this page');
            }
        });

        GM_registerMenuCommand("iGraph Helper: tiny current URL (Ctrl-Y)", () => {
            Tinify.tiny();
        });

        if (onWiki || onCloudWatchUI || onObserve || onPremonition) {
            if (onCloudWatchUI || (onObserve && !isDashboardInternal)) {
                localGMCode(window, unsafeWindow);
            } else {
                localGMCode(unsafeWindow, unsafeWindow);
            }
            WikiSnapshot.initialize();

            if (WikiSourceEditor.onEditPage()) {
                if (WikiSourceEditor.onSourceEditor()) {
                    WikiSourceEditor.initialize();
                }
            } else {
                IGraphSettings.initialize();
                ApolloDeployments.initialize();
                InteractiveWikiGraphs.initialize();
                GMUtils.initialize();
                WikiBulkSnapshot.initialize();
                if (onCloudWatchUI || onObserve) {
                    injectMainIGraphHelper();
                }
            }
        }
        else if (/^weblab.*[.]amazon[.]com$/.test(window.location.host)) {
            WebLabTimes.initialize();
        }
        else if (/http.*:[/][/]carnaval(-dr)?.([a-zA-Z]{3}.)?(amazon.com|[a-zA-Z0-9]{3}-border.[.a-zA-Z0-9]+)[/](v1)?/.test(window.location.href)) {
            Carnaval.initialize();
        }
        // Check if there are iGraphs, collections or monitors on the page
        else if ((document.images.length > 0 || (/collections|metrics\/monitors.*id=/.test(window.location.href)))
          || document.title === 'SIM Ticketing'
          || document.title === 'HALP'
        ) {
            localGMCode(unsafeWindow, unsafeWindow);
            GMUtils.initialize();
            WikiSnapshot.initialize();
            IGraphPage.initialize();
            injectMainIGraphHelper();
        } else {
            localGMCode(unsafeWindow, unsafeWindow);
        }
        if (this.Tinify) {
            Tinify.initialize();
            AsciiArtGraphGenerator.initialize();
            PipelinesRediForkIntegration.initialize();
        }

        fixCutOffIconsAndLinksOnEmbeddedGraphPopins();
        refreshAlpineLinkVisibility(unsafeWindow);
        exposeSnapshotFunction(unsafeWindow);
    }
    catch(ex) {
        if (typeof(console) !== 'undefined') {
            if (console.error) {
                console.error('iGraph Helper Error: ',ex)
            }
            else if (console.log) {
                console.log('iGraph Helper Error: ',ex);
            }
        }
    }
})();

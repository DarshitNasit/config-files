// ==UserScript==
// @name         PhoneTool Enhance
// @namespace    http://amazon.com
// @version      0.4
// @description  Add Meeting request for managers with assistants, Google Map of Seattle Campus building locations, linkedin search links, and a visual job history widget. Also a new and improved stylesheet
// @author       wael@
// @include      https://phonetool.amazon.com/people/*
// @include      https://phonetool.amazon.com/users/*
// @include      https://connect.amazon.com/people/*
// @include      https://connect.amazon.com/users/*
// @grant        GM_xmlhttpRequest
// @grant        GM_getResourceText
// @grant        GM_addStyle
// @grant        GM.getValue
// @grant        GM.setValue
// @require      http://code.jquery.com/jquery-latest.js
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.js
// @require      https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore.js
// @resource     ptCSS https://drive-render.corp.amazon.com/view/rkshtd@/phonetool/phonetoolenhance/ptWael.css
// @downloadURL  https://drive-render.corp.amazon.com/view/rkshtd@/phonetool/phonetoolenhance/PhoneTool%20Enhance.user.js
// ==/UserScript==

(function() {

    'use strict';
    var url = window.location.href;
    var subdomainRE = RegExp('([^.//]+)','g');
    var subdomain = url.match(subdomainRE)[1];
    var params = {
        urlPrefix: `https://${subdomain}.amazon.com/users/`,
        urlPostfix: ".json",
        empId: $(location).attr("pathname").match(/[people|users]\/(\w+)/)[1],
        orgUrlPrefix: "https://ekarulf.corp.amazon.com/phone-widgets/job-history.cgi?format=greasemonkey&target=",
        linkedinSearchPrefix: "https://www.linkedin.com/search/results/people/?keywords="
    };

    function getPersonalInfoWidgets (params) {
        $.ajax({
            url: params.urlPrefix + params.empId + params.urlPostfix,
            type: "GET",
            dataType: "json",
            success: function(data) {
                try {
                  displayMapLoc(data);
                  addLinkedinSearch(data, params.linkedinSearchPrefix);
                  addJobLevel(data);
                  scheduleMeetingWithAssistant(params, data);
                } catch(e) {
                    console.log(e);
                }
            }
        });
    }
    function addJobLevel (data) {
      $("dl.dl-horizontal").append(`<div class="TableRow jobLevelRow"><div class="TableProperty">Job Level:</div><div class="TableValue">${data.job_level}</div></div>`);
    }

    function scheduleMeetingWithAssistant (params, data) {
        var assistantLogin = data.assistant.login;
        if (assistantLogin != null) {
          $.ajax({
              url: params.urlPrefix + assistantLogin + params.urlPostfix,
              type: "GET",
              dataType: "json",
              success: function(moreData) {
                  try {
                    let name = moreData.first_name;
                    let mgrName = data.first_name;
                    let asstEmail = moreData.email;

                    var subjectStr = `Time with ${mgrName}`;
                    var mailToStr = "";

                    var emailTemplateHTML = "";

                    (async () => {
                      emailTemplateHTML = await GM.getValue('ptEnhanceEmailTemplate', false);

                      if (emailTemplateHTML == false) {
                        emailTemplateHTML = `
                        <span class="editable">Hello </span>
                        <span class="fixed" id="assistantNameSpan"></span>
                        <span class="editable">, hope all is well!\nCan you please help me get </span>
                        <span class="fixed" id="meetingLengthSpan"></span>
                        <span class="editable"> minutes with </span>
                        <span class="fixed" id="managerNameSpan"></span>
                        <span class="editable">? Subject is </span>
                        <span class="fixed" id="meetingSubjectSpan"></span>
                        <span class="editable">. My calendar is up to date.\nThanks</span>
                        `;
                      }
                      $("#emailTemplate").html(emailTemplateHTML);
                      $(updateEmail);
                    })();


                    $("div.PersonalInfoContact").first().append(`
                        <div class="RequestMeetingAssistant">
                          <i class="fa fa-calendar-o" aria-hidden="true"></i>
                          <a id="showMeetingDialog">Request meeting</a>
                        </div>`
                      );

                      $(".PrimaryDetails").first().after(`
                        <div class="meetingInfo PrimaryDetails" style="display: none">
                        <div class="meetingInfoLine">
                          <div id="meetingLengthDiv">
                            <label for="meetingLength">Meeting Length (minutes)</label>
                            <input type="text" class="emailInput" id="meetingLength" value="30" size="5">
                          </div>
                          <div id="meetingSubjectDiv">
                            <label for="meetingSubject">Subject</label>
                            <input type="text" class="emailInput" id="meetingSubject" value="1:1" size="25">
                          </div>
                        </div>
                        <div class="meetingInfoLine">
                          <div id="meetingTemplateDiv">
                            <!-- <label for="emailTemplate">Template</label> -->
                            <div  id="emailTemplate">
                            </div>
                            <div class="EditTemplate">
                              <i class="fa fa-edit" aria-hidden="true"></i>
                              <span id="editEmailTemplate">Double click to edit default email template</span>
                            </div>
                          </div>
                          <div  id="meetingButtonDiv">
                            <div class="sendEmailButton" id="sendEmail">Create Email</div>
                            <div id="cancelEmail">Cancel</div>
                          </div>
                          </div>
                        </div>`
                      );

                      $("#showMeetingDialog").click(function(){
                        var offset = $("#showMeetingDialog").offset();
                        $(".meetingInfo").css("left", offset.left - 400);
                        $(".meetingInfo").css("top", offset.top + 30);
                        $(".meetingInfo").show("slow");
                      });

                      $("#cancelEmail").click(function(){
                        $(".meetingInfo").hide("slow");
                        $(".editable").removeClass("active");
                      });

                      $("#emailTemplate").dblclick(function(){
                        $(".editable").attr("contenteditable", "true");
                        $(".editable").addClass("active");
                        $("#sendEmail").text("Save Template and Create Email");
                        // $(".EditTemplate").hide();
                      });

                      function updateEmail (){
                        var bodyParameters = {
                          assistantName: name,
                          meetingLength: $("#meetingLength").val(),
                          managerName: mgrName,
                          meetingSubject: $("#meetingSubject").val()
                        };
                        $("#assistantNameSpan").text(bodyParameters.assistantName);
                        $("#meetingLengthSpan").text(bodyParameters.meetingLength);
                        $("#managerNameSpan").text(bodyParameters.managerName);
                        $("#meetingSubjectSpan").text(bodyParameters.meetingSubject);

                         $("#sendEmail").click(function(){
                           mailToStr = `mailto:${asstEmail}?subject=${encodeURIComponent(subjectStr)}&body=${encodeURIComponent($("#emailTemplate").text().replace(/\s\s+/g, ' ').trim())}`;
                           window.open(mailToStr);
                           $(".editable").removeClass("active");
                           $(".meetingInfo").hide("slow");
                           (async () => {
                             await GM.setValue('ptEnhanceEmailTemplate', $("#emailTemplate").html());
                           })();
                           return false;
                         });

                     };

                    $(updateEmail);
                    $(".emailInput").on("keyup",updateEmail);

                  } catch(e) {
                      console.log(e);
                  }
              }
          });
        }
    }

    function displayMapLoc (data) {
        var building = data.building.substr(data.building.indexOf('-')+1);
        var search = "Amazon " + building + " building, " + data.city + ", " + data.country;
        var deskLoc = (data.building_room?data.building_room:"");
        var deskMapLink = $(".floor-map-link").attr("href");
        var buildingDetailsLink = $(".building-link").attr("href");
        var deskParams = deskLoc.split('.');
        var mapWidget = `<div class="well content-well map">
           <div class="title">Building Location</div>
           <div class="PersonalInfoContact">
              <div><a href="${buildingDetailsLink}">Building: <b>${building}</b></a></div>
              <div><a href="${deskMapLink}">Floor: <b>${deskParams[1]}</b></a></div>
              <div><a href="${deskMapLink}">Desk: <b>${deskParams[2]}${(deskParams[3] ? ("."+deskParams[3]):"")}</b></a></div>
           </div>
           <div class="mapouter">
             <div class="gmap_canvas">
               <iframe width="480" height="400" id="gmap_canvas" src="https://maps.google.com/maps?q=${search}&t=&z=15&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
             </div>
           </div>
         </div>`;
        $("div.row-fluid.employee").append(mapWidget);
    }
    function removeOverlaps (rolesArray) {
      var resultArray = [];
      for (var i=0; i<rolesArray.length; i++) {
        if (rolesArray[i].end_date == "") rolesArray[i].end_date = moment().format("YYYY/MM/DD");
        var currentRoleStartDate = moment(rolesArray[i].start_date);
        var currentRoleStartDateStr = currentRoleStartDate.format("YYYY/MM/DD");
        var currentRoleEndDate = moment(rolesArray[i].end_date);
        var isSuperSet = false;
        for (var k=0; k<rolesArray.length; k++) {
          if ((k!=i) && !isSuperSet) {
            var testRoleStartDate = moment(rolesArray[k].start_date);
            var testRoleEndDate = moment(rolesArray[k].end_date);
            if (currentRoleStartDate.isBefore(testRoleStartDate) && currentRoleEndDate.isAfter(testRoleEndDate)) {
              isSuperSet = true;
              var post = JSON.parse(JSON.stringify(rolesArray[i]));
              var pre = JSON.parse(JSON.stringify(post));
              post.start_date = testRoleEndDate.format("YYYY/MM/DD");
              resultArray.push(post);
              var mid = resultArray[k];
              pre.start_date = currentRoleStartDateStr;
              pre.end_date = testRoleStartDate.format("YYYY/MM/DD");
              resultArray.push(pre);
            }
          }
        }
        if (!isSuperSet) resultArray.push(rolesArray[i]);
      }
      resultArray = _.sortBy(resultArray, 'end_date').reverse();
      return(resultArray);
    }
    function fillInGaps (incomingArray) {
        var targetData = [];
        //fill in data gaps
        var rolesArray = removeOverlaps(incomingArray);
        for (var r=0; r < rolesArray.length; r++) {
            var roleStartDate = moment(rolesArray[r].start_date);
            var roleEndDate = (rolesArray[r].end_date==""?moment():moment(rolesArray[r].end_date));
            var currentRole = rolesArray[r];
            if (roleEndDate.isSame('2015-02-02', 'day') && (r>0)) {
              roleEndDate = moment(rolesArray[r-1].start_date);
              currentRole.end_date = roleEndDate.format("YYYY/MM/DD");
            }
            var roleDays = roleEndDate.diff(roleStartDate, 'days');
            currentRole.roleDays = roleDays;
            targetData.push(currentRole);

            if ((r<rolesArray.length-1) && (roleStartDate > moment(rolesArray[r+1].end_date).add(7, 'd'))) {
                var prevRoleEndDate = moment(rolesArray[r+1].end_date);
                if (!(prevRoleEndDate.isSame('2015-02-02', 'day') && (r>=0))) {
                  roleDays = roleStartDate.diff(prevRoleEndDate, 'days');
                  targetData.push({
                      end_date: roleStartDate.format("YYYY/MM/DD"),
                      start_date: prevRoleEndDate.format("YYYY/MM/DD"),
                      gap: true,
                      job_family: "Data Gap",
                      roleDays: roleDays,
                      department_name: "",
                      supervisor_name: "",
                      business_title: ""
                });
              }
            }
        }
        return targetData;
    }
    function getUniqueJobFamilies (targetData) {
        var jobFamilies = new Set();
        for (var j =0; j < targetData.length; j++) {
            jobFamilies.add(targetData[j].job_family);
        }
        var jobFamilyClass = {};
        var l=0;
        jobFamilies.forEach(function(value){
            if (value == "Data Gap") {jobFamilyClass[value] = "_gap";}
            else {jobFamilyClass[value] = "_"+l++;}
        });
        return jobFamilyClass;
    }
    function consolidateAdjacent(targetData, titleField) {
        var adjChanges = [];
        for (var k = 0; k < targetData.length; k++) {
            if ((k>0) && (targetData[k][titleField] == adjChanges[adjChanges.length-1].title)) { //is the current dept name similar to previous one?
                adjChanges[adjChanges.length-1].days += targetData[k].roleDays;
            } else {
                adjChanges.push({
                    title: targetData[k][titleField],
                    days: targetData[k].roleDays,
                    mgrLogin: targetData[k].supervisor_login
                });
            }
        }
        return adjChanges;
    }
    function consolidateRoles(targetData) {
        var adjChanges = [];
        for (var k = 0; k < targetData.length; k++) {
            if (
                (k>0) &&
                ((
                  (targetData[k].job_family == adjChanges[adjChanges.length-1].job_family) &&
                  (targetData[k].business_title == adjChanges[adjChanges.length-1].business_title)
                )
                || (targetData[k].roleDays <= 30))
            )
              {
                adjChanges[adjChanges.length-1].days += targetData[k].roleDays;
            } else {
                adjChanges.push({
                    department_name: targetData[k].department_name,
                    job_family: targetData[k].job_family,
                    business_title: targetData[k].business_title,
                    days: targetData[k].roleDays
                });
            }
        }
        return adjChanges;
    }
    function consolidateDates (targetData) {
        var adjChanges = [];
        for (var k = 0; k < targetData.length; k++) {
            if (
              (k>0) &&
              ((
                (targetData[k].department_name == adjChanges[adjChanges.length-1].department_name) &&
                (targetData[k].job_family == adjChanges[adjChanges.length-1].job_family) &&
                (targetData[k].supervisor_name == adjChanges[adjChanges.length-1].supervisor_name)
                && (targetData[k].business_title == adjChanges[adjChanges.length-1].business_title)
            ) || (
              targetData[k].roleDays <= 30
            ))
          ) {
                adjChanges[adjChanges.length-1].days += targetData[k].roleDays;
            } else {
                adjChanges.push({
                    department_name: targetData[k].department_name,
                    job_family: targetData[k].job_family,
                    supervisor_name: targetData[k].supervisor_name,
                    date: (targetData[k].end_date==""?moment():moment(targetData[k].end_date)).format("MMM YY"),
                    days: targetData[k].roleDays
                });
            }
        }
        return adjChanges;

    }
    function layoutRow (rowClassName, cellsArr, contentParamName, widthParamName, total, cellClassName, addlClass, searchURL) {
        var rowHTML = "<div class='"+rowClassName+"'>";
        for (var i=0; i<cellsArr.length; i++) {
            var addLinkPre = "";
            var addLinkPost = "";
            var content = cellsArr[i][contentParamName];
            if ((cellClassName == "manager")) {
              if ((cellsArr[i].mgrLogin)) {
                addLinkPre += "<a href='"+params.urlPrefix+cellsArr[i].mgrLogin+"'>";
                addLinkPost += "</a>";
              } else {
                addLinkPre += `<a href="${searchURL}${content} Amazon" title='Former employee. Search for in Linkedin' target='_blank'><i>`;
                addLinkPost += "</i></a>";
              }
            }
            var wid = ((cellsArr[i][widthParamName] / total)*100)+"%";
            rowHTML += `<div class='${cellClassName} ${(addlClass?addlClass[cellsArr[i].job_family]:"")}' style='min-width: ${wid}' title='${content}'>${addLinkPre}${content}${addLinkPost}</div>`;
        }
        rowHTML += "</div>";
        return rowHTML;
    }
    function layoutLegend (legendObj) {
        var rowHTML = "<div class='legend'><div>Job Family:</div>";
        for (var property1 in legendObj) {
            rowHTML += `<div class='${legendObj[property1]}'><div class='swatch'></div>${property1}</div>`;
        }
        rowHTML += "</div>";
        return rowHTML;
    }
    function getyOrgHistoryWidgets (params) {
        GM_xmlhttpRequest({
            method: "GET",
            url: params.orgUrlPrefix + params.empId,
            onload: function(data) {
                try {
                    var historyData = JSON.parse(data.responseText);
                    var roles = historyData.length;
                    var today = moment();
                    var startHistory = moment(historyData[historyData.length-1].start_date);
                    var tenure = today.diff(startHistory, 'days');
                    var fixedHistory = fillInGaps(historyData);
                    var jobFamilyClass = getUniqueJobFamilies(fixedHistory);
                    //Consolidate similar adjacent cells
                    var depts = consolidateAdjacent (fixedHistory, "department_name");
                    var mgrs = consolidateAdjacent (fixedHistory, "supervisor_name");
                    var uniqueRoles = consolidateRoles(fixedHistory);
                    var dates = consolidateDates(fixedHistory);
                    $("div.row-fluid.employee").after(`
                      <div class = 'row-fluid orgHolder'>
                        <div class='well content-well role-history'>
                          <div class='title'>Role History</div>
                          <div class='timeline-holder'>
                            <div class='timeline'>
                              ${layoutRow('dept-names', depts, 'title', 'days', tenure, 'dept-marker')}
                              ${layoutRow('date-names', dates, 'date', 'days', tenure, 'date-marker')}
                              ${layoutRow('timeline-row', uniqueRoles, 'business_title', 'days', tenure, 'timeline-section', jobFamilyClass)}
                              ${layoutRow('mgr-names', mgrs, 'title', 'days', tenure, 'manager', null, params.linkedinSearchPrefix)}
                            </div>
                            <div class = 'start-date-holder'><div class = 'dept-marker'>Start</div><div class='date-marker'>${startHistory.format("MMM YY")}</div></div>
                          </div>
                          ${layoutLegend(jobFamilyClass)}
                        </div>
                      </div>`
                    );
                } catch(e) {
                    console.log(e);
                }
            }
        });

    }
    function addLinkedinSearch(data, searchURL) {
      $("div.PersonalInfoContact").first().append(`
          <div class="PersonalLinkedinSearch">
            <i class="fa fa-linkedin" aria-hidden="true"></i>
            <a href="${searchURL}${data.first_name}+${data.last_name}+Amazon" target='_blank'>Search Linkedin</a>
          </div>`
        );
    }
    var newCSS = GM_getResourceText ("ptCSS");
    GM_addStyle (newCSS);
    getPersonalInfoWidgets(params);
    getyOrgHistoryWidgets(params);
})();

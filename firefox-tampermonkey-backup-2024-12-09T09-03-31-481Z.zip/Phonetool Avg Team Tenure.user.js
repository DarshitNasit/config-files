// ==UserScript==
// @name         Phonetool Avg Team Tenure
// @namespace    Phonetool
// @version      1.9
// @description  Adds Average Team Tenure to PhoneTool
// @author       ravijan@, donatoaz@
// @match        https://phonetool.amazon.com/users/*
// @require      https://m.media-amazon.com/images/I/61SXkEEnLtL.js#ver=jquery-3.4.0.min.js
// ==/UserScript==

(function($) {
    'use strict';
    const DEBUG = false;
    const log = function(...args) {
        if (DEBUG) {
            console.log.apply(console, args);
        }
    }

    const getUserUrl = function(login) {
        return "https://phonetool.amazon.com/users/" + login + ".json";
    };

    const getUser = function() {
        const url = window.location.href;
        const userRegex = /https:\/\/phonetool\.amazon\.com\/users\/(.+)/;
        const userRegexResult = userRegex.exec(url);
        if (userRegexResult.length < 2) {
            return null;
        }
        return userRegexResult[1];
    };

    const getManager = function(user) {
        return new Promise(function(resolve, reject) {
            // root node's parent is itself
            if (user === "jeff") {
                resolve(user);
            } else {
                $.get(getUserUrl(user), function(data) {
                    if (data.manager && data.manager.login) {
                        resolve(data.manager.login);
                    } else {
                        log("Failed to fetch manager info, rawJSON = " + JSON.stringify(data));
                    }
                });
            }
        });
    };

    const getTeamMembers = function(manager) {
        return new Promise(function(resolve, reject) {
            $.get(getUserUrl(manager), function(data) {
                const results = [manager];
                if ($.isArray(data.direct_reports)) {
                    $.each(data.direct_reports, function(index, item) {
                        if (item.login) {
                            results.push(item.login);
                        } else {
                            log("Failed to find login for item = %s", JSON.stringify(item));
                        }
                    });
                    log("Team Members = %s", JSON.stringify(results));
                    resolve(results);
                } else {
                    log("Failed to fetch team member info, rawJSON = " + JSON.stringify(data));
                }
            });
        });
    };

    const arrSum = arr => arr.reduce((a,b) => a + b, 0)

    const rejectWithDelay = function (reason) {
        log("rejectWithDelay called");
        const timeoutInMillis = 100;
        return new Promise(function(resolve, reject) {
            setTimeout(reject.bind(null, reason), timeoutInMillis);
        });
    };

    const getTeamMemberTenure = function(teamMember) {
        return new Promise(function(resolve, reject) {
            $.get(getUserUrl(teamMember), function(data) {
                if (data && data.tenure_days) {
                    resolve(data.tenure_days);
                } else {
                    resolve(0);
                    log("Cannot find tenure data for teamMember = %s, rawData = %s", teamMember, JSON.stringify(data));
                }
            }).fail(function() {
                reject();
                log("Failed to get tenure data for teamMember = %s", teamMember);
            });
        });
    };

    const getTeamMemberTenureWithRetries = function(teamMember) {
        const maxAttempts = 3;
        let prom = getTeamMemberTenure(teamMember);
        for (var i = 0; i < maxAttempts; i++) {
            prom = prom.catch(function() {
                return getTeamMemberTenure(teamMember);
            }).catch(rejectWithDelay);
        }
        return prom.then(function(result) {
            return result;
        }).catch(function(error) {
            log("Failed maxAttempts = %d to get tenure data for teamMember = %s, error = %s", maxAttempts, teamMember, error);
        })
    };

    const getTeamMembersTenure = function(teamMembers) {
        return new Promise(function(resolve, reject) {

            let totalTenureDays = 0;
            let totalTeamMembers = 0;
            const teamMemberMap = {};
            const teamMemberTenurePromises = [];
            for (let i = 0; i < teamMembers.length; i++) {
                const teamMember = teamMembers[i];
                teamMemberTenurePromises.push(getTeamMemberTenureWithRetries(teamMember));
            }
            Promise.all(teamMemberTenurePromises).then(values => {
                const nonZeroValues = values.filter(value => value !== 0);
                resolve({"totalTenureDays": arrSum(nonZeroValues), "totalTeamMembers": nonZeroValues.length});
            });
        });
    };

    const getYearsString = function(years) {
        return years > 1 ? `${years} years` : `${years} year`;

    };

    const getMonthsString = function(months) {
        return months > 1 ? `${months} months` : `${months} month`;

    };

    const renderAvgTeamTenure = function(tenureData) {
        if (!tenureData.totalTenureDays || !tenureData.totalTeamMembers) {
            log("Cannot find tenure data = %s, exiting!", JSON.stringify(tenureData));
            return;
        }
        const avgTeamMemberTenureInDays = Math.round(tenureData.totalTenureDays / tenureData.totalTeamMembers, 10);
        const avgTeamYears = Math.floor(avgTeamMemberTenureInDays / 365);
        const avgTeamMonths = Math.floor((avgTeamMemberTenureInDays - avgTeamYears * 365) / 30);
        const yearsString = getYearsString(avgTeamYears);
        const monthsString = getMonthsString(avgTeamMonths);
        const avgTeamTenureString = avgTeamYears > 0 ? (avgTeamMonths > 0 ? `${yearsString}, ${monthsString}` : `${yearsString}`) : `${monthsString}`;

        const userDetailsTable = $("div.UserDetailsTable");
        const avgTeamTenureDomString = `
<span class="optional-wrapper">
    <div class="TableRow AvgTeamTenureRow">
        <div class="TableProperty">Avg Team Tenure</div>
        <div class="TableValue">${avgTeamTenureString}</div
    </div>
</span>
`
        userDetailsTable.append(avgTeamTenureDomString);
        log("Average Tenure = %s, tenureString = %s", JSON.stringify(tenureData), avgTeamTenureString);
    };

    const user = getUser();
    getManager(user)
        .then(getTeamMembers)
        .then(getTeamMembersTenure)
        .then(renderAvgTeamTenure);
})(jQuery);
jQuery.noConflict();


// ==UserScript==
// @name        BiggerPhoneToolOrgChartPics
// @namespace   Phone Tool
// @description Set the phonetool images of org chart to default size.
// @include     http*://phonetool.amazon.com/*
// @version     3.2
// @grant       none
// @downloadURL https://drive.corp.amazon.com/view/daninagy@/biggerPhoneTool.user.js
// @authors     daninagy@
// ==/UserScript==

var load = window.setInterval(function(){
	
	var pic = document.getElementsByClassName('badge-photo blue-badge-small');

	for ( i = 0; i < pic.length; i++){
		pic[i].style.height = '128px';
  	pic[i].style.width = '96px';
	}

    var pic = document.getElementsByClassName('badge-photo yellow-badge-small');

	for ( i = 0; i < pic.length; i++){
		pic[i].style.height = '128px';
  	pic[i].style.width = '96px';
	}

     var pic = document.getElementsByClassName('badge-photo green-badge-small');

	for ( i = 0; i < pic.length; i++){
		pic[i].style.height = '128px';
  	pic[i].style.width = '96px';
	}

    var chartRow = document.getElementsByClassName('org-chart-row');
    for ( i = 0; i < chartRow.length; i++){
		chartRow[i].style.height = '138px';
	}

}, 1555);  
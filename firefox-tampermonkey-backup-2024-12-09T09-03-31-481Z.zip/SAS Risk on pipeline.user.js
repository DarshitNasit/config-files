// ==UserScript==
// @name         SAS Risk on pipeline
// @namespace    amazon.com
// @version      1.1.1
// @description  Enhance your pipeline page by adding SAS Risk count
// @author       vamgan@amazon.com
// @match        https://pipelines.amazon.com/pipelines/*
// @grant        GM_xmlhttpRequest
// @downloadURL  https://improvement-ninjas.amazon.com/GreaseMonkey/SASRiskOnPipeline.user.js
// @updateURL    https://improvement-ninjas.amazon.com/GreaseMonkey/SASRiskOnPipeline.user.js
// @run-at       document-end
// ==/UserScript==

(function() {
    fetchSasRiskCount();
    function getPipelineId() {
        const pipelineElement = document.getElementById('pipeline_id');

        if (pipelineElement) {
            const pipelineId = pipelineElement.textContent || pipelineElement.innerText;
            return pipelineId;
        } else {
            console.error('Element with ID "pipeline_id" not found.');
            return null;
        }
    }

    // Function to fetch SAS risk count from API
    function fetchSasRiskCount() {
        const baseURLs = {
            "ApolloEnvironmentNameAndStage": "https://sas.corp.amazon.com/details/apollo/",
            "AmazonPipelineTarget": "https://sas.corp.amazon.com/details/pipelineTarget/",
            "BrazilVersionSet": "https://sas.corp.amazon.com/details/brazil/",
            "apiEndpoint": "https://sas.corp.amazon.com/api/risks-by-pipeline/"
        }
        const pipelineId = getPipelineId();
        if (!pipelineId) {
            return;
        }
        const apiEndpoint = baseURLs.apiEndpoint + pipelineId + "/ALL";

        GM_xmlhttpRequest({
            method: 'GET',
            url: apiEndpoint,
            responseType: 'json',
            onload: function(response) {
                if (response.status === 200 && response.response) {
                    let totalRiskCount = 0;
                    let blockingRiskDate = null;
                    const resourceTypeMap = response.response.highLevelResourceDetailsByResourceTypeMap;
                    for (const environmentType in resourceTypeMap) {
                        if (environmentType == "ApolloEnvironmentNameAndStage" || environmentType == "AmazonPipelineTarget") {
                            const environmentData = resourceTypeMap[environmentType];
                            for (const environment of environmentData) {
                                const envName = environmentType == "ApolloEnvironmentNameAndStage" ? 'target-name-' + environment.resourceName.replace(/:/g, "/") : 'target-name-' + environment.resourceName.slice(0, environment.resourceName.lastIndexOf(':'));
                                const hyperlink = baseURLs[environmentType] + environment.resourceName;
                                const riskCount = environment.totalRiskCountWithAction + environment.totalRiskCountWithoutAction;
                                totalRiskCount += riskCount
                                const riskSeverityMap = addRiskSeverityMaps(environment.riskSeverityMapWithRecommendations, environment.riskSeverityMapWithoutRecommendations);
                                updateBoxWithRiskCount(envName, riskCount, riskSeverityMap, hyperlink, blockingRiskDate);
                            }
                        }
                        if (environmentType == "BrazilVersionSet") {
                            const envName = "stage-name-VersionSet" //Edge case if package name and vs name is same
                            const riskCount = resourceTypeMap[environmentType][0].totalRiskCountWithAction + resourceTypeMap[environmentType][0].totalRiskCountWithoutAction;
                            const hyperlink =  baseURLs[environmentType] + resourceTypeMap[environmentType][0].resourceName;
                            totalRiskCount += riskCount
                            const riskSeverityMap = addRiskSeverityMaps(resourceTypeMap[environmentType][0].riskSeverityMapWithRecommendations, resourceTypeMap[environmentType][0].riskSeverityMapWithoutRecommendations);
                            if (resourceTypeMap[environmentType][0].blockingTimeInEpochMilli) {
                                blockingRiskDate = convertEpochToDate(resourceTypeMap[environmentType][0].blockingTimeInEpochMilli);
                            }
                            updateBoxWithRiskCount(envName, riskCount, riskSeverityMap, hyperlink, blockingRiskDate);
                        }
                    }
                    addSasRiskButton(totalRiskCount);
                } else {
                    console.error('Error fetching SAS risk count:', response.statusText);
                }
            },
            onerror: function(error) {
                console.error('Error fetching SAS risk count:', error.statusText);
            },
        });
    }

    //To get the total count of each severity level
    function addRiskSeverityMaps(riskSeverityMapWithRecommendations, riskSeverityMapWithoutRecommendations) {
        const riskSeverityMap = {};
        for (const severityLevel in riskSeverityMapWithRecommendations) {
            riskSeverityMap[severityLevel] = riskSeverityMapWithRecommendations[severityLevel] + riskSeverityMapWithoutRecommendations[severityLevel];
        }
        return riskSeverityMap;
    }

    function addSasRiskButton(totalRiskCount) {
        const pipelineHealthBadges = document.querySelector('.pipeline-health-badges');

        if (pipelineHealthBadges) {
            const riskButton = document.createElement('div');
            riskButton.classList.add('classification-badge');
            riskButton.href = '#';

            if (totalRiskCount > 0) {
                riskButton.classList.add('classification_attention');
                riskButton.innerText = `${totalRiskCount} SAS RISKS`;
            } else {
                riskButton.classList.add('gold');
                riskButton.innerText = '0 SAS Risks';
            }

            pipelineHealthBadges.appendChild(riskButton);

            // Add hover event listener to show popup
            riskButton.addEventListener('mouseover', function () {
                showRiskSeverityPopup(totalRiskCount);
            });

            // Remove popup when mouse leaves the SAS risk count
            riskButton.addEventListener('mouseout', function () {
                removeRiskSeverityPopup();
            });

            // console.log(`Button added for ${totalRiskCount} SAS RISKS.`);
        } else {
            console.error('Pipeline health badges container not found.');
        }
    }

    // Function to update the box inside the specified element with the risk count
    function updateBoxWithRiskCount(envName, riskCount, riskSeverityMap, hyperlink, blockingRiskDate) {
        const stageInfoBox = document.getElementById(envName);
        if (stageInfoBox) {
            const childBox = stageInfoBox.querySelector('.details');
            const countBox = document.createElement('div');
            countBox.innerHTML = `SAS Risk Count: ${riskCount}`;
            countBox.classList.add('status-failed');
            countBox.innerHTML = `<a href="${hyperlink}" target="_blank" style="color:#D30000">${countBox.innerHTML}</a>`;
            childBox.appendChild(countBox);
            // Add a orange badge with date if there is a blocking risk date is not null
            if (blockingRiskDate) {
                const blockingDateBox = document.createElement('div');
                blockingDateBox.classList.add('classification-badge');
                blockingDateBox.classList.add('classification_alert');
                blockingDateBox.innerText = `Blocking ${blockingRiskDate}`;
                childBox.appendChild(blockingDateBox);
            }
            // Add hover event listener to show popup
            countBox.addEventListener('mouseover', function () {
                showRiskSeverityPopup(envName, riskSeverityMap);
            });

            // Remove popup when mouse leaves the SAS risk count
            countBox.addEventListener('mouseout', function () {
                removeRiskSeverityPopup();
            });

            // console.log('Box updated with SAS risk count:', riskCount);
        } else {
            console.error(`Element with ID ${envName} not found.`);
        }
    }

    // Function to show the popup
    function showRiskSeverityPopup(envName, riskSeverityMap) {
        const popup = document.createElement('div');
        popup.classList.add('risk-popup');

        const popupContent = document.createElement('div');
        popupContent.classList.add('popup-content');

        for (const severityLevel in riskSeverityMap) {
            const severityCount = riskSeverityMap[severityLevel];
            const severityItem = document.createElement('div');
            severityItem.textContent = `${severityLevel}: ${severityCount}`;
            popupContent.appendChild(severityItem);
        }

        popup.appendChild(popupContent);

        const stageInfoBox = document.getElementById(envName);
        if (stageInfoBox) {
            const detailsInfoBox = stageInfoBox.querySelector('.details');
            detailsInfoBox.appendChild(popup);
        }
    }

    // Function to remove the popup
    function removeRiskSeverityPopup() {
        const popup = document.querySelector('.risk-popup');
        if (popup) {
            popup.parentNode.removeChild(popup);
        }
    }

    function convertEpochToDate(epochTime) {
        const blockingDate = new Date(epochTime);
        return blockingDate.toLocaleString();
    }

})();

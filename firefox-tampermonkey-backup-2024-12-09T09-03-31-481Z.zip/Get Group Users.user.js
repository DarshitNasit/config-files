// ==UserScript==
// @name        Get Group Users
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/getGroupUsernames.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/getGroupUsernames.user.js
// @namespace   amazon.permissions.custom
// @grant       none
// @description Adds buttons for getting users and emails
// @include     http*://permissions.amazon.com/group.mhtml*
// @version     1
// ==/UserScript==

(function () 
    getgroupnames = {};
    getgroupnames.members = [];
    getgroupnames.owners = [];
    var lookupURL = 'https://permissions.amazon.com/user.mhtml?lookup_user=';
    var members = $('div#group_member_table tr > td > a');
    for (var i = 0; i < members.length; i++) {
        // For ANT groups you can nest, so skip it if it's not a person
        if (!members[i].href.match(/user.mhtml/)) continue;
        getgroupnames.members.push(members[i].href.replace(lookupURL, ''));
    }
    var primaryOwner = $('div#group_ownership_details div > a');
    getgroupnames.owners.push(primaryOwner[0].href.replace(lookupURL, ''));
    var secondaryOwners = $('div#group_ownership_details div > ul > li > a');
    for (var i = 0; i < secondaryOwners.length; i++) {
        getgroupnames.owners.push(secondaryOwners[i].href.replace(lookupURL, ''));
    }
    $('<button id=\'getmembers\'>Get Members</button>').appendTo('#group_member_table h3');
    $('#getmembers').click(function () {
        window.prompt('Copy usernames to clipboard: Ctrl+C, Enter', getgroupnames.members.join(','))
    });
    $('<button id=\'emailmembers\'>Email Members</button>').appendTo('#group_member_table h3');
    $('#emailmembers').click(function () {
        window.location.href = 'mailto:' + getgroupnames.members.join('@amazon.com;') + '@amazon.com'
    });
    $('<button id=\'getowners\'>Get Owners</button>').appendTo('#group_ownership_details');
    $('#getowners').click(function () {
        window.prompt('Copy usernames to clipboard: Ctrl+C, Enter', getgroupnames.owners.join(','))
    });
    $('<button id=\'emailowners\'>Email Owners</button>').appendTo('#group_ownership_details');
    $('#emailowners').click(function () {
        window.location.href = 'mailto:' + getgroupnames.owners.join('@amazon.com;') + '@amazon.com'
    });
}());




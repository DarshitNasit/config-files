// ==UserScript==
// @name         HyperBadge 2.2
// @namespace    https://hyperbadge.amazon.dev/
// @version      2.2
// @description  A Tampermonkey userscript that replaces the default employee badge in the Phone Tool with a hyper-realistic, pseudo-3D, interactive version of The Badge Reimagined.
// @author       johngill
// @match        https://phonetool.amazon.com/users/*
// @match        https://connect.amazon.com/users/*
// @match        https://hyperbadge.amazon.dev/*
// @updateURL    https://userscript.hyperbadge.amazon.dev/hyperbadge.user.js
// @downloadURL  https://userscript.hyperbadge.amazon.dev/hyperbadge.user.js
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
  var VERSION = 'HyperBadge 2.2';
  var ROOT = 'https://userscript.hyperbadge.amazon.dev';

  var applyUserscript = function() {
    var html = document.querySelector('html');
    var head = document.head;

    html.dataset.userscript = VERSION;
    html.dataset.userscripts = html.dataset.userscripts ? html.dataset.userscripts + ',' + VERSION : VERSION;

    var style = document.createElement('style');
    style.appendChild(document.createTextNode('.employee-badge {min-width: 180px; min-height: 400px;} .worker-badge {display: none !important;}'));
    head.appendChild(style);

    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = ROOT + '/styles.css';
    head.appendChild(link);

    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = ROOT + '/scripts.js';
    head.appendChild(script);
  };

  if (document && document.head) {
    applyUserscript();
  } else {
    window.addEventListener('DOMContentLoaded', applyUserscript);
  }
})();
// ==UserScript==
// @name     SIM Sprint Standup Moderator
// @include  https://sim.amazon.com/sprints/*/*mode=list*
// @include  https://issues.amazon.com/sprints/*/*mode=list*
// @include  https://issues*.amazon.com/sprints/*/*mode=list*
// @author   ujwalat@
// @version  1.0
// @grant    GM_getValue
// @grant    GM_setValue
// ==/UserScript==
// SIM Sprint Standup Organizer to auto run SIM based sprint standup for your team.
// Add comma separated participants using "Team Members" button.
// Shows photo of the current person with timer, auto next on time-up with a buzzer sound (can be muted).
// Can select photo to go back to a previous engineer.
// PS: This is not my original work - I have combined  different scripts (mostly from StandupRandomizer and Photo Standup Randomizer) present here.
/**
 * Version 1.0
 **/
(function() {
    var set = false;
    var CURRENT_INDEX_KEY = "sim.current_index";
    var SIM_USERS_KEY = "sim.sim_users";
    var countdownMinutes = 2;
    var COLLAPSE = "&collapse=true";
    var start;
    var timerButton;
    var diff;
    var bell = new Audio("https://upload.wikimedia.org/wikipedia/commons/f/fa/Gong_or_bell_vibrant.ogg");

    var SIM_USERS_STYLE =
        '.SIMUsersScript__faces a.SIMUsersScript__face { ' +
        '  margin-right:5px;  ' +
        '  display: inline-block;  ' +
        '  overflow: hidden;  ' +
        '  width: 50px;  ' +
        '  height: 62px;  ' +
        '  border:solid 1px #999; ' +
        '  position: relative;' +
        '}  ' +
        '.SIMUsersScript__faces a.SIMUsersScript__face img { ' +
        '  width:50px; ' +
        '} ' +
        '.SIMUsersScript__faces a.SIMUsersScript__face span { ' +
        ' display: block;' +
        ' position: absolute;' +
        ' top: 6px;' +
        ' left: -3px;' +
        ' transform: rotate(-45deg);' +
        ' font-size: 10px;' +
        ' color: white;' +
        ' font-weight: bold;' +
        '}';

    documentViewTitle = $('.document-view-title');
    documentViewTitle.after('<div class="SIMUsersScript__faces"></div>');
    $('#SIM_USERS_STYLE').remove();
    $('<style type="text/css" id="SIM_USERS_STYLE"/>').text(SIM_USERS_STYLE).appendTo($('head'));

    function createButtonElement(uid, title, overlay, src) {
        var face = $('<a>')
            .addClass('SIMUsersScript__face')
            .attr('href', 'javascript:')
            .attr('data-trigger-field-event', 'change-assignee-filter')
            .attr('data-trigger-field-value', uid);

        src = (src || 'https://internal-cdn.amazon.com/badgephotos.amazon.com/?uid=' + encodeURIComponent(uid));
        face.append($('<img>')
            .attr('src', src)
            .attr('title', title)
        );
        if (typeof overlay === 'string' && overlay !== "") {
            var span = $('<span>').text(overlay).hide();
            face.append(span);
            face.hover(function() {
                span.show();
            }, function() {
                span.hide();
            });
        }
        return face;
    }

    function createAliasButtonElement(alias) {
        return createButtonElement(alias, alias);
    }

    function createNobodyButtonElement() {
        return createButtonElement("nobody", "nobody", "nobody", "https://improvement-ninjas.amazon.com/s3files/s3get.cgi/badgephoto_default.png");
    }

    function createResetButtonElement() {
        return createButtonElement("", "remove-filter", "remove", "https://improvement-ninjas.amazon.com/s3files/s3get.cgi/sim_owner_nobody.png");
    }

    function construct_url(assignee) {
        var [base_url, parameters] = window.location.href.split("?");
        return base_url + "?mode=lanest&assignee=" + assignee + COLLAPSE;
    }

    function get_current_index() {
        var index_value = GM_getValue(CURRENT_INDEX_KEY, "");
        return index_value ? Number(index_value) : 0;
    }

    function get_current_users() {
        var raw_users = GM_getValue(SIM_USERS_KEY, "");
        if (raw_users !== null && raw_users) {
            return decode_users(raw_users);
        } else {
            return "";
        }
    }

    function decode_users(raw_string) {
        if (raw_string !== null && raw_string && JSON.parse(raw_string)) {
            return JSON.parse(raw_string).replace(/ /g, '').split(",");
        } else {
            return "";
        }
    }

    function encode_users(user_array) {
        return JSON.stringify(user_array.join(","));
    }

    function encode_user_prompt(user_array) {
        return encode_users(user_array).replace(/\"/g, '');
    }

    function shuffle_and_store(user_array) {
        var shuffled_array = shuffle(user_array);
        GM_setValue(SIM_USERS_KEY, encode_users(shuffled_array));
        GM_setValue(CURRENT_INDEX_KEY, 0);
        return shuffled_array;
    }

    function set_next_index(new_index) {
        GM_setValue(CURRENT_INDEX_KEY, new_index);
        return new_index;
    }

    function get_next_index(current_index, len_user_array) {
        return (current_index + 1) % len_user_array;
    }

    function set_initial_sim_array() {
        set = true;
        sim_users = prompt(
            'Please enter sprint users in csv format (ex : mkundra, abavle) .',
            "saaahm, matklein, edmitry, kheraf, aggaraja, sinhaneh, mkundra"
        );

        if (!sim_users) {
            alert("Sim users not set! Click Team Members to add new members.");
            return;
        }
        GM_setValue(SIM_USERS_KEY, JSON.stringify(sim_users));
    }

    function set_sim_array() {
        sim_users_array = get_current_users();
        sim_users_csv = sim_users_array ? encode_user_prompt(sim_users_array) : "user1alias, user2alias";
        sim_users = prompt(
            'Please enter sprint users in csv format (current members are as follows) .',
            sim_users_csv
        );
        if (!sim_users) {
            alert("New sim users not entered! Current_users : " + encode_user_prompt(sim_users_array));
            return false;
        }
        GM_setValue(SIM_USERS_KEY, JSON.stringify(sim_users));
        alert("Sprint users set to : " + sim_users);
        return true;
    }

    function wait_for_assignee_dropdown(callback) {
        if ($('.filterby-assignee li[data-value!=""]').length > 2) {
            callback();
        } else {
            setTimeout(function() {
                wait_for_assignee_dropdown(callback);
            }, 20);
        }
    }

    function click_next() {
        loadClock(timerButton);
        var user_array = get_current_users();
        if (!user_array) {
            alert("No Members found please click Team Members and add new members");
            return;
        }
        current_index = get_current_index();
        var next_index = get_next_index(current_index, user_array.length);
        console.log(" next_index = " + next_index);
        console.log(" length = " + user_array.length);
        //    if((next_index + 1) == user_array.length) {
        //      alert("Stand is over! Anything else you would like to discuss with team, you can!!");
        //      return;
        //    }

        var assignee = user_array[next_index];
        set_next_index(next_index);
        $('.filterby-assignee').click();
        wait_for_assignee_dropdown(function() {
            $('.filterby-assignee li[data-value="' + assignee + '"]').click();
            var current_html = $('[title="Current team member"]').html();
            var current_assignee = user_array[current_index];
            $('[title="Current team member"]').html(current_html.replace(current_assignee, assignee));
            // Amrit attempting random shit
            var next_html = $('[title="Next team member"]').html();
            var next_next_index = get_next_index(next_index, user_array.length);
            var next_assignee = user_array[next_next_index];
            $('[title="Next team member"]').html(next_html.replace(assignee, next_assignee));
            $('.SIMUsersScript__faces').append(createAliasButtonElement(assignee));
        });
    }

    function click_previous() {
        var user_array = get_current_users();
        if (!user_array) {
            alert("No Members found please click Team Members and add new members");
            return;
        }
        current_index = get_current_index();
        var previous_index = get_previous_index(current_index, user_array.length);
        var assignee = user_array[previous_index];
        set_next_index(previous_index);
        window.location.href = construct_url(assignee);
    }

    function get_previous_index(current_index, len_user_array) {
        if (current_index == 0) {
            return len_user_array - 1;
        } else {
            return current_index - 1;
        }
    }

    function click_shuffle() {
        var user_array = get_current_users();
        if (!user_array) {
            alert("No Members found please click Team Members and add new members");
            return;
        }
        shuffle_and_store(user_array);
        click_next();
    }

    function click_edit_members() {
        if (set_sim_array()) {
            // Should we click next when the members are set?
            // click_next();
        }
    }

    function create_and_append_button(text, event_listener, icon_class, hint = "", color) {
        var parent = document.querySelector('#sprint-view > div.inner-container > div.view-state-initialized-visible.view-state-loading-visible.view-state-errored-visible.document-edit-state-hidden-visible > header > div:nth-child(3)');
        var button = document.createElement("button");
        var text_node = document.createTextNode(" " + text);
        button.className = "btn";
        // button.textContent = text + " ";
        var style = "display: inline;float: right;"
        if (color) {
            style = "display: inline;float: right;background-image: none;color: white;background-color: " + color;
        }
        button.style = style;
        button.addEventListener("click", event_listener);
        button.title = hint;
        parent.append(button);
        var icon = document.createElement("i");
        icon.className = icon_class;
        button.appendChild(icon);
        button.append(text_node);
    }

    function create_user_picture_button(user, text, event_listener, icon_class, hint = "", color) {
        var parent = document.querySelector('#sprint-view > div.inner-container > div.view-state-initialized-visible.view-state-loading-visible.view-state-errored-visible.document-edit-state-hidden-visible > header > div:nth-child(3)');
        var button = document.createElement("button");
        var text_node = document.createTextNode(" " + text);
        button.className = "btn";
        // button.textContent = text + " ";
        var style = "display: inline;float: right;"
        if (color) {
            style = "display: inline;float: right;background-image: none;color: white;background-color: " + color;
        }
        button.style = style;
        button.addEventListener("click", event_listener);
        button.title = hint;
        parent.append(button);
        var icon = document.createElement("i");
        icon.className = icon_class;
        button.appendChild(icon);
        button.append(text_node);
        $('.SIMUsersScript__faces').append(createAliasButtonElement(user));
    }

    function get_next_user(current_index, sim_users) {
        var next_user = 0;
        if (current_index < sim_users.length - 1) {
            next_user = current_index + 1;
        }
        return next_user;
    }

    document.onkeydown = function() {
        switch (window.event.keyCode) {
            case 37:
                //disp('Left key is pressed') // execute a function by passing parameter
                click_previous()
                break;
            case 38:
                //disp('Up  key is pressed')
                break;
            case 39:
                //right key
                click_next()
                break;
            case 40:
                //disp('Down key is pressed')
                break;
        }
    };

    function shuffle(array) {
        var currentIndex = array.length,
            temporaryValue, randomIndex;

        // While there remain elements to shuffle...
        while (0 !== currentIndex) {

            // Pick a remaining element...
            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;

            // And swap it with the current element.
            temporaryValue = array[currentIndex];
            array[currentIndex] = array[randomIndex];
            array[randomIndex] = temporaryValue;
        }

        return array;
    }

    function startTimer(duration, display) {
        var minutes,
            seconds;

        function timer() {
            // get the number of seconds that have elapsed since
            // startTimer() was called
            diff = duration - (((Date.now() - start) / 1000) | 0);

            // does the same job as parseInt truncates the float
            minutes = (diff / 60) | 0;
            seconds = (diff % 60) | 0;

            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            display.textContent = minutes + ":" + seconds;
            if (bell.currentTime >= 5) {
                stopBell();
            }

            if (diff <= 0) {
                // add one second so that the count down starts at the full duration
                // example 05:00 not 04:59
                start = Date.now() + 1000;
                playBell();
                click_next();
            }
        };
        // we don't want to wait a full second before the timer starts
        timer();
        setInterval(timer, 1000);
    }

    function playBell() {
        bell.play();
        //a.pause();
        //a.currentTime = 0;
    }

    function stopBell() {
        bell.pause();
        bell.currentTime = 0;
    }

    function loadClock(button) {
        var parent = document.querySelector('#sprint-view > div.inner-container > div.view-state-initialized-visible.view-state-loading-visible.view-state-errored-visible.document-edit-state-hidden-visible > header > div:nth-child(3)');
        var amountOfMinutes = 60 * countdownMinutes;
        diff = 0;
        start = Date.now() + 1000;
        // startTimer(amountOfMinutes, button);
    }

    function createClockButton() {
        var parent = document.querySelector('#sprint-view > div.inner-container > div.view-state-initialized-visible.view-state-loading-visible.view-state-errored-visible.document-edit-state-hidden-visible > header > div:nth-child(3)');
        var amountOfMinutes = 60 * countdownMinutes,
            button = document.createElement("button");
        var text_node = document.createTextNode(" ");
        button.className = "btn";
        // button.textContent = text + " ";
        var style = "display: inline;float: right;"
        button.style = style;
        parent.append(button);
        var icon = document.createElement("i");
        button.appendChild(icon);
        button.append(text_node);
        startTimer(amountOfMinutes, button);
        return button;
    }

    window.onload = function() {
        var i = 0;
        //create the button for timer
        timerButton = createClockButton();
        timerButton.onclick = function() {
            loadClock(timerButton);
        };
        //update the button value
//        loadClock(timerButton);
    };

    var current_index = get_current_index();
    var sim_users = get_current_users();

    if (current_index === "") {
        GM_setValue(CURRENT_INDEX_KEY, 0);
    }
    if (sim_users === "" && !set) {
        // Too invasive will prompt user when he clicks on any button
        // set_initial_sim_array();
    }

    //$('.SIMUsersScript__faces').append(createResetButtonElement());
    //$('.SIMUsersScript__faces').append(createNobodyButtonElement());
    create_and_append_button("Team Members", click_edit_members, "icon-user", "Add or remove members to sprint randomizer");
    create_and_append_button("", click_shuffle, "icon-random", "Shuffle team array");
    create_and_append_button("Next", click_next, "icon-chevron-right", "Next team member");
    create_user_picture_button(sim_users[current_index], "Current: " + sim_users[current_index], click_previous, "icon-chevron-right", "Current team member", "green");
})();
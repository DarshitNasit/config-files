// ==UserScript==
// @name         Phonetool Overtime
// @description  Display time zone overlap on Phonetool
// @author       Casey Lee <caseypl@amazon.com>
// @version      1.9
// @grant        none
// @updateURL    https://axzile.corp.amazon.com/-/carthamus/download_script/phonetool-overtime.user.js
// @downloadURL  https://axzile.corp.amazon.com/-/carthamus/download_script/phonetool-overtime.user.js
// @match        https://phonetool.amazon.com/users/*
// @match        https://admindirectory.corp.amazon.com/users/*
// @run-at       document-idle
//
// ==/UserScript==
const localTimezoneOffset = -1 * new Date().getTimezoneOffset();
const localStartHour = 8;
const localEndHour = 17;

if($("div[data-react-class='UserDetails']").length == 1) {
    const userDetails = JSON.parse($("div[data-react-class='UserDetails']").attr("data-react-props")).targetUser;
    renderStyle();
    renderOverlap(userDetails);
}

function renderStyle() {
  $(`
    <style>
      .Overtime {
        display: flex;
        flex-direction: column;
      }
      .Overtime .OvertimeTitle {
        color: #555;
        font-weight: bold;
        text-transform: uppercase;
        font-size: 10px;
        flex: 1;
        display: flex;
        min-width: 110px;
        margin-right: 5px;
        justify-content: flext-end;
      }
      .Overtime .OvertimeTable {
        font-size: 12px;
        flex: 2;
        min-width: 190px;
        margin-left: 5px;
      }
      .Overtime .OvertimeRow {
        display: flex;
        flex-direction: row;
      }
      .Overtime .OvertimeTZ {
        flex: 1;
      margin-left: 10px;
        margin-right: 10px;
      min-width: 80px;
        flex-grow: 0;
      }
      .Overtime .OvertimePrefix {
        flex-grow: 0;
        flex-shrink: 0;
        justify-content: flex-end;
        display: flex;
        margin-right: 5px;


      }
      .Overtime .OvertimeChart {
        flex-grow: 0;
        flex-shrink: 0;
      }
      .Overtime .OvertimeSuffix {
        flex-grow: 0;
        flex-shrink: 0;
        justify-content: flex-start;
        display: flex;
      }
      .OvertimeFrom {
        color: #fff;
        font-weight: bold;
        float: left;
        margin-left: 5px;
      }
      .OvertimeTo {
        color: #fff;
        font-weight: bold;
        float: right;
        margin-right: 5px;
      }
    </style>
  `).appendTo('head');
}

function renderOverlap(userDetails) {
    const userTimezoneOffset = getUserTimezoneOffset(userDetails);
    const relativeOffset = localTimezoneOffset - userTimezoneOffset;
    //console.log(`localOffset:${localTimezoneOffset} userOffset:${userTimezoneOffset} relativeOffset:${relativeOffset}`);
    const localStart = localStartHour * 60;
    const localEnd = localEndHour * 60;
    let userStart = applyOffset(localStart, relativeOffset);
    let userEnd = applyOffset(localEnd, relativeOffset);
    //console.log(`local=${timeToStr(localStart)}-${timeToStr(localEnd)} user=${timeToStr(userStart)}-${timeToStr(userEnd)}`);


    let overlapStart;
    let overlapEnd;
    let userStartLabel = userStart;
    let userEndLabel = userEnd;
    if(userStart > userEnd) {
        if(userStart < localEnd) {
            overlapStart = userStart;
            overlapEnd = localEnd;
            userEndLabel = userEnd;
            userEnd = 23*60;
        } else if(userEnd > localStart) {
            overlapStart = localStart;
            overlapEnd = userEnd;
            userStartLabel = userStart;
            userStart = 0;
        } else {
            userStartLabel = userStart;
            userEndLabel = userEnd;
            userStart = localEnd + 60;
            userEnd = userStart + 60*(localEndHour-localStartHour);
            overlapStart = 0;
            overlapEnd = 0;
        }
    } else {
        overlapStart = Math.max(localStart, userStart);
        overlapEnd = Math.min(localEnd, userEnd);
    }


    $( ".UserDetailsTable" ).append(`
      <div class="Overtime">
        <div class="OvertimeTitle">Schedule Overlap:</div>
        <div class="OvertimeTable">
          <div class="OvertimeRow">
            <div class="OvertimeTZ">${localStart<=userStart?tzToStr(localTimezoneOffset):""}</div>
            <div class="OvertimePrefix" style="flex-basis:${minsToPixels(localStart-Math.min(localStart, userStart))}px"></div>
            <div class="OvertimeChart" style="flex-basis:${minsToPixels(localEnd-localStart)}px; background-color: #80ad40">
                <span class="OvertimeFrom">${timeToStr(localStart)}</span>
                <span class="OvertimeTo">${timeToStr(localEnd)}</span>
            </div>
            <div class="OvertimeTZ">${localStart>userStart?tzToStr(localTimezoneOffset):""}</div>
          </div>
          <div class="OvertimeRow">
            <div class="OvertimeTZ">&nbsp;</div>
            <div class="OvertimePrefix" style="flex-basis:${minsToPixels(overlapStart-Math.min(localStart,userStart))}px"></div>
            <div class="OvertimeChart" style="flex-basis:${minsToPixels(overlapEnd-overlapStart)}px; background-color: #b6e0ea"></div>
          </div>
          <div class="OvertimeRow">
            <div class="OvertimeTZ">${localStart>userStart?tzToStr(userTimezoneOffset):""}</div>
            <div class="OvertimePrefix" style="flex-basis:${minsToPixels(userStart-Math.min(localStart, userStart))}px"></div>
            <div class="OvertimeChart" style="flex-basis:${minsToPixels(userEnd-userStart)}px; background-color: #3788d8">
                <span class="OvertimeFrom">${timeToStr(userStartLabel)}</span>
                <span class="OvertimeTo">${timeToStr(userEndLabel)}</span>
              </div>
            <div class="OvertimeTZ">${localStart<=userStart?tzToStr(userTimezoneOffset):""}</div>
          </div>
        </div>
      </div>
    `);
}



//console.log(`local=${localStart}-${localEnd} user=${userStart}-${userEnd} overlap=${overlapStart}-${overlapEnd}`);

function applyOffset(referenceTime, offset) {
  const minsInDay = 24*60;
  let offsetTime = referenceTime + offset;
  if(offsetTime < 0) {
    offsetTime = offsetTime + minsInDay;
  } else if (offsetTime >= minsInDay) {
    offsetTime = offsetTime - minsInDay;
  }
  return offsetTime;
}

function timeToStr(t) {
  const tHour = String(Math.trunc(t/60)).padStart(2,'0');
  const tMin = String(t%60).padStart(2,'0');
  return `${tHour}:${tMin}`;
}
function tzToStr(t) {
  const op = (t < 0)?'-':'+';
  const tHour = String(Math.trunc(Math.abs(t)/60)).padStart(2,'0');
  const tMin = String(t%60).padStart(2,'0');
  return `UTC${op}${tHour}:${tMin}`;
}
function minsToPixels(m) {
  return 20*m/60
}

function getStateTimezoneOffset(state) {
  const States = {
      'Alaska': 'America/Anchorage',
      'Idaho': 'America/Boise',
      'Alabama': 'America/Chicago',
      'Arkansas': 'America/Chicago',
      'Illinois': 'America/Chicago',
      'Iowa': 'America/Chicago',
      'Kansas': 'America/Chicago',
      'Louisiana': 'America/Chicago',
      'Minnesota': 'America/Chicago',
      'Mississippi': 'America/Chicago',
      'Missouri': 'America/Chicago',
      'Nebraska': 'America/Chicago',
      'Oklahoma': 'America/Chicago',
      'South Dakota': 'America/Chicago',
      'Tennessee': 'America/Chicago',
      'Texas': 'America/Chicago',
      'Wisconsin': 'America/Chicago',
      'Colorado': 'America/Denver',
      'Montana': 'America/Denver',
      'New Mexico': 'America/Denver',
      'Utah': 'America/Denver',
      'Wyoming': 'America/Denver',
      'Michigan': 'America/Detroit',
      'Indiana': 'America/Indiana/Indianapolis',
      'Kentucky': 'America/Kentucky/Louisville',
      'California': 'America/Los_Angeles',
      'Nevada': 'America/Los_Angeles',
      'Oregon': 'America/Los_Angeles',
      'Washington': 'America/Los_Angeles',
      'Connecticut': 'America/New_York',
      'Deleware': 'America/New_York',
      'Florida': 'America/New_York',
      'Georgia': 'America/New_York',
      'Maine': 'America/New_York',
      'Maryland': 'America/New_York',
      'Massachusetts': 'America/New_York',
      'New Hampshire': 'America/New_York',
      'New Jersey': 'America/New_York',
      'New York': 'America/New_York',
      'N Carolina': 'America/New_York',
      'Ohio': 'America/New_York',
      'Pennsylvania': 'America/New_York',
      'Rhode Island': 'America/New_York',
      'S Carolina': 'America/New_York',
      'Vermont': 'America/New_York',
      'Virginia': 'America/New_York',
      'District of Columbia': 'America/New_York',
      'W Virginia': 'America/New_York',
      'North Dakota': 'America/North_Dakota/Center',
      'Arizona': 'America/Phoenix',
      'Hawaii': 'Pacific/Honolulu',
      'UK': 'Europe/London',
      'Germany': 'Europe/Berlin',
      'South Africa': 'Africa/Johannesburg',
      'Romania': 'Europe/Bucharest',
      'Poland': 'Europe/Warsaw',
      'Phillipines': 'Asia/Manila',
      'Costa Rica': 'America/Costa_Rica',
      'New Brunswick': 'America/Moncton'
  };
  if(state in States) {
    const timeZone = States[state];
    const now = new Date();
    const utcDate = new Date(now.toLocaleString('en-US', { timeZone: "UTC" }));
    const tzDate = new Date(now.toLocaleString("en-US", {timeZone}));
    const localTimezoneOffset = (tzDate.getTime() - utcDate.getTime()) / (60 * 1000);
    return localTimezoneOffset;
  }
  return null;
}

function getUserTimezoneOffset(userDetails) {
  const defaultTimezoneOffset = getStateTimezoneOffset('Washington');
  const userTimezoneParts = userDetails.targetUserUTCOffset.split(':');
  let userTimezoneOffset = (60 * userTimezoneParts[0]) + parseInt(userTimezoneParts[1]);

  const virtualMatch = userDetails.targetUserBuilding.match(/^Virtual Loc(ation)?[\s\(\-]*(.+?)(,.*)?\)?$/);
  if(virtualMatch && userTimezoneOffset == defaultTimezoneOffset) {
    const state = virtualMatch[2];
    console.log(`Virtual state: ${state}`);
    const offset = getStateTimezoneOffset(state);
    if(offset !== null) {
      userTimezoneOffset = offset;
    }
  }
  return userTimezoneOffset;
}
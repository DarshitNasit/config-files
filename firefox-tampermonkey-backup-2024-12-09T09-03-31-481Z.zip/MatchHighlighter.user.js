// ==UserScript==
// @name         MatchHighlighter
// @namespace    com.amazon.dpsinha.greasermonkey
// @version      0.1
// @description  This script highlights the select text in the current browser page and copies it automatically
// @author       dpsinha
// @match        https://code.amazon.com/*
// @match        https://w.amazon.com/*
// ==/UserScript==
// Add styles for both types of highlights
const style = document.createElement('style');
style.textContent = `
  .highlighted-exact { background-color: orange; }
  .highlighted-ignorecase { background-color: yellow; }
`;
document.head.appendChild(style);

document.addEventListener('mouseup', async function() {
    const selection = window.getSelection();
    const selectedText = selection.toString().trim();

    if (selectedText) {
        // Check if selection is within an editable element (textarea, input)
        const activeElement = document.activeElement;
        const isEditable = activeElement && ['TEXTAREA', 'INPUT'].includes(activeElement.tagName.toUpperCase());

        highlightText(document.body, selectedText);

        if (!isEditable) {
            try {
                // Attempt to copy the selected text to the clipboard
                await navigator.clipboard.writeText(selectedText);
                console.log("Text copied to clipboard");
            } catch (err) {
                console.error("Failed to copy text: ", err);
            }
        } else {
            // Don't highlight or copy if selection is within an editable element
            console.log("Selection is within an editable element, not copying.");
        }
    } else {
        removeHighlights();
    }
});

function highlightText(node, text) {
    if (node.nodeType === 3) { // Text node
        const nodeValue = node.nodeValue;
        const regex = new RegExp(`(${text})`, 'gi'); // Global, case insensitive search
        const matches = nodeValue.match(regex);

        if (matches && matches.length > 0) {
            const parentNode = node.parentNode;
            let startIndex = 0;
            let remainingText = nodeValue;

            matches.forEach(match => {
                const index = remainingText.indexOf(match);
                const beforeMatch = remainingText.substring(0, index);
                const afterMatch = remainingText.substring(index + match.length);

                if (beforeMatch.length > 0) {
                    parentNode.insertBefore(document.createTextNode(beforeMatch), node);
                }

                const highlightSpan = document.createElement('span');
                highlightSpan.className = match === text ? 'highlighted-exact' : 'highlighted-ignorecase';
                highlightSpan.textContent = match;
                parentNode.insertBefore(highlightSpan, node);

                remainingText = afterMatch;
                startIndex += index + match.length;
            });

            if (remainingText.length > 0) {
                parentNode.insertBefore(document.createTextNode(remainingText), node);
            }

            parentNode.removeChild(node);
        }
    } else if (node.nodeType === 1 && node.childNodes && !['SCRIPT', 'STYLE', 'TEXTAREA'].includes(node.tagName)) { // Element node but not script/style/textarea
        Array.from(node.childNodes).forEach(child => highlightText(child, text));
    }
}

function removeHighlights() {
    const highlightedSpans = document.querySelectorAll('.highlighted-exact, .highlighted-ignorecase');
    highlightedSpans.forEach(span => {
        const parent = span.parentNode;
        parent.replaceChild(document.createTextNode(span.textContent), span);
        parent.normalize(); // Merge adjacent text nodes
    });
}
// ==UserScript==
// @name           GK Pipelines
// @namespace      http://tampermonkey.net/
// @version        0.8
// @description    Show useful GK results on pipelines.
// @author         lewisjb, anksingh
// @match          https://pipelines.amazon.com/pipelines/*
// @icon           https://pipelines.amazon.com/favicon.ico
// @grant          GM_xmlhttpRequest
// @connect        tim-files.amazon.com
// @updateURL      https://axzile.corp.amazon.com/-/carthamus/download_script/gk-pipelines.user.js
// @downloadURL    https://axzile.corp.amazon.com/-/carthamus/download_script/gk-pipelines.user.js
// ==/UserScript==

(function() {
    'use strict';

    // Shared Variables
    const sharedBadgeCss = "font-size: 8pt; font-family: monospace; display: inline-block; color: white; border-radius: 2px; padding: 0.2em;";
    const sharedTextCss = "font-size: 8pt; padding-right: 0.4em; vertical-align: middle;";
    const showEnforcedViolations = 'GKPipelines.ShowEnforcedViolations';

    function removeReferer(url) {
        return url.split("?referer")[0];
    }

    // GK Test Run Information Extraction Helper Methods
    function getGKTestRunResultUrl(gkStep) {
        const todUrl = gkStep.querySelector("a").href;
        const sanitizedTodUrl = removeReferer(todUrl);
        const split = sanitizedTodUrl.split("/");
        const runId = split[split.length -1];
        return `https://tim-files.amazon.com/amazon.qtt.tod/runs/${runId}/brazil-Gordian_Knot-tests`;
    }

    function getGKTestRunTodUrl(gkStep) {
        return gkStep.querySelector("a").href;
    }

    function getGKStepName(gkStep) {
        return gkStep.getAttribute('data-step-name');
    }

    function getGKTestRunStatus(gkStep) {
        const statusLabel = gkStep.querySelector("span[class^='status-']").innerText.trim().toLowerCase();

        return statusLabel;
    }

    // Browser Cookie Helper Methods
    function setCookie(name, value, expirationDays) {
        const expirationDate = new Date();
        expirationDate.setTime(expirationDate.getTime() + (expirationDays*24*60*60*1000));
        let expiresAt = "expires="+ expirationDate.toUTCString();
        document.cookie = name + "=" + value + ";" + expiresAt + ";path=/";
    }

    function getCookie(name) {
        let identifier = name + "=";
        let decodedCookie = decodeURIComponent(document.cookie);
        let cookies = decodedCookie.split(';');

        for(let i = 0; i < cookies.length; i++) {
            let cookie = cookies[i];
            while (cookie.charAt(0) == ' ') {
                cookie = cookie.substring(1);
            }
            if (cookie.indexOf(name) == 0) {
                return cookie.substring(name.length + 1, cookie.length);
            }
        }

        return null;
    }

    // Get Test Run Details and Convert Into GK Result Info object
    function getGKResultInfo(gkStep, index) {
        const gkTestRunResultUrl = getGKTestRunResultUrl(gkStep);
        const gkTestRunstatus = getGKTestRunStatus(gkStep);
        const gkTestRunTodUrl = getGKTestRunTodUrl(gkStep);
        const gkStepName = getGKStepName(gkStep);

        var parser = new DOMParser();
        var indexUrl = `${gkTestRunResultUrl}/index.html`
        var inputs = new Promise((res, rej) => {
            GM_xmlhttpRequest({
                method: 'GET',
                headers: {
                    "Content-Type": "application/json"
                },
                url: `${gkTestRunResultUrl}/tod.json`,
                onload: (data) => {
                    res(JSON.parse(data.response));
                }
            });
        }).then((json) => {
            let packagesToExcludeByViolationType;
            if (json.args.DependentPackageMajorVersionsToExcludeByViolationType) {
                packagesToExcludeByViolationType = json.args.DependentPackageMajorVersionsToExcludeByViolationType.replaceAll(' ', '').replaceAll('\n', '').replaceAll('\r', '');
                packagesToExcludeByViolationType = packagesToExcludeByViolationType.substring(1, packagesToExcludeByViolationType.length - 1);
            }

            const packagesToExcludeByViolationTypeMap = new Map();
            if (packagesToExcludeByViolationType) {
                let splits = [];
                let previousStart = 0;

                for (let i = 0; i <packagesToExcludeByViolationType.length; i++) {
                    if (packagesToExcludeByViolationType[i] === "]") {
                        splits.push(packagesToExcludeByViolationType.substring(previousStart, i + 1));
                        previousStart = i + 1;
                    }
                }

                splits
                    .forEach((packagesToExcludeWithViolationType) => {
                        const rawKeyValue = packagesToExcludeWithViolationType.split(':');
                        const key = rawKeyValue[0];
                        const value = rawKeyValue[1].substring(1, rawKeyValue[1].length - 1).split(',');
                        packagesToExcludeByViolationTypeMap.set(key, value);
                });
            }

            const excludedPackageMajorVersions = json.args.ExcludePackageMajorVersions ? json.args.ExcludePackageMajorVersions.replaceAll('\n', '').replaceAll('\r', '').split(',') : [];
            const packagesToScan = json.args.ScanPackageMajorVersions ? json.args.ScanPackageMajorVersions.replaceAll(' ', '').replaceAll('\n', '').replaceAll('\r', '').split(',') : [];;

            return {
                stepIndex: index,
                stepName: gkStepName,
                status: gkTestRunstatus,
                assertLevel: json.args.ScanProfileName.split("-")[1],
                packagesToScan: packagesToScan,
                packagesToExcludeByViolationType: packagesToExcludeByViolationTypeMap,
                excludedPackageMajorVersions: excludedPackageMajorVersions,
                todUrl: gkTestRunTodUrl
            };
        });
        var outputs = new Promise((res, rej) => {
            GM_xmlhttpRequest({
                method: 'GET',
                headers: {
                    "Content-Type": "application/json"
                },
                url: indexUrl,
                onload: (data) => {
                    res(parser.parseFromString(data.response, 'text/html'));
                }
            });
        }).then((doc) => {
            const showEnforcedViolationsValue = getCookie(showEnforcedViolations) === 'true';
            const high = Array.from(doc.querySelectorAll('.HIGH'));
            const medium = Array.from(doc.querySelectorAll('.MEDIUM'));
            const low = Array.from(doc.querySelectorAll('.LOW'));

            return {
                high: showEnforcedViolationsValue ? high.filter((element) => !element.querySelector('.notEnforced')).length : high.length,
                medium: showEnforcedViolationsValue ? medium.filter((element) => !element.querySelector('.notEnforced')).length : medium.length,
                low: showEnforcedViolationsValue ? low.filter((element) => !element.querySelector('.notEnforced')).length : low.length
            };
        });

        return Promise.all([inputs, outputs]).then((values) => {
            return {...values[0], ...values[1], url: indexUrl};
        });
    }

    // View Helper Methods
    function createGKInfoContainer(info) {
        const expandContainer = document.createElement("div");
        expandContainer.id = 'gkExpandContainer' + info.stepIndex;
        expandContainer.classList = 'workflow expand-container';

        const expandIndicator = document.createElement('a');
        expandIndicator.id = 'gkExpandIndicator';
        expandIndicator.classList = 'expand-indicator open';
        expandIndicator.onclick = function() {
            const gkExpandIndicator = document.querySelector('#gkExpandContainer' + info.stepIndex).querySelector('#gkExpandIndicator');
            const gkExpandableSection = document.querySelector('#gkExpandContainer' + info.stepIndex).querySelector('#gkExpandableSection');

            if (gkExpandIndicator.classList.contains('open')) {
                gkExpandIndicator.classList.remove('open');
            } else {
                gkExpandIndicator.classList.add('open');
            }

            if (gkExpandableSection.style.display === 'none') {
                gkExpandableSection.style.display = 'block';
            } else {
                gkExpandableSection.style.display = 'none';
            }
        };

        const header = document.createElement('div');
        header.classList = 'workflow-header';

        const headerH3 = document.createElement('h3');
        headerH3.classList = '';

        const headerH3Title = document.createElement('a');
        headerH3Title.classList = 'expand-control';
        headerH3Title.innerText = info.stepName;
        headerH3Title.onclick = function() {
            const gkExpandIndicator = document.querySelector('#gkExpandContainer' + info.stepIndex).querySelector('#gkExpandIndicator');
            const gkExpandableSection = document.querySelector('#gkExpandContainer' + info.stepIndex).querySelector('#gkExpandableSection');

            if (gkExpandIndicator.classList.contains('open')) {
                gkExpandIndicator.classList.remove('open');
            } else {
                gkExpandIndicator.classList.add('open');
            }

            if (gkExpandableSection.style.display === 'none') {
                gkExpandableSection.style.display = 'block';
            } else {
                gkExpandableSection.style.display = 'none';
            }
        };

        headerH3.appendChild(headerH3Title);
        header.appendChild(headerH3);

        const body = document.createElement("div");
        body.id = 'gkExpandableSection';
        body.style.display = 'block';
        body.classList = 'workflow_steps expandable';

        const resultBodyList = document.createElement('ul');
        resultBodyList.style.marginTop = '0em';

        resultBodyList.appendChild(createMainResult(info));

        const packagesToScan = createPackageSection('Scanned Packages', info.packagesToScan, info.stepIndex, info.status);

        if (packagesToScan) {
            resultBodyList.appendChild(packagesToScan);
        }

        const excludedPackageSection = createPackageSection('Excluded Packages', info.excludedPackageMajorVersions, info.stepIndex, info.status);

        if (excludedPackageSection) {
            resultBodyList.appendChild(excludedPackageSection);
        }

        info.packagesToExcludeByViolationType.forEach((packageList, type) => {
            const packageSection = createPackageSection(type.replace(/([A-Z])/g, ' $1'), packageList, info.stepIndex, info.status);

            if (packageSection) {
                resultBodyList.appendChild(packageSection);
            }
        });

        body.appendChild(resultBodyList);

        expandContainer.appendChild(expandIndicator);
        expandContainer.appendChild(header);
        expandContainer.appendChild(body);

        return expandContainer;
    }

    function createMainResult(info) {
        const resultBody = document.createElement('li');
        resultBody.classList.add('workflow_step');

        if (info.status === 'succeeded') {
            resultBody.classList.add('workflow-step-succeeded');
        } else if (info.status === 'failed') {
            resultBody.classList.add('workflow-step-failed');
        }

        resultBody.style.marginTop = '0.4em';

        resultBody.appendChild(createGKInfoViewFromGKInfo(info));

        return resultBody;
    }

    function createPackageSection(type, list, index, status) {
        if (list && list.length > 0) {
            const resultBody = document.createElement('li');
            resultBody.classList.add('workflow_step');

            if (status === 'succeeded') {
                resultBody.classList.add('workflow-step-succeeded');
            } else if (status === 'failed') {
                resultBody.classList.add('workflow-step-failed');
            }

            resultBody.style.backgroundColor = 'whitesmoke';
            resultBody.style.padding = '0.4em 0 0.4em 0.4em';
            resultBody.style.marginTop = '0.4em';

            const indicatorId = 'gk' + type.replaceAll(' ', '') + 'ExpandIndicator' + index;
            const headerId = 'gk' + type.replaceAll(' ', '') + 'Header' + index;

            const expandIndicator = document.createElement('a');
            expandIndicator.id = indicatorId;
            expandIndicator.classList = 'expand-indicator';
            expandIndicator.onclick = function() {
                const expandIndicator = document.querySelector('#' + indicatorId);
                const expandableSection = document.querySelector('#' + headerId);

                if (expandIndicator.classList.contains('open')) {
                    expandIndicator.classList.remove('open');
                } else {
                    expandIndicator.classList.add('open');
                }

                if (expandableSection.style.display === 'none') {
                    expandableSection.style.display = 'block';
                } else {
                    expandableSection.style.display = 'none';
                }
            };

            const header = document.createElement('div');
            header.classList = 'workflow-header';

            const headerH3 = document.createElement('h3');
            headerH3.classList = '';

            const headerH3Title = document.createElement('a');
            headerH3Title.classList = 'expand-control';
            headerH3Title.style.fontSize = '7pt';
            headerH3Title.innerText = type + ' (' + list.length + ')';
            headerH3Title.onclick = function() {
                const expandIndicator = document.querySelector('#' + indicatorId);
                const expandableSection = document.querySelector('#' + headerId);

                if (expandIndicator.classList.contains('open')) {
                    expandIndicator.classList.remove('open');
                } else {
                    expandIndicator.classList.add('open');
                }

                if (expandableSection.style.display === 'none') {
                    expandableSection.style.display = 'block';
                } else {
                    expandableSection.style.display = 'none';
                }
            };

            headerH3.appendChild(headerH3Title);
            header.appendChild(headerH3);

            const container = document.createElement("div");
            container.id = headerId;
            container.style.display = 'none';

            const resultStatus = document.createElement('ul');
            resultStatus.classList.add('status-in-progress');
            resultStatus.style.margin = '0.2em';

            list.forEach((packageMajorVersion) => {
                const packageItem = document.createElement('li');

                const packageTitle = document.createElement('a');
                packageTitle.classList = 'expand-control';
                packageTitle.style.fontSize = '7pt';
                packageTitle.innerText = packageMajorVersion;
                packageTitle.href = 'https://code.amazon.com/packages/' + packageMajorVersion.substring(0, packageMajorVersion.lastIndexOf('-')) + '/releases';

                packageItem.appendChild(packageTitle);

                resultStatus.appendChild(packageItem);
            });

            container.appendChild(resultStatus);

            resultBody.appendChild(expandIndicator);
            resultBody.appendChild(header);
            resultBody.appendChild(container);

            return resultBody;
        }

        return null;
    }

    function createGKAssertLevelContainer(info) {
        const gkAssertLevelContainer = document.createElement("div");
        gkAssertLevelContainer.colSpan = 3;

        const gkAssertLevelTitle = document.createElement("span");
        gkAssertLevelTitle.style = `${sharedTextCss} font-size: 9pt;`;
        gkAssertLevelTitle.innerText = "Assert: ";

        const gkAssertLevel = document.createElement("span");
        const gkAssertLevelBackgroundColor = info.assertLevel === 'high' ? '#dc3545' : info.assertLevel === 'medium' ? '#ffc107' : '#6c757d';
        gkAssertLevel.style = `${sharedBadgeCss} font-size: 9pt; background-color: ${gkAssertLevelBackgroundColor};`;
        const gkAssertLevelText = info.assertLevel.charAt(0).toUpperCase() + info.assertLevel.slice(1);
        gkAssertLevel.innerText = gkAssertLevelText;

        gkAssertLevelContainer.appendChild(gkAssertLevelTitle);
        gkAssertLevelContainer.appendChild(gkAssertLevel);

        return gkAssertLevelContainer;
    }

    function exclusionSectionExpand(type) {
        const expandIndicator = document.querySelector(`#${type}Exclusion`);

        if (expandIndicator.classList.contains('open')) {
            expandIndicator.classList.remove('open');
        } else {
            expandIndicator.classList.add('open');
        }
    }

    function addExclusionSection(type, packageList) {
        const expandIndicator = document.createElement('a');
        expandIndicator.id = `${type}Exclusion`;
        expandIndicator.classList = 'expand-indicator open';
        expandIndicator.onclick = exclusionSectionExpand;

        return expandIndicator;
    }

    function createWithEnforcedViolationsCheckbox() {
        const container = document.createElement('div');

        const checkbox = document.createElement('input');
        const showEnforcedViolationsValue = getCookie(showEnforcedViolations) === 'true';

        checkbox.type = 'checkbox';
        checkbox.checked = showEnforcedViolationsValue;
        checkbox.style.margin = '0.2em 0.2em 0.2em 0em';
        checkbox.onclick = function() {
            if (this.checked) {
                setCookie(showEnforcedViolations, true, 180);
            } else {
                setCookie(showEnforcedViolations, false, 180);
            }

            location.reload();
        };

        const label = document.createElement('span');
        label.style = sharedTextCss;
        label.innerText = 'Show Enforced Only';

        container.appendChild(checkbox);
        container.appendChild(label);

        return container;
    }

    function createGKInfoViewFromGKInfo(info) {
        const tableCss = "width: 100%;"

        const gkInfoContainer = document.createElement("div");

        const resultTable = document.createElement("table");
        resultTable.style = tableCss;

        const resultTableBody = document.createElement("tbody");
        const resultRow = document.createElement("tr");

        const resultHighCell = document.createElement("td");

        const highText = document.createElement("span");
        highText.style = sharedTextCss;
        highText.innerText = "High";

        const highBadge = document.createElement("span");
        highBadge.style = `${sharedBadgeCss} background-color: #dc3545;`;
        highBadge.innerText = `${info.high}`;

        resultHighCell.appendChild(highText);
        resultHighCell.appendChild(highBadge);

        const resultMediumCell = document.createElement("td");

        const mediumText = document.createElement("span");
        mediumText.style = sharedTextCss;
        mediumText.innerText = "Med";

        const mediumBadge = document.createElement("span");
        mediumBadge.style = `${sharedBadgeCss} background-color: #ffc107;`;
        mediumBadge.innerText = `${info.medium}`;

        resultMediumCell.appendChild(mediumText);
        resultMediumCell.appendChild(mediumBadge);

        const resultLowCell = document.createElement("td");

        const lowText = document.createElement("span");
        lowText.style = sharedTextCss;
        lowText.innerText = "Low";

        const lowBadge = document.createElement("span");
        lowBadge.style = `${sharedBadgeCss} background-color: #6c757d;`;
        lowBadge.innerText = `${info.low}`;

        resultLowCell.appendChild(lowText);
        resultLowCell.appendChild(lowBadge);

        resultRow.appendChild(resultHighCell);
        resultRow.appendChild(resultMediumCell);
        resultRow.appendChild(resultLowCell);

        resultTableBody.appendChild(resultRow);
        resultTable.appendChild(resultTableBody);

        const resultStatus = document.createElement('span');
        resultStatus.classList.add(info.status === 'succeeded' ? 'status-succeeded' : info.status === 'failed' ? 'status-failed' : 'status-in-progress')
        resultStatus.innerText = info.status.charAt(0).toUpperCase() + info.status.slice(1) + ' - ';

        const resultLink = document.createElement('a');
        resultLink.href = info.todUrl;
        resultLink.innerText = 'view results';

        resultStatus.appendChild(resultLink);

        gkInfoContainer.appendChild(resultStatus);
        gkInfoContainer.appendChild(createGKAssertLevelContainer(info));
        gkInfoContainer.appendChild(createWithEnforcedViolationsCheckbox());
        gkInfoContainer.appendChild(resultTable);

        return gkInfoContainer;
    }

    function injectGKResultView() {
        const vsSteps = document.querySelectorAll("#stage-name-VersionSet .workflow_step");

        vsSteps.forEach((vsStep, index) => {
            try {
                getGKResultInfo(vsStep, index).then((gkResultInfo) => {
                    return createGKInfoContainer(gkResultInfo);
                }).then((gkResultView) => {
                    const versionSetWorkflow = document.querySelector("#stage-name-VersionSet .workflows");

                    versionSetWorkflow.insertBefore(gkResultView, versionSetWorkflow.children[1]);
                });
            } catch (error) {
                console.log(vsStep + " is not a GK Step");
            }
        });
    }

    injectGKResultView();
})();

// ==UserScript==
// @name        Clean SIMVerification Link
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/Clean_SIMV_Link_Pipelines.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/Clean_SIMV_Link_Pipelines.user.js
// @namespace   benclive@amazon.com
// @description Cleans up the SIM Verification Link in pipelines. Shamelessly copied from the "Clean CRV Link" script by ducrou@
// @include     https:/pipelines.amazon.com/pipelines/*
// @version     1.0
// @grant       none
// ==/UserScript==

var link = document.evaluate(
            "//a[@href='https://w.amazon.com/index.php/SIMVerification/Help']",
            document,
            null,
            XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
            null);

if (link.snapshotLength > 0) {
  var changes = link.snapshotItem(0).innerHTML.match(/\b\w+\/\w+@\w+\b/g);
  var containerDiv = document.createElement('div');
  containerDiv.innerHTML += '<b>Offending Commits:</b><br/>';

  link.snapshotItem(0).parentNode.appendChild(containerDiv);
  link.snapshotItem(0).innerHTML='';

  for (var i = 0; i < changes.length; ++i) {
    var pkg = changes[i].substring(0,changes[i].indexOf('/'));
    var commit = changes[i].substring(changes[i].indexOf('@')+1);
    var link = 'https://code.amazon.com/packages/' + pkg + '/commits/' + commit;
    containerDiv.innerHTML += "<a href='" + link + "'>" + pkg + '</a><br/>';
  }
}


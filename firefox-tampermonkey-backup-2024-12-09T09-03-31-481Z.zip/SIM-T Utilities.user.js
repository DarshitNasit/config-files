// ==UserScript==
// @name         SIM-T Utilities
// @namespace    http://tampermonkey.net/
// @downloadURL https://drive.corp.amazon.com/view/lukasjoh@/SIMTUtilities/SIM-TUtilities.user.js
// @updateURL https://drive.corp.amazon.com/view/lukasjoh@/SIMTUtilities/SIM-TUtilities.user.js
// @version      4.7
// @description  Adds several one-click buttons for SIM-T, bulk relate, and other improvements. [REPORTS ANALYTICS]
// @author       lukasjoh
// @match        https://t.corp.amazon.com/*
// @connect       0s62bmu3aj.execute-api.us-east-1.amazonaws.com
// @connect       s3-us-west-2.amazonaws.com
// @connect       maxis-service-prod-iad.amazon.com
// @connect       sim-ticketing-graphql-fleet.corp.amazon.com
// @connect       wfa-api-integ.iad.proxy.amazon.com
// @include       https://maxis-service-prod-iad.amazon.com/*
// @grant         GM_xmlhttpRequest
// @grant         GM.xmlHttpRequest
// ==/UserScript==

// For questions or bug reports, please Slack or Chime me at lukasjoh
// I maintain this script in my free time so new feature requests or bug fixes may take some time to add.

// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// ANALYTIC COLLECTON DISCLOSURE:
//
// This script collects some basic analytics to better understand version distribution, functionality use, and troubleshoot issues.
// The following information is collected to an Amazon internal metric collection website when this script is ran: username, script version, ticketID, button clicked, and success/fail state of button.
// These metrics greatly help with understanding script usage, feature usage, tracking issues, and justifying additional time spent working on improving this script
//
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


// This script adds five one-click buttons to the SIM-T interface. It also adds a bulk relate option to the bulk edit screen.
// WIP - Sets ticket to work in progress, assigns it to you, adds 5 minutes to time spent, and adds "Taking a look..." to the correspondence (by default).
// Researching - Sets the ticket to Researching, assigns it to you, adds 5 minutes to time spent, and adds "Researching..." to the correspondence (by default).
// Pending AoT - Sets the ticket to Pending Arrival of Technician, assigns it to you, adds 5 minutes to time spent, and adds "Pending arrival of technican" to the correspondence (by default).
// Reassign to Requester - Reassigns the ticket to the requester, sets the status to "assigned", and adds "Reassigning to requester" to the correspondence (by default).
// Pending Schedule - Sets the ticket to Pending Schedule, assigns it to you, adds 5 minutes to time spent, and adds "Pending Schedule." to the ticket correspondence (by default).

// Future additions/known bugs:
// Unable to use buttons on a ticket thats in the "resolved" state. Need to investigate to figure out what API changes need to be done when a ticket is resolved.
// Planned feature - Add more bulk edit options, such as bulk location updates, and improve bulk relate to be more reliable.

// Version 4.7 - Added time spent ticket modification, with 5 minutes being added to any ticket where wip, researching, or pAoT is clicked. This associates work spent on the ticket with your user and allows you to close the ticket without appending additional effort in CTI's requiring time spent.
//             | Added Pending Schedule button, credit to Kevin Maxfield for the idea and the button code.
//             | Fixed some variable scoping issues, guid creation issues, and small bug fixes.
// Version 4.6.2 - Updated url to update from EnvNinjas - Wrapping into 4.7
// Version 4.6.1 - Added graphql endpoint to connect attribute for API requests to succeed. - Wrapping into 4.7
// Version 4.6 - Resolved bug where manual setting of status to pending (any reason) breaks subsecuent status updates using the one click buttons.
// Version 4.5 - (BETA) Added bulk relate functionality, also changed the way metrics are collected as t.corp changed their CSP settings, disabling the old way that the script collected analytics.
// Version 4 - Added reassign to requester button.
//           | Added settings menu where you can enable or disable buttons, as well as modify the default messages posted to correspondence on the ticket.
//           | Added in some analytic collection for tracking this scripts usage as well as button failures.
// Version 3 - Fixed an issue where the element storing the current username changed.
// Version 2 - Modified buttons to reload the page upon successful status update.
// Version 1 - Initial creation, wip, researching, and pendingAoT buttons added.

var localstore = window.localStorage;
var version = GM_info.script.version;

// SIM API url
var simApiUrl = "https://maxis-service-prod-iad.amazon.com/";
var graphqlUrl = "https://sim-ticketing-graphql-fleet.corp.amazon.com/graphql"
var WFAUrl = "https://wfa-api-integ.iad.proxy.amazon.com";

waitForElementToDisplay(".issue-static-container", function(){
    addButtons();
},200, 5000);

waitForElementToDisplay(".sim-timeSpent.sim-bulkEditForm--timeSpent", function(){
    addBulkEditButton();
},200, 5000);

// Create an event listener for when the user clicks on something on the page.
window.onclick = e => {
    waitForElementToDisplay(".issue-static-container", function(){
        addButtons();
    },200, 2000);
    waitForElementToDisplay(".sim-timeSpent.sim-bulkEditForm--timeSpent", function(){
        addBulkEditButton();
    },200, 5000);
}

// Run this on page load to ensure configuration is setup.

(function(){
    if(localstore.getItem("wipEnable") == null || localstore.getItem("rEnable") == null || localstore.getItem("PAOTEnable") == null || localstore.getItem("pScheduleEnable") == null || localstore.getItem("rTrEnable") == null){
        localstore.setItem("wipEnable", "1");
        localstore.setItem("rEnable", "1");
        localstore.setItem("PAOTEnable", "1");
        localstore.setItem("pScheduleEnable", "1");
        localstore.setItem("rTrEnable", "1");
    }
    if(localstore.getItem("wipMessage") == null || localstore.getItem("researchMessage") == null || localstore.getItem("PAOTMessage") == null || localstore.getItem("rTrMessage") == null){
        localstore.setItem("wipMessage", "Taking a look...");
        localstore.setItem("researchMessage", "Researching...");
        localstore.setItem("PAOTMessage", "Pending arrival of technician.");
        localstore.setItem("rTrMessage", "Reassigning to requester.");
    }
    if(localstore.getItem("pScheduleMessage") == null){ // Dont nuke the other custom messages if the user upgrades versions. Only create this key.
        localstore.setItem("pScheduleMessage", "Pending Schedule");
    }
})();

// Add the buttons to SIM-T

function addButtons(){
    if(document.getElementById("simtutilitiestm") != null){
        return;
    }
    var login = document.querySelector('.sim-navDropdown--user').innerText.slice((document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf('(')+1), (document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf(')')));
    var loginIdentity = "kerberos:" + login + "@ANT.AMAZON.COM"; // TODO: This could be problematic. I am unsure if all users are using Kerberos auth. This isnt an ideal way of doing things but will probably work for 95% of people using this script. Hopefully.
    var requester = "kerberos:" + document.querySelector('.requester').innerText.split('\n')[1] + "@ANT.AMAZON.COM";
    var topContainer = document.querySelector(".issue-static-container");
    var buttonDiv = document.createElement("div");
    buttonDiv.id = "simtutilitiestm";
    buttonDiv.style.border = "2px solid grey";
    buttonDiv.style.borderRadius = "5px";
    buttonDiv.style.padding = "2px";
    buttonDiv.style.display = "inline-block";

    // Work in progress
    var wipButton = document.createElement("button");
    wipButton.setAttribute("class", "awsui-button awsui-button-variant-primary awsui-hover-child-icons");
    wipButton.innerText = "WIP";
    wipButton.style.margin = '0px 5px 0px 0px';
    wipButton.onclick = function(){
        updateTicket("Work In Progress", null, null, loginIdentity, null, localstore.getItem("wipMessage"), 5, (function responseFunction(returnMsg){
            if(returnMsg){
                addSIMMetrics("wip", "1");
                alert(returnMsg)
            }else{
                addSIMMetrics("wip", "0");
                setTimeout(function() {
                    window.location.reload(true);
                }, 600); // Wait 600ms before saving to load metric endpoint.
            }
        }))
    };

    // Researching
    var researchingButton = document.createElement("button");
    researchingButton.setAttribute("class", "awsui-button awsui-button-variant-primary awsui-hover-child-icons");
    researchingButton.innerText = "Researching";
    researchingButton.style.margin = '0px 5px 0px 5px';
    researchingButton.onclick = function(){updateTicket("Researching", null, null, loginIdentity, null, localstore.getItem("researchMessage"), 5, (function responseFunction(returnMsg){
            if(returnMsg){
                addSIMMetrics("researching", "1");
                alert(returnMsg)
            }else{
                addSIMMetrics("researching", "0");
                setTimeout(function() {
                    window.location.reload(true);
                }, 600); // Wait 600ms before saving to load metric endpoint.
            }
        }))
    };

    // Pending Arrival of Technician
    var pendingAOT = document.createElement("button");
    pendingAOT.setAttribute("class", "awsui-button awsui-button-variant-primary awsui-hover-child-icons");
    pendingAOT.innerText = "Pending AoT";
    pendingAOT.style.margin = '0px 5px 0px 5px';
    pendingAOT.onclick = function(){updateTicket("Pending", "Arrival of Technician", null, loginIdentity, null, localstore.getItem("PAOTMessage"), 5, (function responseFunction(returnMsg){
            if(returnMsg){
                addSIMMetrics("PAOT", "1");
                alert(returnMsg)
            }else{
                addSIMMetrics("PAOT", "0");
                setTimeout(function() {
                    window.location.reload(true);
                }, 600); // Wait 600ms before saving to load metric endpoint.
            }
        }))
    };

    // Pending Schedule
    var pScheduleButton = document.createElement("button");
    pScheduleButton.setAttribute("class", "awsui-button awsui-button-variant-primary awsui-hover-child-icons");
    pScheduleButton.innerText = "Pending Schedule";
    pScheduleButton.style.margin = '0px 5px 0px 0px';
    pScheduleButton.onclick = function(){updateTicket("Pending", "Schedule", null, loginIdentity, null, localstore.getItem("pScheduleMessage"), 5, (function responseFunction(returnMsg){
            if(returnMsg){
                addSIMMetrics("pSchedule", "1");
                alert(returnMsg)
            }else{
                addSIMMetrics("PSchedule", "0");
                setTimeout(function() {
                    window.location.reload(true);
                }, 600); // Wait 600ms before saving to load metric endpoint.
            }
        }))
    };

    // Reassign to Requester
    var reassignToReq = document.createElement("button");
    reassignToReq.setAttribute("class", "awsui-button awsui-button-variant-primary awsui-hover-child-icons");
    reassignToReq.innerText = "Reassign to Requester";
    reassignToReq.style.margin = '0px 5px 0px 5px';
    reassignToReq.onclick = function(){updateTicket("Assigned", null, null, requester, null, localstore.getItem("rTrMessage"), null, (function responseFunction(returnMsg){
            if(returnMsg){
                addSIMMetrics("rTr", "1");
                alert(returnMsg)
            }else{
                addSIMMetrics("rTr", "0");
                setTimeout(function() {
                    window.location.reload(true);
                }, 600); // Wait 600ms before saving to load metric endpoint.
            }
        }))
    };


    var settings = document.createElement("button");
    settings.innerText = "Settings";
    settings.style.align = "right";
    settings.style.margin = '0px 5px 0px 15px';
    settings.onclick = settingsPanel;

    // Append buttons
    if(localstore.getItem("wipEnable") == "1"){
        buttonDiv.appendChild(wipButton);
    }
    if(localstore.getItem("rEnable") == "1"){
        buttonDiv.appendChild(researchingButton);
    }
    if(localstore.getItem("PAOTEnable") == "1"){
        buttonDiv.appendChild(pendingAOT);
    }
    if(localstore.getItem("pScheduleEnable") == "1"){
        buttonDiv.appendChild(pScheduleButton);
    }
    if(localstore.getItem("rTrEnable") == "1"){
        buttonDiv.appendChild(reassignToReq);
    }
    buttonDiv.appendChild(settings);
    topContainer.insertBefore(buttonDiv, topContainer.firstChild);
}

// Bulk edit tools (bulk relate):

function addBulkEditButton(){
    if(document.getElementById("simtutilitiestm-bulkedit") != null){
        return;
    }
    console.log("Adding bulk edit buttons");
    var login = document.querySelector('.sim-navDropdown--user').innerText.slice((document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf('(')+1), (document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf(')')));
    var loginIdentity = "kerberos:" + login + "@ANT.AMAZON.COM"; // TODO: This could be problematic. I am unsure if all users are using Kerberos auth. This isnt an ideal way of doing things but will probably work for 95% of people using this script. Hopefully.
    var topContainer = document.querySelector(".sim-timeSpent.sim-bulkEditForm--timeSpent");
    var buttonDiv = document.createElement("div");
    buttonDiv.id = "simtutilitiestm-bulkedit";
    buttonDiv.style.border = "2px solid grey";
    buttonDiv.style.borderRadius = "5px";
    buttonDiv.style.padding = "2px";
    buttonDiv.style.display = "inline-block";

    // Bulk Relate
    var bulkRelateButton = document.createElement("button");
    bulkRelateButton.setAttribute("class", "awsui-button awsui-button-variant-primary awsui-hover-child-icons");
    bulkRelateButton.innerText = "Bulk Relate";
    bulkRelateButton.style.margin = '0px 5px 0px 0px';
    bulkRelateButton.onclick = async () =>{
        if(!validateUrl()){
            console.log("Finding all tickets on all pages of edit menu...");
            var ticketArray = await getTickets();
            console.log(ticketArray);
            console.log("All tickets discovered. Starting bulk relate...");
            const bulkRelateStatus = await bulkRelateTickets(ticketArray, 0, null);
            if(bulkRelateStatus != "Success"){alert("Failed to relate all tickets. Check console for debug info");addSIMMetrics("BulkRelate", "1");return;}
            console.log("Bulk relate complete");
            console.log("Finding ticket ID of primary ticket...");
            const primaryTicketID = await findPrimaryTicketID();
            if(primaryTicketID == "Failed to get primary ticket id"){alert("Failed to get primary ticket long ID. See console for debug info");addSIMMetrics("BulkRelate", "1");return;}
            console.log("Primary ticket ID: " + primaryTicketID);
            console.log("Relating back primary to all tickets");
            const reverseBulkRelateStatus = await bulkRelateTickets(ticketArray, 1, primaryTicketID);
            if(reverseBulkRelateStatus != "Success"){alert("Failed to relate all tickets. Check console for debug info");addSIMMetrics("BulkRelate", "1");return;}
            console.log("Operation complete");
            console.log(bulkRelateStatus);
            console.log(reverseBulkRelateStatus);
            if(bulkRelateStatus == "Success" && reverseBulkRelateStatus == "Success"){
                addSIMMetrics("BulkRelate", "0")
                document.getElementById("simtutilitiestm-bulkedit-relate-input").value = "";
                alert("Bulk-relate was successful!");
            }
        }else{
            alert("URL is not in a valid format! Please use https://t.corp.amazon.com/ISSUEID");
        }
    };

    // Bulk Relate framework
    var bulkRelateDisclaimer = document.createElement("span");
    bulkRelateDisclaimer.innerHTML = "Bulk relate button must be pressed before clicking 'save' on this form!<br>";

    var bulkRelateLabel = document.createElement("span");
    bulkRelateLabel.innerText = "SIM-Ticket ID:";
    bulkRelateLabel.style.margin = '0px 5px 0px 0px';

    var bulkRelateInput = document.createElement("input");
    bulkRelateInput.setType = "textbox";
    bulkRelateInput.label = "Ticket ID";
    bulkRelateInput.id = "simtutilitiestm-bulkedit-relate-input";
    bulkRelateInput.style.margin = '0px 5px 0px 0px';

    // Disclaimer
    var generalDisclaimer = document.createElement("span");
    generalDisclaimer.innerHTML = "<br><hr>Note: These features are experimental and do not work all the time!<br>";

    // Append buttons:
    buttonDiv.appendChild(bulkRelateDisclaimer);
    buttonDiv.appendChild(bulkRelateLabel);
    buttonDiv.appendChild(bulkRelateInput);
    buttonDiv.appendChild(bulkRelateButton);

    buttonDiv.appendChild(generalDisclaimer);
    topContainer.appendChild(buttonDiv);
}

function validateUrl(){
    var relatedTicketInfo = document.getElementById("simtutilitiestm-bulkedit-relate-input").value;
    var parsedTicketInfo = relatedTicketInfo.split('/');
    if(parsedTicketInfo[0].toLowerCase() == "https:" && parsedTicketInfo[2].toLowerCase() == "t.corp.amazon.com"){
        if(relatedTicketInfo.length > 40){
            return 1;
        }
    }else{
        return 1;
    }
    return 0;
}

const timer = ms => new Promise(res => setTimeout(res, ms));

async function getTickets(){
    if(document.querySelector(".awsui-table-pagination-content") != null){
        var pages = document.querySelectorAll(".awsui-table-pagination-page-number button");
        var tickets = [];
        console.log(pages.length + " page(s) detected.");
        for(var i=0;i<pages.length;i++){
            await timer(500);
            document.querySelectorAll(".awsui-table-pagination-page-number button")[i].click();
            tickets = tickets.concat(Array.prototype.slice.call(document.querySelectorAll(".alias-wrapper.sim-ellipsis.sim-list--shortId")));
        }
        return tickets;
    }else{
        return document.querySelectorAll(".alias-wrapper.sim-ellipsis.sim-list--shortId");
    }
}

async function bulkRelateTickets(ticketArray, reverse, primaryTicketID){
    // This function can only be called from inside the edit ticket page!
    var relatedTicketInfo = document.getElementById("simtutilitiestm-bulkedit-relate-input").value;
    var failed = 0;
    return new Promise(async (resolve, reject) => {
        for(var i = 0; i<ticketArray.length;i++){
            var payload = [];
            var ticketId = ticketArray[i].getAttribute("data-id");
            if(reverse){
                payload.push({
                    'variables':{
                        'args':{
                            'issueId':primaryTicketID,
                            'childURI':'https://t.corp.amazon.com/'+ticketArray[i].getAttribute("data-sid"),
                            'reason':'is related to',
                            'domain':'prod'
                        }
                    },
                    'extensions':{},
                    'operationName':'RelatedResourcesAdd',
                    'query':'mutation RelatedResourcesAdd($args: RelationInput!) {\n  addRelationToIssue(args: $args) {\n    uri\n    normalized_uri\n    relationships {\n      normalized_child_uri\n      normalized_parent_uri\n      reason\n      __typename\n    }\n    __typename\n  }\n}\n'
                });
            }else{
                payload.push({
                    'variables':{
                        'args':{
                            'issueId':ticketId,
                            'childURI':relatedTicketInfo,
                            'reason':'is related to',
                            'domain':'prod'
                        }
                    },
                    'extensions':{},
                    'operationName':'RelatedResourcesAdd',
                    'query':'mutation RelatedResourcesAdd($args: RelationInput!) {\n  addRelationToIssue(args: $args) {\n    uri\n    normalized_uri\n    relationships {\n      normalized_child_uri\n      normalized_parent_uri\n      reason\n      __typename\n    }\n    __typename\n  }\n}\n'
                });
            }
            if(reverse){
                console.log("Relating "+relatedTicketInfo+" to https://t.corp.amazon.com/"+ticketArray[i].getAttribute("data-sid"));
            }else{
                console.log("Relating https://t.corp.amazon.com/"+ticketArray[i].getAttribute("data-sid")+" to "+relatedTicketInfo);
            }
            await timer(75); // inject 75 ms pause to slow down api calls, hopefully making this more reliable.
            httpGetReqGraphql(payload, (function callback(postResponse){
                //DEBUG  console.log(postResponse);
                if(postResponse.status == 201){
                    // no logging on success console.log("Updated ticket successfully. Refresh to see changes.");
                    if(i == ticketArray.length-1){
                        if(failed){
                            //callback("Error relating tickets!");
                            resolve("Error relating tickets!");
                            return;
                        }else{
                            resolve("Success");
                            return;
                        }
                    }
                }else if(postResponse.status == 200){
                    // no logging on success console.log("Updated ticket, API returned with status code 200.");
                    if(i == ticketArray.length-1){
                        if(failed){
                            resolve("Error relating tickets!");
                            return;
                        }else{
                            resolve("Success");
                            return;
                        }
                    }
                }else{
                    console.log("Non 200/201 response on POST request! Request returned: " + postResponse.status + ". Failed to update ticket.");
                    failed = 1;
                    console.log(postResponse);
                }
            }));
            if(i == ticketArray.length-1){
                if(failed){
                    resolve("Failed to relate all tickets");
                    return;
                }else{
                    resolve("Success");
                    return;
                }
            }
        }
    });
}

function findPrimaryTicketID(){
    var relatedTicketInfo = document.getElementById("simtutilitiestm-bulkedit-relate-input").value;
    var primaryTicketLongID;
    return new Promise((resolve, reject) => {
        var convertShortIdToLong = [{
            "variables": {
                "issueId": relatedTicketInfo.slice(relatedTicketInfo.lastIndexOf('/')+1)
            },
            "extensions": {},
            "operationName": "issueOverview",
            "query": "query issueOverview($issueId: String!) {\n  issue(id: $issueId) {\n    id\n    __typename\n  }\n  __typename\n}\n"
        }];
        httpGetReqGraphql(convertShortIdToLong, (function callback(postResponse){
            var response;
            if(postResponse.status == 201){
                // No logging on success console.log("Queried ticket successfully.");
                response = JSON.parse(postResponse.responseText);
                resolve(response[0].data.issue.id);
            }else if(postResponse.status == 200){
                // no logging on success console.log("Queried ticket, API returned with status code 200.");
                response = JSON.parse(postResponse.responseText);
                resolve(response[0].data.issue.id);
            }else{
                console.log("Non 200/201 response on POST request! Request returned: " + postResponse.status + ". Failed to query ticket.");
                resolve("Failed to get primary ticket id");
            }
        }));
    });
}

function settingsPanel(){
    // Background div to block all other user interaction.
    var darkStyle = 0;
    if(document.getElementById("darkstyle-sheet-TT") != null || document.getElementById("darkstyle-sheet-TTCORP") != null){
        // Website in Dark mode. Adjust colors.
        darkStyle = 1;
    }
    var blockingDiv = document.createElement("div")
    blockingDiv.id = "simtUtilitiesPopupBackground";
    blockingDiv.style.position = "absolute";
    blockingDiv.style.zIndex = "2"; // Needed for SIMT
    blockingDiv.style.width = "100%";
    blockingDiv.style.height = "100%";
    blockingDiv.style.opacity = "0.5";
    blockingDiv.style.backgroundColor = "grey";
    // This

    // Primary div
    var newDivPopup = document.createElement("div");
    newDivPopup.id = "simtUtilitiesSettingsPopup";
    newDivPopup.style.position = "absolute";
    newDivPopup.style.zIndex = "3"; // Needed for SIMT
    newDivPopup.style.top = "25%";
    newDivPopup.style.left = "25%";
    newDivPopup.style.width = "500px"; //400
    newDivPopup.style.height = "300px"; // 250
    newDivPopup.style.backgroundColor = "#FF8F00"
    newDivPopup.style.boxShadow = "0px 0px 20px grey"
    newDivPopup.style.borderRadius = "25px";
    newDivPopup.style.padding = "10px";
    // Internal div
    var logo = document.createElement("div");
    logo.id = "simtUtilitiesSettingsLogo";
    logo.style.padding = "10px";
    logo.style.borderBottom = "2px solid black";
    //logo.style.textShadow = "2px 2px 5px red";
    logo.style.fontSize = "large";
    logo.style.color = "black";
    if(darkStyle){
        logo.style.color = "black";
    }
    logo.innerHTML = ("SIM-T Utilities version " + version + "");

    var content = document.createElement("div");
    content.id = "simtUtilitiesSettingsContent";
    content.style.overflowY = "auto";
    content.style.width = "480px"; //380
    content.style.height = "175px"; //135
    content.style.padding = "10px";
    content.style.fontSize = "small";
    content.style.color = "black";
    if(darkStyle){
        content.style.color = "black";
    }

    var closeButton = document.createElement("button");
    closeButton.style.float = "right";
    closeButton.style.margin = "0px 5px 0px 5px";
    closeButton.onclick = popupClose;
    closeButton.innerText = "Close";
    if(darkStyle){
        closeButton.style.color = "black";
        closeButton.style.borderColor = "black";
    }

    content.innerHTML = "Correspondence message:<br>";

    // WIP options

    var wipCheckboxLabel = document.createElement("label");
    wipCheckboxLabel.innerHTML = "WIP button enabled?<br>";

    var wipCheckbox = document.createElement("input");
    wipCheckbox.type = "checkbox";
    wipCheckbox.id = "simtUtilitiesWipCheckbox";
    if(localstore.getItem("wipEnable") == "1"){
        wipCheckbox.checked = true;
    }
    wipCheckbox.onclick = function(){
        if(document.getElementById("simtUtilitiesWipCheckbox").checked){
            localstore.setItem("wipEnable", "1");
        }else{
            localstore.setItem("wipEnable", "0");
        }
    };

    var wipTextBox = document.createElement("input");
    wipTextBox.type = "textbox";
    wipTextBox.id = "simtUtilitiesWipTextBox";
    wipTextBox.value = localstore.getItem("wipMessage");

    content.appendChild(wipTextBox);
    content.appendChild(wipCheckbox);
    content.appendChild(wipCheckboxLabel);

    // Research options

    var researchCheckboxLabel = document.createElement("label");
    researchCheckboxLabel.innerHTML = "Research button enabled?<br>";

    var researchCheckbox = document.createElement("input");
    researchCheckbox.type = "checkbox";
    researchCheckbox.id = "simtUtilitiesResearchCheckbox";
    if(localstore.getItem("rEnable") == "1"){
        researchCheckbox.checked = true;
    }
    researchCheckbox.onclick = function(){
        if(document.getElementById("simtUtilitiesResearchCheckbox").checked){
            localstore.setItem("rEnable", "1");
        }else{
            localstore.setItem("rEnable", "0");
        }
    };

    var researchTextBox = document.createElement("input");
    researchTextBox.type = "textbox";
    researchTextBox.id = "simtUtilitiesResearchTextBox";
    researchTextBox.value = localstore.getItem("researchMessage");

    content.appendChild(researchTextBox);
    content.appendChild(researchCheckbox);
    content.appendChild(researchCheckboxLabel);

    // Pending Arrival of Tech options

    var PAOTCheckboxLabel = document.createElement("label");
    PAOTCheckboxLabel.innerHTML = "Pending AoT button enabled?<br>";

    var PAOTCheckbox = document.createElement("input");
    PAOTCheckbox.type = "checkbox";
    PAOTCheckbox.id = "simtUtilitiesPAOTCheckbox";
    if(localstore.getItem("PAOTEnable") == "1"){
        PAOTCheckbox.checked = true;
    }
    PAOTCheckbox.onclick = function(){
        if(document.getElementById("simtUtilitiesPAOTCheckbox").checked){
            localstore.setItem("PAOTEnable", "1");
        }else{
            localstore.setItem("PAOTEnable", "0");
        }
    };

    var PAOTTextBox = document.createElement("input");
    PAOTTextBox.type = "textbox";
    PAOTTextBox.id = "simtUtilitiesPAOTTextBox";
    PAOTTextBox.value = localstore.getItem("PAOTMessage");

    content.appendChild(PAOTTextBox);
    content.appendChild(PAOTCheckbox);
    content.appendChild(PAOTCheckboxLabel);

    // pSchedule options

    var pScheduleCheckboxLabel = document.createElement("label");
    pScheduleCheckboxLabel.innerHTML = "Pending Schedule button enabled?<br>";

    var pScheduleCheckbox = document.createElement("input");
    pScheduleCheckbox.type = "checkbox";
    pScheduleCheckbox.id = "simtUtilitiespScheduleCheckbox";
    if(localstore.getItem("pScheduleEnable") == "1"){
        pScheduleCheckbox.checked = true;
    }
    pScheduleCheckbox.onclick = function(){
        if(document.getElementById("simtUtilitiespScheduleCheckbox").checked){
            localstore.setItem("pScheduleEnable", "1");
        }else{
            localstore.setItem("pScheduleEnable", "0");
        }
    };

    var pScheduleTextBox = document.createElement("input");
    pScheduleTextBox.type = "textbox";
    pScheduleTextBox.id = "simtUtilitiespScheduleTextBox";
    pScheduleTextBox.value = localstore.getItem("pScheduleMessage");

    content.appendChild(pScheduleTextBox);
    content.appendChild(pScheduleCheckbox);
    content.appendChild(pScheduleCheckboxLabel);

    // Reassign to requester options

    var rTrCheckboxLabel = document.createElement("label");
    rTrCheckboxLabel.innerHTML = "Reassign to requester button enabled?<br>";

    var rTrCheckbox = document.createElement("input");
    rTrCheckbox.type = "checkbox";
    rTrCheckbox.id = "simtUtilitiesRTRCheckbox";
    if(localstore.getItem("rTrEnable") == "1"){
        rTrCheckbox.checked = true;
    }
    rTrCheckbox.onclick = function(){
        if(document.getElementById("simtUtilitiesRTRCheckbox").checked){
            localstore.setItem("rTrEnable", "1");
        }else{
            localstore.setItem("rTrEnable", "0");
        }
    };

    var rTrTextBox = document.createElement("input");
    rTrTextBox.type = "textbox";
    rTrTextBox.id = "simtUtilitiesRTRTextBox";
    rTrTextBox.value = localstore.getItem("rTrMessage");

    content.appendChild(rTrTextBox);
    content.appendChild(rTrCheckbox);
    content.appendChild(rTrCheckboxLabel);

    newDivPopup.appendChild(logo);
    newDivPopup.appendChild(content);
    newDivPopup.appendChild(closeButton);


    document.body.insertBefore(newDivPopup, document.body.firstChild);
    document.body.insertBefore(blockingDiv, document.body.firstChild);
    addSIMMetrics("settings", "0");
}

function popupClose(){
    // Save messages
    localstore.setItem("wipMessage", document.getElementById("simtUtilitiesWipTextBox").value);
    localstore.setItem("researchMessage", document.getElementById("simtUtilitiesResearchTextBox").value);
    localstore.setItem("PAOTMessage", document.getElementById("simtUtilitiesPAOTTextBox").value);
    localstore.setItem("pScheduleMessage", document.getElementById("simtUtilitiespScheduleTextBox").value);
    localstore.setItem("rTrMessage", document.getElementById("simtUtilitiesRTRTextBox").value);
    // Destroy popup
    document.getElementById("simtUtilitiesPopupBackground").remove();
    document.getElementById("simtUtilitiesSettingsPopup").remove();
    window.location.reload(true);
}//popupClose


// This function is what creates the API body that is fed into the ticket to update all attributes.
function updateTicket(status, pendingReason, assignedGroup, assignedIndividual, tags, correspondence, timeSpent, responseFunction){
    var ticketId = document.getElementsByClassName("ticket-id")[0].dataset.id;
    var login = document.querySelector('.sim-navDropdown--user').innerText.slice((document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf('(')+1), (document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf(')')));
    var loginIdentity = "kerberos:" + login + "@ANT.AMAZON.COM"; // TODO: This could be problematic. I am unsure if all users are using Kerberos auth. This isnt an ideal way of doing things but will probably work for 95% of people using this script. Hopefully
    var edits;
    var pathEdits = [];
    httpGetReq(ticketId, (function callback(getResponse){
        if(getResponse.status == 200){
            var ticketJSON = JSON.parse(getResponse.responseText);
            console.log(ticketJSON);
            // Define the edits
            var statusJSON, assignedGroupJSON, assignedIndividualJSON, correspondenceJSON, timeJSON;
            if(status != null){
                if(status == "Resolved"){
                    statusJSON = {
                        "editAction": "PUT",
                        "path": `/status`,
                        "data": "Resolved"
                    }
                }else{
                    switch(status){
                        case "Assigned":
                            status = "Comment";
                            break;
                        case "Researching":
                            status = "Research";
                            break;
                        case "Work In Progress":
                            status = "Implementation";
                            break;
                        case "Pending":
                            if(pendingReason != null){
                                status = pendingReason;
                            }else{
                                console.log("Status is pending but no pending reason given!");
                                alert("That button is broken!");
                                return;
                            }
                            break;
                        default:
                            status = ticketJSON.extensions.tt.status;
                    }
                    statusJSON = {
                        "path": "/next_step/action",
                        "editAction": "PUT",
                        "data": status
                    }
                }
                var remManualPendingJSON = {
                    "path": "/next_step/exceptions",
                    "editAction": "DELETE"
                }
                pathEdits.push(statusJSON);
                pathEdits.push(remManualPendingJSON);
            }
            if(assignedGroup != null){
                assignedGroupJSON = {
                    "path": "/extensions/tt/assignedGroup",
                    "editAction": "PUT",
                    "data": assignedGroup
                }
                pathEdits.push(assignedGroupJSON);
            }
            if(assignedIndividual != null){
                assignedIndividualJSON = {
                    "path": "/assigneeIdentity",
                    "editAction": "PUT",
                    "data": assignedIndividual
                }
                pathEdits.push(assignedIndividualJSON);
            };
            var tagsJSON = [];
            if(tags != null && tags.length != 0){
                var index = ticketJSON.tags.length;
                for(var i=0;i<tags.length;i++){
                    var tmpTag = {
                        "path": `/tags/${index}`,
                        "editAction": "PUT",
                        "data": {
                            "id": tags[i]
                        }
                    };
                    pathEdits.push(tmpTag);
                    index++;
                }
            }
            if(correspondence != null && correspondence != ""){
                var convoGUID = createGUID();
                correspondenceJSON = {
                    "path": `/conversation/${convoGUID}`,
                    "editAction": "PUT",
                    "data": {
                        "id": convoGUID,
                        "message": correspondence,
                        "contentType": "text/plain",
                        "messageType": "conversation"
                    }
                }
                pathEdits.push(correspondenceJSON);
            }
            if(timeSpent != null && timeSpent != ""){
                var date = new Date().toJSON(); // UTC time. Does not affect time spent, it is only used as an attribute for the json payload.
                if(ticketJSON.extensions.effort.hasOwnProperty("actualEffortLog")){
                    var timeIndex = ticketJSON.extensions.effort.actualEffortLog.time.length;
                    // actualEffortLog exists. Append time to that.
                    timeJSON = {
                        "editAction": "PUT",
                        "path": `/extensions/effort/actualEffortLog/time/${timeIndex}`,
                        "data": {
                            "authorIdentity": loginIdentity,
                            "id": createGUID(),
                            "effortLoggedDate": date,
                            "value": timeSpent
                        }
                    }
                }else{
                    // Time information hasnt been logged yet. Create a new actualEffortLog entry.
                    timeJSON = {
                        "editAction": "PUT",
                        "path": `/extensions/effort`,
                        "data": {
                            "actualEffortLog": {
                                "time": [
                                    {
                                        "authorIdentity": loginIdentity,
                                        "id": createGUID(),
                                        "effortLoggedDate": date,
                                        "value": timeSpent
                                    }
                                ]
                            }
                        }
                    }
                }
                pathEdits.push(timeJSON);
            }
            edits = {"pathEdits": pathEdits};
            console.log(edits);
            httpPostReq(ticketId, edits, (function callback(postResponse){
                if(postResponse.status == 201){
                    console.log("Updated ticket successfully. Refresh to see changes.");
                    responseFunction("");
                }else if(postResponse.status == 200){
                    console.log("Updated ticket, API returned with status code 200.");
                    responseFunction("");
                }else{
                    console.log("Non 200/201 response on POST request! Request returned: " + postResponse.status + ". Failed to update ticket.");
                    console.log(postResponse);
                    responseFunction("Something is broken with that button!");
                }
            }));
        }else{
            console.log("Non 200 response on GET request! Request returned: " + getResponse.status + ". Failed to update ticket.");
            console.log(getResponse);
            responseFunction("Something is broken with that button!");
        }
    }));
}

// ********************************************************************************************************************
// UTILITY FUNCTIONS
// ********************************************************************************************************************

function waitForElementToDisplay(selector, callback, checkFrequencyInMs, timeoutInMs) {
  var startTimeInMs = Date.now();
  (function loopSearch() {
    if (document.querySelector(selector) != null) {
      callback();
      return;
    }
    else {
      setTimeout(function () {
        if (timeoutInMs && Date.now() - startTimeInMs > timeoutInMs){
          return;
        }
        loopSearch();
      }, checkFrequencyInMs);
    }
  })();
}//waitForElementToDisplay

// GET request. Returns the json response text in the callback function
function httpGetReq(ticketId, callback){
         GM.xmlHttpRequest({
            method: "GET",
            url: simApiUrl + "issues/" + ticketId,
            onload: function (response) {
                callback(response);
            },
            onerror: function (response) {
                console.log('Failed GET!');
                console.log(response);
            }
        });
}//httpGetReq

// POST request. Returns response in the callback function.
function httpPostReq(ticketId, jsonText, callback){
         GM.xmlHttpRequest({
            method: "POST",
            url: simApiUrl + "issues/" + ticketId + "/edits",
             headers: {
              "Content-Type": "application/json",
                 "Origin": "https://t.corp.amazon.com"
             },
             data: JSON.stringify(jsonText),
            onload: function (response) {
                callback(response);
            },
            onerror: function (response) {
                console.log('Failed POST!');
                console.log(response);
            }
        });
}//httpPostReq

function httpGetReqGraphql(payload, callback){
    GM.xmlHttpRequest({
        method: "POST",
        url: graphqlUrl,
        headers: {
            "Content-Type": "application/json",
            "Origin": "https://t.corp.amazon.com"
        },
        data: JSON.stringify(payload),
        onload: function (response) {
            callback(response);
        },
        onerror: function (response) {
            console.log('Failed POST!');
            console.log(response);
            callback(response);
        }
    });
}//httpGetReqGraphql

function createGUID() {
  let values = new Uint8Array(16);
  crypto.getRandomValues(values);

  // Set version (4)
  values[6] = values[6] & 0x0F | 0x40;

  // Set variant (0b10)
  values[8] = values[8] & 0x3F | 0x80;

  let result = "";
  for(let i = 0; i < values.length; i++) {
    if([4,6,8,10].includes(i)) {
      result += "-";
    }
    result += values[i].toString(16).padStart(2, "0");
  }
  return result;
}

// SIM usage analytics
function addSIMMetrics(button, state){
    var userName = document.querySelector('.sim-navDropdown--user').innerText.slice((document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf('(')+1), (document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf(')')));
    var SIMID = null;
    if(button != "BulkRelate" && button != "BulkLocationUpdate"){
        SIMID = document.getElementsByClassName("ticket-id")[0].dataset.id;
    }
    var attributes = "&login=" + userName + "&version=" + version + "&caseID=" + SIMID + "&button=" + button + "&state=" + state;
    // Due to CSP, this needs to be done in a get request now.
    GM.xmlHttpRequest({
        method: "GET",
        url: "https://0s62bmu3aj.execute-api.us-east-1.amazonaws.com/PROD/pixel/tracker?PixelID=11045e9e-99c7-f10b-40b7-128b132a1a64" + attributes,
        headers: {
            "Content-Type": "application/json",
            "Origin": "https://t.corp.amazon.com"
        },
        onload: function (response) {
            console.log("Successfully pinged metric point.");
        },
        onerror: function (response) {
            console.log('Failed to ping metric point.');
            console.log(response);
        }
    });
}

// ********************************************************************************************************************
// END UTILITY FUNCTIONS
// ********************************************************************************************************************
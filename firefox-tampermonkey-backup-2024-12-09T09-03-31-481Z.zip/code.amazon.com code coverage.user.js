// ==UserScript==
// @name        code.amazon.com code coverage
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/code.amazon.com_code_coverage.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/code.amazon.com_code_coverage.user.js
// @namespace   https://amazon.com
// @description Adds code coverage display to code.amazon.com
// @include     https://code.amazon.com/packages/*/blobs/*.java
// @connect     devcentral.amazon.com
// @connect     brazil-metadata.amazon.com
// @version     2
// @grant       GM_xmlhttpRequest
// ==/UserScript==

var cssTags = {
  fullCoverage: "sus_fc",
  partCoverage: "sus_pc",
  noneCoverage: "sus_nc",
  checkbox    : "sus_coverage",
  redX        : "sus_redx",
  start       : "sus_start",
  done        : "sus_done",
  fail        : "sus_fail",
};

var css = `.${cssTags.partCoverage} { background-color: #ffffcc; }
           .${cssTags.fullCoverage} { background-color: #ccffcc; }
           .${cssTags.noneCoverage} { background-color: #ffaaaa; }
           .${cssTags.redX} { color: #ffaaaa; }
           .${cssTags.checkbox} { top: -10px; position:relative; padding-left: 20px; }
           .${cssTags.checkbox}.${cssTags.start} i                { display: inline-block; }
           .${cssTags.checkbox}.${cssTags.start} input            { visibility: hidden; }
           .${cssTags.checkbox}.${cssTags.start} .${cssTags.redX} { display: none; }
           .${cssTags.checkbox}.${cssTags.done} i                 { display: none; }
           .${cssTags.checkbox}.${cssTags.done} input             { visibility: visible; }
           .${cssTags.checkbox}.${cssTags.done} .${cssTags.redX}  { display: none; }
           .${cssTags.checkbox}.${cssTags.fail} i                 { display: none; }
           .${cssTags.checkbox}.${cssTags.fail} input             { visibility: hidden; }
           .${cssTags.checkbox}.${cssTags.fail} .${cssTags.redX}  { display: inline; }
          `;

var html = `<span class='${cssTags.checkbox} subtext'>
              <label>Show Coverage</label>
              <i class='fa fa-spinner fa-spin'></i>
              <span title='Could not find or load coverage.' class='${cssTags.redX}'>&#10006;</span>
              <input type='checkbox' checked='checked' />
            </span>
           `;

/**
 * This method is called first and automatically by the browser to begin coverage
 */
function coverageInit() {
  console.log("Hello, World!");

  addGlobalStyle(css);
  addHtml("#file_actions", html);
  attachCoverageCheckHandler();
  addCoverage();
} coverageInit();

/**
 * Add a css styled string to the head of the document
 * @param {String} css styling
 */
function addGlobalStyle(css) {
    if (!document.head) {
      console.error("Failure in getting a document head.");
      return;
    }

    var style = document.createElement("style");
    style.type = "text/css";
    style.innerHTML = css;
    document.head.appendChild(style);
}

/**
 * Add an HTML element to the given selector in the document
 * @param {String} selector indicating which entity should accept the html
 * @param {String} html element to be added
 */
function addHtml(selector, html) {
  document.querySelector(selector).innerHTML += html;
}

/**
 * Create a URL [http://example.com/][?][paramKey=paramValue][&][paramEntry]
 *              [url][seperator][paramMap][delimeter][paramArray]
 * @param {String} url
 * @param {Map}/{Array} params
 * @param {Char} delimeter
 * @param {Char} separator
 * @return {String} a complete url
 */
function buildUrl(url, params, delimeter = '&', separator = '?') {
  var esc = encodeURIComponent;
  var query;

  if(Array.isArray(params)) {
    query = params.join(delimeter);
  } else {
    query = Object.keys(params)
      .map(k => `${esc(k)}=${esc(params[k])}`)
      .join(delimeter);
  }
  return url + separator + query;
}

/**
 * Attach a handler to the coverage checkbox so that events are intercepted and managed
 */
function attachCoverageCheckHandler() {
  var checkbox = document.querySelector(`.${cssTags.checkbox} input`);
  checkbox.onclick = function(event) {
    if(event.target.checked) {
      addCoverage();
    } else {
      removeCoverage();
    }
  };
}

/**
 * Get the current package
 * @return {String} package
 */
function getPackage() {
  // pull the package out of the URL
  // eg https://code.amazon.com/packages/AshaCommon/blobs/mainline/--/src/com/amazon/sunlit/asha/appeal/dao/AppealDao.java -> AshaCommon
  return window.location.href.replace(/^(?:[^/].*)\/packages\/([^/]*)\/.*$/, "$1");
}

/**
 * Get the current commit hash
 * @return {String} commit or undefined
 */
function getCommit() {
  var sha = document.getElementById("source_sha1");
  if(sha) {
    return sha.value;
  }

  var commit = document.getElementById("commit_id");
  if(commit) {
    return commit.value;
  }

  console.error("Could not find a commit");
  return undefined;
}

/**
 * Get the current branch
 * @param {String} package
 * @return {String} branch or undefined
 */
function getBranch(package) {
  var permalink = document.querySelector(".permalink");
  if(permalink) {
    // pull the branch out of the breadcrumb
    var breadcrumb = document.querySelector("ol.breadcrumb li + li + li");
    return breadcrumb.textContent || breadcrumb.innerText;
  }

  var pipeline = document.querySelector("ul.last-commit-summary li.commit_message + li + li a");
  if(pipeline) {
    // pull the branch out of the pipeline url
    // eg https://pipelines.amazon.com/changes/PKG/AshaCommon/mainline/GitFarm:42f55a08d4fab1129d5f1501b11043778f932df5 -> mainline
    return pipeline.href.replace(new RegExp(`^.*\/${package}\/([^/]*)\/.*$`), "$1");
  }

  console.error(`Could not find branch for package: ${package}`);
  return undefined;
}

/**
 * Get the current file path
 * @return {String} file
 */
function getFile() {
  // pull the file out of the path
  // eg src/com/amazon/sunlit/asha/appeal/dao/AppealDao.java -> com/amazon/sunlit/asha/appeal/dao/AppealDao.java
  return document.getElementById("path").value.replace(/^(src|tst)\/(.*)$/, "$2");
}

/**
 * Get the current platform
 * @return {String} default
 */
function getPlatform() {
  return "RHEL5_64";
}

/**
 * Get the current flavor
 * @return {String} default
 */
function getFlavor() {
  return "DEV.STD.PTHREAD";
}

/**
 * Get the current Brazil Build Major Version for Apollo
 * @param {String} package
 * @param {String} branch
 * @param {String} commit
 * @return {Promise{String}} major version
 */
function queryMajorVersion(package, branch, commit) {
  var bmds = "http://brazil-metadata.amazon.com/BMDS";

  return new Promise(function(resolve, reject){
    var params = {
      method     : "getPackageVersionsBySourceChangeRange",
      packageName: package,
      branchName : branch,
      startingCln: commit,
      endingCln  : "", // purposefully left blank to help with version matching
    };

    var bmdsUrl = buildUrl(bmds, params);

    var ret = GM_xmlhttpRequest({
      method: "GET",
      url   : bmdsUrl,
      onload: function(res) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(res.responseText, "text/xml");
        var versSt = xmlDoc.getElementsByTagName("versionString");

        if(versSt.length <= 0) {
          var message = `Could not find Major Version for commit: ${commit}`;
          console.error(message);
          reject(message);
          return;
        }

        var majorVersion = versSt[0].childNodes[0].nodeValue;
        resolve(majorVersion);
      },
      onerror: function(res) {
        var msg = `An error occurred.
                    responseText:    ${res.responseText}
                    readyState:      ${res.readyState}
                    responseHeaders: ${res.responseHeaders}
                    status:          ${res.status}
                    statusText:      ${res.statusText}
                    finalUrl:        ${res.finalUrl}
                  `;
        console.error(msg);
        reject(msg);
      }
    });
  });
}

/**
 * Find the line coverage, branch coverage, and title from the raw XML output of devCentral
 * @param {String} xmlDoc
 * @return {Object} coverage
 */
function calculateCoverage(xmlDoc) {
  var lines       = Array.prototype.slice.call(xmlDoc.querySelectorAll("span.pc, span.nc, span.fc"));
  var testedLines = lines.reduce(function(result, item) {
    var index = item.id;
    var title = item.title;
    var line  = item.textContent || item.innerText || "";
    var coverage = item.classList.contains("fc") ? 100 : 0;
    var covRe = /^(\d)(\sof\s)(\d).*/;
    if(title && title.match(covRe)) {
      coverage = title.replace(covRe, "$1") / title.replace(covRe, "$3") * 100;
    }

    if(result[index] && result[index].coverage < coverage) {
      coverage = result[index].coverage;
    }

    result[index] = {coverage: coverage, line: line, title: title};
    return result;
  }, {});

  return testedLines;
}

/**
 * Get the current coverage document from devCentral
 * @param {String} package
 * @param {String} major version
 * @param {String} platform
 * @param {String} flavor
 * @param {String} file
 * @return {Promise{Object}} coverage
 */
function queryTestedLines(package, majorVer, platform, flavor, file) {
  var devCentral = "https://devcentral.amazon.com/ac/brazil/package-master/package/view/";

  // transform file into format used by devcentral
  // eg com/amazon/sunlit/asha/appeal/dao/AppealDao.java -> com.amazon.sunlit.asha.appeal.dao/AppealDao.java.html
  file = `brazil-documentation/coverage/${file.replace(/[\/](?=.*[\/])/g, ".")}.html`;

  var values = [package, majorVer, platform, flavor, file];
  return new Promise(function(resolve, reject){
    var devCentralUrl = buildUrl(devCentral, values, ";", "");

    var ret = GM_xmlhttpRequest({
      method: "GET",
      url   : devCentralUrl,
      onload: function(res) {
        if(res.responseText.includes("Houston, we have a problem.")) {
          var message = `File is untested: ${file}`;
          console.error(message);
          reject(message);
          return;
        }

        console.log("Calculating tested lines...");
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(res.responseText, "text/xml");
        var testedLines = calculateCoverage(xmlDoc);
        resolve(testedLines);
      },
      onerror: function(res) {
        var msg = `An error occurred.
                    responseText:    ${res.responseText}
                    readyState:      ${res.readyState}
                    responseHeaders: ${res.responseHeaders}
                    status:          ${res.status}
                    statusText:      ${res.statusText}
                    finalUrl:        ${res.finalUrl}
                  `;
        console.error(msg);
        reject(msg);
      }
    });
  });
}

/**
 * Modify document to display line coverage, branch coverage, and titles
 * Ensuring that the lines match character for character before display
 * @param {Object} coverage
 */
function augmentLines(testedLines) {
  for (var key in testedLines) {
    if (testedLines.hasOwnProperty(key)) {
      var testedLine = testedLines[key];
      var item = document.getElementById(key).querySelector(".line_content");
      var line  = item.textContent || item.innerText || "";

      if(line.slice(0, -1) === testedLine.line) {
        var coverageCss = "";
        if(testedLine.coverage <= 0) {
          coverageCss = cssTags.noneCoverage;
        } else if (testedLine.coverage <= 50) {
          coverageCss = cssTags.partCoverage;
        } else {
          coverageCss = cssTags.fullCoverage;
        }

        item.classList.add(coverageCss);

        if(testedLine.title) {
          item.setAttribute("title", testedLine.title);
        }
      }
    }
  }
}

/**
 * Clear whatever coverage we have stored for the primary key [package, commit, branch, file, platform, flavor]
 * @param {String} package
 * @param {String} commit
 * @param {String} branch
 * @param {String} file
 * @param {String} platform
 * @param {String} flavor
 */
function clearCachedValue(package, commit, branch, file, platform, flavor) {
  var values = [package, commit, branch, file, platform, flavor];
  var key = JSON.stringify(values);
  window.sessionStorage.removeItem(key);
}

/**
 * Get coverage we have stored for the primary key [package, commit, branch, file, platform, flavor]
 * @param {String} package
 * @param {String} commit
 * @param {String} branch
 * @param {String} file
 * @param {String} platform
 * @param {String} flavor
 * @return {Object} coverage
 */
function getCachedValue(package, commit, branch, file, platform, flavor) {
  var values = [package, commit, branch, file, platform, flavor];
  var key   = JSON.stringify(values);
  var value = window.sessionStorage[key];

  if(value) {
    return JSON.parse(value);
  } else {
    var message = `No cache value found: ${value}`;
    console.error(message);
    return undefined;
  }
}

/**
 * Save coverage for the primary key [package, commit, branch, file, platform, flavor]
 * This should NOT persist coverage through page refresh, browser closure, and computer restarts
 * Because the Brazil Major version is not part of the cache key
 * @param {String} package
 * @param {String} commit
 * @param {String} branch
 * @param {String} file
 * @param {String} platform
 * @param {String} flavor
 * @param {Object} coverage
 */
function saveCachedValue(package, commit, branch, file, platform, flavor, testedLines) {
  var values = [package, commit, branch, file, platform, flavor];
  var key   = JSON.stringify(values);
  var value = JSON.stringify(testedLines);

  window.sessionStorage[key] = value;
}

/**
 * Query document for necessary fields
 * Download and calculage coverage
 * Modify document to display line coverage, branch coverage, and titles
 * Handle all caching with regards to coverage
 * @param {Boolean} clearCache
 */
function addCoverage(clearCache = false) {
  var package  = getPackage();
  var commit   = getCommit();
  var branch   = getBranch(package);
  var file     = getFile();
  var platform = getPlatform();
  var flavor   = getFlavor();

  if(!package || !commit || !branch || !file || !platform || !flavor) {
    console.log(`Failed to gather a required element for coverage.`);
    failCoverage();
    console.log(`data: package:${package} commit:${commit} branch:${branch} file:${file} platform:${platform} flavor:${flavor}`);
    return;
  }

  startCoverage();

  if(clearCache) {
    clearCachedValue(package, commit, branch, file, platform, flavor);
  }

  var cachedValue = getCachedValue(package, commit, branch, file, platform, flavor);
  if(cachedValue) {
    augmentLines(cachedValue);
    doneCoverage();
  } else {
    var majorVer = queryMajorVersion(package, branch, commit);
    majorVer.catch(failCoverage);

    var testedLi = majorVer.then(majorVer => queryTestedLines(package, majorVer, platform, flavor, file));
    testedLi.catch(failCoverage);
    testedLi.then(testedLi => {
      saveCachedValue(package, commit, branch, file, platform, flavor, testedLi);
      augmentLines(testedLi);
      doneCoverage();
    });
  }
}

/**
 * Modify document to remove display of line coverage, branch coverage, and titles
 */
function removeCoverage() {
  var testedLines = Array.prototype.slice.call(
                      document.querySelectorAll(`.${cssTags.fullCoverage}
                                                ,.${cssTags.partCoverage}
                                                ,.${cssTags.noneCoverage}`));

  testedLines.forEach(line => {
    line.classList.remove(cssTags.fullCoverage);
    line.classList.remove(cssTags.partCoverage);
    line.classList.remove(cssTags.noneCoverage);
    line.setAttribute("title", "");
  });

  console.log("Done removing coverage");
}

/**
 * Show the coverage spinner in the document
 */
function startCoverage() {
  changeCoverage([cssTags.fail, cssTags.done], [cssTags.start]);
}

/**
 * Show the coverage checkbox in the document
 */
function doneCoverage() {
  changeCoverage([cssTags.fail, cssTags.start], [cssTags.done]);
}

/**
 * Show the coverage failure message in the document
 */
function failCoverage() {
  changeCoverage([cssTags.start, cssTags.done], [cssTags.fail]);
}

/**
 * Helper function for showing coverage UI elements
 * @param {Array{String}} elements to remove from display
 * @param {Array{String}} elements to add to display
 */
function changeCoverage(toRemove, toAdd) {
  var checkboxSpan = document.querySelector(`.${cssTags.checkbox}`);

  checkboxSpan.classList.remove(...toRemove);
  checkboxSpan.classList.add(...toAdd);
}

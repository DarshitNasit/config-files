// ==UserScript==
// @name         Search-With-Confidence
// @namespace    Violentmonkey scripts
// @version      0.2
// @description  try to take over the world!
// @author       Rishit Desai, Nabil Silva, Himani Khanduja, Abdul Azeem
// @match        https://code.amazon.com/search*
// @grant        GM_xmlhttpRequest
// @require      http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js
// ==/UserScript==
 
function SearchResult() {
    this.packageName = undefined;
    this.branch = undefined;
    this.commitId = undefined;
    this.path = undefined;
    this.lineNumber = undefined;
    this.confidenceParameters = undefined;
}
 
function SearchResultConfidenceParameters() {
    this.lastCommitTime = undefined;
    this.authorTime = undefined;
    this.authorLogin = undefined;
    this.isCR = undefined;
    this.doesPipelineExist = undefined;
    this.isInProduction = undefined;
    this.pipelineLastDeploymentTime = undefined;
    this.codeCoverage = undefined;
    this.codeReviewExists = undefined;
}
 
function CodeCoverage(lineCoverage, branchCoverage, sloc) {
    this.lineCoverage = lineCoverage;
    this.branchCoverage = branchCoverage;
    this.sloc = sloc;
}
 
function MomentInTime(epochSeconds) {
    this.epochSeconds = epochSeconds;
}
 
MomentInTime.prototype.text = function() {
    return generateTimeAgoText(this.epochSeconds);
};
 
(function() {
    'use strict';
    //console.log("31 Hello World");
    addCssForConfidenceParameter();
    var x = document.getElementsByClassName("extra");
    var search_result_headers = document.getElementsByClassName("cs-result-header");
    var i;
    for (i = 0; i < x.length; i++) {
        //for (i = 0; i < 1; i++) {
        var links = x[i].getElementsByTagName("a");
        var j;
        //for (j = 0; j < links.length; j++) {
        for (j = 0; j < 1; j++) {
            var relativeLink = links[j].getAttribute("href");
            var link = "https://code.amazon.com/" + relativeLink;
            var confidenceParametersDiv = document.createElement("div");
            confidenceParametersDiv.className = "confidenceParameters";
            var statusElement = document.createElement("span");
            var statusNode = document.createTextNode(":");
            statusElement.appendChild(statusNode);
            confidenceParametersDiv.appendChild(statusElement);
            search_result_headers[i].appendChild(confidenceParametersDiv);
            //console.log(link);
 
            var z = $(search_result_headers[i]).parents(".cs-result-item").find(".idiff").first();
            var lineNumber = parseInt($(z).parents(".line_content").prev().find("a").text());
            //console.log("lineNumber="+lineNumber);
            //var relativeLinkTruncated = relativeLink.substring(10);
            //var packageName = relativeLinkTruncated.substring(0,relativeLinkTruncated.indexOf("/"));
            ////console.log("packageName="+packageName);
            constructSearchResultAndFindCondifenceParameters(link, lineNumber, confidenceParametersDiv);
        }
    }
})();
 
function constructSearchResultAndFindCondifenceParameters(link, lineNumber, confidenceParametersDiv) {
    GM_xmlhttpRequest({
        method: "GET",
        url: link,
        onload: function(response) {
            try{
                var results = response.responseText;
                var time_ago = $(results).find(".last-commit-summary > .absolute-time").first().text();
                if(!time_ago) {
                    throw "Cannot determine lastCommitTime";
                }
                lastCommitTime = new MomentInTime(Date.parse(time_ago) / 1000);
                //console.log("time_ago=" + lastCommitTime.text());
                var urlForCheckingPipeline = $(results).find(".last-commit-summary").children().last().find("a").attr("href");
                //console.log("urlForCheckingPipeline=" + urlForCheckingPipeline);
                var packageNameWithBranch = urlForCheckingPipeline.substring(urlForCheckingPipeline.indexOf("PKG") + 4, urlForCheckingPipeline.indexOf("GitFarm:") - 1);
                var packageName = packageNameWithBranch.substring(0, packageNameWithBranch.lastIndexOf("/"));
                var branch = packageNameWithBranch.substring(packageNameWithBranch.lastIndexOf("/") + 1);
                var commitId = urlForCheckingPipeline.substring(urlForCheckingPipeline.indexOf("GitFarm:") + 8);
 
                var searchResult = new SearchResult();
                searchResult.packageName = packageName;
                searchResult.branch = branch;
                searchResult.path = link.substring(link.indexOf("/--/") + 4);
                searchResult.commitId = commitId;
                searchResult.lineNumber = lineNumber;
                var searchResultConfidenceParameters = new SearchResultConfidenceParameters();
                searchResult.confidenceParameters = searchResultConfidenceParameters;
 
                searchResultConfidenceParameters.lastCommitTime = lastCommitTime;
 
                /*var colorBasedOnAge = calculateColorBasedOnAge(lastCommitTime);
                var $span = $(document.createElement('span')).addClass('lastCommitTime').addClass('confidenceParameter').addClass(colorBasedOnAge);
                $span.text("Code: " + searchResultConfidenceParameters.lastCommitTime.text());
                $(confidenceParametersDiv).append($span);*/
 
                findAuthorDate(searchResult, confidenceParametersDiv);
            }catch(err){
                //console.log(err);
                fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
            }
        },
        onerror: function(response) {
            //console.log(response);
            fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
        }
    });
}
 
function findAuthorDate(searchResult, confidenceParametersDiv) {
    var data = "{\"repositoryId\": \"pkg/"+searchResult.packageName+"\",  \"requester\": \"dc-owl\",  \"commitId\": \""+searchResult.commitId+"\",  \"file\": \""+searchResult.path+"\"}";
    //console.log("data=" + data);
    GM_xmlhttpRequest({
        method: "POST",
        url: "http://gitfarm.amazon.com",
        headers: {
            "X-Amz-Target": "com.amazon.brazil.gitfarm.service.GitFarmService.getBlame",
            "Content-Encoding": "amz-1.0",
            "Content-Type": "application/json; charset=UTF-8"
        },
        data: data,
        onload: function(response) {
            try{
                var jsonData = $.parseJSON(response.responseText);
                var sha1 = undefined;
                var spans = jsonData.spans;
                for(var i=0;i<spans.length;i++){
                    var span = spans[i];
                    if(searchResult.lineNumber >= span.firstLine && searchResult.lineNumber <= span.lastLine){
                        sha1 = span.SHA1;
                        break;
                    }
                }
                if(sha1){
                    var commits = jsonData.commits;
                    for (var i=0;i<commits.length;i++) {
                        var commit = commits[i];
                        if(commit.SHA1 == sha1){
                            //console.log("Found");
                            searchResult.confidenceParameters.authorTime = new MomentInTime(commit.authorDate);
                            searchResult.confidenceParameters.authorLogin = commit.authorEmail.substring(0,commit.authorEmail.indexOf("@"));
 
                            var colorBasedOnAge = calculateColorBasedOnAge(searchResult.confidenceParameters.authorTime);
                            var $span = $(document.createElement('span')).addClass('authorDate').addClass('confidenceParameter').addClass(colorBasedOnAge);
                            //$span.text("Code: " + searchResult.confidenceParameters.authorTime.text());
                            //$(confidenceParametersDiv).append($span);
 
                            var lastCommitTimeInnerSpan = $(document.createElement('span')).addClass('lastCommitTime');
                            $(lastCommitTimeInnerSpan).text("Last Commit: " + searchResult.confidenceParameters.lastCommitTime.text());
 
                            var authorInnerSpan = $(document.createElement('span')).addClass('authorLogin');
                            $(authorInnerSpan).text("Author: " + searchResult.confidenceParameters.authorLogin);
 
                            var authorTenureInnerSpan = $(document.createElement('span')).addClass('authorTenure');
 
                            var wrapperInnerSpan = $(document.createElement('span')).addClass('authorDateTooltip').addClass('confidenceParameterTooltip');
                            wrapperInnerSpan.html("&nbsp;&nbsp;"+lastCommitTimeInnerSpan[0].outerHTML + "&nbsp;&nbsp;<br/>&nbsp;&nbsp;" + authorInnerSpan[0].outerHTML + "&nbsp;&nbsp;<br/>&nbsp;&nbsp;"+authorTenureInnerSpan[0].outerHTML+ "&nbsp;&nbsp;");
 
                            $span.html("Code: " + searchResult.confidenceParameters.authorTime.text() + wrapperInnerSpan[0].outerHTML);
 
                            $(confidenceParametersDiv).append($span);
 
 
                            /*var $authorLogin = $(document.createElement('span')).addClass('authorLogin').addClass('confidenceParameter');
                            $authorLogin.text("Author: " + searchResult.confidenceParameters.authorLogin);
                            $(confidenceParametersDiv).append($authorLogin);*/
 
                            searchResult.confidenceParameters.isCR = commit.message.includes("cr ");
                            var $isCRSpan = $(document.createElement('span')).addClass('isCR').addClass('confidenceParameter').addClass(calculateColorBasedOnAvailability(searchResult.confidenceParameters.isCR));
                            $isCRSpan.text("CR: " + searchResult.confidenceParameters.isCR);
                            $(confidenceParametersDiv).append($isCRSpan);
                            break;
                        }
                    }
                }
                else{
                    throw "Cannot find Commit Id for the line";
                }
                calculateTenure(searchResult, confidenceParametersDiv);
                checkIfThereExistsAPipeline(searchResult, confidenceParametersDiv);
            }catch(err){
                //console.log(err);
                fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
            }
        },
        onerror: function(response) {
            //console.log(response);
            fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
        }
    });
}
 
function calculateTenure(searchResult, confidenceParametersDiv){
    var phonetool_login_url = "https://phonetool.amazon.com/users/" + searchResult.confidenceParameters.authorLogin + ".json";
        GM_xmlhttpRequest({ method: "GET", url : phonetool_login_url,
       headers:    {    "X-Force-Preflight": "true"  },
            onload: function(response) {
                var results = response.responseText;
                var jsonData = $.parseJSON(results);
                searchResult.confidenceParameters.authorTenure = jsonData.tenure_days;
 
                //debugger;
                var tenureSpan = $(confidenceParametersDiv).find(".authorTenure").first();
 
 
                var currentEpoch = new Date().getTime() / 1000;
                var timeDiff = currentEpoch - searchResult.confidenceParameters.authorTime.epochSeconds;
                var days = Math.floor(timeDiff / (60 * 60 * 24));
 
                var daysDiff = searchResult.confidenceParameters.authorTenure - days;
                var monthsDiff = Math.floor(daysDiff / 30);
                var yearsDiff = Math.floor(monthsDiff / 12);
 
                var tenureString = "";
                if(monthsDiff == NaN || yearsDiff == NaN){
                    tenureString = "NA";
                }
                else if(yearsDiff >= 2){
                    tenureString = yearsDiff + " years";
                } else if (yearsDiff >= 1) {
                    tenureString = parseFloat(monthsDiff/12).toFixed(2) + " years";
                } else {
                    tenureString = monthsDiff + " months";
                }
 
//                var colorBasedOnAge = calculateColorBasedOnNumberOfDays(jsonData.tenure_days);
//                var $span = $(document.createElement('span')).addClass('tenure').addClass('confidenceParameter').addClass(colorBasedOnAge);;
                $(tenureSpan).text("Tenure when authored: " + tenureString);
                //$(confidenceParametersDiv).append($span);
            },
            onerror : function(response) {
                //console.log(response);
            }
        });
}
function checkIfThereExistsAPipeline(searchResult, confidenceParametersDiv) {
    var data = "{\"targetName\": \"" + searchResult.packageName + "/" + searchResult.branch + "\", \"targetType\": \"PKG\", \"inPrimaryPipeline\": false}";
    //console.log("data=" + data);
    GM_xmlhttpRequest({
        method: "POST",
        url: "https://pipelines-api.corp.amazon.com/v1/",
        headers: {
            "X-Amz-Target": "com.amazonaws.pipelinesapiservice.PipelinesAPIService_v1.GetPipelinesContainingTarget",
            "Content-Encoding": "amz-1.0",
            "Content-Type": "application/json; charset=UTF-8"
        },
        data: data,
        onload: function(response) {
            try{
                var jsonData = $.parseJSON(response.responseText);
                var pipelineIds = jsonData.pipelineIds;
                var doesPipelineExist;
                if (pipelineIds.length > 0) {
                    doesPipelineExist = true;
                } else {
                    doesPipelineExist = false;
                }
                searchResult.confidenceParameters.doesPipelineExist = doesPipelineExist;
                if(searchResult.confidenceParameters.doesPipelineExist == false){
                    throw "No Pipeline exists for this code";
                }
                //console.log("pipelineId" + pipelineIds[0]);
                isInProd(pipelineIds[0], searchResult, confidenceParametersDiv);
            }catch(err){
                //console.log(err);
                fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
            }
        },
        onerror: function(response) {
            //console.log(response);
            fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
        }
    });
}
 
function isInProd(pipelineId, searchResult, confidenceParametersDiv) {
    GM_xmlhttpRequest({
        method: "POST",
        url: "https://pipelines-api.corp.amazon.com/v1/",
        headers: {
            "X-Amz-Target": "com.amazonaws.pipelinesapiservice.PipelinesAPIService_v1.GetPipelineStructureByPipelineId",
            "Content-Encoding": "amz-1.0",
            "Content-Type": "application/json; charset=UTF-8"
        },
        data: "{\"pipelineId\": " + pipelineId + "}",
        onload: function(response) {
            try{
                var jsonData = $.parseJSON(response.responseText);
                var stages = jsonData.stages;
                //console.log("jsonData.stages=" + stages);
                var productionStageFound = false;
                var i;
                for (i = stages.length - 1; i >= 0; i--) {
                    var stage = stages[i];
                    if (stage.stageType == "DEPLOYABLE_ENVS") {
                        if (stage.prod == true) {
                            productionStageFound = true;
                            checkInProd(stage.targets[0].name, searchResult, confidenceParametersDiv);
                            break;
                        }
                    }
                }
                if (productionStageFound == false) {
                    searchResult.confidenceParameters.isInProduction = false;
                    throw "No Prod stage found in Pipeline";
                }
            }catch(err){
                //console.log(err);
                fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
            }
        },
        onerror: function(response) {
            //console.log(response);
            fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
        }
    });
}
 
function checkInProd(envNameWithStage, searchResult, confidenceParametersDiv) {
    var checkChangeURL = encodeURI("change_identifier=GitFarmCommit:" + searchResult.packageName + "/" + searchResult.branch + ":" + searchResult.commitId + "&target_identifier=ENV:" + envNameWithStage);
    GM_xmlhttpRequest({
        method: "GET",
        url: "https://pipelines.amazon.com/target_change_history?" + checkChangeURL,
        headers: {
            "X-Amz-Target": "com.amazonaws.pipelinesapiservice.PipelinesAPIService_v1.GetPipelineStructureByPipelineId",
            "Content-Encoding": "amz-1.0",
            "Content-Type": "application/json; charset=UTF-8"
        },
        onload: function(response) {
            try{
                var responseText = response.responseText;
                if(response.responseText.includes("Sentry MFA Authentication")){
                    var $span = $(document.createElement('span')).addClass('error').addClass('confidenceParameter').addClass("background-red");
                    $span.text("Please Authenticate with Yubikey on https://pipelines.amazon.com");
                    $(confidenceParametersDiv).append($span);
                    throw "Unauthorized";
                }
                var jsonData = $.parseJSON(responseText);
                var reachedTarget = jsonData.target_change_history_output.reached_target;
                //console.log("reachedTarget=" + reachedTarget);
                searchResult.confidenceParameters.isInProduction = reachedTarget;
                var $span = $(document.createElement('span')).addClass('isInProduction').addClass('confidenceParameter').addClass(calculateColorBasedOnAvailability(searchResult.confidenceParameters.isInProduction));
                $span.text("Prod: " + searchResult.confidenceParameters.isInProduction);
                $(confidenceParametersDiv).append($span);
                getLatestDeploymentTime(envNameWithStage, searchResult, confidenceParametersDiv);
            }catch(err){
                //console.log(err);
                fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
            }
        },
        onerror: function(response) {
            //console.log(response);
            fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
        }
    });
}
 
function getLatestDeploymentTime(envNameWithStage, searchResult, confidenceParametersDiv) {
    var envNameWithoutStage = envNameWithStage.substring(0, envNameWithStage.lastIndexOf("/"));
    var data = "{\"EnvironmentStageIdentifier\":{\"EnvironmentName\":\"" + envNameWithoutStage + "\",\"Stage\":\"Prod\"},\"Fleetwide\":true,\"PackageChanging\":true,\"Finished\":true,\"MaxResults\":1}";
    GM_xmlhttpRequest({
        method: "POST",
        url: "https://apollo-api.amazon.com",
        data: data,
        headers: {
            "X-Amz-Target": "com.amazon.apolloapi.coral.generated.ApolloAPIService.ListDeploymentsForEnvironmentStageV2",
            "Content-Encoding": "amz-1.0",
            "Content-Type": "application/json; charset=UTF-8"
        },
        onload: function(response) {
            try{
                var jsonData = $.parseJSON(response.responseText);
                var lastDeploymentEpochSeconds = jsonData.Deployments[0].EndTime;
                searchResult.confidenceParameters.pipelineLastDeploymentTime = new MomentInTime(lastDeploymentEpochSeconds);
                var colorBasedOnAge = calculateColorBasedOnAge(searchResult.confidenceParameters.pipelineLastDeploymentTime);
                var $span = $(document.createElement('span')).addClass('pipelineLastDeploymentTime').addClass('confidenceParameter').addClass(colorBasedOnAge);
                $span.text("Pipeline:" + searchResult.confidenceParameters.pipelineLastDeploymentTime.text());
                $(confidenceParametersDiv).append($span);
                getCodeCoverage(searchResult, confidenceParametersDiv);
            }catch(err){
                //console.log(err);
                fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
            }
        },
        onerror: function(response) {
            //console.log(response);
            fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
        }
    });
}
 
function getCodeCoverage(searchResult, confidenceParametersDiv) {
    var data = "{\"packageNames\":[\"" + searchResult.packageName + "\"]}";
    GM_xmlhttpRequest({
        method: "POST",
        url: "http://brazil-metadata.amazon.com",
        data: data,
        headers: {
            "X-Amz-Target": "com.amazon.devtools.bmds.generated.BrazilMetaDataService.getSlocAndCoverageForPackages",
            "Content-Encoding": "amz-1.0",
            "Content-Type": "application/json; charset=UTF-8"
        },
        onload: function(response) {
            try{
                var jsonData = $.parseJSON(response.responseText);
                var slocData = jsonData.languageSlocAndCoveragesByMajorVersion[0].languageToSlocAndCoverage.java;
                var lineCoverage = slocData.lineCoverage;
                if(!lineCoverage) {
                    lineCoverage = 0;
                }
                var branchCoverage = slocData.branchCoverage;
                if(!branchCoverage) {
                    branchCoverage = 0;
                }
                var sloc = slocData.sloc;
                if(!sloc) {
                    sloc = 0;
                }
                var codeCoverage = new CodeCoverage(lineCoverage, branchCoverage, sloc);
                //console.log("codeCoverage=" + codeCoverage);
                searchResult.confidenceParameters.codeCoverage = codeCoverage;
                var colorBasedOnCoverage = calculateColorBasedOnCoverage(lineCoverage);
                var $span = $(document.createElement('span')).addClass('codeCoverage').addClass('confidenceParameter').addClass(colorBasedOnCoverage);
                //$span.text("Coverage: L:" + codeCoverage.lineCoverage + "% B:" + codeCoverage.branchCoverage + "% N:" + codeCoverage.sloc);
 
                var innerSpan = $(document.createElement('span')).addClass('confidenceParameterTooltip');
                $(innerSpan).html("&nbsp;&nbsp;Line: "+codeCoverage.lineCoverage + "%&nbsp;&nbsp<br/>&nbsp;&nbspBranch: " +codeCoverage.branchCoverage + "%&nbsp;&nbsp<br/>&nbsp;&nbspSloc: " + codeCoverage.sloc + "&nbsp;&nbsp");
                $span.html("Coverage: L:" + codeCoverage.lineCoverage + "%" + innerSpan[0].outerHTML);
 
                $(confidenceParametersDiv).append($span);
 
                fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
            }catch(err){
                //console.log(err);
                fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
            }
        },
        onerror: function(response) {
            //console.log(response);
            fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv);
        }
    });
};
 
function calculateColorBasedOnNumberOfDays(days){
    var months = Math.floor(days / 30);
    var years = Math.floor(months / 12);
    if(years == 0){
        return "background-green";
    }else if (years < 3){
        return "background-orange";
    } else {
        return "background-red";
    }
}
function calculateColorBasedOnCoverage(lineCoverage){
    if(lineCoverage > 75){
        return "background-green";
    } else if(lineCoverage > 40){
        return "background-orange";
    } else if (lineCoverage > 0) {
        return "background-red";
    } else {
        return "background-grey";
    }
}
function calculateColorBasedOnAvailability(isAvailable){
    if(isAvailable){
        return "background-green";
    } else {
        return "background-red";
    }
}
 
function calculateColorBasedOnAge(momentInTime){
    var currentEpoch = new Date().getTime() / 1000;
    var timeDiff = currentEpoch - momentInTime.epochSeconds;
    var days = Math.floor(timeDiff / (60 * 60 * 24));
    var months = Math.floor(days / 30);
    var years = Math.floor(months / 12);
    if(years == 0){
        return "background-green";
    }else if (years < 3){
        return "background-orange";
    } else {
        return "background-red";
    }
}
function generateTimeAgoText(lastDeploymentEpochSeconds) {
    //console.log("lastDeploymentEpochSeconds=" + lastDeploymentEpochSeconds);
    var currentEpoch = new Date().getTime() / 1000;
    var timeDiff = currentEpoch - lastDeploymentEpochSeconds;
    var days = Math.floor(timeDiff / (60 * 60 * 24));
    var months = Math.floor(days / 30);
    var years = Math.floor(months / 12);
    var deploymentText = " about ";
    if (years > 1) {
        deploymentText = years + " years ago";
    } else if (years == 1) {
        deploymentText = "1 year ago";
    } else if (months > 1) {
        deploymentText = months + " months ago";
    } else if (months == 1) {
        deploymentText = "1 month ago";
    } else {
        deploymentText = days + " days ago";
    }
    return deploymentText;
}
 
function addCssForConfidenceParameter(){
    addCss('.confidenceParameter { \
margin: 2px !important; \
display: inline-block; \
padding: 2px 4px; \
//font-size: 10.152px; \
//font-weight: bold; \
//line-height: 14px; \
//color: #fff; \
vertical-align: baseline; \
white-space: nowrap; \
//text-shadow: 0 -1px 0 rgba(0,0,0,0.25); \
border-radius: 3px; \
background-color: #e9e7e5eb;\
}');
    addCss('.background-green { \
background-color: #08620985 !important;\
}');
    addCss('.background-grey { \
background-color: #e9e7e5eb !important;\
}');
    addCss('.background-orange { \
background-color: #ffbd00eb !important;\
}');
    addCss('.background-red { \
background-color: #e900008c !important;\
}');
 
    addCss(' \
.confidenceParameter .confidenceParameterTooltip { \
visibility: hidden; \
background-color: #e9e7e5eb !important; \
color: black; \
padding: 5px 0; \
border-radius: 6px; \
position: absolute; \
z-index: 1; \
} \
.confidenceParameter:hover .confidenceParameterTooltip { \
visibility: visible; \
}');
}
function addCss(cssString) {
    var head = document.getElementsByTagName('head')[0];
    var newCss = document.createElement('style');
    newCss.type = "text/css";
    newCss.innerHTML = cssString;
    head.appendChild(newCss);
}
 
 
function fillInQuestionMarksForUnknownParameters(searchResult, confidenceParametersDiv){
    /*var lastCommitTimeSpan = $(confidenceParametersDiv).find(".lastCommitTime");
    if(lastCommitTimeSpan.length == 0){
        var $span = $(document.createElement('span')).addClass('lastCommitTime').addClass('confidenceParameter');
        $span.text("Code: ?");
        $(confidenceParametersDiv).append($span);
    }*/
 
    var authorDateSpan = $(confidenceParametersDiv).find(".authorDate");
    if(authorDateSpan.length == 0){
        var $span = $(document.createElement('span')).addClass('authorDate').addClass('confidenceParameter');
        $span.text("Code: NA");
        $(confidenceParametersDiv).append($span);
    }
 
    /*var authorLoginSpan = $(confidenceParametersDiv).find(".authorLogin");
    if(authorLoginSpan.length == 0){
        var $span = $(document.createElement('span')).addClass('authorLogin').addClass('confidenceParameter');
        $span.text("Author: NA");
        $(confidenceParametersDiv).append($span);
    }*/
 
    var isCRSpan = $(confidenceParametersDiv).find(".isCR");
    if(isCRSpan.length == 0){
        var $span = $(document.createElement('span')).addClass('isCR').addClass('confidenceParameter');
        $span.text("CR: NA");
        $(confidenceParametersDiv).append($span);
    }
 
    var isInProductionSpan = $(confidenceParametersDiv).find(".isInProduction");
    if(isInProductionSpan.length == 0){
        var $span = $(document.createElement('span')).addClass('isInProduction').addClass('confidenceParameter');
        $span.text("Prod: NA");
        $(confidenceParametersDiv).append($span);
    }
 
    var pipelineLastDeploymentTimeSpan = $(confidenceParametersDiv).find(".pipelineLastDeploymentTime");
    if(pipelineLastDeploymentTimeSpan.length == 0){
        var $span = $(document.createElement('span')).addClass('pipelineLastDeploymentTime').addClass('confidenceParameter');
        $span.text("Pipeline: NA");
        $(confidenceParametersDiv).append($span);
    }
    var codeCoverageSpan = $(confidenceParametersDiv).find(".codeCoverage");
    if(codeCoverageSpan.length == 0){
        var $span = $(document.createElement('span')).addClass('codeCoverage').addClass('confidenceParameter');
        $span.text("Coverage: NA");
        $(confidenceParametersDiv).append($span);
    }
    //console.log(searchResult);
    var totalScore = getCodeScore(searchResult);
    var backgroundColor = calculateColorBasedOnScore(totalScore);
    var $span = $(document.createElement('span')).addClass('totalScore').addClass('confidenceParameter').addClass(backgroundColor);
    $span.text("Score:" + totalScore);
    $(confidenceParametersDiv).append($span);
}
 
 
 
function getCodeScore(searchResult){
    var AUTHOR_DATE_WEIGHT = 0.1;
    var IS_PROD_WEIGHT = 0.4;
    var IS_CR_WEIGHT = 0.2;
    var DEPLOYMENT_DATE_WEIGHT = 0.1;
    var CODE_COVERAGE_WEIGHT = 0.2;
 
    var totalScore = 0;
    if (searchResult.confidenceParameters.authorTime) {
        if (searchResult.confidenceParameters.authorTime.epochSeconds) {
            var scoreAuthorDate = getScoreForDate(searchResult.confidenceParameters.authorTime) * AUTHOR_DATE_WEIGHT;
            //console.log("scoreAuthorDate = " + scoreAuthorDate);
            totalScore = totalScore + scoreAuthorDate;
       }
    }
 
    if (searchResult.confidenceParameters.codeCoverage) {
        if (searchResult.confidenceParameters.codeCoverage.lineCoverage) {
            var codeCoverageScore = searchResult.confidenceParameters.codeCoverage.lineCoverage * CODE_COVERAGE_WEIGHT;
            totalScore = totalScore + codeCoverageScore;
            //console.log("codeCoverageScore = " + codeCoverageScore);
        }
    }
 
    if (searchResult.confidenceParameters.isCR) {
        var crScore = 100 * IS_CR_WEIGHT;
        totalScore = totalScore + crScore;
    }
 
    if (searchResult.confidenceParameters.isInProduction) {
        var prodScore = 100 * IS_PROD_WEIGHT;
        totalScore = totalScore + prodScore;
    }
 
    if (searchResult.confidenceParameters.pipelineLastDeploymentTime) {
        if (searchResult.confidenceParameters.pipelineLastDeploymentTime.epochSeconds) {
            var scorePipelineDeployment = getScoreForDate(searchResult.confidenceParameters.pipelineLastDeploymentTime) * DEPLOYMENT_DATE_WEIGHT;
            totalScore = totalScore + scorePipelineDeployment;
        }
    }
    return Math.floor(totalScore);
}
 
function getScoreForDate(momentInTime) {
    var currentEpoch = new Date().getTime() / 1000;
    var timeDiff = currentEpoch - momentInTime.epochSeconds;
    //console.log("timeDiff " + isNaN(timeDiff));
    var days = Math.floor(timeDiff / (60 * 60 * 24));
    var months = Math.floor(days / 30);
    var years = Math.floor(months / 12);
 
    var timeScore;
    if (years >= 4) {
        timeScore = 0;
    } else if (years >= 1) {
        timeScore = 100 - (months/48)*100;
    } else {
        timeScore = 100;
    }
    return timeScore;
}
 
function calculateColorBasedOnScore(lineCoverage){
    if(lineCoverage > 75){
        return "background-green";
    } else if(lineCoverage > 40){
        return "background-orange";
    } else if (lineCoverage > 0) {
        return "background-red";
    } else {
        return "background-grey";
    }
}
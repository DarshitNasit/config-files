// ==UserScript==
// @name         Format Json Coral
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  To format request json in Coral Explorer
// @author       anuranch
// @match      https://coral.amazon.com/*/*/*/explorer
// @icon         https://www.google.com/s2/favicons?domain=amazon.com
// @grant        none
// ==/UserScript==

function createButton() {
    var btnStyle = "background-color: #008CBA; border: none; color: white; padding: 5px 10px; text-align: center; text-decoration: none; display: inline-block;font-size: 12px; margin-top: 10px";
    var btnText = "Format JSON";
    var formatBtn = document.createElement("button");
    formatBtn.innerHTML = btnText;
    formatBtn.onclick = formatText;
    formatBtn.setAttribute('style', btnStyle);
    // Add the button
    var editor = document.getElementById("request-input-editor");
    editor.before(formatBtn);
}

function formatText() {
    var inputRequest = ace.edit("request-input-editor").getValue();
    var requestInput = inputRequest.replace(/\s/g, '');
    // Format the json
    var jsonRequest = JSON.parse(requestInput);
    var formattedJson = JSON.stringify(jsonRequest, undefined, 4);
    ace.edit("request-input-editor").setValue(formattedJson);
}

createButton();

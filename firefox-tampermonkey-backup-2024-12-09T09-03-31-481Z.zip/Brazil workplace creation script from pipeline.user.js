// ==UserScript==
// @name         Brazil workplace creation script from pipeline
// @namespace    https://pipelines.amazon.com
// @version      0.15
// @description  Adds script code block to create brazil workplace from current pipeline page and version
// @author       fesabino@
// @match        https://pipelines.amazon.com/pipelines/*
// @exclude      https://pipelines.amazon.com/pipelines/search*
// @exclude      /^https://pipelines.amazon.com/pipelines/.*?/.+/
// @grant        none
// @updateURL    https://code.amazon.com/packages/FesabinoScripts/blobs/mainline/--/greasemonkey/builder-tools/pipelines/brazil-wokplace.user.js?download=1#.user.js
// ==/UserScript==

(function() {
  'use strict';

  var main = function() {

    var pipelineName = document.location.pathname.replace('pipelines', '').replace(/\//g, '');
    var versionSetName = $('#stage-name-VersionSet .target .name a').text();
    var packageNames = $('#stage-name-Packages ul li').map((index, pkg) => pkg.id.replace('target-name-', ''));
    var packages = packageNames.map((_, pkg) => {
      var packageName = pkg.replace(/\/(.*)/g, '');
      var branchName = pkg.replace(`${packageName}/`, '');
      return `brazil ws --use --package ${packageName} --branch ${branchName}`;
    }).toArray().join('\n');
    var script = `
eda create --name ${pipelineName} --pipeline ${pipelineName}

or

brazil ws create --name ${pipelineName} --vs ${versionSetName}
cd ${pipelineName}
${packages}`;
    console.log(`

[brazil-build script for workspace]

${script}`);

    $('#content').append(`<pre><code>${script}</code></pre>`);
  };

  $(document).ready(main);

})();
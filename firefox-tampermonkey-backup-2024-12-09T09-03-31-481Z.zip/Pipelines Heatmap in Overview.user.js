// ==UserScript==
// @name        Pipelines Heatmap in Overview
// @author      marcelva@
// @contributor Nathaniel Hutchins (nhutch@)
// @contributor Claudia Meadows (meaisiah@)
// @contributor Leif Snowden (snowdenl@)
// @contributor Rajendra Badapanda (badapr@)
// @contributor Jan Owoc (janowoc@)
// @contributor Kerem Kat (katkerem@)
// @contributor Cory Mainwaring (cormainw@)
// @contributor Franklin Ume Obiekwe (frankume@)
// @contributor Mike Gledhill (gledhim@)
// @contributor Chamantha Kankanamge (chamantk@)
// @contributor Nathaniel Ruiz (enowell@)
// @contributor Ben Evans (evnb@)
// @contributor Kabir Sala (kabisala@)
// @contributor Serah Isaac (serahi@)
// @contributor Brandon Lacy (bjlacy@)
// @contributor Jane Chen (chenjane@)
// @namespace   https://pipelines.amazon.com/pipelines
// @description Displays the heatmap in the Pipelines overview (with ticket and CR links in diff)
// @include     /^https://pipelines.amazon.com\/pipelines\/[\w-]+\/?(\?.*)?$/
// @version     1.17.1
// @require     https://cdnjs.cloudflare.com/ajax/libs/mithril/2.0.4/mithril.min.js
// @require     https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js
// @require     https://cdnjs.cloudflare.com/ajax/libs/localforage/1.7.3/localforage.min.js
// @connect     brazil-metadata-sso.corp.amazon.com
// @connect     code.amazon.com
// @updateURL   https://code.amazon.com/packages/GreasemonkeyScripts/blobs/mainline/--/Pipelines/heatmap-in-overview/embedded-heatmap.user.js?raw=1
// @downloadURL https://code.amazon.com/packages/GreasemonkeyScripts/blobs/mainline/--/Pipelines/heatmap-in-overview/embedded-heatmap.user.js?raw=1
// @grant       GM_xmlhttpRequest
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_registerMenuCommand
// @run-at      document-start
// ==/UserScript==

const ALL_TARGET_TYPES = ['PKG', 'VS', 'ENV', 'CD', 'CF', 'BATS', 'OS', 'DG', 'GEN'];

const PIPELINES_URL = 'https://pipelines.amazon.com';
const QP_CHANGE_ID = 'change_identifier';
const QP_TARGET_ID = 'target_identifier';
const TARGET_CHANGE_HISTORY_API = '/target_change_history';

const TRACK_PKGS_FETCH_CONCURRENCY = 1;
const TRACK_COMMIT_FETCH_CONCURRENCY = 1;
const VS_DIFF_FETCH_CONCURRENCY = 1;

const PIPELINES_CHANGE_HIST_API = PIPELINES_URL + TARGET_CHANGE_HISTORY_API;

const StatusCodes = {
  TOO_MANY_REQUESTS: 429
};

const CopyContentFormat = {
  MARKDOWN_TABLE: 0,
  MARKDOWN_LIST: 1
};

const DiffFetchStatus = {
  LOADING: 'loading',
  QUEUED: 'queued',
  SUCCEEDED: 'succeeded',
  FAILED: 'failed'
};


class PipelineCache {
  currentCacheVersion = 9;
  daysToBeStale = 14;
  pendingCacheUpdates = {};

  constructor(cacheEntriesPrefix, pipelineName) {
    this.cacheEntriesPrefix = cacheEntriesPrefix;
    this.pipelineName = pipelineName;
  }

  clean() {
    Object.keys(localStorage)
      .filter(key => new RegExp(`^${this.cacheEntriesPrefix}-`).test(key))
      .forEach(key => {
        var cacheKeyMatches = key.match(new RegExp(`^${this.cacheEntriesPrefix}-v([^\-]+)-([^\[]+)`));

        if (!cacheKeyMatches || cacheKeyMatches.length < 3) {
            localStorage.removeItem(key);
            return;
        }

        if (cacheKeyMatches[2] != this.pipelineName) {
          return;
        }

        if (cacheKeyMatches[1] != this.currentCacheVersion) {
          localStorage.removeItem(key);
          return;
        }

        const cacheValueRaw = localStorage.getItem(key);
        var cacheValue;
        try {
          cacheValue = JSON.parse(cacheValueRaw);
        }
        catch (error) {
          console.error(
            'Unable to parse cache entry for pipeline. ' +
            `pipelineCacheFilterPrefix=${this.cacheEntriesPrefix} ` +
            error);
          localStorage.removeItem(key)
        }

        const oldestAcceptableCacheDate = new Date();
        oldestAcceptableCacheDate.setDate(oldestAcceptableCacheDate.getDate() - this.daysToBeStale);

        if (cacheValue.accessDate < oldestAcceptableCacheDate) {
          localStorage.removeItem(key);
          return;
        }
      });

      for (let key of Object.keys(this.pendingCacheUpdates)) {
        this.set(key, this.pendingCacheUpdates[key]);
        delete this.pendingCacheUpdates[key];
      }
  }

  get(cacheKey) {
    const cacheValueRaw = localStorage.getItem(cacheKey);

    var cacheValue;
    try {
      cacheValue = JSON.parse(cacheValueRaw);
    } catch (error) {
      console.log(
        'Unable to get cache entry. ' +
        `pipelineName=${this.pipelineName} cacheKey=${cacheKey} cacheValueRaw=${cacheValueRaw}` +
        error);
      return null;
    }

    return cacheValue;
  }

  removeAll() {
    Object.keys(localStorage)
      .filter(key => new RegExp(`^${this.cacheEntriesPrefix}-`).test(key))
      .forEach(key => localStorage.removeItem(key));
  }

  set(cacheKey, body) {
    if (!body) {
      throw new Error('Must provide `body` to set in cache');
    }

    const cacheString = JSON.stringify({
      accessDate: new Date(),
      body
    })

    try {
      localStorage.setItem(cacheKey, cacheString)
    } catch (error) {
      console.error(
        'Failed to set cache value. Saving and trying later. ' +
        `pipelineName=${this.pipelineName} cacheKey=${cacheKey} ` +
        error);
      this.pendingCacheUpdates[cacheKey] = body;
      throw error;
    }
  }

  delete(cacheKey) {
    localStorage.removeItem(cacheKey);
  }
};

/**
 * Cache the diff between 2 version set revisions as seen on a pipeline.
 */
class DiffCache extends PipelineCache {
  constructor(pipelineName) {
    super('diffCache', pipelineName)
  }

  getCacheKeyForVfiDiff(newEventId, oldEventId = null) {
    return this.cacheEntriesPrefix +
      `-v${this.currentCacheVersion}` +
      `-${this.pipelineName}` +
      `[${newEventId}::${oldEventId || ''}]`;
  }

  getCacheKeyForPackageDiff(packageName, branchName, newCommitId, oldCommitId) {
      return this.cacheEntriesPrefix +
          `-v${this.currentCacheVersion}` +
          `-${this.pipelineName}` +
          `[${packageName}-${branchName}-${newCommitId}::${oldCommitId}]`;
  }
}

/**
 * Cache the version set revision currently deployed to a given pipeline stage.
 * If it changes, we want to know so we can fetch which commits were deployed.
 */
class TargetVersionsCache extends PipelineCache {
  constructor(pipelineName) {
    super('targetVersionsCache', pipelineName)
  }

  getCacheKey(target) {
    return `${this.cacheEntriesPrefix}-v${this.currentCacheVersion}-${this.pipelineName}[${target}]`;
  }
}

class OrderedHash {
  _keys = [];
  keys() { return this._keys; }
  _values = {};
  values() { return this._values; }

  contains(k) {
    return k in this.values();
  }

  entries() {
    return this.keys().map(k => [k, this.get(k)]);
  }

  get(k) { return this.values()[k]; }

  length() { return this.keys().length; }

  push(k, v) {
    if (!this.values()[k]) this.keys().push(k);
    this.values()[k] = v;
  }
};

(function () {
  var globalPipelineName = document.location.pathname.replace("/pipelines/", "")
  var scriptVersion = GM_info.script.version

  const runOnLoad = (function () {
    var fnsToRun = []

    function loaded() {
      return document.readyState === 'interactive' || document.readyState === 'complete'
    }

    if (!loaded()) {
      window.addEventListener('load', function load() {
        window.removeEventListener('load', load)

        fnsToRun.filter(fn => fn())
      })
    }

    // if we're loaded, run the function
    // if not, cache it, and load it later
    return fn => new Promise(resolve => {
      loaded() ? resolve(fn()) : fnsToRun.push(() => resolve(fn()))
    })
  }())
  const PALETTE_KEY = "pipelines.heatmap.palette";
  const PALETTE_SELECTION_KEY = "pipelines.heatmap.colors.selected";
  const DEFAULT_PALETTE = "Pipelines";
  const DEFAULT_PALETTES = {
    "Pipelines": {
        "heat-map-color-0": "102, 255, 0",
        "heat-map-color-1": "133, 255, 0",
        "heat-map-color-2": "163, 255, 0",
        "heat-map-color-3": "193, 255, 0",
        "heat-map-color-4": "224, 225, 0",
        "heat-map-color-5": "255, 255, 0",
        "heat-map-color-6": "255, 204, 0",
        "heat-map-color-7": "255, 153, 0",
        "heat-map-color-8": "255, 102, 0",
        "heat-map-color-9": "255, 51, 0",
        "heat-map-color-10": "255, 0, 0",
        "heat-map-color-11": "235, 0, 0",
        "heat-map-color-12": "214, 0, 0",
        "heat-map-color-13": "194, 0, 0",
        "heat-map-color-14": "173, 0, 0",
        "heat-map-color-15": "153, 0, 0"
    },
    "Rainbow": {
        "heat-map-color-0": "92, 171, 255",
        "heat-map-color-1": "92, 255, 190",
        "heat-map-color-2": "75, 224, 0",
        "heat-map-color-3": "180, 251, 14",
        "heat-map-color-4": "255, 248, 35",
        "heat-map-color-5": "255, 223, 40",
        "heat-map-color-6": "255, 198, 45",
        "heat-map-color-7": "255, 148, 55",
        "heat-map-color-8": "255, 124, 92",
        "heat-map-color-9": "255, 51, 51",
        "heat-map-color-10": "210, 23, 39",
        "heat-map-color-11": "164, 12, 81",
        "heat-map-color-12": "117, 0, 123",
        "heat-map-color-13": "59, 0, 62",
        "heat-map-color-14": "30, 0, 31",
        "heat-map-color-15": "0, 0, 0"
    },
    "High Contrast": {
        "heat-map-color-0": "255, 0, 255",
        "heat-map-color-1": "127, 0, 127",
        "heat-map-color-2": "0, 0, 127",
        "heat-map-color-3": "0, 0, 255",
        "heat-map-color-4": "0, 127, 127",
        "heat-map-color-5": "0, 255, 255",
        "heat-map-color-6": "0, 127, 0",
        "heat-map-color-7": "0, 255, 0",
        "heat-map-color-8": "255, 255, 0",
        "heat-map-color-9": "255, 127, 0",
        "heat-map-color-10": "127, 0, 0",
        "heat-map-color-11": "255, 0, 0",
        "heat-map-color-12": "0, 0, 0",
        "heat-map-color-13": "127, 127, 127",
        "heat-map-color-14": "191, 191, 191",
        "heat-map-color-15": "255, 255, 255"
    },
    "Red Palette": {
      "heat-map-color-0": "255, 0, 0", // Pure Red
      "heat-map-color-1": "247, 16, 16", // Deep Red
      "heat-map-color-2": "239, 32, 32", // Fire brick Red
      "heat-map-color-3": "231, 48, 48", // Crimson Red
      "heat-map-color-4": "223, 64, 64", // Rusty Red
      "heat-map-color-5": "215, 80, 80", // Brick Red
      "heat-map-color-6": "207, 96, 96", // Salmon Red
      "heat-map-color-7": "199, 112, 112", // Terra cotta Red
      "heat-map-color-8": "191, 128, 128", // Light Red
      "heat-map-color-9": "183, 144, 144", // Dusty Red
      "heat-map-color-10": "175, 160, 160", // Pale Red
      "heat-map-color-11": "167, 176, 176", // Blush Red
      "heat-map-color-12": "159, 192, 192", // Rosy Red
      "heat-map-color-13": "151, 208, 208", // Soft Red
      "heat-map-color-14": "143, 224, 224", // Pastel Red
      "heat-map-color-15": "135, 240, 240" // Light Red
    },
    "Orange Palette": {
      "heat-map-color-0": "255, 128, 0", // Pure Orange
      "heat-map-color-1": "247, 144, 16", // Deep Orange
      "heat-map-color-2": "239, 160, 32", // Pumpkin Orange
      "heat-map-color-3": "231, 176, 48", // Tangerine Orange
      "heat-map-color-4": "223, 192, 64", // Amber Orange
      "heat-map-color-5": "215, 208, 80", // Apricot Orange
      "heat-map-color-6": "207, 224, 96", // Peach Orange
      "heat-map-color-7": "199, 240, 112", // Cantaloupe Orange
      "heat-map-color-8": "191, 255, 128", // Light Orange
      "heat-map-color-9": "183, 255, 144", // Melon Orange
      "heat-map-color-10": "175, 255, 160", // Pale Orange
      "heat-map-color-11": "167, 255, 176", // Cream Orange
      "heat-map-color-12": "159, 255, 192", // Pastel Orange
      "heat-map-color-13": "151, 255, 208", // Soft Orange
      "heat-map-color-14": "143, 255, 224", // Pearly Orange
      "heat-map-color-15": "135, 255, 240" // Light Orange
    },
    "Yellow Palette": {
      "heat-map-color-0": "255, 255, 0", // Pure Yellow
      "heat-map-color-1": "247, 247, 16", // Deep Yellow
      "heat-map-color-2": "239, 239, 32", // Mustard Yellow
      "heat-map-color-3": "231, 231, 48", // Goldenrod Yellow
      "heat-map-color-4": "223, 223, 64", // Amber Yellow
      "heat-map-color-5": "215, 215, 80", // Marigold Yellow
      "heat-map-color-6": "207, 207, 96", // Butter Yellow
      "heat-map-color-7": "199, 199, 112", // Lemon Yellow
      "heat-map-color-8": "191, 191, 128", // Light Yellow
      "heat-map-color-9": "183, 183, 144", // Cream Yellow
      "heat-map-color-10": "175, 175, 160", // Pale Yellow
      "heat-map-color-11": "167, 167, 176", // Beige Yellow
      "heat-map-color-12": "159, 159, 192", // Pastel Yellow
      "heat-map-color-13": "151, 151, 208", // Soft Yellow
      "heat-map-color-14": "143, 143, 224", // Pearly Yellow
      "heat-map-color-15": "135, 135, 240" // Light Yellow
    },
    "Green Palette": {
      "heat-map-color-0": "0, 255, 0", // Pure Green
      "heat-map-color-1": "16, 247, 16", // Deep Green
      "heat-map-color-2": "32, 239, 32", // Forest Green
      "heat-map-color-3": "48, 231, 48", // Emerald Green
      "heat-map-color-4": "64, 223, 64", // Lime Green
      "heat-map-color-5": "80, 215, 80", // Olive Green
      "heat-map-color-6": "96, 207, 96", // Moss Green
      "heat-map-color-7": "112, 199, 112", // Sage Green
      "heat-map-color-8": "128, 191, 128", // Light Green
      "heat-map-color-9": "144, 183, 144", // Mint Green
      "heat-map-color-10": "160, 175, 160", // Pale Green
      "heat-map-color-11": "176, 167, 176", // Blush Green
      "heat-map-color-12": "192, 159, 192", // Pastel Green
      "heat-map-color-13": "208, 151, 208", // Soft Green
      "heat-map-color-14": "224, 143, 224", // Pearly Green
      "heat-map-color-15": "240, 135, 240" // Light Green
    },
    "Blue Palette": {
      "heat-map-color-0": "0, 0, 255", // Pure Blue
      "heat-map-color-1": "16, 16, 247", // Deep Blue
      "heat-map-color-2": "32, 32, 239", // Navy Blue
      "heat-map-color-3": "48, 48, 231", // Royal Blue
      "heat-map-color-4": "64, 64, 223", // Sapphire Blue
      "heat-map-color-5": "80, 80, 215", // Indigo Blue
      "heat-map-color-6": "96, 96, 207", // Midnight Blue
      "heat-map-color-7": "112, 112, 199", // Slate Blue
      "heat-map-color-8": "128, 128, 191", // Light Blue
      "heat-map-color-9": "144, 144, 183", // Powder Blue
      "heat-map-color-10": "160, 160, 175", // Pale Blue
      "heat-map-color-11": "176, 176, 167", // Blush Blue
      "heat-map-color-12": "192, 192, 159", // Pastel Blue
      "heat-map-color-13": "208, 208, 151", // Soft Blue
      "heat-map-color-14": "224, 224, 143", // Pearly Blue
      "heat-map-color-15": "240, 240, 135" // Light Blue
    },
    "Indigo Palette": {
      "heat-map-color-0": "75, 0, 130", // Deep Indigo
      "heat-map-color-1": "91, 16, 142", // Indigo
      "heat-map-color-2": "107, 32, 154", // Purple Indigo
      "heat-map-color-3": "123, 48, 166", // Violet Indigo
      "heat-map-color-4": "139, 64, 178", // Plum Indigo
      "heat-map-color-5": "155, 80, 190", // Grape Indigo
      "heat-map-color-6": "171, 96, 202", // Lavender Indigo
      "heat-map-color-7": "187, 112, 214", // Mauve Indigo
      "heat-map-color-8": "203, 128, 226", // Light Indigo
      "heat-map-color-9": "219, 144, 238", // Pale Indigo
      "heat-map-color-10": "235, 160, 250", // Blush Indigo
      "heat-map-color-11": "251, 176, 255", // Pastel Indigo
      "heat-map-color-12": "255, 192, 255", // Soft Indigo
      "heat-map-color-13": "255, 208, 255", // Pearly Indigo
      "heat-map-color-14": "255, 224, 255", // Light Indigo
      "heat-map-color-15": "255, 240, 255" // Pale Indigo
    },
    "Violet Palette": {
      "heat-map-color-0": "153, 0, 153", // Deep Violet
      "heat-map-color-1": "179, 51, 179", // Violet
      "heat-map-color-2": "204, 102, 204", // Purple Violet
      "heat-map-color-3": "230, 153, 230", // Magenta Violet
      "heat-map-color-4": "255, 204, 255", // Light Violet
      "heat-map-color-5": "255, 229, 255", // Pale Violet
      "heat-map-color-6": "255, 242, 255", // Blush violet
      "heat-map-color-7": "255, 248, 255", // Pastel violet
      "heat-map-color-8": "255, 251, 255", // Soft violet
      "heat-map-color-9": "255, 253, 255", // Pearly violet
      "heat-map-color-10": "255, 255, 255", // White
      "heat-map-color-11": "253, 253, 253", // Off-white
      "heat-map-color-12": "251, 251, 251", // Cream
      "heat-map-color-13": "248, 248, 248", // Beige
      "heat-map-color-14": "242, 242, 242", // Light gray
      "heat-map-color-15": "230, 230, 230" // Gray
    },
};

function parseColorMap(val) {
  console.log('Loading color map', val);

  // Sample valid values:
  // default
  // ["102, 255, 0", "133, 255, 0", "163, 255, 0", "193, 255, 0", "224, 225, 0", "255, 255, 0", "255, 204, 0", "255, 153, 0", "255, 102, 0", "255, 51, 0", "255, 0, 0",  "235, 0, 0", "214, 0, 0", "194, 0, 0", "173, 0, 0", "153, 0, 0"]
  let colors;
  try{
    colors = JSON.parse(val);

  } catch {
      console.error("Could not parse new color palette");
      return null;
  }

  if(!Array.isArray(colors) || colors.length !== 16) {
    console.error("Color theme is not an array of 16 RGB values");
    return null;
  }

  return Object.fromEntries(colors.map((color, i) => [`heat-map-color-${i}`, color]))
}

function loadPalettes() {
return GM_getValue(PALETTE_KEY, DEFAULT_PALETTES);
}

function savePalettes(palettes) {
try{
  GM_setValue(PALETTE_KEY, palettes);
  renderPaletteChooser();
  return true;
}catch(err){
  console.log(err);
  return false;
}
}

function setPalette(name) {
   GM_setValue(PALETTE_SELECTION_KEY, name);
}

GM_registerMenuCommand("Pipelines Heatmap in Overview: Add/Change color theme...", () => {
const palettes = loadPalettes();
const nameInput = prompt(
    `Enter name for the new color theme to create or an existing name to overwrite it.\n` +
    `Existing color themes are ${Object.keys(palettes).join(", ")}.\n`
    );
let promptText = `Creating new color scheme ${nameInput}\n` +
    'A custom color theme can be defined as a 16-element array with string elements, each element a comma-separated rgb value, e.g.:\n' +
    '["0, 0, 0","16, 16, 16","32, 32, 32","48, 48, 48","64, 64, 64","80, 80, 80","96, 96, 96","112, 112, 112","128, 128, 128","144, 144, 144","160, 160, 160","176, 176, 176","192, 192, 192","208, 208, 208","224, 224, 224","240, 240, 240"]\n';
if (Object.keys(palettes).indexOf(nameInput) !== -1) {
    promptText = `Updating existing color scheme ${nameInput}\n` +
        `16-element array currently defining ${nameInput} is:\n ${JSON.stringify(Object.values(palettes[nameInput]))}`
    ;
}
const inputString = prompt(promptText);
const inputColors = parseColorMap(inputString);
  if (inputColors !== null) {
      palettes[nameInput] = inputColors;
      console.log("Setting color map", inputString);
      setPalette(nameInput);
      if(savePalettes(palettes)) {
          setHeatMapColors();
      }
  }
});
GM_registerMenuCommand("Pipelines Heatmap in Overview: Delete color theme...", () => {
  const palettes = loadPalettes();
  const nameInput = prompt(`Enter name of the color theme to delete.\n` +
    `Existing color themes that can be deleted are: ${Object.keys(palettes).filter((key)=> key !== DEFAULT_PALETTE).join(", ")}.\n`);
  if (Object.keys(palettes).indexOf(nameInput) === -1) {
    console.error(`Color theme '${nameInput}' does not exist! Failed to delete it. Color themes are: ${Object.keys(palettes).join(", ")}`);
      return;
  }

  if (nameInput === DEFAULT_PALETTE) {
      console.error(`Cannot delete '${nameInput}' as it is the default backup palette.`);
      return;
  }

  delete palettes[nameInput];
  savePalettes(palettes);
  setHeatMapColors();
});
GM_registerMenuCommand("Pipelines Heatmap in Overview: Reset color themes", () => {
  if (confirm("WARNING: This will reset color themes to the defaults, deleting any additional themes you've made and all edits to the default themes")) {
      savePalettes(DEFAULT_PALETTES);
      setHeatMapColors();
  }
});

renderPaletteChooser = runOnLoad(() => {
    renderPaletteChooser = () => {
        const CONTAINER_ID = "pipelines-heatmap-palette-selector";
        const pipelineInfoHeader = document.querySelector(".pipeline-info-header");
        if (document.getElementById(CONTAINER_ID)) {
            pipelineInfoHeader.removeChild(document.getElementById(CONTAINER_ID));
        }
        const containerEl = document.createElement("span");
        containerEl.id = CONTAINER_ID;

        const labelEl = document.createElement("label");
        labelEl.innerHTML = "HeatMap Color Scheme: ";
        labelEl.for = "heat-map-color-selector";
        containerEl.appendChild(labelEl);

        const selectEl = document.createElement("select");
        selectEl.id = "heat-map-color-selector";
        const selectedName = GM_getValue(PALETTE_SELECTION_KEY, "Pipelines");
        const palettes = loadPalettes();
        for (let name in palettes) {
            let option = document.createElement("option");
            option.innerHTML = name;
            option.value = name;
            if (name === selectedName) {
                option.selected = "true";
            }
            selectEl.appendChild(option);
        }
        selectEl.onchange = () => {
            setPalette(selectEl.value);
            setHeatMapColors()
        };
        containerEl.appendChild(selectEl);

        pipelineInfoHeader.appendChild(containerEl);
    }
    renderPaletteChooser();
});

  packages = runOnLoad(() =>
    packages = [].slice
      .call(document.querySelectorAll('.contains-pkg li.target div.name'))
      .map(element => element.innerText.replace(/\/.*$/, '').trim())
  )

  const diffCache = new DiffCache(globalPipelineName);
  const targetVersionsCache = new TargetVersionsCache(globalPipelineName);

  /**
   * Keeps track of all the targets in the pipeline and information about them.
   *
   * NOTE: This is an `OrderedHash` so we can track the targets in order. Do not use it as a regular hash.
   *
   * Knowing what version is deployed to each target allows us to:
   * - fetch the tracking status of commits for only that targetType and VFI
   * - easily color of the targets by VFI
   */
  const pipelineTargetsToMetadata = new OrderedHash();

  // the next few variables are objects that map a version to a list of changes with varying degrees of filteredness

  var state = {
    selectedVersion: null,
    selectedTarget: null, // used to keep the details button open
    showChangeFinder: '',
    changeFinderCoords: {
      top: 423,
      left: 495
    },
    filter: {
      isConsumed: true,
      needle: null,
      extra_packages_regex: new RegExp(localStorage.getItem("heatmap_extra_packages_regex")),
      filter_packages_regex: new RegExp(localStorage.getItem("heatmap_filter_packages_regex")),

      // cache settings so that we don't rerender every time something changes
      previous: {}
    },
    stats: {
      diffsFetched: 0,
      diffsSkipped: 0
    }
  }

  var VFIsMap = {
    // "MyVersionSet@BMYREVISIONID": {
    //   version: "MyVersionSet@BMYREVISIONID"
    //   versionset: "MyVersionSet" // group of versions (the thing before the @B)
    //   revision: "MYREVISIONID" // (id of) set of changes in a versionset (the thing after the @B)
    //   color: "heat-map-color-4",
    //   diffUrl: "", // url for the full diff from pipeline
    //   vsDiffUrl: "", // url for the full version set diff
    //   diffWith: "" // version that this is diffed against
    //   status: "", // loading || succeeded || failed
    //   error: [], // array of errors; used to show errors to the user
    //   changes: [ // array of changes
    //     {
    //       version,
    //       package,
    //       commitHash,
    //       author,
    //       date,
    //       description
    //     },
    //     ...
    //   ]
    // }
  }
  var VFIsList = []

  var allChanges = [] // master list of all changes

  var diffCopyContent = []

  function setStyles () {
    var styles = document.createElement('style')
    document.head.appendChild(styles)

    var rules = [
      `.heat-map-box { position: relative; margin-bottom: 4px; overflow-wrap: break-word; cursor: pointer; font-weight: bold; padding: 2px; border-radius: 6px; }`,
      `.heat-map-box>:first-child {
          display: block;
          margin-left: 40px;
          background: white;
          padding: 4px;
          border-radius: 4px;
      }`,
      `.heat-map-box.has-diff:hover {
        border-radius: 6px 0 0 6px
      }`,
      `.heat-map-box.has-diff:hover>:first-child {
        border-radius: 4px 0 0 4px
      }`,
      `.heat-map-box.heat-map-dim:after {
        pointer-events: none;
        content: "";
        background: rgba(255, 255, 255, .3);
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
      }`,
      `.heat-map-box.heat-map-glow {
        border: 2px solid #006B8F;
        margin: -2px -2px 2px -2px;
      }`,
      `.heat-map-box.heat-map-glow.show-diff-button:not(.heat-map-color-all) {
        border-right-color: transparent;
      }`,
      `.heat-map-box.heat-map-glow:not(.heat-map-color-all):after {
        content: '';
        pointer-events: none;
        box-shadow: 0 0 7px 2px #0091C2;
        left: 0px;
        right: 0px;
        border-radius: 6px;
        top: 0px;
        bottom: 0px;
        position: absolute;
      }`,
      `.heat-map-box.has-diff.heat-map-glow:hover:after,
        .heat-map-box.has-diff.heat-map-hover:after,
        .heat-map-box.has-diff.heat-map-glow.show-diff-button:after {
        right: -37px;
      }`,
      `.heat-map-box.heat-map-glow.show-diff-button > :first-child {
        border-radius: 4px 0 0 4px;
      }`,

      '.pipeline .version-sets-container { display: flex; justify-content: space-between } ',
      '.pipeline .version-sets-container .overview-version-set { flex: 0 0 auto; width: 48px; margin-right: 7px; display: flex; flex-direction: column; justify-content: space-between; } ',
      '.pipeline .version-sets-container .individual-version-sets { min-width: 0; } ',

      '.pipeline .changes-panel { position: absolute; background: white; border-radius: 4px; border: 1px solid darkgray; font-size: 11px; padding: 7px; box-shadow: 1px 1px 20px -2px black; min-width: 275px; z-index: 100; }', // they made me do it ><
      `.pipeline .changes-panel [class*=heat-map-color] {
        border: 1px solid black;
        border-radius: 3px;
        margin-top: -1px;
        cursor: pointer;
        display: inline-block;
        padding: 1px 0px;
      }`,
      `.pipeline .changes-panel [class*=heat-map-color]>span {
        background: #1a1a1a;
        color: #e6e6e6;
        padding: 1px;
        padding-right: 3px;
        padding-left: 4px;
        margin-left: 16px;
      `,
      '.pipeline .changes-panel .changes-package { position: -webkit-sticky; position: sticky; top: 0; background: white; text-overflow: ellipsis; overflow: hidden; margin-top: 0px; margin-bottom: 4px; }',
      '.pipeline .changes-panel .changes-package:not(:first-child) { margin-top: 6px; }',
      '.pipeline .changes-panel h3 { display: flex; margin-top: 0; margin-bottom: 5px; white-space: pre-wrap; }',
      '.pipeline .changes-panel h3>a { display: flex; flex-direction: column; justify-content: center; font-size: 10px; margin-left: 5px; }',
      '.pipeline .changes-panel .changes-all-commits { margin: 10px 0; padding-right: 10px; } ',

      '.pipeline .changes-filter { display: flex }',
      '.pipeline .changes-filter label { border: 1px solid lightgray; padding: 2px 6px; border-top-left-radius: 3px; border-bottom-left-radius: 3px; border-right: 0; margin: 0; font-weight: normal; font-style: italic; color: darkgray; display: flex; flex-direction: column; justify-content: center; }',
      '.pipeline .changes-filter input { border: 1px solid lightgray; border-left: 0; padding: 3px 4px 4px 4px; border-top-right-radius: 3px; border-bottom-right-radius: 3px; }',
      '.pipeline .changes-commit { margin-left: 9px; margin-top: 3px; margin-bottom: 1px; }',
      '.pipeline .changes-commit_message+div { position: relative; display: inline; left: 20px; z-index: 1; }',
      '.pipeline .changes-commit_message+div>div { display: none; position: absolute; background: white; width: 200px; word-break: break-word; top: 1.5em }',
      '.pipeline .changes-commit_message:hover+div>div { display: block; padding: 5px; border-radius: 3px; border: 1px solid gray; }',

      '.changes-open_panel { display: none; position: absolute; top: 7px; left: calc(100% + 2px); height: calc(100% - 15px); justify-content: center; flex-direction: column; padding: 0px 5px; background: white; border: solid 1px black; border-left: 0; box-shadow: 1px 1px 6px -2px; border-radius: 3px; border-top-left-radius: 0; border-bottom-left-radius: 0; z-index: 1; white-space: nowrap}',
      '.contains-vs .heat-map-glow .changes-open_panel { display: flex; }',

      `.heat-map-box .diff-button {
        display: none;

        background: inherit;
        border-radius: 0px 6px 6px 0px;

        margin-left: -2px;
        position: absolute;
        padding: 2px;
        left: 100%;
        top: 0px;
        white-space: nowrap;
        height: 100%;
        box-sizing: border-box;
      }`,

      `.heat-map-box .diff-button>a {
        background: white;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 0px 9px;
        border-radius: 0px 4px 4px 0px;
      }`,

      `.heat-map-box:hover .diff-button,
        .heat-map-box.show-diff-button .diff-button {
        display: flex;
      }`,

      `.heat-map-box.heat-map-glow.show-diff-button { border-top-right-radius: 0px; border-bottom-right-radius: 0px; }`,

      `.heat-map-box.heat-map-glow:hover .diff-button,
        .heat-map-box.heat-map-glow.show-diff-button .diff-button  {
        border-bottom-left-radius: 0px;
        border-top-left-radius: 0px;
        top: -2px;
        height: calc(100% + 4px);
        border: 2px solid rgb(0 130 173);
        border-left: 0;
      }`,

      '.pipeline .targets .heat-map-box .naws-details { margin-bottom: 0px;}',

      `.heat-map-box.heat-map-hover:before {
        pointer-events: none;
        content: '';
        box-shadow: 0 0 7px 2px #0091C2;
        left: 0px;
        right: 0px;
        border-radius: 6px;
        top: 0px;
        bottom: 0px;
        position: absolute;
      }`,

      `.heat-map-box.heat-map-hover.has-diff:hover:before {
        right: -37px;
      }`,
    ]

    rules.forEach((rule) => {
      styles.sheet.insertRule(rule)
    })
    setHeatMapColors();
  }
  function setHeatMapColors() {
    let heatMapColorStylesEl = document.querySelector("#heat-map-color-styles");
    if (heatMapColorStylesEl) {
        heatMapColorStylesEl.parentNode.removeChild(heatMapColorStylesEl);
    }
    heatMapColorStylesEl = document.createElement("style");
    heatMapColorStylesEl.id = "heat-map-color-styles";
    document.body.appendChild(heatMapColorStylesEl);

    let palettes = loadPalettes();
    let colorMap = palettes[GM_getValue(PALETTE_SELECTION_KEY, DEFAULT_PALETTE)];
    if (!colorMap) {
        setPalette(DEFAULT_PALETTE);
        colorMap = palettes[GM_getValue(PALETTE_SELECTION_KEY, DEFAULT_PALETTE)];
    }

    const rules = [
    '.heat-map-color-all { background-color: #80ffff; flex: 1 0 auto; }',
    `.heat-map-color-0 { ${backgroundColor(colorMap, 'heat-map-color-0', 1)} }`,
    `.heat-map-color-1 { ${backgroundColor(colorMap, 'heat-map-color-1', 1)} }`,
    `.heat-map-color-2 { ${backgroundColor(colorMap, 'heat-map-color-2', 1)} }`,
    `.heat-map-color-3 { ${backgroundColor(colorMap, 'heat-map-color-3', 1)} }`,
    `.heat-map-color-4 { ${backgroundColor(colorMap, 'heat-map-color-4', 1)} }`,
    `.heat-map-color-5 { ${backgroundColor(colorMap, 'heat-map-color-5', 1)} }`,
    `.heat-map-color-6 { ${backgroundColor(colorMap, 'heat-map-color-6', 1)} }`,
    `.heat-map-color-7 { ${backgroundColor(colorMap, 'heat-map-color-7', 1)} }`,
    `.heat-map-color-8 { ${backgroundColor(colorMap, 'heat-map-color-8', 1)} }`,
    `.heat-map-color-9 { ${backgroundColor(colorMap, 'heat-map-color-9', 1)} }`,
    `.heat-map-color-10 { ${backgroundColor(colorMap, 'heat-map-color-10', 1)} }`,
    `.heat-map-color-11 { ${backgroundColor(colorMap, 'heat-map-color-11', 1)} }`,
    `.heat-map-color-12 { ${backgroundColor(colorMap, 'heat-map-color-12', 1)} }`,
    `.heat-map-color-13 { ${backgroundColor(colorMap, 'heat-map-color-13', 1)} }`,
    `.heat-map-color-14 { ${backgroundColor(colorMap, 'heat-map-color-14', 1)} }`,
    `.heat-map-color-15 { ${backgroundColor(colorMap, 'heat-map-color-15', 1)} }`,
        ];
    for (let rule of rules) {
        heatMapColorStylesEl.sheet.insertRule(rule);
    }
}

function getColor(colorMap, color, opacity = 1) {
    return `rgb(${colorMap[color]}, ${opacity})`
}

  function getColorNumber(color) {
    let matcher = color.match(/heat-map-color-(\d+)/)
    if (matcher) {
      return Number(matcher[1])
    }
    return 15
  }

  function backgroundColor(colorMap, color = 'heat-map-color-15', opacity = 1) {
    let colorValue = getColor(colorMap, color, opacity)
    let colorNumber = getColorNumber(color)

    let angle
    let angleType = colorNumber % 3

    if (angleType === 1) angle = 45
    else if (angleType === 2) angle = 135

    if (!angle) {
      return `background: ${colorValue};`
    }

    return `
      background: repeating-linear-gradient(
        ${angle}deg,
        ${colorValue},
        ${colorValue} 6px,
        transparent 6px,
        transparent 8px
      );
    `
  }

  var tryRender = (function () {
    // a sub-component that when run either a) attempt a redraw or b) initializes the app
    // keeps its state internalized

    var initialized = false,
      windowLoaded = false,

      attemptTimer = null

    window.addEventListener('load', function load() {
      window.removeEventListener('load', load)

      windowLoaded = true

      tryRender()
    })

    function initialize() {
      setStyles();

      document.querySelectorAll("li.target").forEach(function (target) {
        const currentTarget = target.getAttribute("id").trim().replace("target-name-", "");

        if (!pipelineTargetsToMetadata.contains(currentTarget)) {
          return;
        }

        const currentVersion = pipelineTargetsToMetadata.get(currentTarget).version,
          element = target.querySelector("div.name"),
          guts = element,
          root = document.createElement('div')

        // if there's no version for this element, stop
        if (!VFIsMap[currentVersion]) return true;

        // add list of older versions where 'VersionSet is listed'
        if ($(element).closest('.contains-vs')[0]) {
          // insert older versions
          element.insertAdjacentElement('afterend', root)
          element.parentElement.removeChild(element) // delete the element

          m.mount(root, VersionSets)
        } else {
          element.insertAdjacentElement('beforebegin', root)
          m.mount(root, {
            view: () => m(HeatMapBox, {
              target: currentTarget,
              version: currentVersion,
              color: VFIsMap[currentVersion].color,
              isValid: VFIsMap[currentVersion].isValid,
              guts
            })
          })
        }
      });

      // mount changes container
      changesContainer = document.createElement('div')
      document.querySelector('#pipelines_container').appendChild(changesContainer)
      m.mount(changesContainer, DiffPanel)
    }

    function renderAttempt() {
      clearTimeout(attemptTimer);
      attemptTimer = null

      if (initialized) {
        try {
          m.redraw()
        } catch (error) {
          console.warn(error)
        }
      } else if (windowLoaded && Object.keys(VFIsMap).length && pipelineTargetsToMetadata.length()) {
        try {
          m('div') // test for mithril
          initialized = true
          initialize()
        } catch (err) {
          console.warn(err)
          attemptTimer = setTimeout(renderAttempt, 200)
        }
      } else {
        // will use this to prevent infinite attempts on subpages
        attemptTimer = setTimeout(renderAttempt, 200)
      }
    }

    return renderAttempt
  }())

  // build components for use by app
    // VersionSets -- the 'VersionSet' section that shows all versions
  var VersionSets = {
    view: () => {
      var glow = ('' === state.selectedVersion && '.heat-map-glow') || (state.selectedVersion && '.heat-map-dim') || ''
      var loading = !!Object.keys(VFIsMap).map(key => VFIsMap[key].status).find(status => status === DiffFetchStatus.LOADING)
      var hovered = state.hoveredVersion === "full-diff" ? '.heat-map-hover' : ''

      return (
        m('.version-sets-container', [
          m('.overview-version-set',
            m(`.heat-map-box.heat-map-color-all${glow}${hovered}.diff-button`, {
              style: "display: flex; justify-content: center; flex-direction: column; text-align: center; padding: 4px 5px 5px 4px;",
              onclick: (event) => openChangesPanel(event, ''),
              onmouseover: () => {
                if (state.hoveredVersion !== "full-diff") {
                  state.hoveredVersion = "full-diff"
                }
              },
              onmouseout: () => {
                if (state.hoveredVersion === "full-diff") {
                  state.hoveredVersion = undefined
                }
              }
            }, "Full Diff"),
            m('div', { style: `margin-bottom: 10px; ${loading ? '' : 'color: green'}` },
              loading ? "Loading..." : "Loaded!"
            )
          ),
          m('.individual-version-sets',
            VFIsList
              .map((VFI) => {
                return [
                  m(HeatMapBox, {
                    version: VFI.version,
                    target: VFI.version.split(/@b/i)[0],
                    color: VFI.color,
                    guts: `<a href="https://code.amazon.com/version-sets/${VFI.version.replace(/@[A-Z]/,"@")}" target="_blank">${VFI.version.replace(/@[A-Z]/,"@")}</a>`,
                    isValid: VFI.isValid
                  }),
                  m(DiffStatus, {
                    status: VFI.status,
                    version: VFI.version
                  })
                ]
              })
          )
        ])
      )
    }
  }

  // HeatMapBox -- renders each heat map box
  var HeatMapBox = {
    view: (vnode) => {
      var version = vnode.attrs.version
      var isValid = vnode.attrs.isValid
      var target = vnode.attrs.target
      var guts = vnode.attrs.guts

      // CSS variables
      var color = `.${vnode.attrs.color}`
      var selected = target === state.selectedTarget ? '.show-diff-button' : ''
      var glow = (version === state.selectedVersion && '.heat-map-glow') ||
        (state.selectedVersion && version !== state.selectedVersion && '.heat-map-dim') ||
        ''
      var hovered = version === state.hoveredVersion ? '.heat-map-hover' : ''
      var hasDiff = isValid ? '.has-diff' : ''

      var gutsElement
      if (guts && typeof guts === "string") {
        gutsElement = m.trust(guts)
      } else if (guts) {
        gutsElement = m('div[data-guts]')
      }

      return [
        m(`.heat-map-box${color}${glow}${selected}${hovered}${hasDiff}`,
          {
            onclick: (event) => {
              if (state.selectedVersion !== version) {
                event.preventDefault()
                state.selectedVersion = version
                state.selectedTarget = undefined
              }
            },
            onmouseover: () => {
              if (state.hoveredVersion !== version) {
                state.hoveredVersion = version
              }
            },
            onmouseout: () => {
              if (state.hoveredVersion === version) {
                state.hoveredVersion = undefined
              }
            }
          },
          (gutsElement),
          isValid && m('.diff-button', m('a', { onclick: (event) => openChangesPanel(event, version, target) }, 'diff'))
        )
      ]
    },
    oncreate(vnode) {
      let gutsElement = vnode.dom.querySelector('[data-guts]')
      if (gutsElement && vnode.attrs.guts) {
        gutsElement.appendChild(vnode.attrs.guts)
      }
    }
  }

  // shows up below the VersionSet heat map boxes
  var DiffStatus = {
    view: (vnode) => {
      var status = vnode.attrs.status
      var statusText;
      var statusStyle = `color: black;`

      if (status === DiffFetchStatus.QUEUED) {
        statusStyle = `color: black;`
        statusText = 'Diff Queued.'
      }

      if (status === DiffFetchStatus.LOADING) {
        statusStyle = `color: black;`
        statusText = 'Loading Diff...'
      }

      else if (status === DiffFetchStatus.SUCCEEDED) {
        statusStyle = `color: green;`
        statusText = 'Diff Loaded!'
      }

      else if (status === DiffFetchStatus.FAILED) {
        statusStyle = `color: #D30000;`
        statusText = 'Diff Failed!'
      }

      return m('div', { style: " margin-bottom: 10px; " },
        m('div', { style: statusStyle }, statusText),
      )
    }
  }

  const addLinks = description => {
    //ref: https://code.amazon.com/packages/DlenskiTools/blobs/mainline/--/Show%20ticket%20and%20CR%20links%20from%20pipeline%20diffs.user.js?raw=1

    let links = [];
    // $(d).after(` <a target="_blank" href="${t[0]}" title="${t[1]}">[T]</a>`);
    var t = description.match(/\bhttps:\/\/t.corp.amazon.com\/(?:issues\/)?([^\s\/]+)/);
    if (t) links.push(m(`a`, { "target": "_blank", "href": t[0] }, ` [${t[1]}]`))
    // $(d).after(` <a target="_blank" href="${sim[0]}" title="${sim[1]}">[SIM]</a>`);
    var sim = description.match(/\bhttps:\/\/sim.amazon.com\/issues\/([^\s\/]+)/);
    if (sim) links.push(m(`a`, { "target": "_blank", "href": sim[0] }, ` [${sim[1]}]`))
    // $(d).after(` <a target="_blank" href="${cr[0]}" title="${cr[1]}">[${cr[1]}]</a>`);
    var cr = description.match(/\bhttps:\/\/code.amazon.com\/reviews\/([^\s\/]+)/);
    if (cr) links.push(m(`a`, { "target": "_blank", "href": cr[0] }, ` [${cr[1]}]`))
    // $(d).after(` <a target="_blank" href="${tt[0]}" title="${tt[1]}">[TT]</a>`);
    var tt = description.match(/\bhttps:\/\/tt.amazon.com\/(\d+)/);
    if (tt) links.push(m(`a`, { "target": "_blank", "href": tt[0] }, ` [${tt[1]}]`))

    return links;
  }

  // Changes -- the panel that displays changes
  var DiffPanel = {
    view: () => {
      var thisVFI = state.selectedVersion ? VFIsMap[state.selectedVersion] : undefined
      var nextVFI
      var errorsToWrite = []
      var hasChanges = true;
      var loading

      let filteredChanges = getFilteredChanges();

      if (thisVFI) {
        nextVFI = thisVFI.diffWith ? VFIsMap[thisVFI.diffWith] : nextVFI
        errorsToWrite = thisVFI.errors || []
        hasChanges = !!(thisVFI.changes && thisVFI.changes.length)
        const changeAsTexts = getChangesAsText(filteredChanges);
        diffCopyContent = getFormattedDiffOfChanges(changeAsTexts, thisVFI);
        loading = thisVFI.status == DiffFetchStatus.QUEUED || thisVFI.status == DiffFetchStatus.LOADING;
      }

      else
        loading = true;

      return state.showChangeFinder ? (
        m('.changes-panel', { style: `top: ${state.changeFinderCoords.top}px; left: ${state.changeFinderCoords.left}px` }, [
          DiffPanel.changeHeader(thisVFI),
          DiffPanel.changeDetails(thisVFI, nextVFI),
          hasChanges && DiffPanel.changeFilter(),
          m('.changes-all-commits',
            DiffPanel.changes(filteredChanges, errorsToWrite, loading)
          )
        ])
      ) : null
    },
    changeHeader: (thisVFI) => {
      var header

      if (thisVFI)
        header = [
          "Version ",
          m(`span.${thisVFI.color}`, m('span', thisVFI.revision || thisVFI.version))
        ]

      else
        header = ["All Versions"]

      return ([
        m('div', { style: " display: flex; cursor: move; justify-content: space-between; " }, [
          m('h3', {
            style: "margin-bottom: 1px; min-height: 20px; flex-grow: 1;",
            onmousedown: function (event) {
              document.addEventListener('mousemove', move)
              document.addEventListener('mouseup', clear)

              var panel = $(event.target).closest('.changes-panel')[0],
                coords = {
                  x: event.clientX - state.changeFinderCoords.left, //
                  y: event.clientY - state.changeFinderCoords.top
                }

              var moved = false

              function move(event) {
                if (!moved) {
                  document.querySelectorAll('.show-diff-button').forEach(elem => elem.classList.remove('show-diff-button'));
                  moved = true;
                }

                event.preventDefault();
                panel.style.top = (state.changeFinderCoords.top = event.clientY - coords.y) + "px"
                panel.style.left = (state.changeFinderCoords.left = event.clientX - coords.x) + "px"
              }

              function clear() {
                document.removeEventListener('mousemove', move)
                document.removeEventListener('mouseup', clear)
              }
            }
          }, header),
          m('button', {onclick: () => { settingButton() }}, 'settings'),
          m('button', {onclick: () => { filterButton() }}, 'filter'),
          m('button', {onclick: () => { copyButton() }}, 'copy to clipboard'),
          m('button', {onclick: () => { viewRevisionButton(thisVFI) }}, 'view revision'),
          m('a', {
            style: "display: flex; flex-direction: column; justify-content: center; cursor: pointer; font-size: 18px; margin-top: -11px;",
            onclick: () => { state.showChangeFinder = false }
          }, '×')
        ]),
        // this is commented out b/c we don't have a currently reliable way of getting date
        // we'd have to another nextwork call to get it
        // (thisVersion && m('div', { style: "margin-bottom: 8px;margin-top: 1px;margin-left: 1px;color: gray;font-style: italic;" }, `published on ${thisVersion.date}`)),
      ])
    },
    changeDetails: (thisVersion, nextVersion) => {
      var details

      if (nextVersion)
        details = [
          "Changes in ",
          m(`span.${thisVersion.color}`, m('span', thisVersion.revision)),
          " since ",
          m(`span.${nextVersion.color}`, m('span', nextVersion.revision)),
          " ",
          thisVersion.diffUrl && m('a', { target: "_blank", href: thisVersion.diffUrl }, '[diff]'),
          " ",
          thisVersion.vsDiffUrl && m('a', { target: "_blank", href: thisVersion.vsDiffUrl }, '[VS Diff]'),
      ]

      else if (thisVersion)
        details = [
          "Changes in ",
          m(`span.${thisVersion.color}`, thisVersion.revision),
          " plus ~3 weeks ",
          thisVersion.diffUrl && m('a', { target: "_blank", href: thisVersion.diffUrl }, '[diff]')
        ]

      else {
        const successfulVFIs = VFIsList.filter(vfi => vfi.status === DiffFetchStatus.SUCCEEDED);

        if (successfulVFIs.length === 0) {
          console.log(
            "[ERROR] No successful VFIs found in this pipeline. Expected at least 1. " +
            "Not showing diff url for diff across all VFIs in the pipeline.");
          return;
        }

        var fullDiffUrl = generateDiffUrl(
          successfulVFIs[0].version,
          successfulVFIs.length > 1 ? successfulVFIs[successfulVFIs.length - 1].diffWith : null
        )

        details = [
          "Changes in all Versions plus ~3 weeks ",
          fullDiffUrl && m('a', { target: "_blank", href: fullDiffUrl }, '[diff]')
        ]
      }

      return m('div', { style: " margin-bottom: 6px; margin-top: 5px; " }, details)
    },
    changeFilter: () => (
      m('.changes-filter', [
        m('label', { for: 'changes-filter' }, 'filter'),
        m('input', {
          id: 'changes-filter',
          type: 'text',
          style: "width: 100%",
          value: state.filter.needle,
          oninput: (event) => {
            state.filter.needle = event.target.value
            tryRender()
          }
        })
      ])
    ),
    changes: (changesToWrite, errorsToWrite, loading) => {
      var content = []
      var lastPackage = ''
      var lastErrorType = ''

      // if it's loading, always say this
      if (loading)
        content.push(m('div', { style: "text-align: center; font-style: italic; " }, "Loading changes..."))

      // if we have any large errors, show them second
      if (errorsToWrite.length)
        // content = content.concat(errorsToWrite.map(error => {
        content = content.concat(errorsToWrite.reduce((acc, error) => {

          if (lastErrorType !== error.type) {
            lastErrorType = error.type
            acc.push(m('h4.changes-package', { style: "color: red; font-weight: bold; margin-top: 0" }, error.type.replace(/_/g, ' ')))
          }

          acc.push(m('.changes-commit', { style: "color: red; font-weight: bold; word-break: break-word; " }, error.message.replace(/^\s*close\s*/i, '')))

          return acc
        }, []))

      // if we have any actual changes, show them
      if (changesToWrite.length) {

        content = content.concat(changesToWrite.reduce((acc, change) => {
          if (lastPackage !== change.package) {
            lastPackage = change.package
            acc.push(m('h4.changes-package', { title: change.package }, change.package))
          }

          if (change.commitHash) {
            acc.push(m('.changes-commit', [
              m(`span.${VFIsMap[change.version].color}`, {
                onclick: (event) => openChangesPanel(event, change.version)
              }, m('span', change.version.split(/@b/i)[1])),
              " ", // spacing, yay!
              m(`a.changes-commit_message.color`, {
                "target": "_blank",
                "href": `https://code.amazon.com/packages/${change.package}/commits/${change.commitHash}`
              }, ('' + change.commitHash).slice(0, 8)), // trim the guid to 8 characters
              m('div', m('div', change.description)),
              [...addLinks(change.description ? change.description : "")],
              change.added ? m('span', { style: 'color: #228B22' }, ' added') : null,
              change.removed ? m('span', { style: 'color: #CD2626' }, ' removed') : null,
              ' by ',
              m('a', {
                "target": "_blank",
                "href": `https://phonetool.amazon.com/users/${change.author}`
              }, change.author),
              ' ',
              msToRelative(change.date),
              change.targetsTimeDeployed && state.selectedTarget in change.targetsTimeDeployed ? ` deployed ${
                msToRelative(change.targetsTimeDeployed[state.selectedTarget].timestamp)}` : null,
              m('sup', m('a', {
                "target": "_blank",
                "href": change.trackingUrl
              }, 'track'))
            ]))
          } else if (change.branches) {
            acc.push(m('.changes-commit', [
              m(`span.${VFIsMap[change.version].color}`, change.version.split(/@b/i)[1]),
              " ", // spacing, yay!
              m('a', {
                "target": "_blank",
                "href": change.diff
              }, `Switched branch (${change.branches})`)
            ]))

          } else
            console.warn('Change did not match established patterns: ', change)

          return acc
        }, []))

        // content = changesToWrite.map((a,index) => index)
      }

      // but not the 'no changes' message
      if (!loading && !changesToWrite.length && !errorsToWrite.length)
        content.push(
          m(
            'div',
            { style: "text-align: center; font-style: italic; " },
            "No changes using current filter. See the diff link above."));

      return content
    }
  }

  document.addEventListener('click', function (event) {
    if (
      !$(event.target).closest('.diff-button')[0] &&
      !$(event.target).closest('.changes-panel')[0]
    ) {
      state.showChangeFinder = false

      if (!$(event.target).closest('.heat-map-box')[0]) {
        state.selectedVersion = null
        state.selectedTarget = null
      }

      tryRender()
    }
  }, false);

  function openChangesPanel(event, version, selectedTarget) {
    event.preventDefault();

    // set new version (or not)
    if (version !== undefined) {
      state.selectedVersion = version;
      state.selectedTarget = selectedTarget;
    }

    state.showChangeFinder = true;

    var target = $(event.target)
    var targetIsAllButton = target.closest('.heat-map-color-all')[0]

    if (target || targetIsAllButton) {
      var leftOffset = 10
      var topOffset = -4

      // if clicking the full diff box...
      if (targetIsAllButton) {
        target = target.closest('.stage_info')
        leftOffset = 37
        topOffset = -2
      }

      var left = target[0].offsetWidth + target.offset().left + leftOffset

      var topTarget = $(event.target.parentElement).prev('.heat-map-box')[0] || event.target
      var top = $(topTarget).offset().top + topOffset

      state.changeFinderCoords = {
        top,
        left
      }
    }

    tryRender()
  }

  function getFilteredChanges(options) {
    var filter = Object.assign({ selectedVersion: state.selectedVersion }, state.filter, options)

    return allChanges.filter(function (change) {
      var matchesAllCriteria = true // rule changes out as we go
      var needleRegex

      if (filter.selectedVersion)
        matchesAllCriteria = matchesAllCriteria && change.version === filter.selectedVersion

      // not searching diff since it's a url
      if (filter.needle) {
        needleRegex = new RegExp(filter.needle, 'i')

        matchesAllCriteria = matchesAllCriteria && needleRegex.test(JSON.stringify(change).replace(/[{}"]/g, ''))
      }

      return matchesAllCriteria
    })
  }

  function msToRelative(date) {
    var ago
    var sinceMs = new Date() - date
    var sinceMinutes = (sinceMs / 1000) / 60
    var sinceHours = sinceMinutes / 60
    var sinceDays = sinceHours / 24
    var sinceMonths = sinceDays / 30

    if (Math.round(sinceMonths))
      ago = Math.round(sinceMonths) + 'm ago'

    else if (Math.round(sinceDays))
      ago = Math.round(sinceDays) + 'd ago'

    else if (Math.round(sinceHours))
      ago = Math.round(sinceHours) + 'h ago'

    else if (Math.round(sinceMinutes))
      ago = Math.round(sinceMinutes) + 'min ago'

    else
      ago = 'a few seconds ago'

    return ago
  }

  // data now
  function fetchHeatMapData() {
    return fetch(`${location.origin + location.pathname}/heat_map?requestedBy=embeddedHeatmap${scriptVersion}`, { credentials: 'include' })
      // parse heatmap data
      .then(response =>
        response.text() // getting the html text out of the response
          .then((html) => {
            // create an element container and put the resultant html inside it
            var fragment = document.createElement('div')
            fragment.innerHTML = html

            // get all target elements (each target element is a heatmap box)
            // why am I getting li.target and not heat-map-colors?
            fragment.querySelectorAll('li.target').forEach(function (element) {
              var target = element.querySelector('div.name').innerText.trim();
              var heatMapColor = element.className.match(/heat-map-color-\d+/)[0];
              var version = element.getAttribute('data-vsr').trim();

              if (version.indexOf('Transformed VSR') !== -1)
                version = version.replace('Transformed VSR', '').trim().replace(/\/(\d+)$/, '@B$1')

              var isValid = /.+@b\d+/i.test(version)

              const targetType = ALL_TARGET_TYPES.find(type => element.getAttribute('id').includes(`-${type}-`));

              pipelineTargetsToMetadata.push(
                target,
                {
                  targetType,
                  version
                });

              // store an object of version -> bunch of data for everything else
              if (!VFIsMap[version])
                VFIsMap[version] = {}

              if (isValid)
                VFIsMap[version] = {
                  version,
                  color: heatMapColor,
                  isValid,
                  versionset: version.split(/@b/i)[0],
                  revision: version.split(/@b/i)[1],
                  status: DiffFetchStatus.QUEUED,
                  errors: []
                }

              else
                VFIsMap[version] = {
                  version,
                  color: heatMapColor,
                  isValid,
                }
            })

            // generate a sorted list of VFIs
            VFIsList = Object.keys(VFIsMap)
              .sort((a, b) => (VFIsMap[a].color.match(/\d+/)[0]) - (VFIsMap[b].color.match(/\d+/)[0]))
              .reduce((comb, key, index, array) => {
                let VFI = VFIsMap[key]
                VFI.next = VFIsMap[array[index + 1]]
                comb.push(VFI)

                return comb
              }, [])

            tryRender()
          })
      )
  }

  function getErrorFromResponse(response, body, meta) {
    getErrorFromDiff(body, meta.new_version, meta.old_version)
  }

  function getErrorFromDiff(html, new_version, old_version) {
    // reads html, determines if there is an error, and marks the version as errored VFI data
    // if there is an error, and it wasn't on the from/new version, retry

    var sandbox = document.createElement('div')
    sandbox.innerHTML = html

    var new_name = new_version.split(/@b/i)[0],
      new_revision = new_version.split(/@b/i)[1],

      old_version_split = old_version ? old_version.split(/@b/i) : {}
    old_name = old_version_split[0],
      old_revision = old_version_split[1]

    var errorElement = sandbox.querySelector('.alert:not(.hidden).error')
    var hasNoContent = !(sandbox.querySelectorAll('#content .data-table .difflink') || '').length

    var error = {
      status: DiffFetchStatus.FAILED, // always failed
      type: undefined,
      message: undefined,
      count: 1,
      retry: undefined,
      revisionId: undefined,
      versionSetId: undefined,
      versionThatErrored: undefined
    }
    var versionThatErrored

    if (errorElement && hasNoContent) {
      // an annoying way of getting the messages
      var errorTypeMessage = ((errorElement.querySelector('h2') || {}).textContent || "").trim()
      var errorDetailsMessage = ((errorElement.querySelector('h2+p') || {}).textContent || "").trim()

      // determine which error
      if (errorTypeMessage === `We're sorry, but we don't have enough information yet to calculate the changes in this diff.`) {

        // possible error messages
        // Need change locations for revision BackplaneControlService/development:5777060796 (id 191871655) 2018-05-01 23:02:27.0 to calculate the diff.

        // define error details
        error.type = "REVISION_NOT_FOUND"
        error.revisionId = (
          errorDetailsMessage.match(/revision\s*(\S+)\s*of/) ||
          errorDetailsMessage.match(/revision\s*[^:]+:(\S+)\s*/) ||
          ''
        )[1]
        error.message = errorElement.textContent

        // determine which version errored
        if (error.revisionId === new_revision) versionThatErrored = new_version
        else if (error.revisionId === old_revision) versionThatErrored = old_version
        else console.error(`Huh. error.revisionId (${error.revisionId}) is not the new version (${new_version}) or the old one (${old_version}).`)
      }

      else if (errorTypeMessage === `Error diffing revisions. If you were redirected from Heat Map, please refer https://w.amazon.com/index.php/Pipelines/HeatMap for more details`) {

        // define error details

        error.type = "VERSIONSET_NOT_FOUND"
        error.versionSetId = (errorDetailsMessage.match(/VersionSet\s*(.+)/) || '')[1]
        error.message = errorElement.textContent

        // determine which version errored
        if (error.versionSetId === new_name) versionThatErrored = new_version
        else if (error.versionSetId === old_name) versionThatErrored = old_version
        else console.error(`Huh. error.versionSetId (${error.versionSetId}) is not the new version (${new_version}) or the old one (${old_version}).`)
      }

      else {
        error.type = "UNKNOWN_ERROR"
        error.message = errorElement.textContent

        console.error(`Some unknown error occurred.`, error)
      }

      if (versionThatErrored) {
        error.retry = versionThatErrored === old_version, // retry this one if the OLD version is the one that failed
          error.versionThatErrored = versionThatErrored
        return error
      }
    }

    // no errors, yay!
    else
      return null
  }

  function handleError(error) {
    var matchingError

    if (error.versionThatErrored) {
      if (!VFIsMap[error.versionThatErrored].errors)
        VFIsMap[error.versionThatErrored].errors = []

      matchingError = VFIsMap[error.versionThatErrored].errors.find(searchError =>
        searchError.type === error.type && searchError.message === error.message)

      if (matchingError) {
        matchingError.count++
      } else {
        VFIsMap[error.versionThatErrored].errors.push(error)
      }

      // cache on certain errors -- some errors go away with time
      // if we return data, cache it
      if (error.type === "VERSIONSET_NOT_FOUND")
        VFIsMap[error.versionThatErrored]

      tryRender()
    } else {
      console.error(error)
    }
  }

  function generateDiffUrl(new_version, old_version) {
    if (new_version) {
      var new_version = new_version.split(/@b/i)
      var new_name = new_version[0]
      var new_revision = new_version[1]

      if (old_version) {
        var old_version = old_version.split(/@b/i)
        var old_name = old_version[0]
        var old_revision = old_version[1]

        return `https://pipelines.amazon.com/diff?new_name=${new_name}&new_revision=${new_revision}&new_type=VS&old_name=${old_name}&old_revision=${old_revision}&old_type=VS&requestedBy=embeddedHeatmap${scriptVersion}`
      }

      return `https://pipelines.amazon.com/diff?new_name=${new_name}&new_revision=${new_revision}&new_type=VS&requestedBy=embeddedHeatmap${scriptVersion}`

    }

    return undefined
  }

  function generateVSDiffUrl(new_version, old_version) {
    if (new_version) {
      var new_version = new_version.split(/@b/i)
      var new_name = new_version[0]
      var new_revision = new_version[1]

      if (old_version) {
        var old_version = old_version.split(/@b/i)
        var old_name = old_version[0]
        var old_revision = old_version[1]

        return `https://code.amazon.com/version-sets/${new_name}/revisions/${new_revision}?previous=${old_revision}`
      }

      return `https://code.amazon.com/version-sets/${new_name}/revisions/${new_revision}`
    }

    return undefined
  }

  async function getFinalRevision(version) {
    var startDate = null
    var finalRevision = null
    var page = 0
    var pageSize = 100
    var maxPages = 10

    var [versionSet, eventId] = version.split(/@b/i)

    // So basically we're getting a list of all revisions for a given version set page by page
    while (!finalRevision && page <= maxPages) {
      const response = await xFetch("https://brazil-metadata-sso.corp.amazon.com/", {
        "headers": {
          "content-encoding": "amz-1.0",
          "content-type": "application/json; charset=UTF-8",
          "x-amz-target": "com.amazon.devtools.bmds.generated.BrazilMetaDataService.getVersionSetRevisions",
        },
        "data": `{"versionSetName": "${versionSet}", \n "firstResult": ${(page * pageSize)}, \n "maxResults": ${(page + 1) * pageSize}}`,
        "method": "POST"
      })

      var revisions = JSON.parse(response.response).revisions

      // First, we find the one we're starting from
      if (!startDate) {
        // using == here b/c elem.eventId is a number and eventId is a string
        let thisRevision = revisions.find(revision => revision.eventId == eventId)

        if (thisRevision) {
          startDate = new Date(thisRevision.date * 1000)
          // console.log('found this revision', thisRevision, startDate)
        }
      }

      // Then, we find one that's more than 21 days older than the previous one.
      if (startDate) {
        revisions.find(revision => {
          let revisionDate = (new Date(revision.date * 1000))
          let diff = Math.floor((startDate - revisionDate) / 1000 / 60 / 60 / 24)
          if (diff > 21) {
            finalRevision = revision.eventId
          }
          return finalRevision
        })
      }

      page++
    }

    if (finalRevision) {
      // Hooray, we got our diff!
      return `${versionSet}@b${finalRevision}`
    } else {
      return
    }
  }

    function getParentPipelineURL() {
        const overviewPageApp = document.querySelector('[data-component="OverviewPageApp"]');
        const pipelineInfo = overviewPageApp.getAttribute('data-props');
        var listSandbox = document.createElement('div');
        listSandbox.innerHTML = pipelineInfo;
        const pipelineInfoJson = JSON.parse(listSandbox.textContent);

        // Scrape HTML for parent pipeline name
        const mergeFromVS = pipelineInfoJson.pipeline_info_for_react.stage_info_by_stage.MergeFromVS;
        const stageInfo = mergeFromVS.stage.stage_info;
        const targetsWithRevisions = stageInfo.targets_with_revisions[0];
        const targetInStageInfo = targetsWithRevisions.target_in_stage_info;
        const targetInfo = targetInStageInfo.target.target_info;
        const pipelineName = targetInfo.primary_pipeline;

        return `https://pipelines.amazon.com/pipelines/${pipelineName}`;
    }

    async function getPackagesFromParentPipeline(parent_url) {
        const diffResponse = await fetch(parent_url, { credentials: 'include' });
        const diffHtml = await diffResponse.text();
        var listSandbox = document.createElement('div');
        listSandbox.innerHTML = diffHtml;

        const packages = [].slice.call(listSandbox.querySelectorAll('li.target[id]')).map(
            li => {
                const packageNameWithoutBranch = li.id.split('/')[0];
                const idParts = packageNameWithoutBranch.split('-');
                return idParts.slice(2).join('-');
            });

        console.log("Parent pipeline packages:", packages);
        return packages;
    }

  function delay(time) {
    return new Promise(resolve => setTimeout(resolve, time));
  }

  /**
   * Determine if the provided HTTP Status is recoverable.
   */
  function isRecoverableHTTPStatusCode(httpStatusCode) {
    return httpStatusCode === StatusCodes.TOO_MANY_REQUESTS || /^5/.test(httpStatusCode);
  }

  /**
   * Fetch what time this commit was deployed to each target.
   *
   * @param filteredTargets - Only fetch target deployment info on these targets. A commit may have existing target
   * deployment information, but callers may want to check a subset of targets to see if the commit has made it there by
   * now.
   *
   * Return the result in a list. It is possible for items in this list to be `undefined`. The caller is expect to
   * filter out bad results and do any error handling.
   */
  async function getChangesWithTargetsTimeDeployed(pkgChanges, filteredTargets = null) {
    var fetchTargets = pipelineTargetsToMetadata.entries();

    if (filteredTargets && filteredTargets.length > 0) {
      fetchTargets = fetchTargets.filter(([targetName, _]) => filteredTargets.includes(targetName));
    }
    const trackPackagesPromises = pkgChanges.map(async pkgChange => {
      const trackCommitInTargetUrls = fetchTargets.map(([targetName, targetMetadata]) => {
          const QUERY_PARAMS = [
            [QP_CHANGE_ID, `GitFarmCommit:${pkgChange.gitFarmCommitDesc}`],
            [QP_TARGET_ID, `${targetMetadata.targetType}:${targetName}`]
          ].map(qpKeyAndVal => qpKeyAndVal.join('=')).join('&');
          return `${PIPELINES_CHANGE_HIST_API}?${QUERY_PARAMS}`;
        });

      const trackCommitPromises = trackCommitInTargetUrls.map(trackChangesDerivedUrl => {
        return backoff(async (eject) => {
          const responseTrackChangeInfo = await fetch(trackChangesDerivedUrl);

          if (responseTrackChangeInfo.ok) {
            return responseTrackChangeInfo.json();
          }

          if (isRecoverableHTTPStatusCode(responseTrackChangeInfo.status)) {
            throw new Error(responseTrackChangeInfo.statusText)
          }

          console.log(`[ERROR] Retries exhausted. Ejecting URL for deployment tracking. url=${trackChangesDerivedUrl}`);
          eject();
        }).catch(error => {
          console.log(`[ERROR] Unable to fetch tracking info. url=${trackChangesDerivedUrl} error=${error}`);
        });
      });

      const allTrackChangeInfos = [];

      while (trackCommitPromises.length > 0) {
        const resolvedSubset = await Promise.all(trackCommitPromises.splice(0, TRACK_COMMIT_FETCH_CONCURRENCY));

        const trackCommitsWhichReachedTarget = resolvedSubset.filter(response => response).map(responseTrackChangeInfoJSON => {
          const { target_change_history_output: trackChangeInfo } = responseTrackChangeInfoJSON;
          return trackChangeInfo;
        }).filter(trackChangeInfo => {
          return trackChangeInfo.reached_target;
        });

        allTrackChangeInfos.push(...trackCommitsWhichReachedTarget);

        if (trackCommitsWhichReachedTarget.length !== resolvedSubset.length) {
          console.log(
            '[WARN] Not all responses for had info about deployment to the target. Proceeding with next batch. ' +
            `Expected=${resolvedSubset.length} ` +
            `Actual=${trackCommitsWhichReachedTarget.length} ` +
            `GitFarmCommit=${pkgChange.gitFarmCommitDesc}`);
        }
      }

      newTargetsTimeDeployed = allTrackChangeInfos.reduce(
        (acc, trackChangeInfo) => {
          if (trackChangeInfo.change_history.length == 0) {
            console.log(`[ERROR]: No change_history even though commit reached target. targetName=${targetName} pkgDesc=${pkgChange.gitFarmCommitDesc}`);
            return acc;
          }

          const {
            target_revision_identifier: {
              display_name: targetName
            },
            change_event: {
              timestamp,
              action_type: actionType
            }
          } = trackChangeInfo.change_history.at(-1);

          const final = {
            ...acc,
            ...{
              [targetName]: {
                timestamp: timestamp * 1000,
                actionType
              }
            }
          };
          return final;
        },
        {}
      );

      if (newTargetsTimeDeployed.length == 0) {
        console.log(`[ERROR] No deployment information to any target for commit. pkgDesc=${pkgChange.gitFarmCommitDesc}`);
        return pkgChange;
      }

      if (!('targetsTimeDeployed' in pkgChange)) {
        return {
          ...pkgChange,
          targetsTimeDeployed: newTargetsTimeDeployed
        };
      }

      return {
        ...pkgChange,
        targetsTimeDeployed: {
          ...pkgChange['targetsTimeDeployed'],
          ...newTargetsTimeDeployed
        }
      };
    });

    return fetchPromises(trackPackagesPromises, TRACK_PKGS_FETCH_CONCURRENCY);
  }


  /**
   * Call a Pipeline API an scrape the HTML for changes between 2 commits of a package.
   *
   * Return the result in a list. It is possible for items in this list to be `undefined`. The caller is expect to
   * filter out bad results and do any error handling.
   */
  async function getPkgChangesFromDiffUrl(thisVersion, nextVersion) {

    if (!nextVersion) {
      nextVersion = await getFinalRevision(thisVersion);
    }

    const diffResponse = await fetch(VFIsMap[thisVersion].diffUrl, { credentials: 'include' })
    const diffHtml = await diffResponse.text()

    var error = getErrorFromResponse(diffResponse, diffHtml, { new_version: thisVersion, old_version: nextVersion })

    if (error) {
      throw error
    }

    var listSandbox = document.createElement('div');
    listSandbox.innerHTML = diffHtml;

    packages = await packages; // make sure packages is loaded before moving on

    if (packages.length === 0) { // Example https://pipelines.amazon.com/pipelines/RDSWebService-release
      const parent_url = getParentPipelineURL();
      if (parent_url) {
        await getPackagesFromParentPipeline(parent_url)
          .then(value => {
            packages = value;
          })
          .catch(error => console.error(error));
      }
    }

    const nestedPkgChangesScrapedFromDiffPage = await Promise.all(
      [].slice.call(listSandbox.querySelectorAll('.new-diff-pkg-expand-control'))
        .map(elem => {
          var [packageName, branchName] = elem.textContent.trim().split('/');
          var oldCommitId = elem.getAttribute('old_commit_id');
          var newCommitId = elem.getAttribute('new_commit_id');

          var packageIsFiltered = Boolean(state.filter.filter_packages_regex?.test(packageName));

          var packageIsTracked = packages.find(trackedPackage => trackedPackage === packageName) && !packageIsFiltered;

          // TODO: For now, we're not going to even give the option to fetch non-tracked packages.
          // To implement that, we need some UI work first.
          var packageIsExtra = false
          if (!packageIsTracked && state.filter.extra_packages_regex) {
              packageIsExtra = state.filter.extra_packages_regex.test(packageName)
          }

          if (packageIsTracked || packageIsExtra) {
            const pkgDiffCacheKey = diffCache.getCacheKeyForPackageDiff(
              packageName,
              branchName,
              newCommitId,
              oldCommitId,
            );
            const cachedPkgDiff = diffCache.get(pkgDiffCacheKey);

            if (cachedPkgDiff && cachedPkgDiff.body) {
              return cachedPkgDiff.body;
            }

            state.stats.diffsFetched++
            return backoff(async (eject) => {
              const response = await fetch(
                `${PIPELINES_URL}/diff/pkg_changes?` +
                `package_name=${packageName}&` +
                `branch_name=${branchName}&` +
                `old_commit_id=${oldCommitId}&` +
                `new_commit_id=${newCommitId}&` +
                `requestedBy=embeddedHeatmap${scriptVersion}`,
                { credentials: 'include' });
              const html = await response.text()
              if (response.ok) {
                var detailsSandbox = document.createElement('div')
                detailsSandbox.innerHTML = html

                const pkgChangesScrapedFromDiffPage = [].slice.call(detailsSandbox.querySelectorAll('li>div')).map(
                  li => {
                  var commitLink = li.querySelector('.change-link a');
                  var author = li.querySelector('.author a')
                  var date = li.querySelector('.creation-date .relative-time')
                  var description = li.querySelector('.description')
                  var removed = Boolean(li.querySelector('#removed-action-type'))
                  var added = Boolean(li.querySelector('#added-action-type'))
                  // var branches = li.querySelectorAll('.branch_name')
                  // var diff = li.querySelector('a:nth-of-type(2)')

                  const pkgChange = {
                    version: thisVersion,
                    cacheKey: pkgDiffCacheKey,
                    added,
                    removed,
                    package: packageName
                  };

                  if (date) pkgChange.date = date.getAttribute('data-millis')
                  if (description) pkgChange.description = description.textContent.trim()
                  if (author) pkgChange.author = author.textContent
                  if (commitLink) {
                    const commitHash = commitLink.href.replace(/.+\/commits\/(.+)$/, '$1');
                    pkgChange.commitHash = commitHash;
                    pkgChange.gitFarmCommitDesc = `${packageName}/${branchName}:${commitHash}`;
                    pkgChange.trackingUrl = `${PIPELINES_URL}/pipelines/${globalPipelineName}/change_history_v2?` +
                    `changes[]=GitFarmCommit:${pkgChange.gitFarmCommitDesc}`;
                  }

                  return pkgChange;
                });

                diffCache.set(pkgDiffCacheKey, pkgChangesScrapedFromDiffPage);

                return pkgChangesScrapedFromDiffPage;
              } else if (isRecoverableHTTPStatusCode(response.status)) {
                throw new Error(response.statusText)
              } else {
                eject()
              }
            }).catch(error => {
              console.log(
                'Failed to get diff details for package in VersionSet. ' +
                `packageName=${packageName} ` +
                `packageName=${branchName} ` +
                `old_commit_id=${oldCommitId} ` +
                `new_commit_id=${newCommitId} ` +
                `error=${error}`)
              handleError({
                status: DiffFetchStatus.FAILED, // always failed
                type: 'PACKAGE_DIFF_NOT_FOUND',
                message: `Error: Cannot get diff details for package ${packageName}`,
                count: 1,
                retry: false,
                revisionId: undefined,
                versionSetId: undefined,
                versionThatErrored: thisVersion,
              })
            })
          } else {
            state.stats.diffsSkipped++
            return Promise.resolve([])
          }
        }));
    return nestedPkgChangesScrapedFromDiffPage.reduce((acc, item) => acc.concat(item), []);
  }

  /**
   * Fetch promises but only fetch `maxConcurrency` promises at a time to reduce network load.
   */
  async function fetchPromises(promises, maxConcurrency) {
    const resolvedPromises = [];

    while (promises.length > 0) {
      resolvedPromises.push(...await Promise.all(promises.splice(0, maxConcurrency)));
    }

    return resolvedPromises;
  }

  function addToGlobalListOfChanges(changes) {
    // force it into an array
    if (changes) {
      if (!Array.isArray(changes))
        changes = [changes]

      allChanges = allChanges.concat(changes)
        // if any of the sortTests return 0 (meaning they're identical for that sort axis), use a more specific sort axis
        .sort((a, b) => sortTest(a.package, b.package) || sortTest(b.date, a.date) || sortTest(a.commitHash, b.commitHash));
    }
  }

  // utility functions
  function sortTest(a, b) {
    return (
      (a > b ? 1 : 0) +
      (b > a ? -1 : 0)
    )
  }

  function xFetch(url, options = {}) {
    return new Promise((resolve, reject) => {
      GM_xmlhttpRequest({
        url,
        ...options,
        onload(response) { options.onload ? resolve(options.onload(response)) : resolve(response) },
        onabort(error) { options.onabort ? reject(options.onabort(error)) : reject(error) },
        onerror(error) { options.onerror ? reject(options.onerror(error)) : reject(error) }
      })
    })
  }

  // An exponential backoff function.
  // Pass it a function. If that function throws, backoff will retry it. Each time, the delay increases by 2x.
  async function backoff(fn, options = {}) {
    return new Promise(async (resolve, reject) => {
      let { delay = 500, maxTries = 7 } = options

      let tryNumber = 1

      // we use this to eject from the backoff (i.e. cancel the loop and throw the most recent error)
      let ejected = false
      function eject() {
        ejected = true
        reject(error)
      }

      let error
      while (tryNumber <= maxTries && !ejected) {
        try {
          return resolve(await fn(eject, tryNumber))
        } catch (tryError) {
          error = tryError
          tryNumber++
        }

        // no reason to wait if we're passed the maxTries
        if (tryNumber <= maxTries) {
          await wait(delay)
          const jitter = Math.min(delay * Math.random(), 10000) // Add jitter to retries, but cap at 10s
          delay = (delay * 2) + jitter
        }
      }
      reject(error)
    })
  }

  function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)) }

  function settingButton() {
    let extra_packages_regex_ask = prompt("Regular Expression for extra package to show diff", localStorage.getItem("heatmap_extra_packages_regex"));

    if (extra_packages_regex_ask != null) {
      localStorage.setItem("heatmap_extra_packages_regex",extra_packages_regex_ask)
      state.filter.extra_packages_regex = new RegExp(extra_packages_regex_ask);
      /**
       * TODO: (enowell) Instead of reconstructing the cache, filter the VS diff to find only the _new_ packages
       * introduced by this regex and update the cache entry with only those changes.
       */
      diffCache.removeAll();
      main()
    }
  }

  function filterButton() {
    let filter_packages_regex_ask = prompt("Regular Expression for filtering packages from the diff", localStorage.getItem("heatmap_filter_packages_regex"));

    if (filter_packages_regex_ask != null) {
      localStorage.setItem("heatmap_filter_packages_regex", filter_packages_regex_ask)
      state.filter.filter_packages_regex = new RegExp(filter_packages_regex_ask);
      /**
       * TODO: (evnb) Instead of reconstructing the cache, filter the VS diff to remove filtered packages
       * removed by this regex and update the cache entry with only those changes.
       */
      diffCache.removeAll();
      main()
    }
  }

  function copyButton() {
    navigator.clipboard.writeText(diffCopyContent.join('\n')).then(() => {
      /* clipboard successfully set */
    }, () => {
      /* clipboard write failed */
    });
  }

  function viewRevisionButton(vfi) {
      window.open(`https://code.amazon.com/version-sets/${vfi.versionset}@${vfi.revision}`, '_blank').focus();
  }

  /**
   * Get a formatted diff of changes.
   *
   * The provided changes should already be in text format. See `getChangesAsText`.
   */
  function getFormattedDiffOfChanges(allChangeAsTexts, thisVFI, copyContentFormat = CopyContentFormat.MARKDOWN_TABLE) {
    const { selectedTarget } = state;
    var mcmDiffInfo = [
      '## Changes Diff for MCM',
      `Select changes from Version Set Diff. See the [Diff URL](${thisVFI.diffUrl}).`,
      `New Revision: ${thisVFI.revision}`,
      `Promoting from target: ${selectedTarget}`
    ];

    var changesTextFormatted;

    if (copyContentFormat == CopyContentFormat.MARKDOWN_TABLE) {
      changesTextFormatted = getChangesFormattedAsMarkdownTable(allChangeAsTexts);
    } else if (copyContentFormat == CopyContentFormat.MARKDOWN_LIST) {
      changesTextFormatted = getChangesFormattedAsMarkdownList(allChangeAsTexts);
    } else {
      throw new Error(`Invalid format selected for copying content. copyContentFormat=${copyContentFormat}`);
    }

    return mcmDiffInfo.concat(changesTextFormatted);
  }

  /**
   * Convert the list of changes into their text representation. The returned object has package names for keys and an
   * array of objects with change metadata as text.
   */
  function getChangesAsText(changesToWrite) {
    // if we have any actual changes, show them
    if (changesToWrite.length == 0) {
      return {};
    }

    const { selectedTarget } = state;

    var currentPkg = '';
    return changesToWrite.reduce((acc, change) => {
      const changeAsText = {};

      const { description } = change;
      if (description) {
        changeAsText.description = `${description.split('\n')[0]}`;

        const descriptionLinks = [
          ['issue', description.match(/\bhttps:\/\/i.amazon.com\/([^\s\/]+)/)],
          ['t', description.match(/\bhttps:\/\/t.corp.amazon.com\/(?:issues\/)?([^\s\/]+)/)],
          ['sim', description.match(/\bhttps:\/\/sim.amazon.com\/issues\/([^\s\/]+)/)],
          ['cr', description.match(/\bhttps:\/\/code.amazon.com\/reviews\/([^\s\/]+)/)],
          ['tt', description.match(/\bhttps:\/\/tt.amazon.com\/(\d+)/)]
        ].map(keyAndRegexMatch => {
          const [key, regexMatch] = keyAndRegexMatch;
          if (!regexMatch) { return {}; }

          const [capturedMatch, wholeStringMatch] = regexMatch;

          return { [key]: `[${wholeStringMatch}](${capturedMatch})` };
        });

        Object.assign(
          changeAsText,
          ...descriptionLinks
        );
      }

      const { author } = change;
      if (author) {
        changeAsText.author = `Author: [${author}](https://phonetool.amazon.com/users/${author})`;
      }

      const { targetsTimeDeployed } = change;
      if (targetsTimeDeployed && selectedTarget in targetsTimeDeployed) {
        const { [selectedTarget]: { timestamp } } = targetsTimeDeployed;
        const { trackingUrl } = change;
        changeAsText.targetTimeDeployed = `Deployed [${msToRelative(timestamp)}](${trackingUrl})`;
      }

      const { package } = change;
      if (currentPkg !== package) {
        currentPkg = package;
        acc[currentPkg] = [];
      }

      acc[currentPkg].push(changeAsText);

      return acc;
    },
    {});
  }

  /**
   * Generates a markdown list from the changes provided.
   */
  function getChangesFormattedAsMarkdownList(allChngAsTxts) {
    return Object.entries(allChngAsTxts).reduce((acc, [pkgName, changeAsTexts]) => {
      const formattedChanges = changeAsTexts.map(chngAsTxts => {
        const {
          description,
          issue,
          t,
          sim,
          cr,
          tt,
          author,
          targetTimeDeployed
        } = chngAsTxts;
        return `* ${[
          description,
          issue,
          t,
          sim,
          cr,
          tt,
          author,
          targetTimeDeployed
        ].filter(txt => txt).join(', ')}`;
      });

      const pkgChangesAsTexts = [
        `\n### ${pkgName}`,
        ...formattedChanges
      ]

      return acc.concat(pkgChangesAsTexts);
    },
    []);
  }

  /**
   * Generates a markdown table from the changes provided.
   */
  function getChangesFormattedAsMarkdownTable(allChngAsTxts) {
    const formattedPkgs = Object.entries(allChngAsTxts).reduce((acc, [pkgName, changeAsTexts]) => {
      const formattedChanges = changeAsTexts.map(chngAsTxts => {
        const {
          description,
          cr,
          author,
          targetTimeDeployed
        } = chngAsTxts;
        return `||${[
          description,
          cr,
          author
        ].join('|')}|TBD|TBD|${targetTimeDeployed}|TBD||`;
      });

      const pkgChangesAsTexts = [
        `|${pkgName}|||||||||`,
        ...formattedChanges
      ]

      return acc.concat(pkgChangesAsTexts);
      },
      []);

    return [
      '\n|Package name|Commit title|CR link|*Owner*|Tested with Integ Tests?|Gamma Testing details|Baked time?|Is under flag?|Comments|',
      '|:--|:--|:--|:--|:--|:--|:--|:--|:--|',
      ...formattedPkgs
    ];
  }

  function highlightTests() {
    const workflowSteps = document.querySelectorAll(".workflow_step");

    const succeededWorkflowSteps = Array.from(workflowSteps).filter(
      (element) => element.querySelector(".status-succeeded") !== null
    );

    const failedWorkflowSteps = Array.from(workflowSteps).filter(
      (element) => element.querySelector(".status-failed") !== null
    );

    const inProgressWorkflowSteps = Array.from(workflowSteps).filter(
      (element) => element.querySelector(".status-in-progress") !== null
    );

    succeededWorkflowSteps.forEach(function (element) {
      element.classList.add("workflow-step-succeeded");
    });

    failedWorkflowSteps.forEach(function (element) {
      element.classList.add("workflow-step-failed");
    });

    inProgressWorkflowSteps.forEach(function (element) {
      element.classList.add("workflow-step-in-progress");
    });

    let style = `<style>
      .workflow-step-failed {
        background-color: #DC143C33;
        padding: 8px;
        border-radius: 5px;
        margin-left: -5px;
      }

      .workflow-step-succeeded {
        background-color: #228B2222;
        padding: 8px;
        border-radius: 5px;
        margin-left: -5px;
      }

      .workflow-step-in-progress {
        background-color: #FFFF8F77;
        padding: 8px;
        border-radius: 5px;
        margin-left: -5px;
      }
    </style>`;

    document.head.insertAdjacentHTML("beforeend", style);
  }

  async function addTargetsWhichChanged(pkgChanges, targetsWhichChangedVersions) {
    pkgChangesPerTargetInfo = await getChangesWithTargetsTimeDeployed(
      pkgChanges,
      targetsWhichChangedVersions);

    /**
     * NOTE: (enowell) We still display failed `targetTimeDeployed` fetching because the remaining information is
     * valuable to see on the `DiffPanel`. We don't cache it though so we can retry on the next run.
     */
    allFetchesSucceeded = pkgChangesPerTargetInfo.every(pkgChangeResponse => {
      pkgChangeResponse.targetsTimeDeployed;
    });


    return [pkgChangesPerTargetInfo, allFetchesSucceeded];
  }

  async function main() {
    await fetchHeatMapData()

    const targetsWhichChangedVersions = [];
    pipelineTargetsToMetadata.entries().forEach(([target, metadata]) => {
      const targetCacheKey = targetVersionsCache.getCacheKey(target);
      const cachedTargetVersionMetadata = targetVersionsCache.get(targetCacheKey);
      if (!cachedTargetVersionMetadata) {
        targetsWhichChangedVersions.push(target);
        return;
      }

      var { body: cachedTargetVersion } = cachedTargetVersionMetadata;

      if (cachedTargetVersion == metadata.version) {
        return;
      }
      targetsWhichChangedVersions.push(target);
    });

    highlightTests();

    var VFIs = VFIsList.filter(VFI => VFI.isValid);

    const thisAndNextVersionPairs = [...Array(VFIs.length).keys()].map(i => {
      let thisVersion = VFIs[i] ? VFIs[i].version : undefined;
      let nextVersion = VFIs[i + 1] ? VFIs[i + 1].version : undefined;
      VFIsMap[thisVersion].diffWith = nextVersion;
      VFIsMap[thisVersion].diffUrl = generateDiffUrl(thisVersion, nextVersion)
      VFIsMap[thisVersion].vsDiffUrl = generateVSDiffUrl(thisVersion, nextVersion)
      return [thisVersion, nextVersion];
    });

    const versionDiffPromises = thisAndNextVersionPairs.map(async ([thisVer, nextVer]) => {
      VFIsMap[thisVer].status = DiffFetchStatus.LOADING;
      const diffCacheKey = diffCache.getCacheKeyForVfiDiff(thisVer, nextVer);
      const cachedDiff = diffCache.get(diffCacheKey);

      try {
        var pkgChanges;
        if (cachedDiff) {
          var { errors, body: { changes } } = cachedDiff;
          VFIsMap[thisVer].errors = errors;

          if (targetsWhichChangedVersions.length == 0) {
            VFIsMap[thisVer].status = DiffFetchStatus.SUCCEEDED;
            VFIsMap[thisVer].changes = changes;
            return;
          }

          pkgChanges = changes;
        } else {
          pkgChangesFromDiffUrl = await getPkgChangesFromDiffUrl(thisVer, nextVer);
          pkgChangesFromDiffUrl.every(pkgChangeResponse => {
            if (!pkgChangeResponse) {
              VFIsMap[thisVer].status = DiffFetchStatus.FAILED;
              return false;
            }

            return true;
          });
          pkgChanges = pkgChangesFromDiffUrl.filter(pkgChangeResponse => pkgChangeResponse);
        }

        /**
         * NOTE: Disabling the targetsTimeDeployed feature because Pipelines is not ready to
         * handle all this traffic as the default behavior.
         *
         * See more:
         * https://t.corp.amazon.com/V1112834992
         */
        // [
        //   pkgChanges,
        //   VFIsMap[thisVer].status
        // ] = await addTargetsWhichChanged(pkgChanges, targetsWhichChangedVersions);

        /**
         * NOTE: (enowell) All async calls are done by this point. Everything we do below is in an effort to immediately
         * render what is available now instead of waiting for other requests which  may get stuck.
         */

        VFIsMap[thisVer].changes = pkgChanges;

        if (VFIsMap[thisVer].status === DiffFetchStatus.FAILED) {
          console.log(`Not caching version fetch. At least one package failed. version=${thisVer}`);
          return;
        }

        VFIsMap[thisVer].status = DiffFetchStatus.SUCCEEDED;

        // Clear the package diff caches now that the VFI diff was successful
        VFIsMap[thisVer].changes.forEach((change) => {
          if(change.cacheKey) diffCache.delete(change.cacheKey)
        });

        diffCache.set(diffCacheKey, VFIsMap[thisVer]);
        targetsWhichChangedVersions.forEach(target => {
          const targetCacheKey = targetVersionsCache.getCacheKey(target);
          targetVersionsCache.set(targetCacheKey, pipelineTargetsToMetadata.get(target).version);
        });
      } finally {
        addToGlobalListOfChanges(VFIsMap[thisVer].changes);
        tryRender();
      }
    });

    await fetchPromises(versionDiffPromises, VS_DIFF_FETCH_CONCURRENCY);

    diffCache.clean();
    targetVersionsCache.clean();

    console.table(state.stats)
  }

  main()
})();


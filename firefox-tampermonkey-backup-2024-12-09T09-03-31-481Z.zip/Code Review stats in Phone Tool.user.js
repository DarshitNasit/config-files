// ==UserScript==
// @name         Code Review stats in Phone Tool
// @namespace    https://w.amazon.com/index.php/User:Hunjamie
// @version      0.8
// @description  Display code review statistics in Phone Tool
// @author       hunjamie@
// @match        https://phonetool.amazon.com/users/*
// @run-at       document-end
// @grant        GM_xmlhttpRequest
// @grant        GM.xmlHttpRequest
// @grant        unsafeWindow
// @connect      code.amazon.com
// ==/UserScript==

(async function() {
    'use strict';
    var currentUser;
    if (unsafeWindow.PhoneTool && unsafeWindow.PhoneTool.targetUserLogin) {
        currentUser = unsafeWindow.PhoneTool.targetUserLogin;

        await injectInitialTable();

        let startTime = formatDate(addDays(new Date(), -365));
        let endTime = formatDate(new Date());

        parseMainStatistics(currentUser, startTime, endTime, true);
        parseAdditionalStatistics(currentUser, startTime, endTime, true, "year");
    }

    async function waiter(getter) {
        return new Promise((resolve, reject) => {
            let triesLeft = 20; // max tries
            (function doWait() {
                const element = getter();
                if(element !== undefined) {
                    resolve(element);
                } else if(triesLeft-- > 0) { //check we have tries left
                    setTimeout(doWait, 200);
                } else {
                    reject('unable to find object in dom');
                }
            })();
        });
    }

    function getHtml(url) {
        return new Promise(function(resolve, reject) {
            GM.xmlHttpRequest({
                method: 'GET',
                url: url,
                headers: { 'Accept': 'text/html' },
                onload: function (response) {
                    resolve(response.responseText);
                },
                onerror: function (response) {
                    reject(response.statusText);
                }
            });
        });
    }

    function parseMainStatistics(user, startTime, endTime, teamStatsAvailable) {

        let url = "https://code.amazon.com/users/" + currentUser + "/activity?sorted=&start_time=" + startTime + "&end_time=" + endTime;

        getHtml(url).then(function(data) {
            let span = document.createElement('span');
            span.innerHTML = data;

            if(!span.getElementsByClassName('change_time')[0]) {
                // This person has no CR stats and is probably not an engineer.
                document.getElementById('sde-stats').style.display = "none";
                return;
            }

            document.getElementById('sde-stats').style.display = "";

            let summaryText = span.getElementsByClassName('change_time')[0].innerText.split('since')[0].trim();

            let changesText = '<a href="https://code.amazon.com/reviews/from-user/' + currentUser + '?open=true&pending=true&shipped=true&start_time=' + startTime + '%2000:00:00%20+0000&end_time=' + endTime + '%2000:00:00%20+0000">' + summaryText.split('changes')[0] + " changes</a>";
            document.getElementById('sde-stats-changes').getElementsByClassName('TableValue')[0].innerHTML = changesText + (teamStatsAvailable ? ' / ? team avg' : '');

            let linesAddedText = summaryText.split(' lines added')[0].split('(')[1] + " lines added";
            document.getElementById('sde-stats-lines-added').getElementsByClassName('TableValue')[0].innerText = linesAddedText;

            let linesRemovedText = summaryText.split(' lines removed')[0].split(';')[1] + " lines removed";
            document.getElementById('sde-stats-lines-removed').getElementsByClassName('TableValue')[0].innerText = linesRemovedText;

            let packagesText = summaryText.split(' on ')[1].split('packages')[0] + " packages";
            document.getElementById('sde-stats-packages').getElementsByClassName('TableValue')[0].innerText = packagesText;
        });
    }

    function parseAdditionalStatistics(user, startTime, endTime, teamStatsAvailable, period) {
        let url = "https://code.amazon.com/users/" + user + "/activity-stats-cr.json?start_time=" + startTime + "&end_time=" + endTime;

        getHtml(url).then(function(data) {
            let span = document.createElement('span');
            span.innerHTML = data;

            let averageRevisionsText = span.getElementsByClassName('average_rev_user_div')[0].parentElement.parentElement.getElementsByTagName('td')[1].innerText;
            document.getElementById('sde-stats-avg-revision').getElementsByClassName('TableValue')[0].innerText = averageRevisionsText + (teamStatsAvailable ? ' / ? team avg' : '');

            let approvedByUserText = span.getElementsByClassName('approved_by_user_div')[0].parentElement.parentElement.getElementsByTagName('td')[1].innerText;
            document.getElementById('sde-stats-approved-cr').getElementsByClassName('TableValue')[0].innerText = approvedByUserText + (teamStatsAvailable ? ' / ? team avg' : '');

            let commentedByUserText = span.getElementsByClassName('commented_by_user_div')[0].parentElement.parentElement.getElementsByTagName('td')[1].innerText;
            document.getElementById('sde-stats-commented-cr').getElementsByClassName('TableValue')[0].innerText = commentedByUserText + (teamStatsAvailable ? ' / ? team avg' : '');

            if(teamStatsAvailable) {
                parseTeamStats(user, period);
            }
        });
    }

    function parseTeamStats(user, period) {
        let url = "https://code.amazon.com/cr_stats/team-view/" + user + "?time=" + period;

        getHtml(url).then(function(data) {
            var span = document.createElement('span');
            span.innerHTML = data;

            var teamAvgChanges = getAverageStatFromTable(span, "crux_creation_graph").toFixed(0);
            var changesEle = document.getElementById('sde-stats-changes').getElementsByClassName('TableValue')[0];
            changesEle.innerHTML = changesEle.innerHTML.replace("? team avg", teamAvgChanges + " team avg");

            var teamAvgRevisions = getAverageStatFromTable(span, "crux_revs_per_review_graph").toFixed(1);
            var revisionsEle = document.getElementById('sde-stats-avg-revision').getElementsByClassName('TableValue')[0];
            revisionsEle.innerText = revisionsEle.innerText.replace("? team avg", teamAvgRevisions + " team avg");

            var teamAvgComments = getAverageStatFromTable(span, "crux_commented_graph").toFixed(0);
            var commentsEle = document.getElementById('sde-stats-commented-cr').getElementsByClassName('TableValue')[0];
            commentsEle.innerText = commentsEle.innerText.replace("? team avg", teamAvgComments + " team avg");

            var teamAvgApproved = getAverageStatFromTable(span, "crux_approved_graph").toFixed(0);
            var approvedEle = document.getElementById('sde-stats-approved-cr').getElementsByClassName('TableValue')[0];
            approvedEle.innerText = approvedEle.innerText.replace("? team avg", teamAvgApproved + " team avg");
        });
    }

    function getAverageStatFromTable(span, elementName) {
        let revisionsTable = span.getElementsByClassName(elementName)[0].parentElement.getElementsByClassName("table")[0].getElementsByTagName("tr");
        var runningTotal = 0;
        var count = 0;

        for(var i = 0; i < revisionsTable.length; i++) {
            try {
                var val = parseFloat(revisionsTable[i].getElementsByTagName("td")[1].innerText);
                var fieldTitle = revisionsTable[i].getElementsByTagName("td")[0].innerText;
                if(val > 0 && !fieldTitle.includes("Total")) {
                    runningTotal += val;
                    count++;
                }
            } catch(e) {}
        }

        return runningTotal / count;
    }

    function blankStats(teamStatsAvailable, selectedEle) {
        document.getElementById('sde-stats-changes').getElementsByClassName('TableValue')[0].innerHTML = '? changes' + (teamStatsAvailable ? ' / ? team avg' : '');
        document.getElementById('sde-stats-lines-added').getElementsByClassName('TableValue')[0].innerText = '? lines added';
        document.getElementById('sde-stats-lines-removed').getElementsByClassName('TableValue')[0].innerText = '? lines removed';
        document.getElementById('sde-stats-packages').getElementsByClassName('TableValue')[0].innerText = '? packages';
        document.getElementById('sde-stats-avg-revision').getElementsByClassName('TableValue')[0].innerText = '? revisions' + (teamStatsAvailable ? ' / ? team avg' : '');
        document.getElementById('sde-stats-approved-cr').getElementsByClassName('TableValue')[0].innerText = '? CRs' + (teamStatsAvailable ? ' / ? team avg' : '');
        document.getElementById('sde-stats-commented-cr').getElementsByClassName('TableValue')[0].innerText = '? CRs' + (teamStatsAvailable ? ' / ? team avg' : '');

        document.getElementById('codeStatsAllTime').style.fontWeight = (selectedEle === 'codeStatsAllTime' ? 'bold' : 'normal');
        document.getElementById('codeStats12Month').style.fontWeight = (selectedEle === 'codeStats12Month' ? 'bold' : 'normal');
        document.getElementById('codeStats6Month').style.fontWeight = (selectedEle === 'codeStats6Month' ? 'bold' : 'normal');
        document.getElementById('codeStats1Month').style.fontWeight = (selectedEle === 'codeStats1Month' ? 'bold' : 'normal');
    }

    async function injectInitialTable() {
        var passionTable = await waiter(() => document.getElementsByClassName('SharePassion')[0]);

        passionTable.innerHTML += '<div class="sde-stats" style="padding-top:10px; display: none;"  id="sde-stats">  <h4 style="padding-bottom: 5px;">SDE Stats</h4>  <div class="UserDetailsTable">    <span class="optional-wrapper">      <div class="TableRow" id="sde-stats-changes">        <div class="TableProperty">Changes</div>        <div class="TableValue">? changes / ? team avg</div>      </div>      <div class="TableRow" id="sde-stats-lines-added">        <div class="TableProperty">Lines Added</div>        <div class="TableValue">? lines</div>      </div>      <div class="TableRow" id="sde-stats-lines-removed">        <div class="TableProperty">Lines Removed</div>        <div class="TableValue">? lines</div>      </div>      <div class="TableRow" id="sde-stats-packages">        <div class="TableProperty">Packages</div>        <div class="TableValue">? packages</div>      </div>      <div class="TableRow" id="sde-stats-avg-revision">        <div class="TableProperty">Average Revisions</div>        <div class="TableValue">? revisions / ? team avg</div>      </div>      <div class="TableRow" id="sde-stats-approved-cr">        <div class="TableProperty">Approved CRs</div>        <div class="TableValue">? CRs / ? team avg</div>      </div>      <div class="TableRow" id="sde-stats-commented-cr">        <div class="TableProperty">Commented CRs</div>        <div class="TableValue">? CRs / ? team avg</div>      </div>    </span> <span>Showing Data for: <a href="#" id="codeStatsAllTime">[All Time]</a> <a href="#" style="font-weight: bold;" id="codeStats12Month">[1 Year]</a> <a href="#" id="codeStats6Month">[6 Months]</a> <a href="#" id="codeStats1Month">[1 Month]</a></span>  </div></div>';

        document.getElementById('codeStatsAllTime').addEventListener('click', function() {
            blankStats(false, 'codeStatsAllTime');

            let startTime = "1995-01-01";
            let endTime = new Date().getFullYear() + "-12-31";

            parseMainStatistics(currentUser, startTime, endTime, false);
            parseAdditionalStatistics(currentUser, startTime, endTime, false);
        }, false);

        document.getElementById('codeStats12Month').addEventListener('click', function() {
            blankStats(true, 'codeStats12Month');

            let startTime = formatDate(addDays(new Date(), -365));
            let endTime = formatDate(new Date());

            parseMainStatistics(currentUser, startTime, endTime, true);
            parseAdditionalStatistics(currentUser, startTime, endTime, true, "year");
        }, false);

        document.getElementById('codeStats6Month').addEventListener('click', function() {
            blankStats(false, 'codeStats6Month');

            let startTime = formatDate(monthsAgo(6));
            let endTime = new Date().getFullYear() + "-12-31";

            parseMainStatistics(currentUser, startTime, endTime, false);
            parseAdditionalStatistics(currentUser, startTime, endTime, false);
        }, false);

        document.getElementById('codeStats1Month').addEventListener('click', function() {
            blankStats(true, 'codeStats1Month');

            let startTime = formatDate(monthsAgo(1));
            let endTime = new Date().getFullYear() + "-12-31";

            parseMainStatistics(currentUser, startTime, endTime, true);
            parseAdditionalStatistics(currentUser, startTime, endTime, true, "month");
        }, false);
    }

    function addDays(date, days) {
        var result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    }

    function monthsAgo(months) {
        var workingDate = new Date();
        workingDate.setMonth(workingDate.getMonth() - months);
        return workingDate;
    }

    function formatDate(date) {
        var month = '' + (date.getMonth() + 1);
        var day = '' + date.getDate();
        var year = date.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    }

})();
// ==UserScript==
// @name        Clean CRV Link
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/Clean_CRV_Link_In_Pipelines.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/Clean_CRV_Link_In_Pipelines.user.js
// @namespace   ducrou@amazon.com
// @description Cleans up the otherwise useless Code Review Verification and SIM Verification links in pipelines
// @include     https://pipelines.amazon.com/pipelines/*
// @version     1.1
// @grant       none
// ==/UserScript==

function cleanLinks(helpLink) {
  var link = document.evaluate(
              "//a[@href='" + helpLink + "']",
              document,
              null,
              XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
              null);

  if (link.snapshotLength > 0) {
    var changes = link.snapshotItem(0).innerHTML.match(/\b\w+\/\w+@\w+\b/g);
    var containerDiv = document.createElement('div');
    containerDiv.innerHTML += '<b>Offending Commits:</b><br/>';

    link.snapshotItem(0).parentNode.appendChild(containerDiv);
    link.snapshotItem(0).innerHTML='';

    for (var i = 0; i < changes.length; ++i) {
      var pkg = changes[i].substring(0,changes[i].indexOf('/'));
      var commit = changes[i].substring(changes[i].indexOf('@')+1);
      var link = 'https://code.amazon.com/packages/' + pkg + '/commits/' + commit;
      containerDiv.innerHTML += "<a href='" + link + "'>" + pkg + '</a><br/>';
    }
  }
}

helpLinks = [
  "https://w.amazon.com/index.php/CodeReviewVerification/Help",
  "https://w.amazon.com/index.php/SIMVerification/Help"
]

for each (helpLink in helpLinks) {
  cleanLinks(helpLink);
}

// ==UserScript==
// @name         Escalation timer
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Escalation timer for high sev.
// @author       https://phonetool.amazon.com/users/arunkar
// @match        https://t.corp.amazon.com/*
// @downloadURL  https://code.amazon.com/packages/ArunkarScripts/blobs/mainline/--/scripts/ticketing/EscalationTimerForSev2.user.js#?raw=1
// @updateURL    https://code.amazon.com/packages/ArunkarScripts/blobs/mainline/--/scripts/ticketing/EscalationTimerForSev2.user.js#?raw=1
// @require      https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js#sha256=c12f6098e641aaca96c60215800f18f5671039aecf812217fab3c0d152f6adb4
// @require      https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js#sha256=2979f9a6e32fc42c3e7406339ee9fe76b31d1b52059776a02b4a7fa6a4fd280a
// @require      https://cdnjs.cloudflare.com/ajax/libs/showdown/1.9.1/showdown.min.js#sha256=8e5d7e0ceb12b3db800532a9a4e276185f245e87375d0cc1b451724b48bd5e8a
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js#sha256=0aeb4ecf1091b9c52c9fa0ba4dc118b1abafbd88a51278935e574f6baff0bb49
// @resource     bootstrap.min.css https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css#sha256=eece6e0c65b7007ab0eb1b4998d36dafe381449525824349128efc3f86f4c91c
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_getResourceText
// @grant        GM.xmlHttpRequest
// @grant        GM_addStyle
// @grant        GM_openInTab
// ==/UserScript==

var debugEnabled = false;
var collectAnalytics = true;
var version = GM_info.script.version;
$("head").append("<style>" + GM_getResourceText("bootstrap.min.css") + "</style>");

GM_addStyle(`
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url('//internal-cdn.amazon.com/btk.amazon.com/ajax/libs/bootstrap/3.3.6/fonts/glyphicons-halflings-regular.eot');
  src: url('//internal-cdn.amazon.com/btk.amazon.com/ajax/libs/bootstrap/3.3.6/fonts/glyphicons-halflings-regular.eot?#iefix') format('embedded-opentype'),
       url('//internal-cdn.amazon.com/btk.amazon.com/ajax/libs/bootstrap/3.3.6/fonts/glyphicons-halflings-regular.woff2') format('woff2'),
       url('//internal-cdn.amazon.com/btk.amazon.com/ajax/libs/bootstrap/3.3.6/fonts/glyphicons-halflings-regular.woff') format('woff'),
       url('//internal-cdn.amazon.com/btk.amazon.com/ajax/libs/bootstrap/3.3.6/fonts/glyphicons-halflings-regular.ttf') format('truetype'),
       url('//internal-cdn.amazon.com/btk.amazon.com/ajax/libs/bootstrap/3.3.6/fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular') format('svg');
}

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font: normal normal 16px/1 'Glyphicons Halflings';
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  margin-right: 4px;
}
.popover {
    text-align: center
}
`);

var mutated = false;
var mutationObserver = new MutationObserver(function(mutations) {
    if ($('table > tbody > tr').length > 1 && !mutated) {
        debug("calling the main method");
        mutated = true;
        updateHomePage();
    } else if ($('table > tbody > tr').length <= 1) {
        mutated = false;
    }
});

var detailPageMutationObserver = new MutationObserver(function(mutations) {
    debug("seen mutation");
    let statusElement = $('.issue-summary-status .display-mode');
    let sevElement = $('issue-summary-severity .display-mode');
    if (statusElement && sevElement) {
        removeEscalationTimer();
        updateDp();
    }
});

function removeEscalationTimer() {
    // clear the escalation time if exist
    debug("clear the escalation time if exist");
    if (timer != null) {
        clearInterval(timer);
        timer = null;
    }

    const count_down_timer = document.querySelector("#count_down_timer");
    if (count_down_timer) {
        count_down_timer.parentNode.removeChild(count_down_timer)
    }
}


function updateDp() {
    addSIMMetrics();
    let status = $('.issue-summary-status .info-value')[0].innerText;
    let sev = $('.issue-summary-severity .info-value')[0].innerText;
    if (sev <= 2) {
        let ticketId = $('.ticket-id')[0].innerText;
        debug(ticketId);
        let issue = {
            id: ticketId,
            sev: sev,
            status: status
        }
        getEditsAndRender(issue, false)
    }
}

function observeMutation(selector) {
    debug("setting observer on " + selector)
    mutationObserver.observe(document.querySelector(selector), {childList: true, subtree: true});
}

function observeMutationDp(selector) {
    debug("setting dp observer on " + selector)
    detailPageMutationObserver.observe(document.querySelector(selector), {attributes: true});
}

function waitForElementToDisplay(selector, callback, checkFrequencyInMs, timeoutInMs) {
  var startTimeInMs = Date.now();
  (function loopSearch() {
    if (document.querySelector(selector) != null) {
      callback(selector);
      return;
    } else {
      setTimeout(function () {
          if (timeoutInMs && Date.now() - startTimeInMs > timeoutInMs) {
              return;
          }
          loopSearch();
      }, checkFrequencyInMs);
    }
  })();
}


function updateHomePage() {
    addSIMMetrics();
    var table = Array.from(document.querySelector("#sim-issueListContent > div.awsui_content_14iqq_1yx34_27.awsui_content-no-paddings_14iqq_1yx34_27.awsui_content-has-header_14iqq_1yx34_30 > div > div.awsui_wrapper_wih1l_ou0be_46 > table > tbody").querySelectorAll('tr'))
    var ticketData = []
    for (var i = 0; i < table.length; i++) {
        var cols = table[i].querySelectorAll('td');
        let val = {
            sev: cols[1].innerText,
            id: cols[2].innerText,
            status: cols[4].innerText
        }
        ticketData.push(val);
    }
    debug(ticketData);
    filterAndOrchestrate(ticketData);
}

function filterAndOrchestrate(issues) {
    for (let i = 0; i < issues.length; i++) {
        if (issues[i].sev <=2) {
            getEditsAndRender(issues[i], true);
        }
    }
}

function getEditsAndRender(issue, renderOnHome) {
    let gmReq = GM.xmlHttpRequest;
    gmReq({
        method: "GET",
        url: "https://maxis-service-prod-pdx.amazon.com/issues/" + issue.id + "/edits",
        onload: function wrapper(editResponse) {updateEscalationTime(editResponse, issue, renderOnHome);},
        onerror: function wrapper(editResponse) {updateEscalationTime(editResponse, issue, renderOnHome);}
    });
}

const TICKET_STATUS_TO_ESCALATION_MINUTES = {
    'Assigned': 30,
    'Researching': 90,
    'Work In Progress': 480, // 8 hours
    'Work in Progress': 480, // 8 hours
    'Pending': 10080 // 1 week
}

var shortIdIndex = 2;
var titleIndex = shortIdIndex + 1;

function updateEscalationTime(editresponse, issue, renderOnHome) {
    let jsonResponse = JSON.parse(editresponse.responseText);
    let statusUpdates = parseEdits(jsonResponse.edits);
    debug(statusUpdates);
    let statusChanges = statusUpdates.auditTrailStatusChanges.sort((a, b) => b.createDate - a.createDate); //Sort in descending order i.e with latest on the top
    let currentStatus = issue.status;
    debug(currentStatus, "CurrentStatus");
    if (TICKET_STATUS_TO_ESCALATION_MINUTES[currentStatus] == null) {
        debug("Couldn't find the status. The ticket could be resolved");
        return;
    }
    let lastStatus = null;
    //Pick the farthest status. This is to avoid multipe same status changes at once. i.e pending to pending change
    for (let i = 0; i < statusChanges.length; i++) {
        if (lastStatus == null) {
            lastStatus = statusChanges[i];
        } else if (lastStatus.datum == statusChanges[i].datum){
            lastStatus = statusChanges[i];
        } else {
            break;
        }
    }
    debug(lastStatus);
    let lastStatusChangeTime = moment(lastStatus.createDate);
    debug(lastStatusChangeTime);
    let escalationTime = lastStatusChangeTime.add(TICKET_STATUS_TO_ESCALATION_MINUTES[currentStatus], 'm');
    debug(escalationTime);
    let minutesUntilEscalation = escalationTime.diff(moment(), 'minutes');
    debug(minutesUntilEscalation);
    if (renderOnHome) {
        renderInHomePage(issue, minutesUntilEscalation, escalationTime)
    } else {
        renderInDp(issue, minutesUntilEscalation, escalationTime)
    }
}

function renderInHomePage(issue, minutesUntilEscalation, escalationTime) {
    debug(issue)
    let query = "[data-sid=" + issue.id + "]";
    debug(query);
    let twoDaysInMins = 1440 * 2;
    if (minutesUntilEscalation <= twoDaysInMins) {
       var opacity = (twoDaysInMins - minutesUntilEscalation) / twoDaysInMins;
       debug(opacity, "opacity");
       $(query)[0].closest('tr').style.backgroundColor = 'rgba(255, 107, 107, ' + opacity + ')';
    }
    $(query)[0].closest('tr').children[titleIndex].children[0].innerHTML = $(query)[0].closest('tr').children[titleIndex].children[0].innerHTML + '<span style="margin-left: 5px;" class="glyphicon glyphicon-time" data-toggle="popover-' + issue.id + '" data-content="Ticket will escalate ' + escalationTime.fromNow() + '"></span>';
    let popoverquery = "[data-toggle=popover-" + issue.id + "]"
    $(popoverquery).popover(
        {
            trigger: "manual",
            html: true,
            animation: true,
            placement: 'right',
            container: $(query)[0].closest('tr'),
            title: "Escalation time"
        }
    ).on("click", function(event) {
        debug(event)
        $('.popover').popover('hide');
        var _this = this;
        debug(this)
        $(this).popover('show');
        debug('showing');
    })
}

function createCountDownElement() {
    var countDown = document.createElement("p");
    countDown.id = "count_down_timer";
    document.querySelector(".issue-detail-content").before(countDown);
    return countDown;
}

function getNumberAsTwoDigits(number) {
    if (number < 10) {
        return "0" + number.toString();
    }

    return number.toString();
}

String.prototype.format = function () {
    var content = this;
    for (var i = 0; i < arguments.length; i++) {
        var replacement = '{' + i + '}';
        content = content.replace(replacement, arguments[i]);
    }
    return content;
};


var TIME_REMAINING_DIV = '<div style="margin: 0 auto 0 auto; margin-bottom: 5px; font-size: 24px; text-align: center; background-color: #ffffff; color: #ff0000;"><p> Time to escalation: {0} days {1} hours {2} minutes {3} seconds</p></div>';

function updateTimer(countDown, days, hours, mins, sec) {
    if (days == 0 && hours == 0 && mins ==0 && sec == 0) {
        countDown.innerHTML = '<div style="margin: 0 auto 0 auto; margin-bottom: 5px; font-size: 24px; text-align: center; background-color: #ffffff; color: #ff0000;"><p>Escalating</p></div>';;
        return false;
    }
    countDown.innerHTML = TIME_REMAINING_DIV.format(days, hours, mins, sec);
    return true;
}


var timer;
function renderInDp(issue, minutesUntilEscalation, escalationTime) {
    removeEscalationTimer();
    let countDown = createCountDownElement();
    let days = Math.floor((minutesUntilEscalation / 60 / 24));
    let hours = Math.floor(((minutesUntilEscalation - (days * 60 * 24)) / 60));
    let mins = Math.floor((minutesUntilEscalation - (days * 60 * 24) - (hours * 60)))
    let sec = 59;
    function checkAndUpdateTimer() {
        if(updateTimer(countDown, days, hours, mins, sec)) {
            sec--;
            if (sec < 0) {
                sec = 59;
                mins--;
            }
            if (mins < 0) {
                mins = 59;
                hours--;
            }
            if (hours < 0) {
                hours = 23;
                days = 0;
            }
            if (days < 0) {
                days = 0;
                hours = 0;
                mins = 0;
                sec =0;
            }
        }
    }

    checkAndUpdateTimer();
    timer = setInterval(checkAndUpdateTimer, 1000);
}


function debug(value) {
    if (debugEnabled) {
        if (arguments.length > 1) {
            console.log(arguments[1] + " : " + JSON.stringify(value));
        } else {
            console.log(value);
        }
    }
}

function parseEdits(edits) {
    let parsedData = {
        auditTrailStatusChanges: [],
        severityChanges: [],
        resolverGroupChanges: []
    }
    for (let i = 0; i < edits.length; i++) {
        let edit = edits[i];
        // Always include the first audit trail entry so we show when the ticket started
        if (i === 0 && edit.pathEdits.length > 0) {
            let pathEdit = edit.pathEdits[0];
            if (pathEdit.hasOwnProperty('data')) {
                let data = pathEdit.data;
                if (data.hasOwnProperty('extensions') && data.extensions.hasOwnProperty('tt')) {
                    let createDate = new Date(edit.actualCreateDate);
                    parsedData.auditTrailStatusChanges.push({
                        datum: 'Assigned',
                        createDate
                    });
                    parsedData.severityChanges.push({
                        datum: data.extensions.tt.impact + "",
                        createDate
                    });
                    parsedData.resolverGroupChanges.push({
                        datum: data.extensions.tt.assignedGroup,
                        createDate
                    });
                }
            }
        }
        for (let j = 0; j < edit.pathEdits.length; j++) {
            let pathEdit = edit.pathEdits[j];
            // Status
            if (pathEdit.hasOwnProperty('data')) {
                let pathEditData = pathEdit.data;
                if (typeof pathEditData === 'object') {
                    if (pathEditData.hasOwnProperty('action') && pathEditData.hasOwnProperty('owner')) {
                        let datum;
                        if (pathEditData.action === 'Comment') {
                            datum = 'Assigned';
                        } else if (pathEditData.action === 'Research') {
                            console.log(pathEditData);
                            datum = 'Researching';
                        } else if (pathEditData.action === 'Implementation') { // Implementation can either be actual 'Implementation' or 'Pending'
                            if (pathEditData.hasOwnProperty('exceptions') && pathEditData.exceptions.length != 0) {
                                datum = 'Pending';
                            } else {
                                datum = 'Work In Progress';
                            }
                        } else {
                            console.log(pathEditData);
                            datum = pathEditData.action;
                        }
                        let auditTrailChange = {
                            datum,
                            createDate: new Date(edit.actualCreateDate)
                        };
                        parsedData.auditTrailStatusChanges.push(auditTrailChange);
                    }
                }
            }
            // Resolved status is different
            if (pathEdit.hasOwnProperty('path') && pathEdit.path === '/status' && pathEdit.hasOwnProperty('data') && pathEdit.data === 'Resolved') {
                let auditTrailChange = {
                    datum: 'Resolved',
                    createDate: new Date(edit.actualCreateDate)
                };
                parsedData.auditTrailStatusChanges.push(auditTrailChange);
            }
            // Severity
            if (pathEdit.hasOwnProperty('path') && pathEdit.path === '/extensions/tt/impact') {
                let severityChange = {
                    datum: pathEdit.data + "",
                    createDate: new Date(edit.actualCreateDate)
                };
                parsedData.severityChanges.push(severityChange);
            }
            // Group
            if (pathEdit.hasOwnProperty('path') && pathEdit.path === '/extensions/tt/assignedGroup') {
                let groupChange = {
                    datum: pathEdit.data,
                    createDate: new Date(edit.actualCreateDate)
                };
                parsedData.resolverGroupChanges.push(groupChange);
            }
        }
    }
    return parsedData;
}

function addSIMMetrics(){
    if(collectAnalytics){
        var userName = document.querySelector('.sim-navDropdown--user').innerText.slice((document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf('(')+1), (document.querySelector('.sim-navDropdown--user').innerText.lastIndexOf(')')));
        var attributes = "&login=" + userName + "&version=" + version ;
        // Due to CSP, this needs to be done in a get request now.
        GM.xmlHttpRequest({
            method: "GET",
            url: "https://0s62bmu3aj.execute-api.us-east-1.amazonaws.com/PROD/pixel/tracker?PixelID=7b0357b4-cc69-1b4e-2bb5-2d6dd7b3b232" + attributes,
            headers: {
                "Content-Type": "application/json",
                "Origin": "https://t.corp.amazon.com"
            },
            onload: function (response) {
                console.log("Successfully pinged metric point.");
            },
            onerror: function (response) {
                console.log('Failed to ping metric point.');
                console.log(response);
            }
        });
    }
}

let resourceConfig = {
    updates : {
        sourceLocation : "https://code.amazon.com/packages/ArunkarScripts/blobs/mainline/--/scripts/ticketing/EscalationTimerForSev2.user.js#?raw=1",
        downloadLocation : "https://code.amazon.com/packages/ArunkarScripts/blobs/mainline/--/scripts/ticketing/EscalationTimerForSev2.user.js?download=1",
        firefoxExtension : "#.user.js",
        checkFrequency : 1800000, // Check for updates every 30 minutes
        remoteVersion : "",
        localVersion : GM_info.script.version
    },
};


function checkForUpdate(result) {
    // Update local version
    resourceConfig.updates.localVersion = GM_info.script.version;
    debug(resourceConfig.updates.localVersion, "local version");
    if (result) {
        // Handle response and determine if we need to update the script
        let version_text = '' + /\@version\s+[\d|\.]+/.exec(result.responseText);
        console.log(version_text);
        resourceConfig.updates.remoteVersion = version_text.replace(/\s+/g, ' ').split(' ')[1];

        // Only update last time checked if we receive a valid response
        GM_setValue('EscalationTimer', new Date().getTime() + '');
        // Update new remote version so we can display the button again if the user does not update immediately
        GM_setValue('EscalationTimer_remote_version', resourceConfig.updates.remoteVersion);

        console.log("Remote version is " + resourceConfig.updates.remoteVersion);
        console.log("Local version is " + resourceConfig.updates.localVersion);

        if (ltVersion(resourceConfig.updates.localVersion, resourceConfig.updates.remoteVersion)) {
            console.log("An update is available");
            getUpdate();
        } else {
            console.log("No update available");
        }
    } else {
        console.log("Checking for update...");

        // Request the remote version to see if we need to update
        let last_update = parseInt(GM_getValue('EscalationTimer', '0'));
        debug(last_update);
        resourceConfig.updates.remoteVersion = GM_getValue('EscalationTimer_remote_version', '0');

        debug(resourceConfig.updates.remoteVersion, "remote version");

        // If the last fetched remote version is still bigger the user needs to update, this might be because they didn't update the last time we checked
        if (ltVersion(resourceConfig.updates.localVersion, resourceConfig.updates.remoteVersion)) {
            console.log("Update available, but user still hasn't chosen to update");
            getUpdate();
        } else if ((last_update + resourceConfig.updates.checkFrequency) <= (new Date().getTime())) {
            console.log("Checking " + resourceConfig.updates.sourceLocation + " for updated version");
            let gmReq = GM.xmlHttpRequest;
            gmReq({
                method: "GET",
                url: resourceConfig.updates.sourceLocation,
                onload: checkForUpdate,
                onerror: checkForUpdate
            });
        } else {
            console.log("Did not check for update. Last update was at " + new Date(last_update));
        }
    }
}

function compareVersionNumbers(v1, v2) {
    let i, cmp, len, re = /(\.0)+[^\.]*$/;
    v1 = (v1 + '').replace(re, '').split('.');
    v2 = (v2 + '').replace(re, '').split('.');
    len = Math.min(v1.length, v2.length);
    for (i = 0; i < len; i++) {
        cmp = parseInt(v1[i], 10) - parseInt(v2[i], 10);
        if (cmp !== 0) {
            return cmp;
        }
    }
    return v1.length - v2.length;
}

function ltVersion(v1, v2) {
    return compareVersionNumbers(v1, v2) < 0;
}

function getUpdate() {
    // Firefox 1.0+
    let isFirefox = typeof InstallTrigger !== 'undefined';
    // Chrome 1+
    //var isChrome = !!window.chrome && !!window.chrome.webstore;

    let downloadLocation = resourceConfig.updates.downloadLocation;
    if (isFirefox) {
        downloadLocation += resourceConfig.updates.firefoxExtension;
    }
    GM_openInTab(downloadLocation);
}


checkForUpdate()

waitForElementToDisplay("#sim-content", observeMutation, 1000, 10000);
waitForElementToDisplay(".issue-summary-severity .display-mode", updateDp, 1000, 10000);
waitForElementToDisplay(".issue-summary-status .display-mode", observeMutationDp, 1000, 10000);
waitForElementToDisplay(".issue-summary-severity .display-mode", observeMutationDp, 1000, 10000);

$('body').on('click', function (e) {
    if ($(e.target).data('toggle') == null || !$(e.target).data('toggle').includes('popover')) {
        $('.popover').popover('hide');
    }
});
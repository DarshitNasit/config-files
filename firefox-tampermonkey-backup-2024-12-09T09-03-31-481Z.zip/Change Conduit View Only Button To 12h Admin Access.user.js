// ==UserScript==
// @name         Change Conduit View Only Button To 12h Admin Access
// @namespace    com.amazon.alegaz
// @version      1.5
// @description  Adds a '12h admin access' button on the Conduit Account List. Supports filtering, reordering, and multiple pages. No dependencies.
// @author       Sascha Vincent Kurowski <skkurows@amazon.com> and Nathan Morrissey <natmrri@amazon.com> and Alexis Gaziello <alegaz@amazon.com>
// @match        https://conduit.security.a2z.com/accounts/*
// @match        https://conduit.security.a2z.com/accounts
// @grant        none
// @icon         https://conduit.security.a2z.com/Conduit_JustTheBears.svg
// ==/UserScript==

(function() {
    'use strict';

    const changeDurationAndAccessMode = function(el) {
        "use strict";
        if (el.nodeName === 'A' && el.href !== undefined && el.href.includes("console")) {
            const url = new URL(el.href);
            const newSearchParams = new URLSearchParams(url.searchParams);
            let updated = false;

            if (newSearchParams.get("sessionDuration") !== "43200") {
                newSearchParams.set("sessionDuration", "43200");
                updated = true;
            }

            if (newSearchParams.get("policy") !== "arn:aws:iam::aws:policy/AdministratorAccess") {
                newSearchParams.set("policy", "arn:aws:iam::aws:policy/AdministratorAccess");
                updated = true;
            }

            const adminLink = document.createElement('a');
            adminLink.classList.add('awsui-button', 'awsui-button-variant-primary', 'awsui-hover-child-icons');
            adminLink.target = "_blank";
            adminLink.text = "12h Admin Console";

            if (updated) {
                // Work around bug in Conduit website which requires unencoded policy ARN
                const policy = newSearchParams.get("policy");
                newSearchParams.delete("policy");
                url.search = newSearchParams.toString() + "&policy=" + policy;
                adminLink.href = url.href;
            }

            if (el.text.includes("Read Only Access")) {
                const parentNode = el.parentNode;
                const new_link = el.href.replace("Duration=3600", "Duration=43200")

                if (parentNode.childNodes.length === 1) {

                    const el_copy = el.cloneNode()

                    el.style.display = 'none';

                    el_copy.text = "12h Read Console";
                    el_copy.href = new_link
                    parentNode.appendChild(el_copy);

                } else {
                    const existingLink = parentNode.getElementsByTagName('a')[1];
                    existingLink.href = new_link;
                }
            }

            if (el.text.includes("View Only Access")) {
                const parentNode = el.parentNode;

                if (parentNode.childNodes.length === 1) {
                    el.style.display = 'none';
                    parentNode.appendChild(adminLink);
                } else {
                    const existingLink = parentNode.getElementsByTagName('a')[1];
                    existingLink.href = adminLink.href;
                }
            }
        }
    };
    const callback = function(mutationsList, observer) {
        "use strict";
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(node => changeDurationAndAccessMode(node));
            } else if (mutation.type === 'attributes') {
                if (mutation.attributeName === 'href') {
                    changeDurationAndAccessMode(mutation.target);
                }
            }
        }
    };
    const observer = new MutationObserver(callback);
    document.querySelectorAll('awsui-table').forEach(node => observer.observe(node, { attributes: true, childList: true, subtree: true }));

    // Select all div elements within spans with class 'awsui-table-header-content'
    var spans = document.querySelectorAll('span.awsui-table-header-content span div');

    // Iterate over each div and replace the text content
    spans.forEach(function(div) {
        if (div.textContent.includes('View Only Access')) {
            div.textContent = 'Admin Access';
        }
    });
})();
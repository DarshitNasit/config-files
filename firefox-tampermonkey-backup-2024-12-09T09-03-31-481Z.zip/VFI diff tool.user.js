// ==UserScript==
// @name         VFI diff tool
// @namespace    https://pipelines.amazon.com/pipelines
// @version      1.5
// @description  A VFI diff tool to compare different boxes with single clicks. prerequisite: Pipelines Heatmap in Overview 1.15.2
// @author       shuojia@, (sangblee@, zijnie@ many thanks to them for debugging with me!!)
// @require      https://internal-cdn.amazon.com/btk.amazon.com/ajax/libs/jquery/2.1.4/jquery-2.1.4.js
// @require      https://internal-cdn.amazon.com/btk.amazon.com/ajax/libs/jquery/2.1.4/jquery-2.1.4.min.js
// @require      https://gist.github.com/raw/2625891/waitForKeyElements.js
// @require      https://cdnjs.cloudflare.com/ajax/libs/mithril/2.0.4/mithril.min.js
// @updateURL    https://drive.corp.amazon.com/view/shuojia@/public/VFIDiff.user.js
// @downloadURL  https://drive.corp.amazon.com/view/shuojia@/public/VFIDiff.user.js
// @icon         https://www.google.com/s2/favicons?domain=amazon.com
// @include      /^https://pipelines.amazon.com\/pipelines\/[\w-]+\/?$/
// @run-at       document-idle
// ==/UserScript==

var flag = true;
var clickCache = {
  firstClick: null,
  secondClick: null,
};

var firstColor = "#fe2d00";
var secondColor = "#080cfe";

function setStyles() {
  var styles = document.createElement("style");
  document.head.appendChild(styles);

  var rules = [
    `.diff-box { position: fixed; bottom: 0; left: 0; background-color: #f7efef; width: 100px; height: 145px; border: 1px solid #060502; display: none}`,
    `.diff-box-title {display:flex; flex-direction: column; margin-top: 5%}`,
    `.diff-box-content {display:flex; flex-direction: column; margin-top: 20%}`,
    `.diff-box-entry {position: fixed; bottom: 0; left: 0; }`,
    `#start-button {width: 100px !important; }`,
  ];

  rules.forEach((rule) => {
    styles.sheet.insertRule(rule);
  });
}

function switchFlag() {
  return !flag;
}

function createButton() {
  return [
    m("div", { class: "diff-box-title" }, [m("h4", "VFI diff tool")]),
    m("div", { class: "diff-box-content" }, [
      m("input", { type: "text", id: "new-vfi", value: "new version" }),
      m("input", { type: "text", id: "old-vfi", value: "old version" }),
      m(
        "button",
        {
          class: "btn",
          id: "diff-button",
          onclick: function () {
            diffVFI();
          },
        },
        "diff"
      ),
      m(
        "button",
        {
          class: "btn",
          id: "hide-button",
          onclick: function () {
            hideTool();
          },
        },
        "hide tool"
      ),
    ]),
  ];
}

function diffVFI() {
  var target = document
    .querySelector(".heat-map-box.heat-map-color-0")
    .querySelector("a")
    .text.split("@")[0];
  var newVFI = document.querySelector("input#new-vfi").value;
  var oldVFI = document.querySelector("input#old-vfi").value;
  window.open(
    `https://pipelines.amazon.com/diff?new_name=${target}&new_revision=${newVFI}&new_type=VS&old_name=${target}&old_revision=${oldVFI}&old_type=VS&requestedBy=embeddedHeatmap1.15.2`
  );
}

function hideTool() {
  document.querySelector("div.diff-box").style.display = "none";
  document.querySelector("div.diff-box-entry").style.display = "block";
  document.querySelectorAll(".heat-map-box.has-diff").forEach((element) => {
    element.onclick = null;
  });
  for (let key in clickCache) {
    removeBorder(clickCache[key]);
    clickCache[key] = null;
  }
}

function getId(element) {
  return element.querySelector("div.name") === null
    ? element.querySelector("a").href.split("@")[1]
    : element.querySelector("div.name").getAttribute("data-vsr").split("@B")[1];
}

function setBorder(element, color) {
  element.style.border = `thick dashed ${color}`;
}

function removeBorder(element) {
  if (element === null) return;
  element.style.border = null;
}

function showTool() {
  flag = true;
  document.querySelector("input#new-vfi").value = "new version";
  document.querySelector("input#old-vfi").value = "old version";
  document.querySelector("div.diff-box").style.display = "block";
  document.querySelector("div.diff-box-entry").style.display = "none";
  document.querySelectorAll(".heat-map-box.has-diff").forEach((element) => {
    element.onclick = function () {
      if (flag) {
        removeBorder(clickCache.firstClick);
        innerElement = document.getElementById("new-vfi");
        innerElement.value = getId(element);
        setBorder(element, firstColor);
        innerElement.style.color = firstColor;
        clickCache.firstClick = element;
      } else {
        removeBorder(clickCache.secondClick);
        innerElement = document.getElementById("old-vfi");
        innerElement.value = getId(element);
        setBorder(element, secondColor);
        innerElement.style.color = secondColor;
        clickCache.secondClick = element;
      }
      flag = switchFlag();
    };
  });
}

(function () {
  setStyles();
  var container = document.createElement("div");
  container.classList.add("diff-box");

  var entry = document.createElement("div");
  entry.classList.add("diff-box-entry");
  container.setAttribute("id", "vfi-diff");
  var root = document.querySelector("body.pipelines.show");
  m.render(container, createButton());
  root.appendChild(container);
  root.appendChild(entry);
  m.render(entry, [
    m(
      "button",
      {
        class: "btn",
        id: "start-button",
        onclick: function () {
          showTool();
        },
      },
      "VFI diff tool"
    ),
  ]);
})();

// ==UserScript==
// @name         Phonetool Availability Indicator
// @version      1.8
// @description  Displays the availability of someone based on their Outlook calendar
// @author       @tvaroht
// @match        *://phonetool.amazon.com/users/*
// @grant        GM.xmlHttpRequest
// @require      https://drive.corp.amazon.com/view/tvaroht@/public/userscripts/phonetool_availability_indicator/lib/jquery-3.5.1.min.js
// ==/UserScript==

/////////////////////////////////////////////////////////////////////

// REVISION HISTORY:

// 1.8 - 2022-04-18 - tvaroht@ - Fixed the issue with document-idle timer.
// 1.7 - 2022-02-16 - tvaroht@ - Using a local version of JQuery within Amazon's network to comply with InfoSec.
// 1.6 - 2021-08-20 - tvaroht@ - Fixed the Outside of Work Hours time zone issue.
// 1.5 - 2021-08-19 - tvaroht@ - Polishing the code, adding comments and some minor changes, waiting for the personal info to load first.
// 1.4 - 2021-08-19 - tvaroht@ - Waiting for the org chart to load before populating availability. Fixing outside of work hours for employees with no work hours set.
// 1.3 - 2021-08-18 - tvaroht@ - Added availability indicator to the org chart.
// 1.2 - 2021-08-17 - tvaroht@ - Added more error-handling for HTTP requests.
// 1.1 - 2021-08-16 - tvaroht@ - Added error protection and info about signing into ballard.amazon.com/owa/service.svc for the first time.
// 1.0 - 2021-08-13 - tvaroht@ - Created the first version of the tool (showing Busy/Tentative/Free/OOTO/Outside of Work Hours).

/////////////////////////////////////////////////////////////////////

(function() {
    'use strict';

    // -------------------------------------------------------------------------
    // GENERIC HTTP REQUEST

    function http_request(url, method, headers="", data=""){

        return new Promise((resolve, reject) => {

            GM.xmlHttpRequest({
                url: url,
                method: method,
                headers: headers,
                data: data,
                onload: (response) => {

                    // Once we receive a response

                    try {
                        resolve(response);
                    }

                    // Error parsing the response

                    catch(e) {
                        reject("An error occured processing response: ", e, response);
                    }
                },

                // Error connecting to the tech survey API

                onerror: function(response) {
                    reject("An error occured connecting to the " + url + ": ", response);
                }
            });
        });
    }

    // -------------------------------------------------------------------------
    // GET LOGIN OF THE PHONETOOL USER

    function get_login(){
        return JSON.parse($("div[data-react-class='UserDetails']").attr("data-react-props")).targetUser.targetUserLogin;
    }

    // -------------------------------------------------------------------------
    // WAITS FOR AN ELEMENT TO GET LOADED (VIA AJAX)

    function wait_for_element(element, callback, attempt_counter=0, attempt_counter_max=100){
        if($(element).length >= 1){
            callback();
        }
        else{
            if(attempt_counter >= attempt_counter_max){
                return false;
            }
            else{
                setTimeout(function(){
                    wait_for_element(element, callback, attempt_counter + 1);
                }, 100);
            }
        }
    }

    // -------------------------------------------------------------------------
    // GET LOGIN OF THE PHONETOOL USER

    async function get_cookie(attempt_counter=0){

        const cookie_response = await http_request("https://ballard.amazon.com/owa/service.svc", "POST");
        const cookie_match = cookie_response.responseHeaders.match(/x-owa-canary=(.*?);/i);

        if(cookie_match){
            return cookie_match[1];
        }
        else{
            if(attempt_counter <= 2){
                return get_cookie(attempt_counter + 1);
            }
            else{
                return "";
            }
        }
    }

    // -------------------------------------------------------------------------
    // GET PERSON'S CURRENT AVAILABILITY STATUS

    async function get_status(start, end, cookie, employee_login){

        // Calling the Outlook API to get the Phonetool user's availability (and providing the cookie from above)

        const response = await http_request(
            "https://ballard.amazon.com/owa/service.svc",
            "POST",
            {
                "action": "GetUserAvailabilityInternal",
                "content-type": "application/json; charset=UTF-8",
                "x-owa-actionname": "GetUserAvailabilityInternal_FetchWorkingHours",
                "x-owa-canary": cookie
            },
            JSON.stringify({
                request: {
                    Header: {
                        RequestServerVersion: "Exchange2013",
                        TimeZoneContext: {
                            TimeZoneDefinition: {Id: "UTC"}
                        }
                    },
                    Body: {
                        MailboxDataArray: [{"Email": {"Address": employee_login + "@amazon.com"}}],
                        FreeBusyViewOptions: {
                            RequestedView: "Detailed",
                            TimeWindow: {"StartTime": start.toISOString(), "EndTime": end.toISOString()}
                        }
                    }
                }
            })
        );

        try{

            // Reading and parsing the response

            const response_text = JSON.parse(response.responseText);

            // Listing the status parameters (including priority) and setting the default

            const status_dict = {
                OOF: {phonetool_title: "Out of Office", color: "#9F3F9F", priority: 1},
                Busy: {phonetool_title: "Busy", color: "red", priority: 2},
                Tentative: {phonetool_title: "Tentative", color: "orange", priority: 3},
                OWH: {phonetool_title: "Outside of Work Hours", color: "gray", priority: 4},
                Free: {phonetool_title: "Free", color: "green", priority: 5}
            };

            let current_status = status_dict.Free;

            // Let's check if we're not outside of their business hours

            const work_start = response_text.Body.Responses[0].CalendarView.WorkingHours.WorkHoursStartTimeInMinutes;
            const work_end = response_text.Body.Responses[0].CalendarView.WorkingHours.WorkHoursEndTimeInMinutes;

            if(work_end > work_start){

                let current_time_in_minutes = 0;
                let inside_work_hours = false;

                for(let i=-1; i<=1; i++){

                    current_time_in_minutes = (start.getUTCHours() + i * 24) * 60 + start.getUTCMinutes();

                    if(current_time_in_minutes >= work_start && current_time_in_minutes <= work_end){
                        inside_work_hours = true;
                    }
                }

                if(inside_work_hours == false && status_dict.OWH.priority <= current_status.priority){
                    current_status = status_dict.OWH;
                };
            }

            // Looping through active meetings

            const item_list = response_text.Body.Responses[0].CalendarView.Items;
            for (let i = 0; i < item_list.length; i++) {

                // If the meeting is happening right now (and it's not "free")

                if(Date.parse(start) >= Date.parse(item_list[i].Start + "Z") && Date.parse(start) <= Date.parse(item_list[i].End + "Z") && item_list[i].FreeBusyType != "Free"){

                    // Checking if the priority of this meeting is higher than the current one if there's a conflict (OOTO > Busy > Tentative > OWH > Free)

                    if(status_dict[item_list[i].FreeBusyType].priority <= current_status.priority){
                        current_status = status_dict[item_list[i].FreeBusyType];
                    }
                }
            }

            return current_status;
        }
        catch{
            return "";
        }
    }

    // -------------------------------------------------------------------------
    // SCRIPT START

    const start = new Date();
    const end = new Date(start.getTime() + 30 * 60000);

    // Waiting for the personal info section to load

    wait_for_element(".PersonalInfoJobTitle", () => {

        // Initializing the CSS

        $(".PersonalInfoJobTitle").append("<span class='optional-wrapper'><div class='PersonalInfoAvailabilityStatus' style='padding-left: 10px;'><span id='availability_icon' style='width: 10px; height: 10px; border-radius: 50%; display: inline-block; background-color: gray;'></span><span id='availability_status' style='padding-left: 5px;'>Loading Availability</span></div></span>");

        // Loading the authentication cookie

        get_cookie().then((cookie) => {

            // Authentication error - can't load the OWA canary

            if(cookie == ""){
                $("#availability_status").html("Authentication failed. If you're using Greasemonkey, running the script in Tampermonkey might help.");
            }

            else{

                // Loading the Phonetool person's availability data

                get_status(start, end, cookie, get_login()).then((status) => {
                    if(status == ""){
                        $("#availability_status").html("Can't load availability data. Try signing in <a href='https://ballard.amazon.com/owa/service.svc'>here</a>.");
                    }
                    else{
                        $("#availability_status").html(status.phonetool_title);
                        $("#availability_icon").css("background-color", status.color);
                    }
                });

                // Waiting for the .org-chart-row to be populated by AJAX

                wait_for_element(".org-chart-row", () => {

                    // Looping through the org chart one by one

                    $('.org-chart-row').each(function(_, org_chart_row_object) {

                        // Parsing the user login from the org chart's photo and calling the get_status() function

                        get_status(start, end, cookie, org_chart_row_object.innerHTML.match(/https:\/\/internal-cdn.amazon.com\/badgephotos.amazon.com\/.uid=([\w]*)/)[1]).then((status_org_chart) => {
                            if(status_org_chart != ""){
                                org_chart_row_object
                                    .getElementsByClassName("user-information")[0]
                                    .getElementsByTagName("div")[0]
                                    .insertAdjacentHTML("afterBegin", "<span style='width: 6px; height: 6px; margin-right: 4px; border-radius: 50%; display: inline-block; background-color: " + status_org_chart.color + ";'></span>");
                            }
                        });
                    });
                });
            }
        });
    });
})();

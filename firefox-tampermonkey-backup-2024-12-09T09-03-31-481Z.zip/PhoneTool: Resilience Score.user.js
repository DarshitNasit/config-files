// ==UserScript==
// @name           PhoneTool: Resilience Score
// @version        0.1
// @downloadURL    https://axzile.corp.amazon.com/-/carthamus/download_script/PhoneTool_Resilience_Score.user.js
// @updateURL      https://axzile.corp.amazon.com/-/carthamus/download_script/PhoneTool_Resilience_Score.user.js
// @namespace      Amazon:Phone_Tool_Resilience_Score
// @description    Add resilience score on Phone tool page
// @author         resilience-reporting-platforms@
// @include        https://phonetool.amazon.com/*
// @connect        api.resilience-score.tools.amazon.dev
// @grant          GM_xmlhttpRequest
// ==/UserScript==

/*the downloadURL and updateURL in the metadata are for carthamus (for hosting) - should be changed if we go with different hosting method*/

(function () {
    const CURRENT_SCORE_VERSION = '0.5.0';
    const BASE_URL = 'https://api.resilience-score.tools.amazon.dev/high_latency'
    const NOT_AVAILABLE = 'N/A'

    const apiPaths = {
        LEADER_SCORE: '/leader/latest/',
        REPORTES_SCORE: '/reporters/latest/'
    }
    const filteringConstants = {
        SCORE_TIER_TYPE: "score_tier_type",
        SCORE_VERSION: "score_version"
    }

    const Tiers =  {
        ALL: "all",
        TIER_ONE: "tier-1",
        NON_TIER_ONE :  "non tier-1"
    }

    /*helper func to make API calls*/
    const ajax = (options) => {
        const xhrPromise = new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                onload: (response) => { resolve(response); },
                onerror: (response) => { reject(response); },
                ...options,
            });
        });

        return xhrPromise;
    };

    function buildURL(path, login, score_tier_type, score_version) {
        const url = new URL(BASE_URL)
        url.pathname += path + login
        url.searchParams.append(filteringConstants.SCORE_TIER_TYPE, score_tier_type)
        url.searchParams.append(filteringConstants.SCORE_VERSION, score_version)

        return url
    }

    async function processURL(targetURL) {
        const resp = await ajax({url: targetURL})

        return JSON.parse(resp.responseText)
    }

    /*function to get resilience score based on the user alias*/
    async function getResilienceScore (login, tier = Tiers.ALL, scoreVersion = CURRENT_SCORE_VERSION) {
        const leaderScoreURL = buildURL(apiPaths.LEADER_SCORE, login, tier, scoreVersion)

        return await processURL(leaderScoreURL)
    }

    /*function to get a user's manager and reporter resilience scores*/
    async function getReportersScore (login, tier = Tiers.ALL, scoreVersion = CURRENT_SCORE_VERSION) {
        const reportersScoreURL = buildURL(apiPaths.REPORTES_SCORE, login, tier, scoreVersion)

        return await processURL(reportersScoreURL)
    }

    function newLine(className, title, content) {
        let props = document.createElement('span');
        props.classList.add('optional-wrapper');
        props.innerHTML = `<div class='TableRow ${className}'>
                                <div class='TableProperty'>
                                    ${title}:
                                </div>
                                <div class='TableValue'>
                                    ${content}
                                </div>
                            </div>`;
        document.querySelector('.UserDetailsTable .dl-horizontal').before(props);
        return props.querySelector(':scope > div.TableRow > div.TableValue');
    }

    function createScoreText(resp, login, tier=Tiers.ALL) {
        if ( !resp || !login ) {
            return NOT_AVAILABLE
        }

        const score = resp.score ? `${resp.score.toFixed(2)} (max: ${resp.max_score}, rank: p${(resp.percentile_rank*100).toFixed(0)}, tier: ${tier})`: NOT_AVAILABLE;
        return (score === NOT_AVAILABLE) ? score : `<a href='https://resilience-score.tools.amazon.dev/dashboard/leader/overallscore?leader_login=${login}&tier=${tier}'>${score}</a>`
    }

    function getLogin(anchorTag) {
        const userLoginLink = anchorTag.getAttribute('href');
        return userLoginLink.split('/')[2]; /* Format => /users/alias/ */
    }

    /*function to handle org rows*/
    function processOrgChartRows(orgRows, reportersMap) {
        for(const target of orgRows) {
            if((target.tagName === 'DIV') && (target.classList.contains('org-chart-row'))) {
                const userinfo = target.querySelector('div.user-information');
                const userLogin = userinfo.querySelector('div');
                const targetPlace = userinfo.querySelector(":scope span.additional-attributes")
                const loginAlias = getLogin(userLogin.querySelector('a'));

                if(reportersMap[loginAlias] != null){
                    const scoreText = createScoreText(reportersMap[loginAlias], loginAlias);
                    if (scoreText !== NOT_AVAILABLE) {
                        const node = document.createElement('span');
                        node.innerHTML = ` Resilience Score: ${scoreText}`;
                        targetPlace.appendChild(node);
                    }
                }
            }
        }
    }

    function processUserPanel(userScore, login) {
        const scoreText = createScoreText(userScore, login);
        const ResScoreCell = newLine('ResScoreRow', 'Resilience Score', 'Loading...');
        ResScoreCell.innerHTML = scoreText;
    }

    function populateReportersMap(reportersScore, reportersMap) {
        let supervisor = '';
        for(let entry in reportersScore) {
            if(reportersMap[reportersScore[entry].login] == null) {
                reportersMap[reportersScore[entry].login] = reportersScore[entry]
            }
            if (reportersScore[entry].report_level === 'supervisor') {
                supervisor = reportersScore[entry].login
            }
        }
        return supervisor
    }

    function processOrgChart(reportersMap) {
        /*Display resilience score in the org chart*/
        const orgChart = document.documentElement.querySelector('div.org-chart');
        if(orgChart !== null) {
            /* Execute if already done*/
            const entries = orgChart.querySelectorAll(':scope div.org-chart-row');
            /*process all rows*/
            processOrgChartRows(entries, reportersMap);
        } else {
            console.error('Org Chart Userscript, unable to find the Org Chart Widget');
        }
    }
    async function getAndStoreReportersScore(login, reportersMap) {
        const reportersScore = await getReportersScore(login)

        /*Store in a map for easier access key: {alias}, value: {res score}*/
        return populateReportersMap(reportersScore, reportersMap)
    }
    async function displayResInfo() {
        /*Display resilience score in the user information panel*/
        const targetUser = JSON.parse(document.querySelector('div[data-react-class=UserDetails]').getAttribute('data-react-props')).targetUser;
        const login = targetUser.targetUserLogin;

        const reportersMap = {}

        const supervisor = await getAndStoreReportersScore(login, reportersMap)

        /*process for supervisor as well*/
        if (supervisor !== '') {
            await getAndStoreReportersScore(supervisor, reportersMap)
        }
        processUserPanel(reportersMap[login], login);

        processOrgChart(reportersMap)
    }
    window.addEventListener('load', displayResInfo);
})();
